import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.ReadablePartial readablePartial1 = null;
        int[] intArray2 = new int[] {};
        try {
            julianChronology0.validate(readablePartial1, intArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) ' ', 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) instant1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.halfdayOfDay();
        long long9 = julianChronology3.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        try {
            org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(100, (int) (short) 0, (int) (short) 100, (org.joda.time.Chronology) julianChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167391999903L) + "'", long9 == (-62167391999903L));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = julianChronology0.get(readablePeriod2, (long) (byte) 100, (-62167391999903L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        boolean boolean2 = julianChronology0.equals((java.lang.Object) (-1));
        try {
            long long8 = julianChronology0.getDateTimeMillis((long) '#', (int) 'a', (int) (short) 1, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4999999884d + "'", double1 == 2440587.4999999884d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField5 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) 10, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = instant0.toDateTimeISO();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.DateTime.Property property5 = dateTime3.property(dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        long long6 = julianChronology0.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        try {
            long long14 = julianChronology0.getDateTimeMillis((int) (byte) 0, (int) 'a', (int) (short) 100, (int) (short) 10, (int) (byte) 10, (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167391999903L) + "'", long6 == (-62167391999903L));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekOfWeekyear();
        try {
            long long10 = julianChronology0.getDateTimeMillis((int) (byte) -1, 0, 0, 941, (int) '4', 0, 941);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 941 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.halfdayOfDay();
        long long10 = julianChronology4.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DurationField durationField11 = julianChronology4.centuries();
        org.joda.time.DateTime dateTime12 = mutableDateTime3.toDateTime((org.joda.time.Chronology) julianChronology4);
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        try {
            org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) mutableDateTime3, readableDateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62167391999903L) + "'", long10 == (-62167391999903L));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
//        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "", 0);
//        int int7 = mutableDateTime3.getMinuteOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        java.lang.String str9 = mutableDateTime3.toString(dateTimeFormatter8);
//        java.lang.Appendable appendable10 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.LocalTime localTime13 = dateTimeFormatter11.parseLocalTime("2019-06-15T15");
//        try {
//            dateTimeFormatter8.printTo(appendable10, (org.joda.time.ReadablePartial) localTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 941 + "'", int7 == 941);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-W24-6" + "'", str9.equals("2019-W24-6"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(localTime13);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(10L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = mutableDateTime2.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
        int int4 = mutableDateTime3.getDayOfWeek();
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime3);
        boolean boolean7 = mutableDateTime3.isAfter((long) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31T16" + "'", str5.equals("1969-12-31T16"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = instant7.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime9.getZone();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((int) (short) 100, 941, (int) (short) 10, 0, (int) ' ', 0, (int) '#', dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 941 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[America/Los_Ang...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.halfdayOfDay();
        long long9 = julianChronology3.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DurationField durationField10 = julianChronology3.centuries();
        org.joda.time.DateTime dateTime11 = mutableDateTime2.toDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = instant12.toMutableDateTime(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = mutableDateTime14.getZone();
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) julianChronology3, dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.JulianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167391999903L) + "'", long9 == (-62167391999903L));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("BuddhistChronology[UTC]", 941, (int) (short) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 941 for BuddhistChronology[UTC] must be in the range [100,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = instant7.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime9.getZone();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((int) (short) 100, 2000, (int) (short) 100, 0, (int) '#', 0, (int) (byte) 100, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        java.lang.String str1 = localDate0.toString();
        try {
            java.lang.String str3 = localDate0.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1969-12-31" + "'", str1.equals("1969-12-31"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        try {
            long long6 = skipUndoDateTimeField3.set(10L, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for halfdayOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = instant5.toMutableDateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = mutableDateTime7.getZone();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((-1), (int) 'a', 3, (int) (byte) 0, 1, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        int[] intArray2 = new int[] { 6 };
        try {
            org.joda.time.Partial partial3 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 2, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            int int4 = mutableDateTime2.get(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) 'a', (int) (short) 10, 2, 4, 100, 2, 2000, (org.joda.time.Chronology) julianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology8);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "", 0);
        int int7 = mutableDateTime3.getMinuteOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.String str9 = mutableDateTime3.toString(dateTimeFormatter8);
        int int10 = mutableDateTime3.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 960 + "'", int7 == 960);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-W01-3" + "'", str9.equals("1970-W01-3"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(11L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) ' ', (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 320L + "'", long2 == 320L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
        int[] intArray9 = new int[] {};
        try {
            int[] intArray11 = skipUndoDateTimeField3.set((org.joda.time.ReadablePartial) localDate7, (int) (byte) 0, intArray9, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for halfdayOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AM" + "'", str6.equals("AM"));
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 10, (int) 'a', (int) (short) -1, 0, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        java.lang.String str1 = localDate0.toString();
        org.joda.time.LocalDate.Property property2 = localDate0.era();
        try {
            org.joda.time.LocalDate localDate4 = property2.addToCopy((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1969-12-31" + "'", str1.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 10, 1969, (int) (byte) 10, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        long long9 = skipUndoDateTimeField3.getDifferenceAsLong(0L, (long) (-1));
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate();
        java.lang.String str11 = localDate10.toString();
        int int12 = localDate10.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate10.era();
        org.joda.time.LocalDate localDate14 = property13.roundHalfCeilingCopy();
        int[] intArray19 = new int[] { 10, (short) 10, 3 };
        try {
            int[] intArray21 = skipUndoDateTimeField3.addWrapField((org.joda.time.ReadablePartial) localDate14, 1969, intArray19, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AM" + "'", str6.equals("AM"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969-12-31" + "'", str11.equals("1969-12-31"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(dateTimeZone1);
        org.joda.time.Instant instant5 = instant0.withDurationAdded((long) '#', (int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime6 = instant0.toMutableDateTimeISO();
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = mutableDateTime6.toString("1969-12-31T16", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 1);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate();
        java.lang.String str5 = localDate4.toString();
        int int6 = localDate4.getDayOfMonth();
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) localDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31" + "'", str5.equals("1969-12-31"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "", 0);
        int int7 = mutableDateTime3.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600010 + "'", int7 == 57600010);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
        java.lang.String str8 = localDate7.toString();
        int[] intArray13 = new int[] { 2000, '#', 2000 };
        try {
            int[] intArray15 = skipUndoDateTimeField3.add((org.joda.time.ReadablePartial) localDate7, 0, intArray13, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31" + "'", str8.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.DurationField durationField2 = buddhistChronology0.seconds();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField4 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
        java.lang.String str8 = skipUndoDateTimeField3.getAsText((long) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalTime localTime11 = dateTimeFormatter9.parseLocalTime("2019-06-15T15");
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) localTime11, (int) (short) 10, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AM" + "'", str8.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(localTime11);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        java.lang.String str1 = localDate0.toString();
        int int2 = localDate0.getDayOfMonth();
        org.joda.time.LocalDate.Property property3 = localDate0.era();
        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
        int int6 = property3.getMinimumValue();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1969-12-31" + "'", str1.equals("1969-12-31"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = instant0.toDateTimeISO();
        org.joda.time.Instant instant5 = instant0.withMillis(2000L);
        boolean boolean7 = instant0.isBefore((long) ' ');
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.LocalDateTime localDateTime2 = null;
        try {
            boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        java.lang.String str1 = localDate0.toString();
        org.joda.time.LocalDate.Property property2 = localDate0.era();
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime(dateTimeZone4);
        int int6 = mutableDateTime5.getDayOfWeek();
        try {
            long long7 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1969-12-31" + "'", str1.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        try {
            org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long5 = gJChronology0.getDateTimeMillis((int) (byte) 1, 10, 2000, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
        int int4 = mutableDateTime3.getDayOfWeek();
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime3);
        try {
            org.joda.time.DateTime dateTime7 = dateTimeFormatter0.parseDateTime("2019-W24-6");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-W24-6\" is malformed at \"W24-6\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31T16" + "'", str5.equals("1969-12-31T16"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime(dateTimeZone4);
        int int8 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "", 0);
        int int9 = mutableDateTime5.getMinuteOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.String str11 = mutableDateTime5.toString(dateTimeFormatter10);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime5, (int) (short) 1);
        try {
            org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 960 + "'", int9 == 960);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-W01-3" + "'", str11.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(gJChronology13);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        java.lang.String str1 = localDate0.toString();
        org.joda.time.LocalDate.Property property2 = localDate0.era();
        org.joda.time.LocalDate localDate4 = property2.addWrapFieldToCopy(0);
        try {
            int int6 = localDate4.getValue(941);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 941");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1969-12-31" + "'", str1.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime(dateTimeZone4);
        int int8 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "", 0);
        int int9 = mutableDateTime5.getMinuteOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.String str11 = mutableDateTime5.toString(dateTimeFormatter10);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime5, (int) (short) 1);
        try {
            org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (short) 0, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 960");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 960 + "'", int9 == 960);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-W01-3" + "'", str11.equals("1970-W01-3"));
        org.junit.Assert.assertNotNull(gJChronology13);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
        java.lang.String str7 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "JulianChronology[UTC]" + "'", str7.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        java.lang.String str1 = localDate0.toString();
        int int2 = localDate0.getDayOfMonth();
        org.joda.time.LocalDate.Property property3 = localDate0.era();
        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
        boolean boolean10 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate localDate12 = localDate9.withYear(6);
        int int13 = localDate9.getEra();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1969-12-31" + "'", str1.equals("1969-12-31"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.weeks();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType4, 6, (-1969));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        java.lang.String str1 = localDate0.toString();
        int int2 = localDate0.getDayOfMonth();
        org.joda.time.LocalDate.Property property3 = localDate0.era();
        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.LocalDate.Property property10 = localDate6.property(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1969-12-31" + "'", str1.equals("1969-12-31"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("2019-06-15T15");
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime(dateTimeZone4);
        org.joda.time.Instant instant8 = instant3.withDurationAdded((long) '#', (int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = instant3.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime10 = localTime2.toDateTime((org.joda.time.ReadableInstant) instant3);
        try {
            org.joda.time.DateTime dateTime15 = dateTime10.withTime((int) (byte) -1, (int) 'a', (int) (byte) 0, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.halfdayOfDay();
        long long12 = julianChronology6.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DurationField durationField13 = julianChronology6.centuries();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.Chronology chronology17 = julianChronology6.withZone(dateTimeZone15);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) (byte) -1, 0, 2, 1, (int) (short) -1, 100, dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62167391999903L) + "'", long12 == (-62167391999903L));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        try {
//            org.joda.time.LocalDate localDate8 = property3.setCopy("2019-06-15T15");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T15\" for era is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.Partial partial2 = new org.joda.time.Partial(dateTimeFieldType0, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long5 = julianChronology0.getDateTimeMillis((int) 'a', 57600010, (int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600010 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField4.getAsText(0, locale6);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalTime localTime12 = dateTimeFormatter10.parseLocalTime("2019-06-15T15");
        org.joda.time.DateTimeField[] dateTimeFieldArray13 = localTime12.getFields();
        int[] intArray20 = new int[] { (short) 10, 12, (byte) -1, (byte) 10, (short) -1 };
        int[] intArray22 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) localTime12, 0, intArray20, 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        boolean boolean25 = iSOChronology23.equals((java.lang.Object) dateTimeFormatter24);
        try {
            org.joda.time.Partial partial26 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray22, (org.joda.time.Chronology) iSOChronology23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AM" + "'", str7.equals("AM"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
        try {
            java.lang.String str2 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = instant2.plus(0L);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) instant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 35, 12, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField8 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, durationField2, dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("2019-W24-6");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-W24-6\" is malformed at \"19-W24-6\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = skipUndoDateTimeField3.getMinimumValue(readablePartial7);
        long long10 = skipUndoDateTimeField3.roundHalfEven((long) 4);
        int int12 = skipUndoDateTimeField3.getLeapAmount((long) 10);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField3, (int) (short) 0, (int) (byte) 1, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for halfdayOfDay must be in the range [1,960]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        org.joda.time.LocalDate.Property property2 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property2.addWrapFieldToCopy(0);
//        java.lang.String str5 = property2.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[era]" + "'", str5.equals("Property[era]"));
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.clockhourOfHalfday();
        int int6 = instant1.get(dateTimeField5);
        org.joda.time.Instant instant8 = instant1.withMillis(320L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(dateTimeZone1);
        org.joda.time.Chronology chronology3 = mutableDateTime2.getChronology();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            int int5 = mutableDateTime2.get(dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 1);
//        java.io.Writer writer3 = null;
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.MutableDateTime mutableDateTime6 = instant4.toMutableDateTime(dateTimeZone5);
//        int int7 = mutableDateTime6.getDayOfWeek();
//        try {
//            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) mutableDateTime6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "AM");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (-28800000));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.1666666665d + "'", double1 == 2440587.1666666665d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(0, 31, 0, 0, (int) (byte) -1, 6, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        try {
            org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1969-12-31");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1969-12-31' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 100, (int) (byte) -1, 35, 100, (-28800000), 31, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(dateTimeZone1);
        org.joda.time.Chronology chronology3 = mutableDateTime2.getChronology();
        int int4 = mutableDateTime2.getWeekyear();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(31, (-2019), (int) '4', 1969, 15, 941, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        long long6 = julianChronology0.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.monthOfYear();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, 0, (int) '#', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [35,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167391999903L) + "'", long6 == (-62167391999903L));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        org.joda.time.LocalDate.Property property2 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property2.addWrapFieldToCopy(0);
//        boolean boolean6 = property2.equals((java.lang.Object) 2000);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
//        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
//        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
//        org.joda.time.ReadablePartial readablePartial7 = null;
//        int int8 = skipUndoDateTimeField3.getMinimumValue(readablePartial7);
//        long long10 = skipUndoDateTimeField3.roundHalfEven((long) 4);
//        int int12 = skipUndoDateTimeField3.getLeapAmount((long) 10);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate();
//        java.lang.String str14 = localDate13.toString();
//        int int15 = localDate13.getDayOfMonth();
//        org.joda.time.LocalDate.Property property16 = localDate13.era();
//        org.joda.time.LocalDate localDate17 = property16.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField18 = property16.getLeapDurationField();
//        org.joda.time.LocalDate localDate19 = property16.roundFloorCopy();
//        int[] intArray25 = new int[] { '#', 100, (byte) 0, 3 };
//        try {
//            int[] intArray27 = skipUndoDateTimeField3.add((org.joda.time.ReadablePartial) localDate19, 19, intArray25, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-06-15" + "'", str14.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNull(durationField18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(intArray25);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(1969);
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.append(dateTimeParser5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        int int3 = dateTime2.getMillisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withField(dateTimeFieldType4, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
        org.joda.time.Instant instant6 = instant1.withDurationAdded((long) '#', (int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = instant1.toMutableDateTimeISO();
        try {
            org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime7, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        java.util.Locale locale7 = null;
        int int8 = skipUndoDateTimeField3.getMaximumTextLength(locale7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalTime localTime11 = dateTimeFormatter9.parseLocalTime("2019-06-15T15");
        org.joda.time.DateTimeField[] dateTimeFieldArray12 = localTime11.getFields();
        int[] intArray19 = new int[] { (short) 10, 12, (byte) -1, (byte) 10, (short) -1 };
        int[] intArray21 = skipUndoDateTimeField3.set((org.joda.time.ReadablePartial) localTime11, 0, intArray19, 0);
        int int22 = skipUndoDateTimeField3.getMinimumValue();
        java.util.Locale locale25 = null;
        try {
            long long26 = skipUndoDateTimeField3.set((long) 1, "2019-06-15", locale25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15\" for halfdayOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AM" + "'", str6.equals("AM"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(localTime11);
        org.junit.Assert.assertNotNull(dateTimeFieldArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(4, 0, 15, (int) '4', 4, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(100L, dateTimeZone1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 4);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.util.Date date0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(35, (int) 'a', (int) (byte) 10, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560638517177L + "'", long0 == 1560638517177L);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.Instant instant5 = new org.joda.time.Instant();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = instant5.toMutableDateTime(dateTimeZone6);
//        int int10 = dateTimeFormatter4.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "", 0);
//        int int11 = mutableDateTime7.getMinuteOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        java.lang.String str13 = mutableDateTime7.toString(dateTimeFormatter12);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7, (int) (short) 1);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) chronology1, (org.joda.time.Chronology) gJChronology15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 941 + "'", int11 == 941);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-W24-6" + "'", str13.equals("2019-W24-6"));
//        org.junit.Assert.assertNotNull(gJChronology15);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withYearOfEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (-28800000), 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28800011L) + "'", long2 == (-28800011L));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str3 = buddhistChronology2.toString();
        org.joda.time.DurationField durationField4 = buddhistChronology2.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField5 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        long long3 = property2.remainder();
        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withEra(10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        long long6 = julianChronology0.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DurationField durationField7 = julianChronology0.centuries();
        try {
            long long10 = durationField7.subtract((-28800011L), 1560638517177L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -156063851717700");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167391999903L) + "'", long6 == (-62167391999903L));
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011576d + "'", double1 == 2440587.5000011576d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        java.lang.Integer int3 = dateTimeFormatter1.getPivotYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("2019-W24-6", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-W24-6\" is malformed at \"19-W24-6\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 1, 6, 4, 100, 10, (int) '4', chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
//        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "", 0);
//        int int7 = mutableDateTime3.getMinuteOfDay();
//        int int8 = mutableDateTime3.getWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 941 + "'", int7 == 941);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) '#', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.LocalDateTime localDateTime2 = dateTime1.toLocalDateTime();
        try {
            org.joda.time.DateTime dateTime4 = dateTime1.withEra(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDateTime2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
//        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "", 0);
//        java.lang.StringBuffer stringBuffer7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        java.lang.String str9 = localDate8.toString();
//        int int10 = localDate8.getDayOfMonth();
//        org.joda.time.LocalDate localDate12 = localDate8.withYear((int) (short) 10);
//        org.joda.time.LocalDate localDate14 = localDate12.withDayOfMonth(4);
//        org.joda.time.DateMidnight dateMidnight15 = localDate12.toDateMidnight();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer7, (org.joda.time.ReadablePartial) localDate12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-06-15" + "'", str9.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = julianChronology0.add(readablePeriod5, 0L, (int) (byte) -1);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = julianChronology1.weeks();
        org.joda.time.DurationField durationField3 = julianChronology1.months();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField3, dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 1, "");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(960, 0, 35, 12, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-1969), (-28800000), (-1), 1, 2000, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "hi!", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "365", "1969-12-31");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "1970-W01-3", "1969-12-31T16");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
//        java.util.Locale locale7 = null;
//        int int8 = skipUndoDateTimeField3.getMaximumTextLength(locale7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.LocalTime localTime11 = dateTimeFormatter9.parseLocalTime("2019-06-15T15");
//        org.joda.time.DateTimeField[] dateTimeFieldArray12 = localTime11.getFields();
//        int[] intArray19 = new int[] { (short) 10, 12, (byte) -1, (byte) 10, (short) -1 };
//        int[] intArray21 = skipUndoDateTimeField3.set((org.joda.time.ReadablePartial) localTime11, 0, intArray19, 0);
//        int int22 = skipUndoDateTimeField3.getMinimumValue();
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
//        java.lang.String str24 = localDate23.toString();
//        int int25 = localDate23.getDayOfMonth();
//        org.joda.time.LocalDate.Property property26 = localDate23.era();
//        org.joda.time.LocalDate localDate27 = property26.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField28 = property26.getLeapDurationField();
//        org.joda.time.LocalDate localDate29 = property26.withMinimumValue();
//        int int30 = localDate29.getCenturyOfEra();
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate();
//        boolean boolean33 = localDate31.equals((java.lang.Object) "2019-W24-6");
//        org.joda.time.LocalDate.Property property34 = localDate31.monthOfYear();
//        boolean boolean35 = localDate29.equals((java.lang.Object) localDate31);
//        int[] intArray37 = null;
//        try {
//            int[] intArray39 = skipUndoDateTimeField3.addWrapField((org.joda.time.ReadablePartial) localDate29, (int) (byte) -1, intArray37, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AM" + "'", str6.equals("AM"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(localTime11);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray12);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertNotNull(intArray21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019-06-15" + "'", str24.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNull(durationField28);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 20 + "'", int30 == 20);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 10, (long) 20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("1969-12-31T16");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16\" is malformed at \"T16\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField4.getAsText(0, locale6);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField4, 35);
        org.joda.time.DateTimeField dateTimeField12 = skipUndoDateTimeField4.getWrappedField();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField14 = gregorianChronology13.minutes();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField12, durationField14, dateTimeFieldType15, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AM" + "'", str7.equals("AM"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = instant4.toMutableDateTime(dateTimeZone5);
        try {
            dateTimeFormatter1.printTo(stringBuffer3, (org.joda.time.ReadableInstant) mutableDateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long5 = gJChronology0.getDateTimeMillis(2, 20, 2019, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendPattern("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
        java.lang.String str3 = property2.getAsText();
        org.joda.time.DateTime dateTime4 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withField(dateTimeFieldType6, 166);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "365" + "'", str3.equals("365"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        try {
            long long7 = iSOChronology0.getDateTimeMillis(32L, 3, 166, (int) ' ', 287);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.DurationField durationField2 = buddhistChronology0.hours();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.Chronology chronology5 = buddhistChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant8 = gJChronology7.getGregorianCutover();
        org.joda.time.DateTime dateTime9 = instant8.toDateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay(0);
        try {
            org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.ReadableDateTime) dateTime6, (org.joda.time.ReadableDateTime) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
        java.lang.String str3 = property2.getAsText();
        org.joda.time.DateTime dateTime4 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withYear((int) (short) -1);
        org.joda.time.DateTime dateTime9 = dateTime5.plusMonths(0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "365" + "'", str3.equals("365"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str7 = buddhistChronology6.toString();
        org.joda.time.DurationField durationField8 = buddhistChronology6.hours();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology9.getZone();
        org.joda.time.Chronology chronology11 = buddhistChronology6.withZone(dateTimeZone10);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) (short) 1, 3, 100, 0, 4, (int) (short) 100, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BuddhistChronology[UTC]" + "'", str7.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 350L + "'", long2 == 350L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        int int3 = dateTime2.getMillisOfSecond();
        int int4 = dateTime2.getDayOfWeek();
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear(15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "1969365", (int) '#', (int) (short) 0);
        long long6 = fixedDateTimeZone4.nextTransition(32L);
        try {
            org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
//        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
//        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
//        org.joda.time.ReadablePartial readablePartial7 = null;
//        int int8 = skipUndoDateTimeField3.getMinimumValue(readablePartial7);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        java.lang.String str10 = localDate9.toString();
//        int int11 = localDate9.getDayOfMonth();
//        org.joda.time.LocalDate.Property property12 = localDate9.era();
//        org.joda.time.LocalDate localDate13 = property12.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField14 = property12.getLeapDurationField();
//        org.joda.time.LocalDate localDate15 = property12.withMinimumValue();
//        org.joda.time.LocalDate localDate17 = localDate15.minusWeeks((int) (byte) 10);
//        int int18 = localDate17.getYear();
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = julianChronology20.weeks();
//        org.joda.time.DurationField durationField22 = julianChronology20.months();
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
//        java.lang.String str24 = localDate23.toString();
//        int int25 = localDate23.getDayOfMonth();
//        org.joda.time.LocalDate.Property property26 = localDate23.era();
//        org.joda.time.LocalDate localDate27 = property26.withMaximumValue();
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate();
//        java.lang.String str29 = localDate28.toString();
//        int int30 = localDate28.getDayOfMonth();
//        org.joda.time.LocalDate.Property property31 = localDate28.era();
//        org.joda.time.LocalDate localDate32 = property31.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField33 = property31.getLeapDurationField();
//        org.joda.time.LocalDate localDate34 = property31.withMinimumValue();
//        org.joda.time.LocalDate localDate36 = localDate34.minusWeeks((int) (byte) 10);
//        int int37 = localDate36.getYear();
//        org.joda.time.LocalDate localDate39 = localDate36.minusMonths((int) (short) 10);
//        boolean boolean40 = localDate27.isEqual((org.joda.time.ReadablePartial) localDate39);
//        int[] intArray42 = julianChronology20.get((org.joda.time.ReadablePartial) localDate27, 2000L);
//        try {
//            int[] intArray44 = skipUndoDateTimeField3.addWrapPartial((org.joda.time.ReadablePartial) localDate17, (int) (byte) 1, intArray42, 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Fields invalid for add");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNull(durationField14);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-2019) + "'", int18 == (-2019));
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019-06-15" + "'", str24.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019-06-15" + "'", str29.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNull(durationField33);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-2019) + "'", int37 == (-2019));
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(intArray42);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
        java.lang.String str8 = skipUndoDateTimeField3.getAsText((long) (byte) 10);
        boolean boolean9 = skipUndoDateTimeField3.isLenient();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((java.lang.Object) localDateTime12, dateTimeZone14);
        int[] intArray18 = null;
        java.util.Locale locale20 = null;
        try {
            int[] intArray21 = skipUndoDateTimeField3.set((org.joda.time.ReadablePartial) localDateTime12, 31, intArray18, "2019-06-15T15", locale20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T15\" for halfdayOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AM" + "'", str8.equals("AM"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        int[] intArray7 = new int[] { (-1), 1, (byte) 1, (short) 10, '4', 15 };
        try {
            org.joda.time.Partial partial8 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-1), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) '#');
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeParser3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        int int13 = dateTimeZone11.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtStartOfDay(dateTimeZone11);
//        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16", "America/Los_Angeles", 31, 35);
//        org.joda.time.DateTime dateTime22 = dateTime15.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        long long25 = fixedDateTimeZone21.adjustOffset((long) 15, false);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2019) + "'", int9 == (-2019));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 15L + "'", long25 == 15L);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'ISOChronology[America/Los_Angeles]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendYear(0, 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
        java.lang.String str8 = skipUndoDateTimeField3.getAsText((long) (byte) 10);
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = skipUndoDateTimeField3.getAsText(3, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AM" + "'", str8.equals("AM"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = skipUndoDateTimeField3.getMinimumValue(readablePartial7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, dateTimeField13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField14.getAsText(0, locale16);
        java.util.Locale locale18 = null;
        int int19 = skipUndoDateTimeField14.getMaximumTextLength(locale18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalTime localTime22 = dateTimeFormatter20.parseLocalTime("2019-06-15T15");
        org.joda.time.DateTimeField[] dateTimeFieldArray23 = localTime22.getFields();
        int[] intArray30 = new int[] { (short) 10, 12, (byte) -1, (byte) 10, (short) -1 };
        int[] intArray32 = skipUndoDateTimeField14.set((org.joda.time.ReadablePartial) localTime22, 0, intArray30, 0);
        try {
            int[] intArray34 = skipUndoDateTimeField3.addWrapPartial(readablePartial9, (int) 'a', intArray32, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(localTime22);
        org.junit.Assert.assertNotNull(dateTimeFieldArray23);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        long long3 = property2.remainder();
        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
        boolean boolean6 = dateTime4.isBefore(32L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
        java.lang.String str3 = property2.getAsText();
        org.joda.time.DateTime dateTime4 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withYear((int) (short) -1);
        int int8 = dateTime5.getMonthOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "365" + "'", str3.equals("365"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        long long6 = julianChronology0.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DurationField durationField7 = julianChronology0.centuries();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray10 = julianChronology0.get(readablePeriod8, (-3155759999713L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167391999903L) + "'", long6 == (-62167391999903L));
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
        try {
            long long9 = skipUndoDateTimeField3.set((long) (-28800000), (-101));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -101 for halfdayOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        int int5 = property3.getLeapAmount();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate localDate4 = localDate0.withYear((int) (short) 10);
//        try {
//            org.joda.time.LocalDate localDate6 = localDate4.withDayOfWeek(100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(localDate4);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.LocalDateTime localDateTime2 = dateTime1.toLocalDateTime();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((java.lang.Object) localDateTime2, dateTimeZone4);
        try {
            org.joda.time.DateTimeField dateTimeField8 = localDate6.getField((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 35");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
        org.joda.time.DurationField durationField7 = skipDateTimeField6.getDurationField();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsShortText(2019, locale9);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        boolean boolean2 = localDate0.equals((java.lang.Object) "2019-W24-6");
        org.joda.time.LocalDate.Property property3 = localDate0.monthOfYear();
        try {
            org.joda.time.LocalDate localDate5 = localDate0.withDayOfWeek(287);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 287 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = julianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.clockhourOfHalfday();
        try {
            long long11 = julianChronology1.getDateTimeMillis(57600010, (int) (short) 10, (int) ' ', 31, 20, (int) (short) 1, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = skipUndoDateTimeField3.getMinimumValue(readablePartial7);
        long long10 = skipUndoDateTimeField3.roundHalfEven((long) 4);
        int int12 = skipUndoDateTimeField3.getLeapAmount((long) 10);
        java.lang.String str14 = skipUndoDateTimeField3.getAsShortText(1560638515057L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PM" + "'", str14.equals("PM"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("2019-06-15T15", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-15T15/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(2000L, (long) 166);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 332000L + "'", long2 == 332000L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = skipUndoDateTimeField4.getAsText(0, locale6);
//        java.util.Locale locale8 = null;
//        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField4, 35);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate();
//        java.lang.String str13 = localDate12.toString();
//        org.joda.time.LocalDate.Property property14 = localDate12.era();
//        org.joda.time.LocalDate localDate16 = property14.addWrapFieldToCopy(0);
//        java.util.Locale locale18 = null;
//        try {
//            java.lang.String str19 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate16, 100, locale18);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AM" + "'", str7.equals("AM"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-06-15" + "'", str13.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate16);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.centuries();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        boolean boolean10 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate9);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        try {
//            org.joda.time.LocalDate localDate13 = localDate9.withField(dateTimeFieldType11, (-1969));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.clockhourOfHalfday();
        int int6 = instant1.get(dateTimeField5);
        org.joda.time.DateTime dateTime7 = instant1.toDateTime();
        org.joda.time.Instant instant9 = instant1.minus((long) (-1));
        java.lang.Class<?> wildcardClass10 = instant1.getClass();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        boolean boolean9 = iSOChronology7.equals((java.lang.Object) dateTimeFormatter8);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology10.getZone();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone11);
        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) (short) 0, 0, 10, 20, (int) 'a', (int) (byte) 0, 0, chronology14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitYear(0, false);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendFractionOfHour((-101), 959);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfMinute((-101), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 1, "");
        java.lang.String str3 = illegalInstantException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 ()" + "'", str3.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 ()"));
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        java.lang.String str5 = property3.getAsString();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        java.lang.String str7 = property3.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[era]" + "'", str7.equals("Property[era]"));
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "hi!", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 ()", "JulianChronology[America/Los_Angeles]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        boolean boolean10 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate9);
//        org.joda.time.Chronology chronology11 = localDate9.getChronology();
//        java.util.Locale locale13 = null;
//        try {
//            java.lang.String str14 = localDate9.toString("GJChronology[America/Los_Angeles]", locale13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(chronology11);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = julianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.clockhourOfHalfday();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology4.getZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        try {
            org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((java.lang.Object) julianChronology1, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.JulianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(20);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks((int) (byte) 1);
//        org.joda.time.LocalDate.Property property11 = localDate8.yearOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology12, dateTimeField17);
//        int int20 = skipDateTimeField18.get(0L);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = julianChronology22.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology21, dateTimeField23);
//        java.lang.String str26 = skipUndoDateTimeField24.getAsText(10L);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField24.getAsShortText((int) (byte) 0, locale28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField24.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType30);
//        try {
//            int int32 = localDate8.get(dateTimeFieldType30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'halfdayOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 960 + "'", int20 == 960);
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AM" + "'", str26.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AM" + "'", str29.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        long long6 = julianChronology0.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DurationField durationField7 = julianChronology0.centuries();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField9 = new org.joda.time.field.DecoratedDurationField(durationField7, durationFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167391999903L) + "'", long6 == (-62167391999903L));
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        int int13 = dateTimeZone11.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtStartOfDay(dateTimeZone11);
//        java.lang.String str15 = dateTimeZone11.getID();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, 4);
//        try {
//            long long25 = gregorianChronology17.getDateTimeMillis((int) (short) 1, 1969, 0, 2000, (-28800000), (int) (short) -1, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2019) + "'", int9 == (-2019));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        org.joda.time.LocalDate.Property property2 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property2.addWrapFieldToCopy(0);
//        org.joda.time.LocalDate.Property property5 = localDate4.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.LocalTime localTime8 = dateTimeFormatter6.parseLocalTime("2019-06-15T15");
//        org.joda.time.Instant instant9 = new org.joda.time.Instant();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = instant9.toMutableDateTime(dateTimeZone10);
//        org.joda.time.Instant instant14 = instant9.withDurationAdded((long) '#', (int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime15 = instant9.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime16 = localTime8.toDateTime((org.joda.time.ReadableInstant) instant9);
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, dateTimeField19);
//        java.lang.String str22 = skipUndoDateTimeField20.getAsText(10L);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = skipUndoDateTimeField20.getAsShortText((int) (byte) 0, locale24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField20.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "1969-12-31T16");
//        boolean boolean29 = instant9.isSupported(dateTimeFieldType26);
//        try {
//            int int30 = localDate4.get(dateTimeFieldType26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'halfdayOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AM" + "'", str22.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "AM" + "'", str25.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        long long6 = julianChronology0.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray10 = julianChronology0.get(readablePeriod8, (long) 20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167391999903L) + "'", long6 == (-62167391999903L));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitYear(0, false);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap6);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipUndoDateTimeField3.getAsShortText((int) (byte) 0, locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = skipUndoDateTimeField3.getType();
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = skipUndoDateTimeField3.getAsText(166, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 166");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AM" + "'", str8.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 1560638517033L, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant3, (-101));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -101");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("BuddhistChronology[UTC]", (int) (short) -1, 35, 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for BuddhistChronology[UTC] must be in the range [35,35]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
        int int8 = skipDateTimeField6.get(0L);
        int int10 = skipDateTimeField6.get((-10L));
        long long12 = skipDateTimeField6.roundCeiling((long) '4');
        int int14 = skipDateTimeField6.get((long) 960);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 960 + "'", int8 == 960);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 959 + "'", int10 == 959);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60000L + "'", long12 == 60000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 960 + "'", int14 == 960);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
//        int int4 = dateTime3.getDayOfYear();
//        try {
//            org.joda.time.DateTime dateTime6 = dateTime3.withMinuteOfHour(959);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 959 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 166 + "'", int4 == 166);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = julianChronology0.add(readablePeriod5, 0L, (int) (byte) -1);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        long long3 = property2.remainder();
        org.joda.time.DateTime dateTime4 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
        boolean boolean8 = localDate6.equals((java.lang.Object) "2019-W24-6");
        org.joda.time.LocalDate.Property property9 = localDate6.monthOfYear();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsShortText(locale10);
        org.joda.time.Instant instant13 = org.joda.time.Instant.parse("1970-W01-3");
        int int14 = property9.getDifference((org.joda.time.ReadableInstant) instant13);
        long long15 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) instant13);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Jun" + "'", str11.equals("Jun"));
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 593 + "'", int14 == 593);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 16L + "'", long15 == 16L);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("2019-06-15T15");
//        java.lang.Object obj3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj3);
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.weekOfWeekyear();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime((org.joda.time.Chronology) julianChronology5);
//        int int11 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime8, "2019-06-15", (int) (byte) 100);
//        int int12 = mutableDateTime8.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-101) + "'", int11 == (-101));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 22 + "'", int12 == 22);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        java.lang.String str2 = gJChronology0.toString();
        try {
            long long10 = gJChronology0.getDateTimeMillis((-1), 0, 593, 0, 960, 166, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str2.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.weekyear();
        java.lang.String str6 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JulianChronology[UTC]" + "'", str6.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(0L);
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = partial2.getFormatter();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Partial partial6 = partial2.withFieldAddWrapped(durationFieldType4, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        long long9 = skipUndoDateTimeField3.getDifferenceAsLong(0L, (long) (-1));
        int int10 = skipUndoDateTimeField3.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AM" + "'", str6.equals("AM"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        int int13 = dateTimeZone11.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtStartOfDay(dateTimeZone11);
//        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
//        try {
//            org.joda.time.DateTime dateTime18 = property16.setCopy((int) '4');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2019) + "'", int9 == (-2019));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        org.joda.time.LocalDate.Property property2 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property2.addWrapFieldToCopy(0);
//        org.joda.time.LocalDate.Property property5 = localDate4.year();
//        java.util.Locale locale6 = null;
//        int int7 = property5.getMaximumTextLength(locale6);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1969));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 2, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendWeekyear((int) ' ', (int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.plusWeeks((int) 'a');
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt((-125872358822000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -125872358822000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.LocalDate localDate4 = dateTime1.toLocalDate();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime1.withFieldAdded(durationFieldType5, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(0L);
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalTime localTime5 = dateTimeFormatter3.parseLocalTime("2019-06-15T15");
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = instant6.toMutableDateTime(dateTimeZone7);
        org.joda.time.Instant instant11 = instant6.withDurationAdded((long) '#', (int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime12 = instant6.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime13 = localTime5.toDateTime((org.joda.time.ReadableInstant) instant6);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField(chronology14, dateTimeField16);
        java.lang.String str19 = skipUndoDateTimeField17.getAsText(10L);
        java.util.Locale locale21 = null;
        java.lang.String str22 = skipUndoDateTimeField17.getAsShortText((int) (byte) 0, locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField17.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, "1969-12-31T16");
        boolean boolean26 = instant6.isSupported(dateTimeFieldType23);
        try {
            org.joda.time.Partial partial28 = partial2.with(dateTimeFieldType23, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for halfdayOfDay must not be larger than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "AM" + "'", str19.equals("AM"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AM" + "'", str22.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 ()", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 ()/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        try {
            org.joda.time.LocalDateTime localDateTime6 = dateTimeFormatter3.parseLocalDateTime("GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        org.joda.time.LocalDate localDate11 = localDate8.minusMonths((int) (short) 10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.LocalDate localDate14 = localDate11.withPeriodAdded(readablePeriod12, 3);
//        org.joda.time.LocalDate localDate16 = localDate11.minusWeeks(960);
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType18 = localDate16.getFieldType(941);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 941");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2019) + "'", int9 == (-2019));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        boolean boolean2 = localDate0.equals((java.lang.Object) "2019-W24-6");
        org.joda.time.LocalDate.Property property3 = localDate0.monthOfYear();
        int int4 = localDate0.getYearOfCentury();
        try {
            int int6 = localDate0.getValue(960);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 960");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) -1, 287, 2000, (int) (byte) 1, 22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 287 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) 9, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendYear(4, (int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.append(dateTimePrinter10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (short) 10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap16 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendTimeZoneShortName(strMap16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendTwoDigitYear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendHourOfHalfday((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendYear((int) (byte) 1, 3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimePrinter dateTimePrinter27 = dateTimeFormatter26.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder20.append(dateTimePrinter27);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray29 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder11.append(dateTimePrinter27, dateTimeParserArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimePrinter27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeParserArray29);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        long long3 = property2.remainder();
        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) ' ');
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime6.toCalendar(locale7);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(calendar8);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        int int13 = dateTimeZone11.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtStartOfDay(dateTimeZone11);
//        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime14.withDayOfMonth(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2019) + "'", int9 == (-2019));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        long long6 = julianChronology0.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.monthOfYear();
        org.joda.time.Chronology chronology8 = julianChronology0.withUTC();
        java.lang.String str9 = julianChronology0.toString();
        java.lang.String str10 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167391999903L) + "'", long6 == (-62167391999903L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JulianChronology[UTC]" + "'", str9.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JulianChronology[UTC]" + "'", str10.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.halfdayOfDay();
        long long11 = julianChronology5.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DurationField durationField12 = julianChronology5.centuries();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.Chronology chronology16 = julianChronology5.withZone(dateTimeZone14);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(6, 3, 287, 22, 100, (org.joda.time.Chronology) julianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62167391999903L) + "'", long11 == (-62167391999903L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        int int13 = dateTimeZone11.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtStartOfDay(dateTimeZone11);
//        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16", "America/Los_Angeles", 31, 35);
//        org.joda.time.DateTime dateTime22 = dateTime15.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        boolean boolean23 = dateTime15.isEqualNow();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2019) + "'", int9 == (-2019));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        boolean boolean2 = localDate0.equals((java.lang.Object) "2019-W24-6");
//        org.joda.time.LocalDate localDate4 = localDate0.withCenturyOfEra(6);
//        org.joda.time.LocalDate.Property property5 = localDate0.dayOfMonth();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
//        java.lang.String str7 = localDate6.toString();
//        int int8 = localDate6.getDayOfMonth();
//        org.joda.time.LocalDate.Property property9 = localDate6.era();
//        org.joda.time.LocalDate localDate10 = property9.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField11 = property9.getLeapDurationField();
//        org.joda.time.LocalDate localDate12 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray13 = localDate12.getFieldTypes();
//        org.joda.time.DateTimeField[] dateTimeFieldArray14 = localDate12.getFields();
//        int int15 = localDate0.compareTo((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.DateTimeField dateTimeField17 = localDate0.getField(0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15" + "'", str7.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNull(durationField11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray13);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendYear(4, (int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatterBuilder8.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        boolean boolean2 = localDate0.equals((java.lang.Object) "2019-W24-6");
        org.joda.time.LocalDate.Property property3 = localDate0.monthOfYear();
        java.util.Locale locale5 = null;
        try {
            org.joda.time.LocalDate localDate6 = property3.setCopy("ISOChronology[America/Los_Angeles]", locale5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[America/Los_Angeles]\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 0, 2488320000000000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(100, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        int int3 = dateTime2.getMillisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime5 = dateTime2.toDateTimeISO();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        java.util.Locale locale6 = null;
//        int int7 = property3.getMaximumShortTextLength(locale6);
//        try {
//            org.joda.time.LocalDate localDate9 = property3.setCopy((int) '4');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        java.lang.String str5 = property3.getAsString();
//        org.joda.time.LocalDate localDate6 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField7 = property3.getLeapDurationField();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNull(durationField7);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
//        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
//        int int3 = dateTime2.getMillisOfSecond();
//        int int4 = dateTime2.getDayOfWeek();
//        boolean boolean6 = dateTime2.isEqual((long) 2);
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTimeISO();
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        try {
//            int int9 = dateTime7.compareTo(readableInstant8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, (-101));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -101");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        org.joda.time.LocalDate.Property property2 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property2.addWrapFieldToCopy(0);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate();
//        java.lang.String str6 = localDate5.toString();
//        org.joda.time.LocalDate.Property property7 = localDate5.era();
//        org.joda.time.LocalDate localDate9 = property7.addWrapFieldToCopy(0);
//        org.joda.time.LocalDate.Property property10 = localDate9.year();
//        java.lang.String str11 = property10.getAsString();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = instant12.toMutableDateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = instant12.toDateTimeISO();
//        org.joda.time.Instant instant17 = instant12.withMillis(2000L);
//        int int18 = property10.getDifference((org.joda.time.ReadableInstant) instant12);
//        org.joda.time.DateTime dateTime19 = localDate4.toDateTime((org.joda.time.ReadableInstant) instant12);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-06-15" + "'", str6.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) -1, 9, (int) (short) 0, 960, (int) (byte) 10, 959, 2, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        org.joda.time.LocalDate localDate11 = localDate8.minusMonths((int) (short) 10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.LocalDate localDate14 = localDate11.withPeriodAdded(readablePeriod12, 3);
//        org.joda.time.LocalDate localDate16 = localDate11.minusWeeks(960);
//        int int17 = localDate16.getEra();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2019) + "'", int9 == (-2019));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withHourOfDay(0);
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withHourOfDay((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
        java.lang.String str8 = skipUndoDateTimeField3.getAsText((long) (byte) 10);
        boolean boolean9 = skipUndoDateTimeField3.isLenient();
        long long12 = skipUndoDateTimeField3.getDifferenceAsLong((long) 100, 0L);
        org.joda.time.DurationField durationField13 = skipUndoDateTimeField3.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType14 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField13, durationFieldType14, 941);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AM" + "'", str8.equals("AM"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks((int) (byte) 1);
//        org.joda.time.LocalDate.Property property11 = localDate8.yearOfEra();
//        org.joda.time.DateMidnight dateMidnight12 = localDate8.toDateMidnight();
//        int int13 = localDate8.getWeekyear();
//        int int14 = localDate8.getYearOfCentury();
//        org.joda.time.LocalDate.Property property15 = localDate8.weekyear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateMidnight12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2019) + "'", int13 == (-2019));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate localDate3 = localDate1.minusYears(57600010);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 31);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210864081600000L) + "'", long1 == (-210864081600000L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
        java.lang.String str7 = skipDateTimeField6.getName();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "minuteOfDay" + "'", str7.equals("minuteOfDay"));
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        boolean boolean2 = localDate0.equals((java.lang.Object) "2019-W24-6");
//        org.joda.time.LocalDate localDate4 = localDate0.withCenturyOfEra(6);
//        org.joda.time.LocalDate.Property property5 = localDate0.dayOfMonth();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
//        java.lang.String str7 = localDate6.toString();
//        int int8 = localDate6.getDayOfMonth();
//        org.joda.time.LocalDate.Property property9 = localDate6.era();
//        org.joda.time.LocalDate localDate10 = property9.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField11 = property9.getLeapDurationField();
//        org.joda.time.LocalDate localDate12 = property9.withMinimumValue();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray13 = localDate12.getFieldTypes();
//        org.joda.time.DateTimeField[] dateTimeFieldArray14 = localDate12.getFields();
//        int int15 = localDate0.compareTo((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField21);
//        int int24 = skipDateTimeField22.get(0L);
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = julianChronology26.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField(chronology25, dateTimeField27);
//        java.lang.String str30 = skipUndoDateTimeField28.getAsText(10L);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipUndoDateTimeField28.getAsShortText((int) (byte) 0, locale32);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipUndoDateTimeField28.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField22, dateTimeFieldType34);
//        try {
//            int int36 = localDate12.get(dateTimeFieldType34);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'halfdayOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15" + "'", str7.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNull(durationField11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray13);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "AM" + "'", str30.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AM" + "'", str33.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
//        int int4 = mutableDateTime3.getDayOfWeek();
//        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime3);
//        int int6 = mutableDateTime3.getCenturyOfEra();
//        try {
//            java.lang.String str8 = mutableDateTime3.toString("2019-W24-6");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-15T22" + "'", str5.equals("2019-06-15T22"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        long long3 = property2.remainder();
        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime4.plus((long) (-2019));
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeField dateTimeField11 = property9.getField();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        long long3 = property2.remainder();
        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) ' ');
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime6.withFieldAdded(durationFieldType8, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendYear(4, (int) 'a');
        boolean boolean9 = dateTimeFormatterBuilder3.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(0L);
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = partial2.getFormatter();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField6);
        java.lang.String str9 = skipUndoDateTimeField7.getAsText(10L);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField7.getAsShortText((int) (byte) 0, locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipUndoDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "1969-12-31T16");
        try {
            org.joda.time.Partial partial17 = partial2.with(dateTimeFieldType13, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for halfdayOfDay must not be larger than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AM" + "'", str9.equals("AM"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AM" + "'", str12.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) 0, (int) (byte) 1, 1, 15, 35);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = instant0.plus(0L);
        boolean boolean4 = instant0.isBefore(82800032L);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.DurationField durationField2 = buddhistChronology0.hours();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str4 = buddhistChronology3.toString();
        org.joda.time.DurationField durationField5 = buddhistChronology3.hours();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.Chronology chronology8 = buddhistChronology3.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology9 = buddhistChronology0.withZone(dateTimeZone7);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BuddhistChronology[UTC]" + "'", str4.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitYear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfSecond((int) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 100);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField4.getAsText(0, locale6);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField4, 35);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField4.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField15 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType13, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AM" + "'", str7.equals("AM"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        long long6 = julianChronology0.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.monthOfYear();
        org.joda.time.Chronology chronology8 = julianChronology0.withUTC();
        org.joda.time.DurationField durationField9 = julianChronology0.days();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.Chronology chronology12 = iSOChronology10.withZone(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField13, (int) (byte) -1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167391999903L) + "'", long6 == (-62167391999903L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'GJChronology[America/Los_Angeles]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 22, 959);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (-1969));
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        java.lang.String str29 = unsupportedDateTimeField28.toString();
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        org.joda.time.Chronology chronology32 = null;
//        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = julianChronology33.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField(chronology32, dateTimeField34);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = skipUndoDateTimeField35.getAsText(0, locale37);
//        long long41 = skipUndoDateTimeField35.getDifferenceAsLong(0L, (long) (-1));
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate();
//        java.lang.String str43 = localDate42.toString();
//        int int44 = localDate42.getDayOfMonth();
//        org.joda.time.LocalDate localDate46 = localDate42.withYear((int) (short) 10);
//        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField49 = julianChronology48.weeks();
//        org.joda.time.DurationField durationField50 = julianChronology48.months();
//        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate();
//        java.lang.String str52 = localDate51.toString();
//        int int53 = localDate51.getDayOfMonth();
//        org.joda.time.LocalDate.Property property54 = localDate51.era();
//        org.joda.time.LocalDate localDate55 = property54.withMaximumValue();
//        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate();
//        java.lang.String str57 = localDate56.toString();
//        int int58 = localDate56.getDayOfMonth();
//        org.joda.time.LocalDate.Property property59 = localDate56.era();
//        org.joda.time.LocalDate localDate60 = property59.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField61 = property59.getLeapDurationField();
//        org.joda.time.LocalDate localDate62 = property59.withMinimumValue();
//        org.joda.time.LocalDate localDate64 = localDate62.minusWeeks((int) (byte) 10);
//        int int65 = localDate64.getYear();
//        org.joda.time.LocalDate localDate67 = localDate64.minusMonths((int) (short) 10);
//        boolean boolean68 = localDate55.isEqual((org.joda.time.ReadablePartial) localDate67);
//        int[] intArray70 = julianChronology48.get((org.joda.time.ReadablePartial) localDate55, 2000L);
//        int[] intArray72 = skipUndoDateTimeField35.addWrapField((org.joda.time.ReadablePartial) localDate42, 0, intArray70, (int) (short) 1);
//        try {
//            int[] intArray74 = unsupportedDateTimeField28.set(readablePartial30, 15, intArray70, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(julianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "AM" + "'", str38.equals("AM"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1970-01-01" + "'", str43.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertNotNull(julianChronology48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1970-01-01" + "'", str52.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "1970-01-01" + "'", str57.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertNotNull(localDate60);
//        org.junit.Assert.assertNull(durationField61);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1971) + "'", int65 == (-1971));
//        org.junit.Assert.assertNotNull(localDate67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(intArray70);
//        org.junit.Assert.assertNotNull(intArray72);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        int int3 = dateTime2.getMillisOfSecond();
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withDate(6, 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        int int13 = dateTimeZone11.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtStartOfDay(dateTimeZone11);
//        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16", "America/Los_Angeles", 31, 35);
//        org.joda.time.DateTime dateTime22 = dateTime15.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        java.lang.String str24 = fixedDateTimeZone21.getName(0L);
//        java.util.TimeZone timeZone25 = fixedDateTimeZone21.toTimeZone();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1971) + "'", int9 == (-1971));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.031" + "'", str24.equals("+00:00:00.031"));
//        org.junit.Assert.assertNotNull(timeZone25);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        java.lang.String str29 = unsupportedDateTimeField28.toString();
//        try {
//            long long32 = unsupportedDateTimeField28.set(350L, 5);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField3);
//        java.lang.String str6 = skipUndoDateTimeField4.getAsText(10L);
//        org.joda.time.DateTimeField dateTimeField7 = skipUndoDateTimeField4.getWrappedField();
//        java.lang.String str9 = skipUndoDateTimeField4.getAsText((long) (byte) 10);
//        boolean boolean10 = skipUndoDateTimeField4.isLenient();
//        long long13 = skipUndoDateTimeField4.getDifferenceAsLong((long) 100, 0L);
//        org.joda.time.DurationField durationField14 = skipUndoDateTimeField4.getRangeDurationField();
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = julianChronology15.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology15, dateTimeField20);
//        int int23 = skipDateTimeField21.get(0L);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField(chronology24, dateTimeField26);
//        java.lang.String str29 = skipUndoDateTimeField27.getAsText(10L);
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = skipUndoDateTimeField27.getAsShortText((int) (byte) 0, locale31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipUndoDateTimeField27.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField21, dateTimeFieldType33);
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        boolean boolean38 = iSOChronology36.equals((java.lang.Object) dateTimeFormatter37);
//        java.lang.String str39 = iSOChronology36.toString();
//        org.joda.time.Partial partial40 = new org.joda.time.Partial(dateTimeFieldType33, 0, (org.joda.time.Chronology) iSOChronology36);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField14, dateTimeFieldType33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AM" + "'", str6.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AM" + "'", str9.equals("AM"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AM" + "'", str29.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "AM" + "'", str32.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ISOChronology[UTC]" + "'", str39.equals("ISOChronology[UTC]"));
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
//        java.lang.String str3 = property2.getAsText();
//        org.joda.time.DateTime dateTime4 = property2.roundCeilingCopy();
//        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime7 = dateTime5.withYear((int) (short) -1);
//        org.joda.time.DateTime dateTime9 = dateTime7.withDayOfWeek(3);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "1969365", (int) '#', (int) (short) 0);
        long long13 = fixedDateTimeZone11.nextTransition(32L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = fixedDateTimeZone11.getName((long) 35, locale15);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(20, (int) (short) 1, 287, 593, (int) (byte) -1, 20, 4, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 593 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.035" + "'", str16.equals("+00:00:00.035"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = instant0.withMillis((long) 3);
        org.joda.time.DateTime dateTime3 = instant2.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        long long6 = julianChronology0.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.monthOfYear();
        org.joda.time.Chronology chronology8 = julianChronology0.withUTC();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.halfdayOfDay();
        long long15 = julianChronology9.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DateTimeField dateTimeField16 = julianChronology9.monthOfYear();
        org.joda.time.Chronology chronology17 = julianChronology9.withUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology9.yearOfCentury();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField(chronology8, dateTimeField18, 31);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167391999903L) + "'", long6 == (-62167391999903L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62167391999903L) + "'", long15 == (-62167391999903L));
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField4.getAsText(0, locale6);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField4, 35);
        try {
            long long14 = skipDateTimeField11.set((long) (byte) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2 for halfdayOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AM" + "'", str7.equals("AM"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 97L, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        long long3 = property2.remainder();
        org.joda.time.DateTime dateTime5 = property2.addWrapFieldToCopy(1);
        org.joda.time.DateTime dateTime6 = property2.withMinimumValue();
        int int7 = property2.getMaximumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 23 + "'", int7 == 23);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
//        long long8 = julianChronology2.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
//        org.joda.time.DateTimeField dateTimeField9 = julianChronology2.monthOfYear();
//        org.joda.time.Chronology chronology10 = julianChronology2.withUTC();
//        org.joda.time.DurationField durationField11 = julianChronology2.days();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gregorianChronology12);
//        long long15 = julianChronology2.set((org.joda.time.ReadablePartial) localDate13, (long) 1);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167391999903L) + "'", long8 == (-62167391999903L));
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1123200001L + "'", long15 == 1123200001L);
//    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        java.util.Locale locale8 = null;
//        try {
//            org.joda.time.LocalDate localDate9 = property3.setCopy("", locale8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for era is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.append(dateTimePrinter5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        try {
//            long long30 = unsupportedDateTimeField28.roundFloor((long) 20);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        java.lang.String str5 = property3.getAsString();
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = instant6.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = mutableDateTime8.getZone();
//        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime8.toMutableDateTimeISO();
//        java.util.Date date11 = mutableDateTime10.toDate();
//        try {
//            int int12 = property3.getDifference((org.joda.time.ReadableInstant) mutableDateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(date11);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        long long3 = property2.remainder();
        org.joda.time.DateTime dateTime4 = property2.roundCeilingCopy();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime6.era();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        boolean boolean23 = iSOChronology21.equals((java.lang.Object) dateTimeFormatter22);
//        java.lang.String str24 = iSOChronology21.toString();
//        org.joda.time.Partial partial25 = new org.joda.time.Partial(dateTimeFieldType18, 0, (org.joda.time.Chronology) iSOChronology21);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) ' ');
//        org.joda.time.DateTime.Property property28 = dateTime27.hourOfDay();
//        long long29 = property28.remainder();
//        org.joda.time.DateTime dateTime30 = property28.withMaximumValue();
//        org.joda.time.DateTime dateTime32 = dateTime30.minusMonths((int) ' ');
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Instant instant34 = gJChronology33.getGregorianCutover();
//        org.joda.time.DateTime dateTime35 = instant34.toDateTime();
//        int int36 = dateTime35.getMillisOfSecond();
//        org.joda.time.DateTime.Property property37 = dateTime35.year();
//        org.joda.time.DateTime dateTime39 = dateTime35.plusMillis((int) ' ');
//        int int40 = dateTime35.getDayOfYear();
//        org.joda.time.DateTime dateTime42 = dateTime35.withMillisOfSecond((int) 'a');
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology43 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology21, (org.joda.time.ReadableDateTime) dateTime32, (org.joda.time.ReadableDateTime) dateTime42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[UTC]" + "'", str24.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 32L + "'", long29 == 32L);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(instant34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 288 + "'", int40 == 288);
//        org.junit.Assert.assertNotNull(dateTime42);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        int int13 = dateTimeZone11.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtStartOfDay(dateTimeZone11);
//        org.joda.time.LocalDate localDate16 = localDate8.withYear(19);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1971) + "'", int9 == (-1971));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localDate16);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone4);
        try {
            long long11 = zonedChronology6.getDateTimeMillis((int) (short) 1, 1969, 0, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(zonedChronology6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000001737d + "'", double1 == 2440587.5000001737d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        try {
            long long6 = buddhistChronology0.getDateTimeMillis(960, 20, 166, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        try {
            org.joda.time.DateTime dateTime4 = dateTime1.withCenturyOfEra(57600010);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600010 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        try {
//            long long30 = unsupportedDateTimeField28.roundCeiling((long) (-28800000));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay((int) (byte) 1);
//        org.joda.time.DateTime.Property property4 = dateTime1.millisOfSecond();
//        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate();
//        java.lang.String str7 = localDate6.toString();
//        int int8 = localDate6.getDayOfMonth();
//        org.joda.time.LocalDate.Property property9 = localDate6.era();
//        org.joda.time.LocalDate localDate10 = property9.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField11 = property9.getLeapDurationField();
//        org.joda.time.LocalDate localDate12 = property9.withMinimumValue();
//        org.joda.time.LocalDate localDate14 = localDate12.minusWeeks((int) (byte) 10);
//        int int15 = localDate14.getYear();
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        int int19 = dateTimeZone17.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime20 = localDate14.toDateTimeAtStartOfDay(dateTimeZone17);
//        try {
//            org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((java.lang.Object) property4, dateTimeZone17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.DateTime$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNull(durationField11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1971) + "'", int15 == (-1971));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        long long6 = julianChronology0.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.monthOfYear();
        org.joda.time.Chronology chronology8 = julianChronology0.withUTC();
        java.lang.String str9 = julianChronology0.toString();
        try {
            long long14 = julianChronology0.getDateTimeMillis((-1), (int) (byte) 100, 960, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167391999903L) + "'", long6 == (-62167391999903L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JulianChronology[UTC]" + "'", str9.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        boolean boolean2 = localDate0.equals((java.lang.Object) "2019-W24-6");
        org.joda.time.LocalDate.Property property3 = localDate0.monthOfYear();
        org.joda.time.DateMidnight dateMidnight4 = localDate0.toDateMidnight();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("JulianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.weekyears();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(0L);
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType4 = partial2.getFieldType((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField4.getAsText(0, locale6);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField4, 35);
        long long14 = skipDateTimeField11.addWrapField((long) 100, 6);
        int int16 = skipDateTimeField11.getMinimumValue((long) (-1971));
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AM" + "'", str7.equals("AM"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property3 = dateTime2.hourOfDay();
        long long4 = property3.remainder();
        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) ' ');
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 100, (java.lang.Object) dateTime7);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        boolean boolean2 = localDate0.equals((java.lang.Object) "2019-W24-6");
//        org.joda.time.LocalDate.Property property3 = localDate0.monthOfYear();
//        int int4 = localDate0.getYearOfCentury();
//        org.joda.time.LocalDate localDate6 = localDate0.minusDays((int) (short) 1);
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.halfdayOfDay();
//        long long13 = julianChronology7.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology7.monthOfYear();
//        org.joda.time.Chronology chronology15 = julianChronology7.withUTC();
//        boolean boolean16 = localDate0.equals((java.lang.Object) chronology15);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62167391999903L) + "'", long13 == (-62167391999903L));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipUndoDateTimeField3.getAsShortText((int) (byte) 0, locale7);
        int int9 = skipUndoDateTimeField3.getMinimumValue();
        try {
            long long12 = skipUndoDateTimeField3.set((long) (byte) 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for halfdayOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AM" + "'", str8.equals("AM"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalTime localTime5 = dateTimeFormatter3.parseLocalTime("2019-06-15T15");
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = instant6.toMutableDateTime(dateTimeZone7);
        org.joda.time.Instant instant11 = instant6.withDurationAdded((long) '#', (int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime12 = instant6.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime13 = localTime5.toDateTime((org.joda.time.ReadableInstant) instant6);
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) instant0, (java.lang.Object) instant6);
        boolean boolean16 = instant0.isBefore(0L);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        org.joda.time.LocalDate localDate11 = localDate8.minusMonths((int) (short) 10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.LocalDate localDate14 = localDate11.withPeriodAdded(readablePeriod12, 3);
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology15.getZone();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
//        java.lang.String str18 = dateTimeZone16.toString();
//        org.joda.time.DateTime dateTime19 = localDate14.toDateTimeAtStartOfDay(dateTimeZone16);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1971) + "'", int9 == (-1971));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        boolean boolean23 = iSOChronology21.equals((java.lang.Object) dateTimeFormatter22);
//        java.lang.String str24 = iSOChronology21.toString();
//        org.joda.time.Partial partial25 = new org.joda.time.Partial(dateTimeFieldType18, 0, (org.joda.time.Chronology) iSOChronology21);
//        org.joda.time.Chronology chronology26 = partial25.getChronology();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.Partial partial28 = partial25.minus(readablePeriod27);
//        org.joda.time.DurationFieldType durationFieldType29 = null;
//        try {
//            org.joda.time.Partial partial31 = partial25.withFieldAddWrapped(durationFieldType29, 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[UTC]" + "'", str24.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(partial28);
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        org.joda.time.LocalDate.Property property2 = localDate0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField3 = property2.getField();
//        org.joda.time.DateTimeField dateTimeField4 = property2.getField();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        boolean boolean2 = localDate0.equals((java.lang.Object) "2019-W24-6");
        java.util.Locale locale4 = null;
        try {
            java.lang.String str5 = localDate0.toString("Jun", locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipUndoDateTimeField3.getAsShortText((int) (byte) 0, locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = skipUndoDateTimeField3.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "1969-12-31T16");
        java.lang.String str12 = illegalFieldValueException11.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType13 = illegalFieldValueException11.getDurationFieldType();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AM" + "'", str8.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31T16" + "'", str12.equals("1969-12-31T16"));
        org.junit.Assert.assertNull(durationFieldType13);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        java.io.Writer writer1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, dateTimeField5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = skipUndoDateTimeField6.getAsText(0, locale8);
//        java.util.Locale locale10 = null;
//        int int11 = skipUndoDateTimeField6.getMaximumTextLength(locale10);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField(chronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField6, 35);
//        org.joda.time.DurationField durationField14 = skipUndoDateTimeField6.getRangeDurationField();
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate();
//        java.lang.String str16 = localDate15.toString();
//        int int17 = localDate15.getDayOfMonth();
//        org.joda.time.LocalDate localDate19 = localDate15.withYear((int) (short) 10);
//        org.joda.time.LocalDate localDate21 = localDate19.withDayOfMonth(4);
//        org.joda.time.DateMidnight dateMidnight22 = localDate19.toDateMidnight();
//        int int23 = skipUndoDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localDate19);
//        java.lang.String str25 = localDate19.toString("2019-06-15");
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate19);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AM" + "'", str9.equals("AM"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970-01-01" + "'", str16.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(dateMidnight22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019-06-15" + "'", str25.equals("2019-06-15"));
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.DurationFieldType durationFieldType24 = illegalFieldValueException23.getDurationFieldType();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNull(durationFieldType24);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(16L, dateTimeZone1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, 4, (-101));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
//        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
//        int int3 = dateTime2.getMillisOfSecond();
//        int int4 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
//        java.lang.String str6 = property5.getName();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hourOfDay" + "'", str6.equals("hourOfDay"));
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(70, (-2019));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1949) + "'", int2 == (-1949));
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) 1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = mutableDateTime5.getZone();
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime5.toMutableDateTimeISO();
//        java.util.Date date8 = mutableDateTime7.toDate();
//        int int11 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "21", 2019);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "19700101" + "'", str2.equals("19700101"));
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-2020) + "'", int11 == (-2020));
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(0L);
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = partial2.getFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withPivotYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long4 = gJChronology0.add((long) 166, (long) 2000, 9);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gJChronology0.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 18166L + "'", long4 == 18166L);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        boolean boolean8 = julianChronology6.equals((java.lang.Object) (-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology6, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (short) 100, (-1949), 1970, 57600010, 19, 960, (org.joda.time.Chronology) zonedChronology11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600010 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        boolean boolean3 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 100L, (java.lang.Number) (-1.0d), (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("21");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"21/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = julianChronology1.toString();
//        java.lang.Class<?> wildcardClass3 = julianChronology1.getClass();
//        try {
//            long long8 = julianChronology1.getDateTimeMillis((int) (short) -1, (int) 'a', 287, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipUndoDateTimeField3.getAsShortText((int) (byte) 0, locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = skipUndoDateTimeField3.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "1969-12-31T16");
        java.lang.String str12 = illegalFieldValueException11.getFieldName();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AM" + "'", str8.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "halfdayOfDay" + "'", str12.equals("halfdayOfDay"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("minuteOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"minuteOfDay\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.DurationField durationField2 = buddhistChronology0.hours();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str4 = buddhistChronology3.toString();
        org.joda.time.DurationField durationField5 = buddhistChronology3.hours();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        org.joda.time.Chronology chronology8 = buddhistChronology3.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology9 = buddhistChronology0.withZone(dateTimeZone7);
        java.lang.String str10 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BuddhistChronology[UTC]" + "'", str4.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "BuddhistChronology[UTC]" + "'", str10.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        long long3 = property2.remainder();
        org.joda.time.DateTime dateTime5 = property2.addWrapFieldToCopy(1);
        org.joda.time.DateTime dateTime6 = property2.withMinimumValue();
        org.joda.time.DateTime dateTime8 = property2.setCopy(10);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        try {
//            long long31 = unsupportedDateTimeField28.add((long) 960, (-210864081600000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -210864081600000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        java.lang.String str29 = unsupportedDateTimeField28.toString();
//        try {
//            java.lang.String str31 = unsupportedDateTimeField28.getAsShortText((long) 593);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        long long6 = julianChronology0.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
        org.joda.time.DurationField durationField7 = julianChronology0.centuries();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology8.getZone();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.Chronology chronology11 = julianChronology0.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167391999903L) + "'", long6 == (-62167391999903L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendYear(0, 35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        org.joda.time.LocalDate localDate11 = localDate8.minusMonths((int) (short) 10);
//        boolean boolean12 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate11);
//        java.util.Locale locale14 = null;
//        try {
//            java.lang.String str15 = localDate11.toString("hi!", locale14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1971) + "'", int9 == (-1971));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        boolean boolean2 = localDate0.equals((java.lang.Object) "2019-W24-6");
//        org.joda.time.LocalDate.Property property3 = localDate0.monthOfYear();
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate();
//        java.lang.String str5 = localDate4.toString();
//        int int6 = localDate4.getDayOfMonth();
//        boolean boolean7 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate4);
//        boolean boolean8 = localDate0.isEqual((org.joda.time.ReadablePartial) localDate4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.LocalTime localTime11 = dateTimeFormatter9.parseLocalTime("2019-06-15T15");
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = instant12.toMutableDateTime(dateTimeZone13);
//        org.joda.time.Instant instant17 = instant12.withDurationAdded((long) '#', (int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime18 = instant12.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime19 = localTime11.toDateTime((org.joda.time.ReadableInstant) instant12);
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology20, dateTimeField22);
//        java.lang.String str25 = skipUndoDateTimeField23.getAsText(10L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField23.getAsShortText((int) (byte) 0, locale27);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipUndoDateTimeField23.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "1969-12-31T16");
//        boolean boolean32 = instant12.isSupported(dateTimeFieldType29);
//        try {
//            org.joda.time.LocalDate localDate34 = localDate4.withField(dateTimeFieldType29, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'halfdayOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970-01-01" + "'", str5.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(localTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "AM" + "'", str25.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "AM" + "'", str28.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 ()");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 287);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        java.lang.String str3 = localDate2.toString();
//        int int4 = localDate2.getDayOfMonth();
//        org.joda.time.LocalDate.Property property5 = localDate2.era();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField7 = property5.getLeapDurationField();
//        org.joda.time.LocalDate localDate8 = property5.withMinimumValue();
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) 10);
//        int int11 = localDate10.getYear();
//        org.joda.time.LocalDate localDate13 = localDate10.minusMonths((int) (short) 10);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.LocalDate localDate16 = localDate13.withPeriodAdded(readablePeriod14, 3);
//        org.joda.time.LocalDate.Property property17 = localDate13.dayOfYear();
//        org.joda.time.DateTime dateTime18 = localDate13.toDateTimeAtMidnight();
//        boolean boolean19 = localDate1.isAfter((org.joda.time.ReadablePartial) localDate13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01" + "'", str3.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1971) + "'", int11 == (-1971));
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.clockhourOfHalfday();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0, 1969, (-1), 1970, (int) (short) -1, (org.joda.time.Chronology) julianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(15, (int) (short) 0, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
//        java.lang.String str4 = skipUndoDateTimeField3.getName();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, (int) (byte) 1);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField12 = julianChronology11.weeks();
//        org.joda.time.DurationField durationField13 = julianChronology11.months();
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
//        java.lang.String str15 = localDate14.toString();
//        int int16 = localDate14.getDayOfMonth();
//        org.joda.time.LocalDate.Property property17 = localDate14.era();
//        org.joda.time.LocalDate localDate18 = property17.withMaximumValue();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate();
//        java.lang.String str20 = localDate19.toString();
//        int int21 = localDate19.getDayOfMonth();
//        org.joda.time.LocalDate.Property property22 = localDate19.era();
//        org.joda.time.LocalDate localDate23 = property22.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField24 = property22.getLeapDurationField();
//        org.joda.time.LocalDate localDate25 = property22.withMinimumValue();
//        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) (byte) 10);
//        int int28 = localDate27.getYear();
//        org.joda.time.LocalDate localDate30 = localDate27.minusMonths((int) (short) 10);
//        boolean boolean31 = localDate18.isEqual((org.joda.time.ReadablePartial) localDate30);
//        int[] intArray33 = julianChronology11.get((org.joda.time.ReadablePartial) localDate18, 2000L);
//        try {
//            int[] intArray35 = skipUndoDateTimeField3.add((org.joda.time.ReadablePartial) localDate6, (-2019), intArray33, (-1969));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2019");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "halfdayOfDay" + "'", str4.equals("halfdayOfDay"));
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-01" + "'", str15.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01" + "'", str20.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1971) + "'", int28 == (-1971));
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(intArray33);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        try {
//            int int30 = unsupportedDateTimeField28.getMinimumValue((-62167391999903L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        boolean boolean10 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate9);
//        org.joda.time.LocalDate.Property property11 = localDate6.centuryOfEra();
//        org.joda.time.LocalDate localDate12 = property11.roundFloorCopy();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate12);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime(dateTimeZone4);
        org.joda.time.Instant instant8 = instant3.withDurationAdded((long) '#', (int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = instant3.toMutableDateTimeISO();
        long long10 = instant3.getMillis();
        org.joda.time.Instant instant12 = instant3.withMillis(11L);
        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) instant12);
        org.joda.time.Instant instant15 = instant12.plus((long) 3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970-W01" + "'", str13.equals("1970-W01"));
        org.junit.Assert.assertNotNull(instant15);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        java.lang.String str3 = localDate2.toString();
//        int int4 = localDate2.getDayOfMonth();
//        org.joda.time.LocalDate.Property property5 = localDate2.era();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField7 = property5.getLeapDurationField();
//        org.joda.time.LocalDate localDate8 = property5.withMinimumValue();
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) 10);
//        int int11 = localDate10.getYear();
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        int int15 = dateTimeZone13.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime16 = localDate10.toDateTimeAtStartOfDay(dateTimeZone13);
//        org.joda.time.Chronology chronology17 = gregorianChronology0.withZone(dateTimeZone13);
//        long long20 = dateTimeZone13.adjustOffset((long) 'a', false);
//        boolean boolean22 = dateTimeZone13.isStandardOffset((long) '#');
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01" + "'", str3.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1971) + "'", int11 == (-1971));
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalTime localTime3 = dateTimeFormatter1.parseLocalTime("2019-06-15T15");
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = instant4.toMutableDateTime(dateTimeZone5);
        org.joda.time.Instant instant9 = instant4.withDurationAdded((long) '#', (int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime10 = instant4.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = localTime3.toDateTime((org.joda.time.ReadableInstant) instant4);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, dateTimeField14);
        java.lang.String str17 = skipUndoDateTimeField15.getAsText(10L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField15.getAsShortText((int) (byte) 0, locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipUndoDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "1969-12-31T16");
        boolean boolean24 = instant4.isSupported(dateTimeFieldType21);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(localTime3);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AM" + "'", str20.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks((int) (byte) 1);
//        org.joda.time.LocalDate.Property property11 = localDate8.yearOfEra();
//        org.joda.time.LocalDate.Property property12 = localDate8.weekOfWeekyear();
//        int int13 = localDate8.size();
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        boolean boolean16 = julianChronology14.equals((java.lang.Object) (-1));
//        boolean boolean17 = localDate8.equals((java.lang.Object) (-1));
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, (int) (byte) 1);
//        int int23 = localDate8.compareTo((org.joda.time.ReadablePartial) localDate22);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMillisOfDay((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime4.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime();
        try {
            org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime4, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
//        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
//        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
//        java.lang.String str8 = skipUndoDateTimeField3.getAsText((long) (byte) 10);
//        boolean boolean9 = skipUndoDateTimeField3.isLenient();
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate();
//        java.lang.String str11 = localDate10.toString();
//        int int12 = localDate10.getDayOfMonth();
//        org.joda.time.LocalDate.Property property13 = localDate10.era();
//        org.joda.time.LocalDate localDate14 = property13.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField15 = property13.getLeapDurationField();
//        org.joda.time.LocalDate localDate16 = property13.withMinimumValue();
//        org.joda.time.LocalDate localDate18 = localDate16.minusWeeks((int) (byte) 10);
//        int int19 = localDate18.getYear();
//        org.joda.time.LocalDate localDate21 = localDate18.minusMonths((int) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
//        boolean boolean23 = localDate21.isSupported(dateTimeFieldType22);
//        int int24 = skipUndoDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.LocalDate localDate26 = localDate21.withYearOfCentury(22);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AM" + "'", str8.equals("AM"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-01-01" + "'", str11.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNull(durationField15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1971) + "'", int19 == (-1971));
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(localDate26);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32) + "'", int1 == (-32));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        long long3 = property2.remainder();
        org.joda.time.DateTime dateTime5 = property2.addWrapFieldToCopy(1);
        org.joda.time.DateTime dateTime7 = property2.setCopy(12);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withMonthOfYear((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        java.lang.Number number24 = illegalFieldValueException23.getUpperBound();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (byte) 10 + "'", number24.equals((byte) 10));
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) chronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology5);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 ()");
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField21 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        org.joda.time.DateTime.Property property7 = dateTime5.millisOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.yearOfEra();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks((int) (byte) 1);
//        org.joda.time.LocalDate.Property property11 = localDate8.yearOfEra();
//        org.joda.time.LocalDate localDate12 = property11.withMinimumValue();
//        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((-2020));
//        java.util.Locale locale16 = null;
//        try {
//            java.lang.String str17 = localDate12.toString("AM", locale16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) '4', 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfWeek(959);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendLiteral("-1970");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
//        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
//        long long3 = property2.remainder();
//        org.joda.time.DateTime dateTime5 = property2.setCopy(2);
//        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate();
//        java.lang.String str8 = localDate7.toString();
//        int int9 = localDate7.getDayOfMonth();
//        org.joda.time.LocalDate.Property property10 = localDate7.era();
//        org.joda.time.LocalDate localDate11 = property10.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField12 = property10.getLeapDurationField();
//        org.joda.time.LocalDate localDate13 = property10.withMinimumValue();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray14 = localDate13.getFieldTypes();
//        org.joda.time.DateTime dateTime15 = dateTime5.withFields((org.joda.time.ReadablePartial) localDate13);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-06-15" + "'", str8.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNull(durationField12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray14);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMaximumValue();
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField3.getAsShortText((long) 'a', locale6);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AM" + "'", str7.equals("AM"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1, (int) (byte) 1, (int) (short) 10, (int) (short) 100, (-28800000), (int) 'a', 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendYear(4, (int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.append(dateTimePrinter10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder3.appendWeekyear(100, 1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate();
//        java.lang.String str3 = localDate2.toString();
//        int int4 = localDate2.getDayOfMonth();
//        org.joda.time.LocalDate.Property property5 = localDate2.era();
//        org.joda.time.LocalDate localDate6 = property5.roundHalfCeilingCopy();
//        java.lang.String str7 = property5.getAsString();
//        org.joda.time.LocalDate localDate8 = property5.roundHalfCeilingCopy();
//        long long10 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate8, 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019-06-15" + "'", str3.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62135596800000L) + "'", long10 == (-62135596800000L));
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate();
//        java.lang.String str30 = localDate29.toString();
//        int int31 = localDate29.getDayOfMonth();
//        org.joda.time.LocalDate localDate33 = localDate29.withYear((int) (short) 10);
//        org.joda.time.LocalDate localDate35 = localDate33.withDayOfMonth(4);
//        org.joda.time.DateTime dateTime36 = localDate33.toDateTimeAtMidnight();
//        java.util.Locale locale38 = null;
//        try {
//            java.lang.String str39 = unsupportedDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate33, (int) (short) 100, locale38);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019-06-15" + "'", str30.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(dateTime36);
//    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfYear();
//        java.lang.String str3 = property2.getAsText();
//        org.joda.time.DateTime dateTime4 = property2.roundCeilingCopy();
//        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime6 = dateTime5.withEarlierOffsetAtOverlap();
//        int int7 = dateTime5.getDayOfMonth();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 593, 960, 20, (int) (short) -1, 35, 23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        java.lang.String str1 = buddhistChronology0.toString();
//        org.joda.time.DurationField durationField2 = buddhistChronology0.hours();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
//        org.joda.time.Chronology chronology5 = buddhistChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = buddhistChronology0.withUTC();
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(0L);
//        org.joda.time.Partial partial9 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = partial9.getFormatter();
//        boolean boolean11 = buddhistChronology0.equals((java.lang.Object) partial9);
//        java.lang.String str12 = partial9.toStringList();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[year=1970, monthOfYear=1, dayOfMonth=1]" + "'", str12.equals("[year=1970, monthOfYear=1, dayOfMonth=1]"));
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
//        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
//        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
//        java.lang.String str8 = skipUndoDateTimeField3.getAsText((long) (byte) 10);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        boolean boolean11 = localDate9.equals((java.lang.Object) "2019-W24-6");
//        org.joda.time.LocalDate.Property property12 = localDate9.monthOfYear();
//        int int13 = localDate9.getYearOfCentury();
//        org.joda.time.LocalDate localDate15 = localDate9.minusDays((int) (short) 1);
//        java.lang.String str16 = localDate9.toString();
//        java.util.Locale locale18 = null;
//        try {
//            java.lang.String str19 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate9, 941, locale18);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 941");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AM" + "'", str8.equals("AM"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019-06-15" + "'", str16.equals("2019-06-15"));
//    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.withMaximumValue();
//        org.joda.time.LocalDate.Property property5 = localDate4.year();
//        org.joda.time.LocalDate localDate6 = property5.roundCeilingCopy();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("2019-06-15T15");
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime(dateTimeZone4);
        org.joda.time.Instant instant8 = instant3.withDurationAdded((long) '#', (int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = instant3.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime10 = localTime2.toDateTime((org.joda.time.ReadableInstant) instant3);
        boolean boolean11 = instant3.isAfterNow();
        boolean boolean12 = instant3.isAfterNow();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime3.plusMinutes(0);
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
//        int int4 = dateTime3.getDayOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 166 + "'", int4 == 166);
//        org.junit.Assert.assertNotNull(property5);
//    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
//        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
//        int int3 = dateTime2.getMillisOfSecond();
//        int int4 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
//        java.util.Locale locale7 = null;
//        try {
//            org.joda.time.DateTime dateTime8 = property5.setCopy("-1970", locale7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1970 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertNotNull(property5);
//    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        java.lang.String str24 = illegalFieldValueException23.toString();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1561680000001 for halfdayOfDay must be in the range [-1,10]" + "'", str24.equals("org.joda.time.IllegalFieldValueException: Value 1561680000001 for halfdayOfDay must be in the range [-1,10]"));
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField4.getAsText(0, locale6);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField4, 35);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField4.getRangeDurationField();
        try {
            long long15 = skipUndoDateTimeField4.set((long) 'a', "1969365");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969365\" for halfdayOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AM" + "'", str7.equals("AM"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        int int7 = localDate6.getCenturyOfEra();
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        boolean boolean10 = localDate8.equals((java.lang.Object) "2019-W24-6");
//        org.joda.time.LocalDate.Property property11 = localDate8.monthOfYear();
//        boolean boolean12 = localDate6.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField14 = localDate8.getField(0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField4.getAsText(0, locale6);
        java.util.Locale locale8 = null;
        int int9 = skipUndoDateTimeField4.getMaximumTextLength(locale8);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField4, 35);
        long long14 = skipDateTimeField11.addWrapField((long) 100, 6);
        long long17 = skipDateTimeField11.add((long) 22, (int) (short) 10);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AM" + "'", str7.equals("AM"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 432000022L + "'", long17 == 432000022L);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
//        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate();
//        java.lang.String str4 = localDate3.toString();
//        org.joda.time.LocalDate.Property property5 = localDate3.era();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.halfdayOfDay();
//        long long12 = julianChronology6.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
//        org.joda.time.DurationField durationField13 = julianChronology6.centuries();
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.Chronology chronology17 = julianChronology6.withZone(dateTimeZone15);
//        org.joda.time.DateMidnight dateMidnight18 = localDate3.toDateMidnight(dateTimeZone15);
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((java.lang.Object) 2000L, dateTimeZone15);
//        java.util.TimeZone timeZone20 = dateTimeZone15.toTimeZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter0.withZone(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeParser1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-15" + "'", str4.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62167391999903L) + "'", long12 == (-62167391999903L));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateMidnight18);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendClockhourOfHalfday(960);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTimeZoneOffset("21", true, 941, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property5 = dateTime4.hourOfDay();
        long long6 = property5.remainder();
        org.joda.time.DateTime dateTime7 = property5.withMaximumValue();
        java.util.GregorianCalendar gregorianCalendar8 = dateTime7.toGregorianCalendar();
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianCalendar8);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendYear(4, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendHourOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendPattern("1");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfDay(5, (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = dateTime2.isSupported(dateTimeFieldType3);
//        int int5 = dateTime2.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateMidnight dateMidnight4 = dateTime3.toDateMidnight();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime3.plusHours(6);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        boolean boolean2 = localDate0.equals((java.lang.Object) "2019-W24-6");
        org.joda.time.LocalDate localDate4 = localDate0.withCenturyOfEra(6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "1969365", (int) '#', (int) (short) 0);
        long long11 = fixedDateTimeZone9.nextTransition((long) 0);
        org.joda.time.DateMidnight dateMidnight12 = localDate0.toDateMidnight((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.util.TimeZone timeZone13 = fixedDateTimeZone9.toTimeZone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertNotNull(timeZone13);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
//        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime1.withMinuteOfHour(0);
//        int int5 = dateTime1.getDayOfWeek();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        org.joda.time.LocalDate.Property property2 = localDate0.era();
//        org.joda.time.LocalDate localDate3 = property2.withMinimumValue();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int8 = gregorianChronology7.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology4, dateTimeField9);
//        int int12 = skipDateTimeField10.get(0L);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology13, dateTimeField15);
//        java.lang.String str18 = skipUndoDateTimeField16.getAsText(10L);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipUndoDateTimeField16.getAsShortText((int) (byte) 0, locale20);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = skipUndoDateTimeField16.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType22);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone29 = julianChronology28.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = buddhistChronology30.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField31);
//        try {
//            int int33 = localDate3.get(dateTimeFieldType22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'halfdayOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "AM" + "'", str18.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "AM" + "'", str21.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(julianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(buddhistChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16", "America/Los_Angeles", 31, 35);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 12");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = iSOChronology1.withUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType4 = localDate0.getFieldType(19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 19");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        java.lang.String str2 = localDate1.toString();
//        org.joda.time.LocalDate.Property property3 = localDate1.era();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.halfdayOfDay();
//        long long10 = julianChronology4.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
//        org.joda.time.DurationField durationField11 = julianChronology4.centuries();
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        org.joda.time.Chronology chronology15 = julianChronology4.withZone(dateTimeZone13);
//        org.joda.time.DateMidnight dateMidnight16 = localDate1.toDateMidnight(dateTimeZone13);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((java.lang.Object) 2000L, dateTimeZone13);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone13.getName(43199999L, locale19);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15" + "'", str2.equals("2019-06-15"));
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62167391999903L) + "'", long10 == (-62167391999903L));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateMidnight16);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(2000);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime(dateTimeZone4);
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "2019-06-15", (int) (byte) 100);
        boolean boolean9 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-101) + "'", int8 == (-101));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfWeek(19);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfSecond((-28800000), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        int int13 = dateTimeZone11.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtStartOfDay(dateTimeZone11);
//        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16", "America/Los_Angeles", 31, 35);
//        org.joda.time.DateTime dateTime22 = dateTime15.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        java.lang.String str24 = fixedDateTimeZone21.getName(0L);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone21, (long) 0, 35);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2019) + "'", int9 == (-2019));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.031" + "'", str24.equals("+00:00:00.031"));
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        int int3 = dateTime2.getMillisOfSecond();
        java.util.Locale locale4 = null;
        java.util.Calendar calendar5 = dateTime2.toCalendar(locale4);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.fromCalendarFields(calendar5);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(calendar5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendYear(4, (int) 'a');
        boolean boolean9 = dateTimeFormatterBuilder3.canBuildFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder3.toFormatter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendCenturyOfEra((-101), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone4);
        try {
            long long12 = zonedChronology6.getDateTimeMillis((long) 1969, (int) '4', 5, 2019, (-32));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(zonedChronology6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendPattern("");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.withMaximumValue();
//        org.joda.time.LocalDate.Property property5 = localDate4.year();
//        org.joda.time.LocalDate localDate7 = localDate4.plusWeeks(4);
//        java.lang.String str8 = localDate7.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-15" + "'", str1.equals("2019-06-15"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-07-13" + "'", str8.equals("2019-07-13"));
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendDayOfYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
//        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
//        long long3 = property2.remainder();
//        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
//        org.joda.time.DateTime dateTime5 = property2.roundHalfEvenCopy();
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        int int10 = dateTime7.getYear();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(320L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendTimeZoneOffset("1969353", true, (-32), 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.centuryOfEra();
        org.joda.time.Chronology chronology6 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        int int3 = dateTime2.getMillisOfSecond();
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        java.lang.Class<?> wildcardClass5 = dateTime2.getClass();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        int int3 = dateTime2.getMillisOfSecond();
        java.util.Locale locale4 = null;
        java.util.Calendar calendar5 = dateTime2.toCalendar(locale4);
        org.joda.time.DateTime dateTime7 = dateTime2.plusHours(959);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(calendar5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("-1970");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-1970\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        java.lang.String str2 = localDate1.toString();
//        int int3 = localDate1.getDayOfMonth();
//        org.joda.time.LocalDate.Property property4 = localDate1.era();
//        org.joda.time.LocalDate localDate5 = property4.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField6 = property4.getLeapDurationField();
//        org.joda.time.LocalDate localDate7 = property4.withMinimumValue();
//        org.joda.time.LocalDate localDate9 = localDate7.minusWeeks((int) (byte) 10);
//        int int10 = localDate9.getYear();
//        java.util.TimeZone timeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
//        int int14 = dateTimeZone12.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime15 = localDate9.toDateTimeAtStartOfDay(dateTimeZone12);
//        java.lang.String str16 = dateTimeZone12.getID();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, 4);
//        org.joda.time.Chronology chronology19 = copticChronology0.withZone(dateTimeZone12);
//        java.lang.String str20 = copticChronology0.toString();
//        try {
//            long long25 = copticChronology0.getDateTimeMillis((int) (short) 10, 31, (-1), (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,13]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-01-01" + "'", str2.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNull(durationField6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1971) + "'", int10 == (-1971));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "CopticChronology[UTC]" + "'", str20.equals("CopticChronology[UTC]"));
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        int int4 = dateTimeZone2.getOffsetFromLocal((long) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone2);
//        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter0.getPrinter();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNull(dateTimePrinter6);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        boolean boolean23 = iSOChronology21.equals((java.lang.Object) dateTimeFormatter22);
//        java.lang.String str24 = iSOChronology21.toString();
//        org.joda.time.Partial partial25 = new org.joda.time.Partial(dateTimeFieldType18, 0, (org.joda.time.Chronology) iSOChronology21);
//        org.joda.time.Chronology chronology26 = partial25.getChronology();
//        java.lang.String str27 = partial25.toStringList();
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.Partial partial29 = partial25.minus(readablePeriod28);
//        org.joda.time.Instant instant30 = new org.joda.time.Instant();
//        org.joda.time.Instant instant32 = instant30.withMillis((long) 22);
//        boolean boolean33 = partial29.isMatch((org.joda.time.ReadableInstant) instant30);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[UTC]" + "'", str24.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "[halfdayOfDay=0]" + "'", str27.equals("[halfdayOfDay=0]"));
//        org.junit.Assert.assertNotNull(partial29);
//        org.junit.Assert.assertNotNull(instant32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
//        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
//        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendMinuteOfDay((int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMillisOfSecond(57600010);
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField21);
//        int int24 = skipDateTimeField22.get(0L);
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = julianChronology26.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField(chronology25, dateTimeField27);
//        java.lang.String str30 = skipUndoDateTimeField28.getAsText(10L);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipUndoDateTimeField28.getAsShortText((int) (byte) 0, locale32);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipUndoDateTimeField28.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField22, dateTimeFieldType34);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder13.appendFixedSignedDecimal(dateTimeFieldType34, 100);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField38 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType34);
//        long long40 = zeroIsMaxDateTimeField38.roundHalfFloor((long) 941);
//        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate();
//        boolean boolean43 = localDate41.equals((java.lang.Object) "2019-W24-6");
//        org.joda.time.LocalDate localDate45 = localDate41.withCenturyOfEra(6);
//        int int46 = zeroIsMaxDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "AM" + "'", str30.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AM" + "'", str33.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DurationField durationField2 = julianChronology0.millis();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        java.lang.String str29 = unsupportedDateTimeField28.toString();
//        long long32 = unsupportedDateTimeField28.getDifferenceAsLong(0L, (long) 24);
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate();
//        java.lang.String str34 = localDate33.toString();
//        int int35 = localDate33.getDayOfMonth();
//        org.joda.time.LocalDate.Property property36 = localDate33.era();
//        org.joda.time.LocalDate localDate37 = property36.withMaximumValue();
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate();
//        java.lang.String str39 = localDate38.toString();
//        int int40 = localDate38.getDayOfMonth();
//        org.joda.time.LocalDate.Property property41 = localDate38.era();
//        org.joda.time.LocalDate localDate42 = property41.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField43 = property41.getLeapDurationField();
//        org.joda.time.LocalDate localDate44 = property41.withMinimumValue();
//        org.joda.time.LocalDate localDate46 = localDate44.minusWeeks((int) (byte) 10);
//        int int47 = localDate46.getYear();
//        org.joda.time.LocalDate localDate49 = localDate46.minusMonths((int) (short) 10);
//        boolean boolean50 = localDate37.isEqual((org.joda.time.ReadablePartial) localDate49);
//        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate();
//        java.lang.String str52 = localDate51.toString();
//        int int53 = localDate51.getDayOfMonth();
//        org.joda.time.LocalDate.Property property54 = localDate51.era();
//        org.joda.time.LocalDate localDate55 = property54.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField56 = property54.getLeapDurationField();
//        org.joda.time.LocalDate localDate57 = property54.withMinimumValue();
//        org.joda.time.LocalDate localDate59 = localDate57.minusWeeks((int) (byte) 10);
//        org.joda.time.LocalDate localDate61 = localDate59.plusWeeks((int) (byte) 1);
//        org.joda.time.LocalDate.Property property62 = localDate59.yearOfEra();
//        org.joda.time.LocalDate localDate63 = localDate49.withFields((org.joda.time.ReadablePartial) localDate59);
//        try {
//            int int64 = unsupportedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) localDate63);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-01-01" + "'", str34.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1970-01-01" + "'", str39.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNull(durationField43);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1971) + "'", int47 == (-1971));
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1970-01-01" + "'", str52.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertNull(durationField56);
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertNotNull(localDate59);
//        org.junit.Assert.assertNotNull(localDate61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(localDate63);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.LocalTime localTime3 = dateTimeFormatter1.parseLocalTime("2019-06-15T15");
        java.lang.Object obj4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj4);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.weekOfWeekyear();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime5.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        int int12 = dateTimeFormatter1.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "2019-06-15", (int) (byte) 100);
        try {
            org.joda.time.Instant instant13 = org.joda.time.Instant.parse("19691231", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19691231\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(localTime3);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-101) + "'", int12 == (-101));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateMidnight dateMidnight4 = dateTime3.toDateMidnight();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.yearOfEra();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime8 = property6.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField3);
//        java.lang.String str6 = skipUndoDateTimeField4.getAsText(10L);
//        org.joda.time.DateTimeField dateTimeField7 = skipUndoDateTimeField4.getWrappedField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTimeZoneShortName(strMap11);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendMinuteOfDay((int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(57600010);
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int21 = gregorianChronology20.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, dateTimeField22);
//        int int25 = skipDateTimeField23.get(0L);
//        org.joda.time.Chronology chronology26 = null;
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField(chronology26, dateTimeField28);
//        java.lang.String str31 = skipUndoDateTimeField29.getAsText(10L);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipUndoDateTimeField29.getAsShortText((int) (byte) 0, locale33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField29.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType35);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder14.appendFixedSignedDecimal(dateTimeFieldType35, 100);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType35);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, (java.lang.Number) 25200032L, "0");
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AM" + "'", str6.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "AM" + "'", str31.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "AM" + "'", str34.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.Instant instant3 = instant1.toInstant();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitYear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendYear((int) (byte) 1, 3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendTwoDigitWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        boolean boolean23 = iSOChronology21.equals((java.lang.Object) dateTimeFormatter22);
//        java.lang.String str24 = iSOChronology21.toString();
//        org.joda.time.Partial partial25 = new org.joda.time.Partial(dateTimeFieldType18, 0, (org.joda.time.Chronology) iSOChronology21);
//        org.joda.time.Chronology chronology26 = partial25.getChronology();
//        java.lang.String str27 = partial25.toStringList();
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.Partial partial29 = partial25.minus(readablePeriod28);
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.Partial partial31 = partial29.plus(readablePeriod30);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[UTC]" + "'", str24.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "[halfdayOfDay=0]" + "'", str27.equals("[halfdayOfDay=0]"));
//        org.junit.Assert.assertNotNull(partial29);
//        org.junit.Assert.assertNotNull(partial31);
//    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        boolean boolean10 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate9);
//        org.joda.time.LocalDate.Property property11 = localDate6.weekyear();
//        java.lang.String str12 = property11.toString();
//        org.joda.time.LocalDate localDate13 = property11.roundFloorCopy();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[weekyear]" + "'", str12.equals("Property[weekyear]"));
//        org.junit.Assert.assertNotNull(localDate13);
//    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate();
//        boolean boolean31 = localDate29.equals((java.lang.Object) "2019-W24-6");
//        java.util.Locale locale33 = null;
//        try {
//            java.lang.String str34 = unsupportedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate29, (-32), locale33);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        boolean boolean2 = localDate0.equals((java.lang.Object) "2019-W24-6");
        org.joda.time.LocalDate localDate4 = localDate0.withCenturyOfEra(6);
        org.joda.time.LocalDate.Property property5 = localDate0.dayOfMonth();
        org.joda.time.LocalDate.Property property6 = localDate0.weekyear();
        org.joda.time.LocalDate localDate7 = property6.getLocalDate();
        java.util.Locale locale8 = null;
        int int9 = property6.getMaximumTextLength(locale8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        int int31 = unsupportedDateTimeField28.getDifference(32L, 1L);
//        try {
//            java.lang.String str33 = unsupportedDateTimeField28.getAsShortText((-28800011L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate();
//        java.lang.String str2 = localDate1.toString();
//        org.joda.time.LocalDate.Property property3 = localDate1.era();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.halfdayOfDay();
//        long long10 = julianChronology4.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
//        org.joda.time.DurationField durationField11 = julianChronology4.centuries();
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        org.joda.time.Chronology chronology15 = julianChronology4.withZone(dateTimeZone13);
//        org.joda.time.DateMidnight dateMidnight16 = localDate1.toDateMidnight(dateTimeZone13);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((java.lang.Object) 2000L, dateTimeZone13);
//        java.util.TimeZone timeZone18 = dateTimeZone13.toTimeZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter19.withPivotYear((java.lang.Integer) (-1));
//        org.joda.time.DateTimeZone dateTimeZone22 = dateTimeFormatter19.getZone();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) ' ');
//        org.joda.time.DateTime.Property property25 = dateTime24.dayOfYear();
//        java.lang.String str26 = property25.getAsText();
//        org.joda.time.DateTime dateTime27 = property25.roundCeilingCopy();
//        org.joda.time.DateTime dateTime29 = dateTime27.plusYears(3);
//        java.lang.String str30 = dateTimeFormatter19.print((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime27);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-01-01" + "'", str2.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62167391999903L) + "'", long10 == (-62167391999903L));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateMidnight16);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970002" + "'", str30.equals("1970002"));
//        org.junit.Assert.assertNotNull(gJChronology31);
//    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        org.joda.time.LocalDate localDate11 = localDate8.minusMonths((int) (short) 10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.LocalDate localDate14 = localDate11.withPeriodAdded(readablePeriod12, 3);
//        org.joda.time.LocalDate localDate16 = localDate11.minusWeeks(960);
//        org.joda.time.LocalDate.Property property17 = localDate16.weekOfWeekyear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1971) + "'", int9 == (-1971));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime3.plusWeeks(57600010);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.String str9 = dateTime7.toString(dateTimeFormatter8);
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "00:00:00" + "'", str9.equals("00:00:00"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(0L);
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        try {
            org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) partial2, dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.Partial");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, 959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 959 + "'", int2 == 959);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        java.lang.String str29 = unsupportedDateTimeField28.toString();
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate();
//        java.lang.String str31 = localDate30.toString();
//        int int32 = localDate30.getDayOfMonth();
//        org.joda.time.LocalDate.Property property33 = localDate30.era();
//        org.joda.time.LocalDate localDate34 = property33.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField35 = property33.getLeapDurationField();
//        org.joda.time.LocalDate localDate36 = property33.withMinimumValue();
//        org.joda.time.Chronology chronology37 = null;
//        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField(chronology37, dateTimeField39);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = skipUndoDateTimeField40.getAsText(0, locale42);
//        java.util.Locale locale44 = null;
//        int int45 = skipUndoDateTimeField40.getMaximumTextLength(locale44);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.LocalTime localTime48 = dateTimeFormatter46.parseLocalTime("2019-06-15T15");
//        org.joda.time.DateTimeField[] dateTimeFieldArray49 = localTime48.getFields();
//        int[] intArray56 = new int[] { (short) 10, 12, (byte) -1, (byte) 10, (short) -1 };
//        int[] intArray58 = skipUndoDateTimeField40.set((org.joda.time.ReadablePartial) localTime48, 0, intArray56, 0);
//        try {
//            int int59 = unsupportedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) localDate36, intArray56);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970-01-01" + "'", str31.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNull(durationField35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(julianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "AM" + "'", str43.equals("AM"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(localTime48);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray49);
//        org.junit.Assert.assertNotNull(intArray56);
//        org.junit.Assert.assertNotNull(intArray58);
//    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate();
//        boolean boolean10 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate9);
//        org.joda.time.LocalDate.Property property11 = localDate6.weekyear();
//        org.joda.time.LocalDate localDate13 = localDate6.minusDays(0);
//        int int14 = localDate6.getYearOfEra();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1971 + "'", int14 == 1971);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendYear(4, (int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.append(dateTimePrinter10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (short) 10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder11.appendTimeZoneOffset("", "GJChronology[America/Los_Angeles]", true, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        int int9 = localDate8.getYear();
//        org.joda.time.LocalDate localDate11 = localDate8.minusMonths((int) (short) 10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.LocalDate localDate14 = localDate11.withPeriodAdded(readablePeriod12, 3);
//        org.joda.time.LocalDate.Property property15 = localDate11.dayOfYear();
//        org.joda.time.DateTime dateTime16 = localDate11.toDateTimeAtMidnight();
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTimeISO();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1971) + "'", int9 == (-1971));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        int int4 = dateTimeZone2.getOffsetFromLocal((long) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone2);
//        java.lang.Integer int6 = dateTimeFormatter0.getPivotYear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNull(int6);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime.Property property2 = dateTime1.hourOfDay();
        long long3 = property2.remainder();
        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.LocalDate localDate6 = dateTime4.toLocalDate();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
//        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
//        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, dateTimeField12);
//        int int15 = skipDateTimeField13.get(0L);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = skipDateTimeField13.getAsText(0, locale17);
//        long long20 = skipDateTimeField13.remainder((long) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap22 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendTimeZoneShortName(strMap22);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder21.appendMinuteOfDay((int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendMillisOfSecond(57600010);
//        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = julianChronology28.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology28.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int32 = gregorianChronology31.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology28, dateTimeField33);
//        int int36 = skipDateTimeField34.get(0L);
//        org.joda.time.Chronology chronology37 = null;
//        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField(chronology37, dateTimeField39);
//        java.lang.String str42 = skipUndoDateTimeField40.getAsText(10L);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = skipUndoDateTimeField40.getAsShortText((int) (byte) 0, locale44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = skipUndoDateTimeField40.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField34, dateTimeFieldType46);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder25.appendFixedSignedDecimal(dateTimeFieldType46, 100);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField51 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField13, dateTimeFieldType46, (int) 'a');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField52 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType46);
//        org.joda.time.chrono.JulianChronology julianChronology54 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField55 = julianChronology54.halfdayOfDay();
//        long long60 = julianChronology54.getDateTimeMillis((-1), (int) (short) 1, (int) (short) 1, (int) 'a');
//        org.joda.time.DurationField durationField61 = julianChronology54.centuries();
//        org.joda.time.chrono.JulianChronology julianChronology62 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone63 = julianChronology62.getZone();
//        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now(dateTimeZone63);
//        org.joda.time.Chronology chronology65 = julianChronology54.withZone(dateTimeZone63);
//        try {
//            org.joda.time.Partial partial66 = new org.joda.time.Partial(dateTimeFieldType46, (int) (byte) 100, chronology65);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for halfdayOfDay must not be larger than 1");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(julianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "AM" + "'", str42.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "AM" + "'", str45.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(julianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-62167391999903L) + "'", long60 == (-62167391999903L));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(julianChronology62);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(chronology65);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withHourOfDay(0);
        org.joda.time.DateTime dateTime6 = dateTime2.withYearOfEra(959);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long4 = gJChronology0.add((long) 166, (long) 2000, 9);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 18166L + "'", long4 == 18166L);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        org.joda.time.DurationField durationField7 = skipDateTimeField6.getDurationField();
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        java.lang.String str9 = localDate8.toString();
//        int int10 = localDate8.getDayOfMonth();
//        org.joda.time.LocalDate.Property property11 = localDate8.era();
//        org.joda.time.LocalDate localDate12 = property11.roundHalfCeilingCopy();
//        java.lang.String str13 = property11.getAsString();
//        org.joda.time.LocalDate localDate14 = property11.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField(chronology16, dateTimeField18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField19.getAsText(0, locale21);
//        java.util.Locale locale23 = null;
//        int int24 = skipUndoDateTimeField19.getMaximumTextLength(locale23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.LocalTime localTime27 = dateTimeFormatter25.parseLocalTime("2019-06-15T15");
//        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localTime27.getFields();
//        int[] intArray35 = new int[] { (short) 10, 12, (byte) -1, (byte) 10, (short) -1 };
//        int[] intArray37 = skipUndoDateTimeField19.set((org.joda.time.ReadablePartial) localTime27, 0, intArray35, 0);
//        try {
//            int[] intArray39 = skipDateTimeField6.addWrapField((org.joda.time.ReadablePartial) localDate14, (int) '#', intArray35, 1970);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01" + "'", str9.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AM" + "'", str22.equals("AM"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(localTime27);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertNotNull(intArray37);
//    }
//}

