import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 10.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test004");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560629643324L + "'", long0 == 1560629643324L);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Period period6 = period2.plusHours((int) (short) 100);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType8 = periodType7.withSecondsRemoved();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) (short) 100, periodType8, chronology11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011576d + "'", double1 == 2440587.5000011576d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1.0f), "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        try {
            long long10 = iSOChronology1.getDateTimeMillis((int) (short) 100, 0, 10, (int) 'a', 100, (int) (short) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) -1, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4L) + "'", long2 == (-4L));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        try {
            org.joda.time.Period period9 = period7.minusHours((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDay();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((int) (byte) 0, 3, 0, (int) 'a', 3, 0, (-1), (int) (byte) 100, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'hours'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        org.joda.time.Period period7 = new org.joda.time.Period(1L, (long) '#', periodType4);
        try {
            org.joda.time.Period period9 = period7.withSeconds((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.eras();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = iSOChronology5.eras();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField7 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField3, durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        org.joda.time.Period period7 = new org.joda.time.Period(1L, (long) '#', periodType4);
        int int8 = periodType4.size();
        org.joda.time.PeriodType periodType9 = periodType4.withWeeksRemoved();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = periodType9.indexOf(durationFieldType10);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType9, (int) ' ', (int) (byte) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationFrom(readableInstant3);
        int int5 = period2.getWeeks();
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (byte) 100);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 0, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-4L), "PT1H0.002S");
        org.joda.time.IllegalInstantException illegalInstantException5 = new org.joda.time.IllegalInstantException((long) (byte) 1, "hi!");
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException5);
        java.lang.Throwable[] throwableArray7 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType9 = periodType8.withSecondsRemoved();
        try {
            org.joda.time.Period period10 = new org.joda.time.Period(0, (int) (short) 1, (-1), 10, (int) (short) 10, (-1), 1, (int) '4', periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("PT0.002S", (-1), (int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for PT0.002S must be in the range [10,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) '4', (int) (byte) -1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long9 = gregorianChronology1.getDateTimeMillis(10, 0, (int) (short) -1, 100, (int) (short) 1, (int) (short) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5);
        boolean boolean8 = period6.equals((java.lang.Object) 10L);
        org.joda.time.Period period10 = period6.withMinutes((int) (short) 0);
        boolean boolean12 = period10.equals((java.lang.Object) "PT1H0.002S");
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        try {
            org.joda.time.Period period6 = period4.plusSeconds(1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            int[] intArray5 = iSOChronology1.get(readablePartial3, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        java.lang.Class<?> wildcardClass2 = periodType1.getClass();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5);
        org.joda.time.Period period8 = period6.minusSeconds((int) '#');
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.Period period11 = period8.withField(durationFieldType9, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 10, 1560629643324L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560629643334L + "'", long2 == 1560629643334L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        try {
            long long13 = iSOChronology4.getDateTimeMillis((long) (byte) 0, (int) (short) 1, 100, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10.0d, (java.lang.Number) 1L, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.eras();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField4 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType5, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PeriodType[YearMonthDay]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PeriodType[YearMonthDay]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 100);
        java.io.OutputStream outputStream4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-4L), "PT1H0.002S");
        org.joda.time.IllegalInstantException illegalInstantException5 = new org.joda.time.IllegalInstantException((long) (byte) 1, "hi!");
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException5);
        java.lang.Throwable[] throwableArray7 = illegalInstantException5.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType7 = periodType6.withSecondsRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant4, readableInstant5, periodType6);
        org.joda.time.Period period9 = new org.joda.time.Period(1L, (long) '#', periodType6);
        int int10 = periodType6.size();
        org.joda.time.PeriodType periodType11 = periodType6.withWeeksRemoved();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Period period6 = period2.plusSeconds((int) (short) 100);
        org.joda.time.Period period8 = period2.withHours((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = period2.indexOf(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.Period period13 = period2.withFieldAdded(durationFieldType11, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        try {
            long long5 = durationField2.subtract(10L, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1560629643324L, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 151381075402428");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.era();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, 0, 0, 10);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        try {
            long long5 = durationField2.subtract(1560629643334L, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        try {
            long long5 = durationField2.subtract((long) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 1, (java.lang.Number) 0.0f, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("GregorianChronology[America/Los_Angeles]", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        try {
//            org.joda.time.Period period3 = new org.joda.time.Period((java.lang.Object) gregorianChronology1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1560629643334L, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 100);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("", 0, (int) (byte) 0, (int) (short) 1, '4', (int) '4', (int) '#', 0, true, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        int[] intArray3 = period2.getValues();
        org.joda.time.Period period5 = period2.plusSeconds(3);
        int int6 = period2.getMonths();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.ReadableInstant readableInstant0 = null;
        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5);
        boolean boolean8 = period6.equals((java.lang.Object) 10L);
        org.joda.time.Period period10 = period6.plusMinutes((int) ' ');
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        try {
            long long5 = durationField2.subtract((-4L), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period9 = period7.minusSeconds((int) '#');
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationFrom(readableInstant10);
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11, periodType12);
        org.joda.time.Duration duration14 = period13.toStandardDuration();
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(duration14);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 0, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField10, dateTimeFieldType11, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("hi!", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        long long11 = iSOChronology4.add((long) (byte) 1, (-1L), 0);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology4.weekyearOfCentury();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        boolean boolean8 = fixedDateTimeZone4.equals((java.lang.Object) 2440587.5d);
        java.lang.String str9 = fixedDateTimeZone4.getID();
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.era();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 3);
        java.lang.String str13 = fixedDateTimeZone9.getNameKey((long) (short) 1);
        int int15 = fixedDateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean22 = fixedDateTimeZone20.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime23 = null;
        boolean boolean24 = fixedDateTimeZone20.isLocalDateTimeGap(localDateTime23);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        long long27 = fixedDateTimeZone9.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone25, 1560629643334L);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.ReadablePartial readablePartial29 = null;
        try {
            long long31 = iSOChronology1.set(readablePartial29, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560629643334L + "'", long27 == 1560629643334L);
        org.junit.Assert.assertNotNull(zonedChronology28);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        java.util.Locale locale7 = null;
        try {
            long long8 = offsetDateTimeField4.set((long) (short) 1, "hi!", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Period period6 = period2.withHours(0);
        org.joda.time.Period period8 = period6.withHours((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (byte) 1, "hi!");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) ' ');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long9 = gregorianChronology1.getDateTimeMillis((int) (short) 10, (int) 'a', (int) (short) -1, (int) (byte) 10, (int) ' ', (int) (byte) 10, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter8 = null;
        java.lang.String str9 = period7.toString(periodFormatter8);
        org.joda.time.Period period11 = period7.plusHours((int) (short) 100);
        boolean boolean12 = periodType2.equals((java.lang.Object) period11);
        int int13 = period11.getWeeks();
        org.joda.time.Period period15 = period11.withMinutes((int) (byte) -1);
        org.joda.time.Period period17 = period11.minusSeconds((int) '#');
        org.joda.time.Days days18 = period11.toStandardDays();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0.002S" + "'", str9.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(days18);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(28800000L, (-4L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28800004L + "'", long2 == 28800004L);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        try {
//            long long8 = gregorianChronology1.getDateTimeMillis(100, (int) '#', (int) (short) -1, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period(0L, (long) '4', chronology4);
        org.joda.time.Period period7 = period5.withMonths((int) (byte) -1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("PT100.002S", (-100), 196, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for PT100.002S must be in the range [196,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(100);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder4.addCutover((int) '#', 'a', (int) (byte) 10, (int) 'a', (int) (byte) 100, true, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.Period period4 = period2.withSeconds(100);
        org.joda.time.Period period6 = period2.minusWeeks(0);
        org.joda.time.Period period8 = period6.withMonths((int) (byte) 10);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 3155760000032L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) '4', (-100), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Days days5 = period2.toStandardDays();
        org.joda.time.Period period7 = period2.withHours(0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(days5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.millisOfDay();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            int[] intArray7 = iSOChronology1.get(readablePartial5, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 0, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField11 = new org.joda.time.field.RemainderDateTimeField(dateTimeField8, dateTimeFieldType9, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "52");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDay]", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearMonthDay]" + "'", str3.equals("PeriodType[YearMonthDay]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PeriodType[YearMonthDay]" + "'", str5.equals("PeriodType[YearMonthDay]"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "PT0.002S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5);
        boolean boolean8 = period6.equals((java.lang.Object) 10L);
        org.joda.time.Period period10 = period6.plusWeeks(100);
        org.joda.time.Period period12 = period6.plusMonths((int) (short) 10);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.Period period5 = period3.withSeconds(100);
        org.joda.time.Duration duration6 = period5.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType12 = periodType11.withSecondsRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant9, readableInstant10, periodType11);
        org.joda.time.Period period14 = new org.joda.time.Period(1L, (long) '#', periodType11);
        int int15 = periodType11.size();
        org.joda.time.PeriodType periodType16 = periodType11.withWeeksRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6, periodType11);
        try {
            org.joda.time.Period period19 = period17.minusSeconds((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(periodType16);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = new org.joda.time.DurationFieldType[] {};
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-210865896000000L), (java.lang.Number) 10, (java.lang.Number) (-210865896000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        try {
            long long7 = offsetDateTimeField4.set(10L, "3");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3 for yearOfCentury must be in the range [97,196]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PT1H0.002S");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PT1H0.002S' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDay]", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number6 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number7 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearMonthDay]" + "'", str3.equals("PeriodType[YearMonthDay]"));
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        try {
            long long13 = iSOChronology5.getDateTimeMillis((int) '#', 3, (int) '#', (int) (short) 100, 1, 196, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 10, (int) (short) 100, (int) ' ', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, "+00:00:00.010");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.eras();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.minutes();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField6 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField3, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.centuryOfEra();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = iSOChronology1.get(readablePartial4, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
//        long long8 = offsetDateTimeField4.roundHalfFloor((-1L));
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.Period period13 = new org.joda.time.Period((long) (-1), 1L);
//        int[] intArray14 = period13.getValues();
//        try {
//            int[] intArray16 = offsetDateTimeField4.set(readablePartial9, 3, intArray14, 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for yearOfCentury must be in the range [97,196]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28800000L + "'", long8 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray14);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(10L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        java.util.Locale locale5 = null;
        int int6 = offsetDateTimeField4.getMaximumTextLength(locale5);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField4.getAsText(readablePartial8, 3, locale10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField4.getAsText((int) '#', locale13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = iSOChronology21.eras();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.yearOfCentury();
        org.joda.time.Period period24 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType19, (org.joda.time.Chronology) iSOChronology21);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology21.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology21.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = iSOChronology31.eras();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.Chronology chronology34 = iSOChronology31.withZone(dateTimeZone33);
        org.joda.time.Period period35 = new org.joda.time.Period((long) 100, (-210865896000000L), chronology34);
        org.joda.time.Period period36 = new org.joda.time.Period(1L, chronology34);
        int[] intArray39 = iSOChronology21.get((org.joda.time.ReadablePeriod) period36, (long) (byte) 10, (long) (byte) 100);
        try {
            int[] intArray41 = offsetDateTimeField4.set(readablePartial15, (int) '#', intArray39, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for yearOfCentury must be in the range [97,196]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3" + "'", str11.equals("3"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "35" + "'", str14.equals("35"));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(intArray39);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
//        int int8 = offsetDateTimeField4.getMinimumValue((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.Period period13 = new org.joda.time.Period((long) (-1), 1L);
//        int[] intArray14 = period13.getValues();
//        org.joda.time.Period period16 = period13.plusSeconds(3);
//        int[] intArray17 = period13.getValues();
//        try {
//            int[] intArray19 = offsetDateTimeField4.addWrapPartial(readablePartial9, (int) (short) 0, intArray17, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for yearOfCentury must be in the range [97,196]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(intArray17);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 100);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("PeriodType[YearMonthDay]", (int) (short) 100, 3, (int) (byte) 10, '4', 0, (int) (short) 10, (int) (byte) 100, false, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-100), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType9 = periodType8.withDaysRemoved();
        org.joda.time.PeriodType periodType10 = periodType8.withMillisRemoved();
        org.joda.time.PeriodType periodType11 = org.joda.time.DateTimeUtils.getPeriodType(periodType10);
        try {
            org.joda.time.Period period12 = new org.joda.time.Period(97, (int) 'a', (-1), (int) (byte) 10, (int) (short) 10, (int) (byte) 0, 10, (int) (byte) 100, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str11 = cachedDateTimeZone9.getNameKey((long) '4');
        java.lang.String str13 = cachedDateTimeZone9.getNameKey(3L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0.002S" + "'", str11.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = zonedChronology4.minuteOfDay();
        try {
            long long11 = zonedChronology4.getDateTimeMillis(1L, (int) 'a', (int) (short) 1, (int) (short) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5);
        org.joda.time.Period period8 = period6.minusWeeks(0);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationFrom(readableInstant3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.Period period7 = period2.withField(durationFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(duration4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationFrom(readableInstant6);
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration7);
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType13 = periodType12.withSecondsRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant11, periodType13);
        org.joda.time.DurationFieldType durationFieldType15 = null;
        try {
            org.joda.time.Period period17 = period14.withField(durationFieldType15, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-100), 0, (-100), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-100) + "'", int4 == (-100));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = cachedDateTimeZone9.getShortName((long) 196, locale11);
        long long14 = cachedDateTimeZone9.nextTransition(0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.010" + "'", str12.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) ' ');
        int int2 = period1.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.Period period3 = period2.negated();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType9 = periodType8.withSecondsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant6, readableInstant7, periodType8);
        org.joda.time.Period period11 = new org.joda.time.Period(1L, (long) '#', periodType8);
        int int12 = periodType8.size();
        org.joda.time.PeriodType periodType13 = periodType8.withWeeksRemoved();
        org.joda.time.PeriodType periodType14 = periodType13.withWeeksRemoved();
        org.joda.time.PeriodType periodType15 = periodType14.withHoursRemoved();
        try {
            org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) period3, periodType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("PST");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PST/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationFrom(readableInstant3);
        org.joda.time.Period period6 = period2.withMillis((int) (short) 100);
        org.joda.time.Period period8 = period6.withMillis(196);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = iSOChronology1.withZone(dateTimeZone3);
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) chronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter8 = null;
        java.lang.String str9 = period7.toString(periodFormatter8);
        org.joda.time.Period period11 = period7.plusHours((int) (short) 100);
        boolean boolean12 = periodType2.equals((java.lang.Object) period11);
        int int13 = period11.getWeeks();
        org.joda.time.Period period15 = period11.withMinutes((int) (byte) -1);
        org.joda.time.Period period17 = period11.minusSeconds((int) '#');
        try {
            org.joda.time.DurationFieldType durationFieldType19 = period17.getFieldType(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0.002S" + "'", str9.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        int int5 = offsetDateTimeField4.getMaximumValue();
//        long long7 = offsetDateTimeField4.remainder((long) (short) -1);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(100L);
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        java.util.Locale locale11 = null;
//        try {
//            java.lang.String str12 = offsetDateTimeField4.getAsText(readablePartial10, locale11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31507199999L + "'", long7 == 31507199999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "166" + "'", str9.equals("166"));
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        boolean boolean7 = offsetDateTimeField4.isSupported();
        org.joda.time.ReadablePartial readablePartial8 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType13 = periodType12.withSecondsRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant10, readableInstant11, periodType12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType18 = periodType17.withSecondsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant15, readableInstant16, periodType17);
        org.joda.time.Period period22 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter23 = null;
        java.lang.String str24 = period22.toString(periodFormatter23);
        org.joda.time.Period period26 = period22.plusHours((int) (short) 100);
        boolean boolean27 = periodType17.equals((java.lang.Object) period26);
        org.joda.time.PeriodType periodType28 = periodType17.withHoursRemoved();
        org.joda.time.Period period29 = period14.withPeriodType(periodType28);
        int[] intArray30 = period14.getValues();
        try {
            int[] intArray32 = offsetDateTimeField4.addWrapPartial(readablePartial8, 0, intArray30, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PT0.002S" + "'", str24.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int6 = offsetDateTimeField4.getLeapAmount((long) (byte) 0);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsText((int) (short) 10, locale8);
        try {
            long long12 = offsetDateTimeField4.set((-210865896000000L), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for yearOfCentury must be in the range [97,196]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000035d + "'", double1 == 2440587.500000035d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean11 = fixedDateTimeZone9.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = fixedDateTimeZone9.isLocalDateTimeGap(localDateTime12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Chronology chronology15 = iSOChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology1.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(4);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = iSOChronology6.eras();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.dayOfWeek();
        try {
            org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) dateTimeZoneBuilder4, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.DateTimeZoneBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        org.joda.time.Chronology chronology3 = gregorianChronology1.withUTC();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(chronology3);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-100), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-68) + "'", int2 == (-68));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = zonedChronology4.weekOfWeekyear();
        try {
            long long13 = zonedChronology4.getDateTimeMillis((int) (byte) 1, (int) (short) 1, 8, 1, 0, (int) (short) 1, (-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value \"\" for PeriodType[YearMonthDay] is not supported");
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(97, (-100));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-9700) + "'", int2 == (-9700));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((-100), (-100));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean16 = fixedDateTimeZone14.isStandardOffset((long) (short) -1);
        boolean boolean17 = cachedDateTimeZone9.equals((java.lang.Object) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0, "PT1H0.002S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
//        try {
//            long long12 = gregorianChronology1.getDateTimeMillis((int) (byte) 0, (int) (short) -1, 1, 0, 1, (int) (byte) 100, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(chronology4);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        org.joda.time.Period period7 = new org.joda.time.Period(1L, (long) '#', periodType4);
        int int8 = periodType4.size();
        org.joda.time.PeriodType periodType9 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType10 = periodType9.withWeeksRemoved();
        org.joda.time.PeriodType periodType11 = periodType10.withHoursRemoved();
        org.joda.time.PeriodType periodType12 = periodType10.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = iSOChronology1.withZone(dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 3);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        long long14 = fixedDateTimeZone9.nextTransition(0L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("-100", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(31507199999L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 0, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.dayOfYear();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 28800000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2277453240000000L + "'", long1 == 2277453240000000L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDay]", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearMonthDay]" + "'", str3.equals("PeriodType[YearMonthDay]"));
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("10");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '10' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PT0S");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PT0S' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField11 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        int int7 = offsetDateTimeField4.getOffset();
        boolean boolean9 = offsetDateTimeField4.isLeap((long) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110 + "'", int2 == 110);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) '#', (-1), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(100L, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        int int7 = offsetDateTimeField4.getOffset();
        long long10 = offsetDateTimeField4.add((long) 100, (long) 100);
        boolean boolean12 = offsetDateTimeField4.isLeap((long) (short) -1);
        try {
            long long15 = offsetDateTimeField4.set((-210865896000000L), "org.joda.time.IllegalFieldValueException: Value \"\" for PeriodType[YearMonthDay] is not supported");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value \"\" for PeriodType[YearMonthDay] is not supported\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000100L + "'", long10 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = iSOChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "PeriodType[YearMonthDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDay]", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str5 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearMonthDay]" + "'", str3.equals("PeriodType[YearMonthDay]"));
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ZonedChronology[ISOChronology[UTC], ]", "PT100.002S");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = iSOChronology8.eras();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.yearOfCentury();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType6, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology8.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology8.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology8.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology8.hourOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int22 = fixedDateTimeZone20.getOffsetFromLocal((long) 3);
        java.lang.String str24 = fixedDateTimeZone20.getNameKey((long) (short) 1);
        org.joda.time.Chronology chronology25 = iSOChronology8.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        try {
            org.joda.time.Period period26 = new org.joda.time.Period((java.lang.Object) "ZonedChronology[ISOChronology[UTC], ]", periodType3, (org.joda.time.Chronology) iSOChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ZonedChronology[ISOChronology[UT...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PT0.002S" + "'", str24.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(chronology25);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("3", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationFrom(readableInstant3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) duration4, chronology5);
        org.joda.time.Period period8 = period6.plusDays((-9700));
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        try {
//            long long11 = gregorianChronology1.getDateTimeMillis((int) ' ', 0, 97, (int) (byte) 10, (int) (byte) 1, (int) (byte) 10, (-100));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((-100));
        int int2 = period1.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDay]", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearMonthDay]" + "'", str3.equals("PeriodType[YearMonthDay]"));
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant9);
        org.joda.time.Period period12 = period10.withHours((int) (byte) 1);
        org.joda.time.Period period14 = period12.plusYears((int) (byte) 10);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.time();
        org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) period12, periodType15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period12.toDurationTo(readableInstant17);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(duration18);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
//        int int8 = offsetDateTimeField4.getMinimumValue((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        java.util.Locale locale10 = null;
//        try {
//            java.lang.String str11 = offsetDateTimeField4.getAsShortText(readablePartial9, locale10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = cachedDateTimeZone9.getShortName((long) 196, locale11);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.010" + "'", str12.equals("+00:00:00.010"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((-68));
        org.joda.time.Period period3 = period1.minusHours(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = zonedChronology4.weekOfWeekyear();
        try {
            long long10 = zonedChronology4.getDateTimeMillis((-68), (int) 'a', (-9700), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = fixedDateTimeZone4.previousTransition((long) 10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.yearOfCentury();
        org.joda.time.DurationField durationField4 = iSOChronology2.halfdays();
        long long7 = durationField4.subtract((long) 97, (long) 'a');
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField8 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-4190399903L) + "'", long7 == (-4190399903L));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 3);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) (short) 1);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 10);
        java.lang.String str12 = fixedDateTimeZone4.getName((long) (short) 1);
        long long15 = fixedDateTimeZone4.convertLocalToUTC(0L, true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PT0.002S" + "'", str8.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.010" + "'", str12.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-10L) + "'", long15 == (-10L));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Hours hours8 = period7.toStandardHours();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.Period period11 = period7.withFieldAdded(durationFieldType9, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(hours8);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationFrom(readableInstant3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) duration4, chronology5);
        org.joda.time.Period period8 = period6.plusMonths((int) (short) 0);
        org.joda.time.Period period9 = period6.normalizedStandard();
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 3);
        java.lang.String str13 = fixedDateTimeZone9.getNameKey((long) (short) 1);
        int int15 = fixedDateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.Chronology chronology16 = zonedChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        try {
            long long21 = zonedChronology4.getDateTimeMillis(100, (int) '#', (int) '4', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, 110, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant9);
        org.joda.time.Period period12 = period10.withHours((int) (byte) 1);
        org.joda.time.Period period14 = period12.plusYears((int) (byte) 10);
        org.joda.time.Period period16 = period14.withMinutes(4);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        int int18 = period16.get(durationFieldType17);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType8 = periodType7.withSecondsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant5, readableInstant6, periodType7);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period16 = period12.plusHours((int) (short) 100);
        boolean boolean17 = periodType7.equals((java.lang.Object) period16);
        org.joda.time.PeriodType periodType18 = periodType7.withHoursRemoved();
        org.joda.time.Period period19 = period4.withPeriodType(periodType18);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period19.indexOf(durationFieldType20);
        org.joda.time.Period period23 = period19.plusDays((int) '#');
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0.002S" + "'", str14.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(period23);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]", (-1), (int) (short) -1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = iSOChronology14.eras();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.yearOfCentury();
        org.joda.time.Period period17 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType12, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology14.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology14.weekOfWeekyear();
        boolean boolean20 = cachedDateTimeZone9.equals((java.lang.Object) dateTimeField19);
        java.lang.String str22 = cachedDateTimeZone9.getShortName((long) 196);
        long long25 = cachedDateTimeZone9.convertLocalToUTC(0L, true);
        long long27 = cachedDateTimeZone9.nextTransition(0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.010" + "'", str22.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-10L) + "'", long25 == (-10L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 3);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "+00:00:00.010", (int) (short) -1, (int) (byte) 0);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter8 = null;
        java.lang.String str9 = period7.toString(periodFormatter8);
        org.joda.time.Period period11 = period7.plusSeconds((int) (short) 100);
        org.joda.time.Period period13 = period7.withHours((int) (short) 1);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        int int17 = period13.get(durationFieldType16);
        org.joda.time.Hours hours18 = period13.toStandardHours();
        boolean boolean19 = fixedDateTimeZone4.equals((java.lang.Object) period13);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0.002S" + "'", str9.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT1H0.002S" + "'", str15.equals("PT1H0.002S"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(hours18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
//        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DurationField durationField6 = gregorianChronology1.days();
//        long long9 = durationField6.subtract((-406468790591L), (int) (short) 1);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(lenientChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-406555190591L) + "'", long9 == (-406555190591L));
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        org.joda.time.Period period7 = new org.joda.time.Period(1L, (long) '#', periodType4);
        org.joda.time.PeriodType periodType8 = periodType4.withMillisRemoved();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        org.joda.time.PeriodType periodType10 = periodType8.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-9700), (long) (-68));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9768L) + "'", long2 == (-9768L));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.clockhourOfDay();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone3);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
//        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 3);
//        java.lang.String str13 = fixedDateTimeZone9.getNameKey((long) (short) 1);
//        int int15 = fixedDateTimeZone9.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.Chronology chronology16 = zonedChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        java.lang.String str17 = zonedChronology4.toString();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(zonedChronology4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]" + "'", str17.equals("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]"));
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        int int7 = offsetDateTimeField4.getOffset();
        long long10 = offsetDateTimeField4.add((long) 100, (long) 100);
        int int11 = offsetDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000100L + "'", long10 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.Period period11 = period10.negated();
        try {
            org.joda.time.Period period12 = period7.plus((org.joda.time.ReadablePeriod) period11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "PT1H0.002S", "166");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32) + "'", int1 == (-32));
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
//        int int8 = offsetDateTimeField4.getMinimumValue((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.Period period13 = new org.joda.time.Period((long) (-1), 1L);
//        int[] intArray14 = period13.getValues();
//        java.util.Locale locale16 = null;
//        try {
//            int[] intArray17 = offsetDateTimeField4.set(readablePartial9, 8, intArray14, "America/Los_Angeles", locale16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for yearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
//        org.junit.Assert.assertNotNull(intArray14);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "yearOfCentury");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        boolean boolean8 = fixedDateTimeZone4.equals((java.lang.Object) 2440587.5d);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) (byte) 1);
        java.lang.String str11 = gregorianChronology10.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[,mdfw=1]" + "'", str11.equals("GregorianChronology[,mdfw=1]"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 10000, (java.lang.Number) (-4190399903L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField4 = new org.joda.time.field.ScaledDurationField(durationField1, durationFieldType2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 3);
        java.lang.String str13 = fixedDateTimeZone9.getNameKey((long) (short) 1);
        int int15 = fixedDateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.Chronology chronology16 = zonedChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        try {
            long long22 = zonedChronology4.getDateTimeMillis((long) (short) 1, 0, (-32), 97, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(chronology16);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        int int5 = offsetDateTimeField4.getMaximumValue();
//        long long7 = offsetDateTimeField4.remainder((long) (short) -1);
//        int int9 = offsetDateTimeField4.getMinimumValue(0L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31507199999L + "'", long7 == 31507199999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Period period6 = period2.plusSeconds((int) (short) 100);
        org.joda.time.Period period8 = period2.withHours((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = period2.indexOf(durationFieldType9);
        org.joda.time.Period period12 = period2.minusMonths(0);
        int int13 = period12.getDays();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.Period period1 = org.joda.time.Period.millis(196);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        int int5 = offsetDateTimeField4.getMaximumValue();
//        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
//        int int7 = offsetDateTimeField4.getOffset();
//        long long10 = offsetDateTimeField4.add((long) 100, (long) 100);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField4.getAsText(0, locale12);
//        long long15 = offsetDateTimeField4.roundCeiling(2440588L);
//        boolean boolean17 = offsetDateTimeField4.isLeap((long) (-1));
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.Period period22 = new org.joda.time.Period((long) (-1), 1L);
//        int[] intArray23 = period22.getValues();
//        try {
//            int[] intArray25 = offsetDateTimeField4.add(readablePartial18, 196, intArray23, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 196");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
//        org.junit.Assert.assertNull(durationField6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000100L + "'", long10 == 3155760000100L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(intArray23);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        java.io.File file5 = null;
        java.io.File[] fileArray6 = new java.io.File[] { file5 };
        try {
            java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = zoneInfoCompiler0.compile(file4, fileArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int6 = offsetDateTimeField4.getLeapAmount((long) (byte) 0);
        boolean boolean7 = offsetDateTimeField4.isSupported();
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField4.getAsText((int) (byte) 0, locale9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField4.getAsText(100, locale12);
        try {
            long long16 = offsetDateTimeField4.set((long) 0, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 0, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        try {
            long long13 = iSOChronology4.getDateTimeMillis((-49L), (-68), (-32), 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -68 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 110, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110L + "'", long2 == 110L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-100));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) 'a');
        int int7 = offsetDateTimeField5.getLeapAmount((long) (byte) 0);
        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getDurationField();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = iSOChronology14.eras();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.yearOfCentury();
        org.joda.time.Period period17 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType12, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology14.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology14.weekOfWeekyear();
        boolean boolean20 = cachedDateTimeZone9.equals((java.lang.Object) dateTimeField19);
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException("ZonedChronology[ISOChronology[UTC], ]", (java.lang.Number) 2440587.5d, (java.lang.Number) 196, (java.lang.Number) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = illegalFieldValueException25.getDateTimeFieldType();
        boolean boolean27 = cachedDateTimeZone9.equals((java.lang.Object) dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder4.setStandardOffset((int) 'a');
        java.io.DataOutput dataOutput8 = null;
        try {
            dateTimeZoneBuilder6.writeTo("PST", dataOutput8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
//        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.millisOfSecond();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(lenientChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        org.joda.time.Period period7 = new org.joda.time.Period(1L, (long) '#', periodType4);
        try {
            org.joda.time.DurationFieldType durationFieldType9 = period7.getFieldType((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(100L, (long) (-32));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 68L + "'", long2 == 68L);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        int int5 = offsetDateTimeField4.getMaximumValue();
//        long long7 = offsetDateTimeField4.remainder((long) (short) -1);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(100L);
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        int[] intArray12 = null;
//        try {
//            int[] intArray14 = offsetDateTimeField4.addWrapField(readablePartial10, (int) (short) 0, intArray12, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31507199999L + "'", long7 == 31507199999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "166" + "'", str9.equals("166"));
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.Period period5 = period3.withSeconds(100);
        org.joda.time.Duration duration6 = period5.toStandardDuration();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period9 = period7.withSeconds((int) '4');
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period9);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        int int5 = offsetDateTimeField4.getMaximumValue();
//        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
//        java.util.Locale locale7 = null;
//        int int8 = offsetDateTimeField4.getMaximumShortTextLength(locale7);
//        long long10 = offsetDateTimeField4.roundHalfFloor((long) 4);
//        org.joda.time.DurationField durationField11 = offsetDateTimeField4.getLeapDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
//        org.junit.Assert.assertNull(durationField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
//        org.junit.Assert.assertNull(durationField11);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.DurationField durationField3 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.era();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("100", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = gregorianChronology1.equals(obj4);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        try {
//            int[] intArray8 = gregorianChronology1.get(readablePartial6, (long) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000000116d + "'", double1 == 2440587.5000000116d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        org.joda.time.Period period7 = new org.joda.time.Period(1L, (long) '#', periodType4);
        org.joda.time.PeriodType periodType8 = periodType4.withYearsRemoved();
        java.lang.String str9 = periodType8.getName();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "YearMonthDayNoYears" + "'", str9.equals("YearMonthDayNoYears"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 3);
        java.lang.String str13 = fixedDateTimeZone9.getNameKey((long) (short) 1);
        int int15 = fixedDateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean22 = fixedDateTimeZone20.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime23 = null;
        boolean boolean24 = fixedDateTimeZone20.isLocalDateTimeGap(localDateTime23);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        long long27 = fixedDateTimeZone9.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone25, 1560629643334L);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Period period31 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter32 = null;
        java.lang.String str33 = period31.toString(periodFormatter32);
        org.joda.time.Period period35 = period31.plusSeconds((int) (short) 100);
        org.joda.time.Period period37 = period31.withHours((int) (short) 1);
        org.joda.time.format.PeriodFormatter periodFormatter38 = null;
        java.lang.String str39 = period37.toString(periodFormatter38);
        org.joda.time.Period period41 = period37.withHours((int) (byte) 1);
        boolean boolean42 = fixedDateTimeZone9.equals((java.lang.Object) period41);
        int int44 = fixedDateTimeZone9.getOffset((long) 10000);
        boolean boolean45 = fixedDateTimeZone9.isFixed();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560629643334L + "'", long27 == 1560629643334L);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PT0.002S" + "'", str33.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PT1H0.002S" + "'", str39.equals("PT1H0.002S"));
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        int[] intArray3 = period2.getValues();
        org.joda.time.Period period5 = period2.plusSeconds(3);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.Period period12 = period8.plusSeconds((int) (short) 100);
        org.joda.time.Period period13 = period2.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period15 = period13.minusSeconds((int) (byte) 100);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.months();
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
        try {
            org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) (byte) 100, periodType16, chronology18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0.002S" + "'", str10.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Period period6 = period2.plusSeconds((int) (short) 100);
        org.joda.time.Period period8 = period2.withHours((int) (short) 1);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.Period period12 = period8.withHours((int) (byte) 1);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationFrom(readableInstant13);
        org.joda.time.MutablePeriod mutablePeriod15 = period12.toMutablePeriod();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT1H0.002S" + "'", str10.equals("PT1H0.002S"));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(mutablePeriod15);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter12 = null;
        java.lang.String str13 = period11.toString(periodFormatter12);
        org.joda.time.Period period15 = period11.plusSeconds((int) (short) 100);
        boolean boolean16 = period8.equals((java.lang.Object) period15);
        org.joda.time.Period period18 = period15.withHours((int) (short) 100);
        org.joda.time.Period period20 = period18.minusMonths((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType26 = periodType25.withSecondsRemoved();
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant23, readableInstant24, periodType25);
        org.joda.time.Period period28 = new org.joda.time.Period(1L, (long) '#', periodType25);
        org.joda.time.PeriodType periodType29 = periodType25.withYearsRemoved();
        try {
            org.joda.time.Period period30 = period18.withPeriodType(periodType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'hours'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType29);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 1, 0, (int) ' ', 110);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 80 + "'", int4 == 80);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int11 = cachedDateTimeZone9.getStandardOffset(31536000001L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType8 = periodType7.withSecondsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant5, readableInstant6, periodType7);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period16 = period12.plusHours((int) (short) 100);
        boolean boolean17 = periodType7.equals((java.lang.Object) period16);
        org.joda.time.PeriodType periodType18 = periodType7.withHoursRemoved();
        org.joda.time.Period period19 = period4.withPeriodType(periodType18);
        int[] intArray20 = period4.getValues();
        int int21 = period4.getWeeks();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0.002S" + "'", str14.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        boolean boolean8 = fixedDateTimeZone4.isStandardOffset((long) (byte) 10);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("166");
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int[] intArray5 = period4.getValues();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration7, readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period9.toDurationFrom(readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant6, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.MutablePeriod mutablePeriod14 = period13.toMutablePeriod();
        org.joda.time.Period period15 = period13.normalizedStandard();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(mutablePeriod14);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Period period6 = period2.plusHours((int) (short) 100);
        org.joda.time.Period period8 = period6.minusMillis((int) '4');
        org.joda.time.Period period10 = period6.withYears((int) (short) 0);
        org.joda.time.Period period12 = period6.minusMonths((-9700));
        org.joda.time.Period period14 = period6.minusMillis(0);
        org.joda.time.Period period16 = period14.plusMinutes((-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File file2 = null;
        java.io.File[] fileArray3 = new java.io.File[] { file2 };
        try {
            java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = zoneInfoCompiler0.compile(file1, fileArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray3);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        int int5 = offsetDateTimeField4.getMaximumValue();
//        long long7 = offsetDateTimeField4.remainder((long) (short) -1);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(100L);
//        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
//        int int11 = offsetDateTimeField4.getMinimumValue();
//        org.joda.time.ReadablePartial readablePartial12 = null;
//        int[] intArray13 = null;
//        int int14 = offsetDateTimeField4.getMinimumValue(readablePartial12, intArray13);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31507199999L + "'", long7 == 31507199999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "166" + "'", str9.equals("166"));
//        org.junit.Assert.assertNull(durationField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        boolean boolean8 = fixedDateTimeZone4.equals((java.lang.Object) 2440587.5d);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean15 = fixedDateTimeZone13.isStandardOffset((long) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        long long18 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone13, (long) 10);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.time();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = iSOChronology21.eras();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = iSOChronology21.withZone(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology21.minuteOfHour();
        try {
            org.joda.time.Period period26 = new org.joda.time.Period((java.lang.Object) fixedDateTimeZone13, periodType19, (org.joda.time.Chronology) iSOChronology21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder4.setStandardOffset(10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder4.addRecurringSavings("hi!", 10000, (int) (short) 0, (int) (short) -1, ' ', 110, 100, (int) '#', true, (int) '#');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder28 = dateTimeZoneBuilder4.addRecurringSavings("0", (int) (byte) -1, (int) '#', (int) (byte) 0, '#', (int) (short) -1, (int) '#', (int) (byte) 100, true, (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder17);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder28);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ZonedChronology[ISOChronology[UTC], ]", (java.lang.Number) 2440587.5d, (java.lang.Number) 196, (java.lang.Number) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 1 + "'", number6.equals((short) 1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(10000);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        java.util.Locale locale5 = null;
//        int int6 = offsetDateTimeField4.getMaximumTextLength(locale5);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getRangeDurationField();
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField4.getAsText(readablePartial8, 3, locale10);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = offsetDateTimeField4.getAsText((int) '#', locale13);
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText((long) 1);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3" + "'", str11.equals("3"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "35" + "'", str14.equals("35"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "166" + "'", str16.equals("166"));
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField4.getMaximumShortTextLength(locale7);
        int int9 = offsetDateTimeField4.getOffset();
        int int12 = offsetDateTimeField4.getDifference(68L, (long) (-100));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = null;
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = zonedChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField6 = zonedChronology4.hourOfHalfday();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.days();
        try {
            org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) dateTimeField6, periodType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        int int7 = offsetDateTimeField4.getOffset();
        long long10 = offsetDateTimeField4.add((long) 100, (long) 100);
        boolean boolean12 = offsetDateTimeField4.isLeap((long) (short) -1);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray19 = new int[] { (byte) 100, 4, (byte) 0, 0 };
        try {
            int[] intArray21 = offsetDateTimeField4.addWrapField(readablePartial13, (int) (short) 1, intArray19, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000100L + "'", long10 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.hourOfHalfday();
        org.joda.time.ReadablePartial readablePartial11 = null;
        try {
            long long13 = iSOChronology4.set(readablePartial11, (-10L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        int int7 = offsetDateTimeField4.getOffset();
        long long10 = offsetDateTimeField4.add((long) 100, (long) 100);
        boolean boolean11 = offsetDateTimeField4.isSupported();
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = offsetDateTimeField4.getAsText(readablePartial12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000100L + "'", long10 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-4L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        int int7 = offsetDateTimeField4.getOffset();
        int int8 = offsetDateTimeField4.getOffset();
        org.joda.time.DurationField durationField9 = offsetDateTimeField4.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) (byte) 1, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter8 = null;
        java.lang.String str9 = period7.toString(periodFormatter8);
        org.joda.time.Period period11 = period7.plusHours((int) (short) 100);
        boolean boolean12 = periodType2.equals((java.lang.Object) period11);
        int int13 = period11.getWeeks();
        org.joda.time.Minutes minutes14 = period11.toStandardMinutes();
        java.lang.String str15 = period11.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0.002S" + "'", str9.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(minutes14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT100H0.002S" + "'", str15.equals("PT100H0.002S"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int12 = fixedDateTimeZone10.getOffsetFromLocal((long) 3);
        java.lang.String str14 = fixedDateTimeZone10.getNameKey((long) (short) 1);
        int int16 = fixedDateTimeZone10.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.Chronology chronology17 = zonedChronology5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.Period period18 = new org.joda.time.Period((long) 80, chronology17);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0.002S" + "'", str14.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder0.setFixedSavings("100", (int) (short) 100);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder7.addCutover((-32), ' ', (-9700), (-68), (int) (short) 10, false, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 3);
        java.lang.String str13 = fixedDateTimeZone9.getNameKey((long) (short) 1);
        int int15 = fixedDateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.Chronology chronology16 = zonedChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period(readableDuration21, readableInstant22);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Duration duration25 = period23.toDurationFrom(readableInstant24);
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant20, (org.joda.time.ReadableDuration) duration25);
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant19, (org.joda.time.ReadableDuration) duration25);
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant18, (org.joda.time.ReadableDuration) duration25);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType31 = periodType30.withSecondsRemoved();
        org.joda.time.Period period32 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration25, readableInstant29, periodType31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) 196, periodType31);
        boolean boolean34 = zonedChronology4.equals((java.lang.Object) 196);
        try {
            long long39 = zonedChronology4.getDateTimeMillis((int) (byte) 1, 3, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(duration25);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        int int5 = offsetDateTimeField4.getMaximumValue();
//        long long8 = offsetDateTimeField4.add((long) ' ', (int) (byte) 100);
//        boolean boolean9 = offsetDateTimeField4.isLenient();
//        long long11 = offsetDateTimeField4.roundCeiling((long) (short) 100);
//        java.util.Locale locale12 = null;
//        int int13 = offsetDateTimeField4.getMaximumTextLength(locale12);
//        try {
//            long long16 = offsetDateTimeField4.set((long) 1, "org.joda.time.IllegalFieldValueException: Value \"\" for PeriodType[YearMonthDay] is not supported");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value \"\" for PeriodType[YearMonthDay] is not supported\" for yearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155760000032L + "'", long8 == 3155760000032L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "35");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
//        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
//        long long8 = offsetDateTimeField4.roundHalfFloor((-1L));
//        boolean boolean10 = offsetDateTimeField4.isLeap(1L);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearMonthDay();
//        org.joda.time.PeriodType periodType16 = periodType15.withSecondsRemoved();
//        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearMonthDay();
//        org.joda.time.PeriodType periodType21 = periodType20.withSecondsRemoved();
//        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant18, readableInstant19, periodType20);
//        org.joda.time.Period period25 = new org.joda.time.Period((long) (-1), 1L);
//        org.joda.time.format.PeriodFormatter periodFormatter26 = null;
//        java.lang.String str27 = period25.toString(periodFormatter26);
//        org.joda.time.Period period29 = period25.plusHours((int) (short) 100);
//        boolean boolean30 = periodType20.equals((java.lang.Object) period29);
//        org.joda.time.PeriodType periodType31 = periodType20.withHoursRemoved();
//        org.joda.time.Period period32 = period17.withPeriodType(periodType31);
//        int[] intArray33 = period17.getValues();
//        java.util.Locale locale35 = null;
//        try {
//            int[] intArray36 = offsetDateTimeField4.set(readablePartial11, (int) (short) 10, intArray33, "PT100.002S", locale35);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PT100.002S\" for yearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28800000L + "'", long8 == 28800000L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(periodType20);
//        org.junit.Assert.assertNotNull(periodType21);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PT0.002S" + "'", str27.equals("PT0.002S"));
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(periodType31);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(intArray33);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = gregorianChronology1.toString();
//        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
//        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
//        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DurationField durationField6 = gregorianChronology1.days();
//        long long9 = durationField6.subtract(100L, (long) 1);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str2.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(lenientChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-86399900L) + "'", long9 == (-86399900L));
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str11 = cachedDateTimeZone9.getNameKey((long) '4');
        long long13 = cachedDateTimeZone9.previousTransition(28800004L);
        long long16 = cachedDateTimeZone9.convertLocalToUTC((long) 110, true);
        long long18 = cachedDateTimeZone9.previousTransition(1L);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0.002S" + "'", str11.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800004L + "'", long13 == 28800004L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = iSOChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.weekyearOfCentury();
        org.joda.time.Chronology chronology6 = iSOChronology1.withUTC();
        org.joda.time.DurationField durationField7 = iSOChronology1.eras();
        try {
            long long10 = durationField7.subtract((long) (-9700), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean8 = fixedDateTimeZone6.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = fixedDateTimeZone6.isLocalDateTimeGap(localDateTime9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = iSOChronology16.eras();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.yearOfCentury();
        org.joda.time.Period period19 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType14, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology16.weekOfWeekyear();
        boolean boolean22 = cachedDateTimeZone11.equals((java.lang.Object) dateTimeField21);
        java.lang.String str24 = cachedDateTimeZone11.getShortName((long) 196);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone11);
        try {
            long long30 = zonedChronology25.getDateTimeMillis((int) ' ', (int) (byte) -1, 8, (-68));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -68 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.010" + "'", str24.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(zonedChronology25);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.field.FieldUtils.verifyValueBounds("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]", (int) (byte) 10, (int) (short) 1, (int) 'a');
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, 10000);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        java.lang.String str2 = period1.toString();
        org.joda.time.Period period4 = period1.minusHours(10000);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PT0S" + "'", str2.equals("PT0S"));
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int6 = offsetDateTimeField4.getLeapAmount((long) (byte) 0);
        boolean boolean7 = offsetDateTimeField4.isSupported();
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField4.getAsText((int) (byte) 0, locale9);
        java.lang.String str11 = offsetDateTimeField4.getName();
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = iSOChronology18.eras();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.yearOfCentury();
        org.joda.time.Period period21 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType16, (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology18.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology18.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology18.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
        org.joda.time.DurationField durationField29 = iSOChronology28.eras();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.Chronology chronology31 = iSOChronology28.withZone(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) 100, (-210865896000000L), chronology31);
        int[] intArray34 = iSOChronology18.get((org.joda.time.ReadablePeriod) period32, 10L);
        try {
            int[] intArray36 = offsetDateTimeField4.addWrapField(readablePartial12, (int) (short) 100, intArray34, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "yearOfCentury" + "'", str11.equals("yearOfCentury"));
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) ' ');
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationTo(readableInstant2);
        org.joda.time.DurationFieldType[] durationFieldTypeArray4 = period1.getFieldTypes();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.forFields(durationFieldTypeArray4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
        org.junit.Assert.assertNotNull(durationFieldTypeArray4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-9700), (-86399900L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 838079030000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 3);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) (short) 1);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PT0.002S" + "'", str8.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = lenientChronology2.getZone();
        org.joda.time.Chronology chronology4 = lenientChronology2.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = iSOChronology6.eras();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Chronology chronology9 = iSOChronology6.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology6.dayOfWeek();
        boolean boolean11 = lenientChronology2.equals((java.lang.Object) iSOChronology6);
        org.joda.time.DateTimeField dateTimeField12 = lenientChronology2.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int6 = offsetDateTimeField4.getLeapAmount((long) (byte) 0);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsText((int) '4', locale8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField4.getAsShortText(readablePartial10, (-9700), locale12);
        int int15 = offsetDateTimeField4.getLeapAmount((-406468790591L));
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField4.getAsShortText((int) (short) 0, locale17);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "52" + "'", str9.equals("52"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-9700" + "'", str13.equals("-9700"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), 10000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 10000");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT1H0.002S", "", 3, 196);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 3);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) (short) 1);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean17 = fixedDateTimeZone15.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime18);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        long long22 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone20, 1560629643334L);
        int int24 = cachedDateTimeZone20.getStandardOffset(0L);
        int int26 = cachedDateTimeZone20.getStandardOffset((long) 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PT0.002S" + "'", str8.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560629643334L + "'", long22 == 1560629643334L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = zonedChronology4.getZone();
        org.joda.time.DurationField durationField6 = zonedChronology4.minutes();
        try {
            long long14 = zonedChronology4.getDateTimeMillis((int) (short) 10, (-100), (int) (short) 100, (-32), (-68), (int) ' ', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
        long long8 = offsetDateTimeField4.roundHalfFloor((-1L));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText(readablePartial9, (-100), locale11);
        long long14 = offsetDateTimeField4.roundCeiling((long) 100);
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField4.getMaximumShortTextLength(locale15);
        java.util.Locale locale19 = null;
        try {
            long long20 = offsetDateTimeField4.set((long) '4', "35", locale19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for yearOfCentury must be in the range [97,196]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-10L) + "'", long6 == (-10L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-10L) + "'", long8 == (-10L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-100" + "'", str12.equals("-100"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31535999990L + "'", long14 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("PT0S");
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology4.hourOfDay();
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = iSOChronology14.eras();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.dayOfMonth();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean24 = fixedDateTimeZone22.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime25 = null;
        boolean boolean26 = fixedDateTimeZone22.isLocalDateTimeGap(localDateTime25);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.Chronology chronology28 = iSOChronology14.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period(readableDuration30, readableInstant31);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period32.toDurationFrom(readableInstant33);
        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant29, (org.joda.time.ReadableDuration) duration34);
        int[] intArray38 = iSOChronology14.get((org.joda.time.ReadablePeriod) period35, (long) (short) 1, 0L);
        try {
            iSOChronology4.validate(readablePartial12, intArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long7 = offsetDateTimeField4.remainder((long) (short) -1);
        java.lang.String str9 = offsetDateTimeField4.getAsText(100L);
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
        int int11 = offsetDateTimeField4.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField4.getAsText(readablePartial12, (int) (byte) -1, locale14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField4.getAsText((-86399900L), locale17);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9L + "'", long7 == 9L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "167" + "'", str9.equals("167"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "166" + "'", str18.equals("166"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = iSOChronology10.eras();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.dayOfMonth();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean20 = fixedDateTimeZone18.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime21 = null;
        boolean boolean22 = fixedDateTimeZone18.isLocalDateTimeGap(localDateTime21);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone23 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.Chronology chronology24 = iSOChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(readableDuration25, readableInstant26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period27.toDurationFrom(readableInstant28);
        org.joda.time.Period period31 = period27.withMillis((int) (short) 100);
        org.joda.time.Hours hours32 = period31.toStandardHours();
        int[] intArray34 = iSOChronology10.get((org.joda.time.ReadablePeriod) hours32, (-4190399903L));
        try {
            int[] intArray36 = offsetDateTimeField4.add(readablePartial7, (-9700), intArray34, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9700");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-10L) + "'", long6 == (-10L));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(hours32);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long8 = offsetDateTimeField4.add((long) ' ', (int) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField4.getAsText((int) (byte) 100, locale10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) 'a');
        int int17 = offsetDateTimeField16.getMaximumValue();
        org.joda.time.DurationField durationField18 = offsetDateTimeField16.getLeapDurationField();
        int int19 = offsetDateTimeField16.getOffset();
        long long22 = offsetDateTimeField16.add((long) 100, (long) 100);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField16.getAsText(0, locale24);
        long long27 = offsetDateTimeField16.roundCeiling(2440588L);
        boolean boolean29 = offsetDateTimeField16.isLeap((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 0, (java.lang.Number) 100.0f, (java.lang.Number) 6311433600032L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, "-9700");
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155760000032L + "'", long8 == 3155760000032L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 196 + "'", int17 == 196);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 97 + "'", int19 == 97);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 3155760000100L + "'", long22 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 31535999990L + "'", long27 == 31535999990L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        int[] intArray3 = period2.getValues();
        org.joda.time.Period period5 = period2.plusSeconds(3);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.Period period12 = period8.plusSeconds((int) (short) 100);
        org.joda.time.Period period13 = period2.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Minutes minutes14 = period2.toStandardMinutes();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0.002S" + "'", str10.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(minutes14);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalFieldValueException: Value \"\" for PeriodType[YearMonthDay] is not supported", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalFieldValueException: Value \"\" for PeriodType[YearMonthDay] is not supported/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 0, 1L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(110L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.Period period2 = new org.joda.time.Period(3155760000032L, (-10L));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period4.toString(periodFormatter5);
        org.joda.time.Period period8 = period4.plusSeconds((int) (short) 100);
        org.joda.time.Period period10 = period4.withHours((int) (short) 1);
        org.joda.time.Period period12 = period4.plusMonths((int) (short) 1);
        boolean boolean13 = periodType0.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0.002S" + "'", str6.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.Period period4 = period2.withSeconds(100);
        org.joda.time.Duration duration5 = period4.toStandardDuration();
        org.joda.time.Minutes minutes6 = period4.toStandardMinutes();
        org.joda.time.Period period8 = period4.plusHours((-32));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(minutes6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = iSOChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.weekyearOfCentury();
        org.joda.time.Chronology chronology6 = iSOChronology1.withUTC();
        org.joda.time.DurationField durationField7 = iSOChronology1.eras();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField10 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(97);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray11 = new int[] { (-68), (short) 10, (short) 1 };
        java.util.Locale locale13 = null;
        try {
            int[] intArray14 = offsetDateTimeField4.set(readablePartial6, (int) 'a', intArray11, "167", locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) 'a');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 3);
        java.lang.String str13 = fixedDateTimeZone9.getNameKey((long) (short) 1);
        int int15 = fixedDateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean22 = fixedDateTimeZone20.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime23 = null;
        boolean boolean24 = fixedDateTimeZone20.isLocalDateTimeGap(localDateTime23);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        long long27 = fixedDateTimeZone9.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone25, 1560629643334L);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
        java.lang.String str30 = zonedChronology28.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560629643334L + "'", long27 == 1560629643334L);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str30.equals("ZonedChronology[ISOChronology[UTC], ]"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period(0L, (long) '4', chronology4);
        org.joda.time.Period period7 = period5.multipliedBy(1);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.Period period10 = period5.withField(durationFieldType8, 166);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = iSOChronology7.eras();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.yearOfCentury();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 0, (long) (byte) 0, periodType5, (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.dayOfYear();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.weekOfWeekyear();
        org.joda.time.Period period13 = new org.joda.time.Period(0L, 0L, periodType2, (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology7.getZone();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsText((-9700), locale8);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-10L) + "'", long6 == (-10L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-9700" + "'", str9.equals("-9700"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler5 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file6 = null;
        java.io.File[] fileArray7 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = zoneInfoCompiler5.compile(file6, fileArray7);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = zoneInfoCompiler0.compile(file4, fileArray7);
        java.io.BufferedReader bufferedReader10 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray7);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertNotNull(strMap9);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int[] intArray5 = period4.getValues();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration7, readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period9.toDurationFrom(readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant6, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.MutablePeriod mutablePeriod14 = period13.toMutablePeriod();
        java.lang.String str15 = mutablePeriod14.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(mutablePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "P0D" + "'", str15.equals("P0D"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter8 = null;
        java.lang.String str9 = period7.toString(periodFormatter8);
        org.joda.time.Period period11 = period7.plusHours((int) (short) 100);
        boolean boolean12 = periodType2.equals((java.lang.Object) period11);
        int int13 = period11.getYears();
        int int14 = period11.getMinutes();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0.002S" + "'", str9.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int6 = offsetDateTimeField4.getLeapAmount((long) (byte) 0);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsText((int) '4', locale8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField4.getAsShortText(readablePartial10, (-9700), locale12);
        int int15 = offsetDateTimeField4.getLeapAmount((-406468790591L));
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField4.getAsShortText(2277453240000000L, locale17);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "52" + "'", str9.equals("52"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-9700" + "'", str13.equals("-9700"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "136" + "'", str18.equals("136"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str11 = cachedDateTimeZone9.getNameKey((long) '4');
        long long13 = cachedDateTimeZone9.nextTransition((long) ' ');
        long long15 = cachedDateTimeZone9.convertUTCToLocal(0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0.002S" + "'", str11.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(2440587L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5282475348d + "'", double1 == 2440587.5282475348d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.weekOfWeekyear();
        try {
            long long15 = iSOChronology4.getDateTimeMillis(68L, (int) (short) 0, (-68), (int) (short) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -68 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "136");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder4.setStandardOffset((int) 'a');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = dateTimeZoneBuilder4.setFixedSavings("", (int) (byte) 100);
        java.io.DataOutput dataOutput11 = null;
        try {
            dateTimeZoneBuilder9.writeTo("52", dataOutput11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder9);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(103L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long8 = offsetDateTimeField4.add((long) ' ', (int) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField4.getAsText((int) (byte) 100, locale10);
        long long14 = offsetDateTimeField4.addWrapField(0L, (-1));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155760000032L + "'", long8 == 3155760000032L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-31536000000L) + "'", long14 == (-31536000000L));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology1.millis();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[]" + "'", str2.equals("GregorianChronology[]"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDay]", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("ZonedChronology[ISOChronology[UTC], ]", (java.lang.Number) 2440587.5d, (java.lang.Number) 196, (java.lang.Number) (short) 1);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException8);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "hi!");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        illegalFieldValueException12.prependMessage("PT1H0.002S");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearMonthDay]" + "'", str3.equals("PeriodType[YearMonthDay]"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int6 = offsetDateTimeField4.getLeapAmount((long) (byte) 0);
        boolean boolean7 = offsetDateTimeField4.isSupported();
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField4.getAsText((int) (byte) 0, locale9);
        java.lang.String str11 = offsetDateTimeField4.getName();
        int int13 = offsetDateTimeField4.getLeapAmount(196L);
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = offsetDateTimeField4.getAsText(readablePartial14, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "yearOfCentury" + "'", str11.equals("yearOfCentury"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter8 = null;
        java.lang.String str9 = period7.toString(periodFormatter8);
        org.joda.time.Period period11 = period7.plusHours((int) (short) 100);
        boolean boolean12 = periodType2.equals((java.lang.Object) period11);
        int int13 = period11.getWeeks();
        org.joda.time.Period period15 = period11.withMinutes((int) (byte) -1);
        org.joda.time.Period period17 = period11.minusSeconds((int) '#');
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period17.get(durationFieldType18);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0.002S" + "'", str9.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (short) 0, (int) (short) -1, (int) 'a', (int) '#');
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = iSOChronology6.eras();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.yearOfCentury();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType4, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology6.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology6.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology6.hourOfDay();
        org.joda.time.Period period14 = new org.joda.time.Period(obj0, periodType1, (org.joda.time.Chronology) iSOChronology6);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        try {
            long long7 = offsetDateTimeField4.set((long) 167, "-68");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -68 for yearOfCentury must be in the range [97,196]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int6 = offsetDateTimeField4.getLeapAmount((long) (byte) 0);
        boolean boolean7 = offsetDateTimeField4.isSupported();
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = offsetDateTimeField4.getAsShortText(readablePartial8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period9 = period7.minusSeconds((int) '#');
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationFrom(readableInstant10);
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11, periodType12);
        java.lang.String str14 = period13.toString();
        int int15 = period13.getMillis();
        org.joda.time.Period period17 = period13.minusYears(1);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0S" + "'", str14.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.Period period8 = new org.joda.time.Period(167, 8, (int) '#', (int) 'a', 100, (int) (short) 1, 0, 10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.Period period7 = period5.withSeconds(100);
        org.joda.time.Duration duration8 = period7.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType14 = periodType13.withSecondsRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant11, readableInstant12, periodType13);
        org.joda.time.Period period16 = new org.joda.time.Period(1L, (long) '#', periodType13);
        int int17 = periodType13.size();
        org.joda.time.PeriodType periodType18 = periodType13.withWeeksRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration8, periodType13);
        org.joda.time.ReadableInterval readableInterval20 = null;
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance(chronology21, dateTimeZone23);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int31 = fixedDateTimeZone29.getOffsetFromLocal((long) 3);
        java.lang.String str33 = fixedDateTimeZone29.getNameKey((long) (short) 1);
        int int35 = fixedDateTimeZone29.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.Chronology chronology36 = zonedChronology24.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.joda.time.Chronology chronology37 = zonedChronology24.withUTC();
        org.joda.time.Period period38 = new org.joda.time.Period((long) (byte) 1, (-4L), periodType13, chronology37);
        org.joda.time.PeriodType periodType39 = periodType13.withWeeksRemoved();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PT0.002S" + "'", str33.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(periodType39);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(6311433600032L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6311433600042L + "'", long2 == 6311433600042L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        java.lang.Object obj4 = null;
        boolean boolean5 = gregorianChronology1.equals(obj4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[]" + "'", str2.equals("GregorianChronology[]"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        boolean boolean7 = offsetDateTimeField4.isSupported();
        long long10 = offsetDateTimeField4.getDifferenceAsLong((long) 0, 1560629643334L);
        int int12 = offsetDateTimeField4.getMinimumValue((long) 1);
        boolean boolean14 = offsetDateTimeField4.isLeap(0L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-49L) + "'", long10 == (-49L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant9);
        org.joda.time.Period period12 = period10.withHours((int) (byte) 1);
        org.joda.time.Period period14 = period12.plusYears((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = period12.indexOf(durationFieldType15);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone4.getName((long) (-1), locale10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal((long) 3);
        java.lang.String str20 = fixedDateTimeZone16.getNameKey((long) (short) 1);
        long long22 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone16, (long) 0);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(readableDuration25, readableInstant26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period27.toDurationFrom(readableInstant28);
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant24, (org.joda.time.ReadableDuration) duration29);
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant23, (org.joda.time.ReadableDuration) duration29);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter35 = null;
        java.lang.String str36 = period34.toString(periodFormatter35);
        org.joda.time.Period period38 = period34.plusSeconds((int) (short) 100);
        boolean boolean39 = period31.equals((java.lang.Object) period38);
        boolean boolean40 = fixedDateTimeZone16.equals((java.lang.Object) boolean39);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.yearOfEra();
        try {
            long long50 = gregorianChronology41.getDateTimeMillis(97, (int) (short) 1, 110, (-9700), 65, 65, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9700 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.010" + "'", str11.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PT0.002S" + "'", str20.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "PT0.002S" + "'", str36.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone4.getName((long) (-1), locale10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal((long) 3);
        java.lang.String str20 = fixedDateTimeZone16.getNameKey((long) (short) 1);
        long long22 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone16, (long) 0);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(readableDuration25, readableInstant26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period27.toDurationFrom(readableInstant28);
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant24, (org.joda.time.ReadableDuration) duration29);
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant23, (org.joda.time.ReadableDuration) duration29);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter35 = null;
        java.lang.String str36 = period34.toString(periodFormatter35);
        org.joda.time.Period period38 = period34.plusSeconds((int) (short) 100);
        boolean boolean39 = period31.equals((java.lang.Object) period38);
        boolean boolean40 = fixedDateTimeZone16.equals((java.lang.Object) boolean39);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DurationField durationField42 = gregorianChronology41.weekyears();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.010" + "'", str11.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PT0.002S" + "'", str20.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "PT0.002S" + "'", str36.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(durationField42);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((-68));
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.get(durationFieldType2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "167");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.LocalDateTime localDateTime8 = null;
        boolean boolean9 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long8 = offsetDateTimeField4.add((long) ' ', (int) (byte) 100);
        boolean boolean9 = offsetDateTimeField4.isLenient();
        long long11 = offsetDateTimeField4.roundCeiling((long) (short) 100);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField4.getMaximumTextLength(locale12);
        long long15 = offsetDateTimeField4.remainder((long) (byte) 100);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155760000032L + "'", long8 == 3155760000032L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31535999990L + "'", long11 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 110L + "'", long15 == 110L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period9 = period7.minusSeconds((int) '#');
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period7.toDurationFrom(readableInstant10);
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11, periodType12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration11, readableInstant14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType17 = periodType16.withHoursRemoved();
        org.joda.time.Period period18 = period15.withPeriodType(periodType16);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType20 = periodType19.withSecondsRemoved();
        java.lang.String str21 = periodType20.toString();
        try {
            org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) periodType16, periodType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PeriodType[YearMonthDay]" + "'", str21.equals("PeriodType[YearMonthDay]"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone4.getName((long) (-1), locale10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal((long) 3);
        java.lang.String str20 = fixedDateTimeZone16.getNameKey((long) (short) 1);
        long long22 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone16, (long) 0);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(readableDuration25, readableInstant26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period27.toDurationFrom(readableInstant28);
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant24, (org.joda.time.ReadableDuration) duration29);
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant23, (org.joda.time.ReadableDuration) duration29);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter35 = null;
        java.lang.String str36 = period34.toString(periodFormatter35);
        org.joda.time.Period period38 = period34.plusSeconds((int) (short) 100);
        boolean boolean39 = period31.equals((java.lang.Object) period38);
        boolean boolean40 = fixedDateTimeZone16.equals((java.lang.Object) boolean39);
        boolean boolean42 = fixedDateTimeZone16.isStandardOffset((long) 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.010" + "'", str11.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PT0.002S" + "'", str20.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "PT0.002S" + "'", str36.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        int[] intArray3 = period2.getValues();
        org.joda.time.Period period5 = period2.plusSeconds(3);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.Period period12 = period8.plusSeconds((int) (short) 100);
        org.joda.time.Period period13 = period2.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period15 = period13.minusSeconds((int) (byte) 100);
        org.joda.time.Duration duration16 = period15.toStandardDuration();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0.002S" + "'", str10.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration16);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        int int7 = offsetDateTimeField4.getOffset();
        long long10 = offsetDateTimeField4.add((long) 100, (long) 100);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField4.getAsText(0, locale12);
        long long15 = offsetDateTimeField4.roundCeiling(2440588L);
        boolean boolean17 = offsetDateTimeField4.isLeap((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1, (java.lang.Number) 28800000L, (java.lang.Number) 2440587.5d);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = illegalFieldValueException22.getDateTimeFieldType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType23, (int) (byte) -1, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [0,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000100L + "'", long10 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str11 = cachedDateTimeZone9.getNameKey((long) '4');
        long long13 = cachedDateTimeZone9.nextTransition((long) ' ');
        int int15 = cachedDateTimeZone9.getOffset((long) (-100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0.002S" + "'", str11.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period6.toDurationFrom(readableInstant7);
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant3, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType14 = periodType13.withSecondsRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant12, periodType14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) 196, periodType14);
        int int17 = periodType14.size();
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Period period6 = period2.plusSeconds((int) (short) 100);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period6.isSupported(durationFieldType7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone3);
        try {
            long long12 = zonedChronology4.getDateTimeMillis(4, 80, 4, (int) (short) 0, (-68), 100, 55);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -68 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 10);
        org.joda.time.Period period3 = period1.plusMinutes((int) (byte) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
        long long8 = offsetDateTimeField4.roundHalfFloor((-1L));
        java.lang.String str9 = offsetDateTimeField4.getName();
        long long12 = offsetDateTimeField4.getDifferenceAsLong(31507199999L, (long) (-100));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-10L) + "'", long6 == (-10L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-10L) + "'", long8 == (-10L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfCentury" + "'", str9.equals("yearOfCentury"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("-1", (-68), 196, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -68 for -1 must be in the range [196,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean8 = fixedDateTimeZone6.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = fixedDateTimeZone6.isLocalDateTimeGap(localDateTime9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = iSOChronology16.eras();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.yearOfCentury();
        org.joda.time.Period period19 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType14, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology16.weekOfWeekyear();
        boolean boolean22 = cachedDateTimeZone11.equals((java.lang.Object) dateTimeField21);
        java.lang.String str24 = cachedDateTimeZone11.getShortName((long) 196);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone11);
        try {
            long long33 = zonedChronology25.getDateTimeMillis((int) (byte) -1, (int) 'a', 0, 0, 4, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.010" + "'", str24.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(zonedChronology25);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter12 = null;
        java.lang.String str13 = period11.toString(periodFormatter12);
        org.joda.time.Period period15 = period11.plusSeconds((int) (short) 100);
        boolean boolean16 = period8.equals((java.lang.Object) period15);
        org.joda.time.Period period18 = period8.withMinutes(0);
        org.joda.time.Period period20 = period8.withWeeks(52);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        long long4 = dateTimeZone1.adjustOffset(28799990L, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28799990L + "'", long4 == 28799990L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
        long long8 = offsetDateTimeField4.roundHalfFloor((-1L));
        boolean boolean10 = offsetDateTimeField4.isLeap(1L);
        try {
            long long13 = offsetDateTimeField4.set(28799990L, 10000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10000 for yearOfCentury must be in the range [97,196]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-10L) + "'", long6 == (-10L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-10L) + "'", long8 == (-10L));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        org.joda.time.Period period7 = new org.joda.time.Period(1L, (long) '#', periodType4);
        int int8 = periodType4.size();
        org.joda.time.PeriodType periodType9 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType10 = periodType9.withWeeksRemoved();
        java.lang.String str11 = periodType10.toString();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        boolean boolean13 = periodType10.isSupported(durationFieldType12);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PeriodType[YearMonthDay]" + "'", str11.equals("PeriodType[YearMonthDay]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "3");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder4.setStandardOffset((int) '4');
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder4.addCutover((int) '#', ' ', 52, (int) (short) 1, (-100), true, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ZonedChronology[ISOChronology[UTC], ]", (java.lang.Number) 2440587.5d, (java.lang.Number) 196, (java.lang.Number) (short) 1);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = iSOChronology1.withZone(dateTimeZone3);
        try {
            long long9 = iSOChronology1.getDateTimeMillis(52, 0, 196, 65);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-49L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210870993600000L) + "'", long1 == (-210870993600000L));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter12 = null;
        java.lang.String str13 = period11.toString(periodFormatter12);
        org.joda.time.Period period15 = period11.plusSeconds((int) (short) 100);
        boolean boolean16 = period8.equals((java.lang.Object) period15);
        org.joda.time.Period period18 = period15.minusYears(10);
        org.joda.time.Period period20 = period18.minusDays(10);
        try {
            org.joda.time.Seconds seconds21 = period18.toStandardSeconds();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Seconds as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        long long9 = offsetDateTimeField4.add(3155760000032L, (int) (short) 100);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter15 = null;
        java.lang.String str16 = period14.toString(periodFormatter15);
        org.joda.time.Period period18 = period14.withHours(0);
        int[] intArray19 = period18.getValues();
        try {
            int[] intArray21 = offsetDateTimeField4.addWrapField(readablePartial10, 0, intArray19, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6311433600032L + "'", long9 == 6311433600032L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PT0.002S" + "'", str16.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long8 = offsetDateTimeField4.add((long) ' ', (int) (byte) 100);
        boolean boolean9 = offsetDateTimeField4.isLenient();
        long long11 = offsetDateTimeField4.roundCeiling((long) (short) 100);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField4.getMaximumTextLength(locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsText((int) (byte) 1, locale15);
        int int17 = offsetDateTimeField4.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155760000032L + "'", long8 == 3155760000032L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31535999990L + "'", long11 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        boolean boolean7 = offsetDateTimeField4.isSupported();
        long long10 = offsetDateTimeField4.getDifferenceAsLong((-9768L), (long) '#');
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.lang.String str6 = dateTimeZone3.getID();
        long long9 = dateTimeZone3.adjustOffset(1L, true);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-31536000000L), (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-31535999992L) + "'", long2 == (-31535999992L));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long7 = offsetDateTimeField4.remainder((long) (short) -1);
        long long9 = offsetDateTimeField4.roundHalfFloor((long) 65);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9L + "'", long7 == 9L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-10L) + "'", long9 == (-10L));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PeriodType[YearMonthDay]", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException2.getSuppressed();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearMonthDay]" + "'", str3.equals("PeriodType[YearMonthDay]"));
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("ZonedChronology[ISOChronology[UTC], America/Los_Angeles]", (-32), (int) ' ', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for ZonedChronology[ISOChronology[UTC], America/Los_Angeles] must be in the range [32,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5);
        org.joda.time.Period period8 = period6.minusSeconds((int) '#');
        org.joda.time.Period period10 = period6.withMonths(10);
        org.joda.time.Period period12 = period10.withSeconds((-100));
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Object obj0 = null;
        org.joda.time.Period period1 = new org.joda.time.Period(obj0);
        java.lang.Class<?> wildcardClass2 = period1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("hi!");
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = iSOChronology6.eras();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.yearOfCentury();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType4, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology6.centuryOfEra();
        org.joda.time.DurationField durationField11 = iSOChronology6.eras();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = iSOChronology16.eras();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.yearOfCentury();
        org.joda.time.Period period19 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType14, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Period period21 = period19.minusMonths(65);
        int[] intArray23 = iSOChronology6.get((org.joda.time.ReadablePeriod) period21, (long) (byte) -1);
        boolean boolean24 = iSOChronology1.equals((java.lang.Object) iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int6 = offsetDateTimeField4.getLeapAmount((long) (byte) 0);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsText((int) (short) 10, locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) 'a');
        int int15 = offsetDateTimeField14.getMaximumValue();
        org.joda.time.DurationField durationField16 = offsetDateTimeField14.getLeapDurationField();
        int int17 = offsetDateTimeField14.getOffset();
        long long20 = offsetDateTimeField14.add((long) 100, (long) 100);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField14.getAsText(0, locale22);
        long long25 = offsetDateTimeField14.roundCeiling(2440588L);
        boolean boolean27 = offsetDateTimeField14.isLeap((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 1, (java.lang.Number) 28800000L, (java.lang.Number) 2440587.5d);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = illegalFieldValueException32.getDateTimeFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType33, 166);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 196 + "'", int15 == 196);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3155760000100L + "'", long20 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31535999990L + "'", long25 == 31535999990L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Days days5 = period2.toStandardDays();
        org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) period2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(days5);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField4.getMaximumShortTextLength(locale7);
        int int9 = offsetDateTimeField4.getOffset();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.LenientChronology lenientChronology14 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTimeZone dateTimeZone15 = lenientChronology14.getZone();
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType21 = periodType20.withSecondsRemoved();
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant18, readableInstant19, periodType20);
        org.joda.time.Period period23 = new org.joda.time.Period(1L, (long) '#', periodType20);
        org.joda.time.Period period24 = period23.normalizedStandard();
        int[] intArray27 = lenientChronology14.get((org.joda.time.ReadablePeriod) period23, (-49L), 28800000L);
        java.util.Locale locale29 = null;
        try {
            int[] intArray30 = offsetDateTimeField4.set(readablePartial10, (-1), intArray27, "1", locale29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for yearOfCentury must be in the range [97,196]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(lenientChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 68L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210860884800000L) + "'", long1 == (-210860884800000L));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period6.toDurationFrom(readableInstant7);
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant3, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType14 = periodType13.withSecondsRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant12, periodType14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) 196, periodType14);
        org.joda.time.Period period17 = period16.negated();
        try {
            org.joda.time.Period period19 = period17.plusSeconds(3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[]" + "'", str2.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Period period9 = period7.minusMonths(65);
        org.joda.time.Period period10 = period9.negated();
        try {
            org.joda.time.Period period12 = period9.withSeconds(97);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        int int7 = offsetDateTimeField4.getOffset();
        long long10 = offsetDateTimeField4.add((long) 100, (long) 100);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField4.getAsText(0, locale12);
        long long15 = offsetDateTimeField4.roundCeiling(2440588L);
        boolean boolean17 = offsetDateTimeField4.isLeap((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 0, (java.lang.Number) 100.0f, (java.lang.Number) 6311433600032L);
        illegalFieldValueException22.prependMessage("-68");
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000100L + "'", long10 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(80);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DurationField durationField9 = iSOChronology4.eras();
        long long13 = iSOChronology4.add(110L, (long) 166, 65);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10900L + "'", long13 == 10900L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = iSOChronology1.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology1.withUTC();
        java.lang.String str6 = iSOChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[]" + "'", str6.equals("ISOChronology[]"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
        long long8 = offsetDateTimeField4.roundHalfFloor((-1L));
        boolean boolean9 = offsetDateTimeField4.isSupported();
        long long11 = offsetDateTimeField4.roundCeiling(32L);
        java.lang.String str13 = offsetDateTimeField4.getAsShortText((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) 'a');
        int int19 = offsetDateTimeField18.getMaximumValue();
        org.joda.time.DurationField durationField20 = offsetDateTimeField18.getLeapDurationField();
        int int21 = offsetDateTimeField18.getOffset();
        long long24 = offsetDateTimeField18.add((long) 100, (long) 100);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField18.getAsText(0, locale26);
        long long29 = offsetDateTimeField18.roundCeiling(2440588L);
        boolean boolean31 = offsetDateTimeField18.isLeap((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField18.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) 1, (java.lang.Number) 28800000L, (java.lang.Number) 2440587.5d);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType32, 3);
        long long40 = dividedDateTimeField38.roundFloor((long) (-32));
        try {
            long long43 = dividedDateTimeField38.add((long) 100, 1560629643324L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 4681888929972");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-10L) + "'", long6 == (-10L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-10L) + "'", long8 == (-10L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31535999990L + "'", long11 == 31535999990L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "167" + "'", str13.equals("167"));
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 196 + "'", int19 == 196);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3155760000100L + "'", long24 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 31535999990L + "'", long29 == 31535999990L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-63158400010L) + "'", long40 == (-63158400010L));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.Period period4 = period2.withSeconds(100);
        int int5 = period2.getHours();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType11 = periodType10.withSecondsRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
        org.joda.time.Period period13 = new org.joda.time.Period(1L, (long) '#', periodType10);
        int int14 = periodType10.size();
        int int15 = periodType10.size();
        org.joda.time.PeriodType periodType16 = periodType10.withHoursRemoved();
        org.joda.time.Period period17 = period2.normalizedStandard(periodType16);
        org.joda.time.DurationFieldType durationFieldType18 = null;
        boolean boolean19 = period17.isSupported(durationFieldType18);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant9);
        org.joda.time.Period period12 = period10.withHours((int) (byte) 1);
        org.joda.time.Period period14 = period12.plusYears((int) (byte) 10);
        org.joda.time.Days days15 = period12.toStandardDays();
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(days15);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5);
        org.joda.time.Period period7 = period6.negated();
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.hourOfDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        try {
            long long12 = iSOChronology4.set(readablePartial10, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        boolean boolean8 = fixedDateTimeZone4.equals((java.lang.Object) 2440587.5d);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) (byte) 1);
        long long12 = fixedDateTimeZone4.nextTransition(100L);
        java.util.TimeZone timeZone13 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long7 = offsetDateTimeField4.remainder((long) (short) -1);
        java.lang.String str9 = offsetDateTimeField4.getAsText(100L);
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
        int int11 = offsetDateTimeField4.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField4.getAsText(readablePartial12, (int) (byte) -1, locale14);
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField4.getWrappedField();
        long long18 = offsetDateTimeField4.roundHalfCeiling((-63158400010L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9L + "'", long7 == 9L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "167" + "'", str9.equals("167"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-63158400010L) + "'", long18 == (-63158400010L));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-406555190591L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2435882.0001089005d + "'", double1 == 2435882.0001089005d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Period period6 = period2.plusHours((int) (short) 100);
        org.joda.time.Period period8 = period6.minusMillis((int) '4');
        org.joda.time.Period period10 = period6.withYears((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableDuration13, readableInstant14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period15.toDurationFrom(readableInstant16);
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant12, (org.joda.time.ReadableDuration) duration17);
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant11, (org.joda.time.ReadableDuration) duration17);
        org.joda.time.Period period22 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter23 = null;
        java.lang.String str24 = period22.toString(periodFormatter23);
        org.joda.time.Period period26 = period22.plusSeconds((int) (short) 100);
        boolean boolean27 = period19.equals((java.lang.Object) period26);
        org.joda.time.Period period29 = period26.withHours((int) (short) 100);
        java.lang.String str30 = period26.toString();
        org.joda.time.Period period32 = period26.withMillis((-100));
        org.joda.time.Period period33 = period10.minus((org.joda.time.ReadablePeriod) period26);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PT0.002S" + "'", str24.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PT100.002S" + "'", str30.equals("PT100.002S"));
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period33);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Coordinated Universal Time");
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long8 = offsetDateTimeField4.add((long) ' ', (int) (byte) 100);
        boolean boolean9 = offsetDateTimeField4.isLenient();
        long long11 = offsetDateTimeField4.roundCeiling((long) (short) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, 100);
        long long15 = offsetDateTimeField4.roundHalfFloor(2277453240000000L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155760000032L + "'", long8 == 3155760000032L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31535999990L + "'", long11 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2277465206399990L + "'", long15 == 2277465206399990L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Period period6 = period2.plusSeconds((int) (short) 100);
        org.joda.time.Period period8 = period2.withHours((int) (short) 1);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.Period period12 = period8.withHours((int) (byte) 1);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationFrom(readableInstant13);
        org.joda.time.Hours hours15 = period12.toStandardHours();
        org.joda.time.DurationFieldType[] durationFieldTypeArray16 = period12.getFieldTypes();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT1H0.002S" + "'", str10.equals("PT1H0.002S"));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(hours15);
        org.junit.Assert.assertNotNull(durationFieldTypeArray16);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "ISOChronology[]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap3);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6);
        org.joda.time.Period period11 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter12 = null;
        java.lang.String str13 = period11.toString(periodFormatter12);
        org.joda.time.Period period15 = period11.plusSeconds((int) (short) 100);
        boolean boolean16 = period8.equals((java.lang.Object) period15);
        org.joda.time.Period period18 = period15.withHours((int) (short) 100);
        java.lang.String str19 = period15.toString();
        org.joda.time.Period period21 = period15.withMillis((-100));
        int int22 = period21.getDays();
        org.joda.time.Period period25 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.Period period27 = period25.withSeconds(100);
        int int28 = period25.getHours();
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType34 = periodType33.withSecondsRemoved();
        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant31, readableInstant32, periodType33);
        org.joda.time.Period period36 = new org.joda.time.Period(1L, (long) '#', periodType33);
        int int37 = periodType33.size();
        int int38 = periodType33.size();
        org.joda.time.PeriodType periodType39 = periodType33.withHoursRemoved();
        org.joda.time.Period period40 = period25.normalizedStandard(periodType39);
        try {
            org.joda.time.Period period41 = period21.withPeriodType(periodType39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'seconds'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PT100.002S" + "'", str19.equals("PT100.002S"));
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(period40);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("3", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"3/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = iSOChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.weekyearOfCentury();
        org.joda.time.Chronology chronology6 = iSOChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationFrom(readableInstant6);
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration7);
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7);
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType13 = periodType12.withSecondsRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant11, periodType13);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant15);
        org.joda.time.Minutes minutes17 = period16.toStandardMinutes();
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(minutes17);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-35) + "'", int1 == (-35));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = iSOChronology14.eras();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = iSOChronology14.withZone(dateTimeZone16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) 100, (-210865896000000L), chronology17);
        int[] intArray20 = iSOChronology4.get((org.joda.time.ReadablePeriod) period18, 10L);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period(readableDuration23, readableInstant24);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Duration duration27 = period25.toDurationFrom(readableInstant26);
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant22, (org.joda.time.ReadableDuration) duration27);
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant21, (org.joda.time.ReadableDuration) duration27);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter33 = null;
        java.lang.String str34 = period32.toString(periodFormatter33);
        org.joda.time.Period period36 = period32.plusSeconds((int) (short) 100);
        boolean boolean37 = period29.equals((java.lang.Object) period36);
        org.joda.time.Period period39 = period36.withHours((int) (short) 100);
        java.lang.String str40 = period36.toString();
        org.joda.time.Period period41 = period18.plus((org.joda.time.ReadablePeriod) period36);
        int int42 = period41.getYears();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PT0.002S" + "'", str34.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PT100.002S" + "'", str40.equals("PT100.002S"));
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-6682) + "'", int42 == (-6682));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(52, 52, 166);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(4);
        java.io.DataOutput dataOutput6 = null;
        try {
            dateTimeZoneBuilder0.writeTo("GregorianChronology[,mdfw=1]", dataOutput6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = lenientChronology2.getZone();
        org.joda.time.Chronology chronology4 = lenientChronology2.withUTC();
        org.joda.time.DurationField durationField5 = lenientChronology2.weekyears();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = iSOChronology7.eras();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = iSOChronology7.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.weekyearOfCentury();
        org.joda.time.Chronology chronology12 = iSOChronology7.withUTC();
        try {
            org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) durationField5, chronology12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period3.toString(periodFormatter4);
        org.joda.time.Period period7 = period3.plusSeconds((int) (short) 100);
        org.joda.time.Period period9 = period3.withHours((int) (short) 1);
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period9.toString(periodFormatter10);
        org.joda.time.Period period13 = period9.withHours((int) (byte) 1);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationFrom(readableInstant14);
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration15);
        int int17 = period16.getMinutes();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0.002S" + "'", str5.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT1H0.002S" + "'", str11.equals("PT1H0.002S"));
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter8 = null;
        java.lang.String str9 = period7.toString(periodFormatter8);
        org.joda.time.Period period11 = period7.plusHours((int) (short) 100);
        boolean boolean12 = periodType2.equals((java.lang.Object) period11);
        int int13 = period11.getWeeks();
        org.joda.time.Period period15 = period11.withMinutes((int) (byte) -1);
        org.joda.time.Period period17 = period11.multipliedBy((int) (byte) 0);
        org.joda.time.Period period19 = period11.minusWeeks(97);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0.002S" + "'", str9.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfMonth();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean11 = fixedDateTimeZone9.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = fixedDateTimeZone9.isLocalDateTimeGap(localDateTime12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Chronology chronology15 = iSOChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration17, readableInstant18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period19.toDurationFrom(readableInstant20);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant16, (org.joda.time.ReadableDuration) duration21);
        int[] intArray25 = iSOChronology1.get((org.joda.time.ReadablePeriod) period22, (long) (short) 1, 0L);
        org.joda.time.Days days26 = period22.toStandardDays();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(days26);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology4.hourOfDay();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType15 = periodType14.withSecondsRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant12, readableInstant13, periodType14);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType20 = periodType19.withSecondsRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant17, readableInstant18, periodType19);
        org.joda.time.Period period24 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.Period period28 = period24.plusHours((int) (short) 100);
        boolean boolean29 = periodType19.equals((java.lang.Object) period28);
        org.joda.time.PeriodType periodType30 = periodType19.withHoursRemoved();
        org.joda.time.Period period31 = period16.withPeriodType(periodType30);
        org.joda.time.PeriodType periodType32 = org.joda.time.DateTimeUtils.getPeriodType(periodType30);
        try {
            org.joda.time.Period period33 = new org.joda.time.Period((java.lang.Object) iSOChronology4, periodType30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT0.002S" + "'", str26.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(periodType32);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
        int int8 = offsetDateTimeField4.getMinimumValue((long) (short) 100);
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField4.getWrappedField();
        int int11 = offsetDateTimeField4.getMinimumValue((long) 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-10L) + "'", long6 == (-10L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("267");
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long8 = offsetDateTimeField4.add((long) ' ', (int) (byte) 100);
        boolean boolean9 = offsetDateTimeField4.isLenient();
        long long11 = offsetDateTimeField4.roundCeiling((long) (short) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, 100);
        long long15 = offsetDateTimeField13.roundFloor(3155760000001L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155760000032L + "'", long8 == 3155760000032L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31535999990L + "'", long11 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3155759999990L + "'", long15 == 3155759999990L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone9.getUncachedZone();
        int int12 = cachedDateTimeZone9.getStandardOffset((long) 10);
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone9.getUncachedZone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeZone dateTimeZone13 = lenientChronology12.getZone();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType19 = periodType18.withSecondsRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant16, readableInstant17, periodType18);
        org.joda.time.Period period21 = new org.joda.time.Period(1L, (long) '#', periodType18);
        org.joda.time.Period period22 = period21.normalizedStandard();
        int[] intArray25 = lenientChronology12.get((org.joda.time.ReadablePeriod) period21, (-49L), 28800000L);
        int[] intArray28 = iSOChronology4.get((org.joda.time.ReadablePeriod) period21, (long) (-68), (long) (-9700));
        org.joda.time.PeriodType periodType29 = period21.getPeriodType();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(periodType29);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long8 = offsetDateTimeField4.add((long) ' ', (int) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField4.getAsText(4, locale10);
        int int12 = offsetDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155760000032L + "'", long8 == 3155760000032L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4" + "'", str11.equals("4"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 196 + "'", int12 == 196);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 3);
        java.lang.String str13 = fixedDateTimeZone9.getNameKey((long) (short) 1);
        int int15 = fixedDateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean22 = fixedDateTimeZone20.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime23 = null;
        boolean boolean24 = fixedDateTimeZone20.isLocalDateTimeGap(localDateTime23);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        long long27 = fixedDateTimeZone9.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone25, 1560629643334L);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Period period31 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter32 = null;
        java.lang.String str33 = period31.toString(periodFormatter32);
        org.joda.time.Period period35 = period31.plusSeconds((int) (short) 100);
        org.joda.time.Period period37 = period31.withHours((int) (short) 1);
        org.joda.time.format.PeriodFormatter periodFormatter38 = null;
        java.lang.String str39 = period37.toString(periodFormatter38);
        org.joda.time.Period period41 = period37.withHours((int) (byte) 1);
        boolean boolean42 = fixedDateTimeZone9.equals((java.lang.Object) period41);
        int int44 = fixedDateTimeZone9.getOffsetFromLocal(10L);
        java.util.TimeZone timeZone45 = fixedDateTimeZone9.toTimeZone();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0.002S" + "'", str13.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560629643334L + "'", long27 == 1560629643334L);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PT0.002S" + "'", str33.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PT1H0.002S" + "'", str39.equals("PT1H0.002S"));
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
        org.junit.Assert.assertNotNull(timeZone45);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter8 = null;
        java.lang.String str9 = period7.toString(periodFormatter8);
        org.joda.time.Period period11 = period7.plusHours((int) (short) 100);
        boolean boolean12 = periodType2.equals((java.lang.Object) period11);
        int int13 = period11.getWeeks();
        org.joda.time.Period period15 = period11.withMinutes((int) (byte) -1);
        org.joda.time.Period period17 = period11.minusSeconds((int) '#');
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType23 = periodType22.withSecondsRemoved();
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant20, readableInstant21, periodType22);
        org.joda.time.Period period25 = new org.joda.time.Period(1L, (long) '#', periodType22);
        int int26 = periodType22.size();
        org.joda.time.PeriodType periodType27 = periodType22.withWeeksRemoved();
        try {
            org.joda.time.Period period28 = period17.withPeriodType(periodType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'hours'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0.002S" + "'", str9.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
        org.junit.Assert.assertNotNull(periodType27);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Period period6 = period2.plusSeconds((int) (short) 100);
        org.joda.time.Period period8 = period2.withHours((int) (short) 1);
        org.joda.time.Period period10 = period2.plusMonths((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.Period period13 = period10.withFieldAdded(durationFieldType11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 3);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getName((-10L), locale8);
        long long12 = fixedDateTimeZone4.convertLocalToUTC((long) 32, true);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType18 = periodType17.withSecondsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant15, readableInstant16, periodType17);
        org.joda.time.Period period20 = new org.joda.time.Period(1L, (long) '#', periodType17);
        int int21 = periodType17.size();
        org.joda.time.PeriodType periodType22 = periodType17.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        org.joda.time.PeriodType periodType24 = periodType22.withWeeksRemoved();
        boolean boolean25 = fixedDateTimeZone4.equals((java.lang.Object) periodType24);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.010" + "'", str9.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 22L + "'", long12 == 22L);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        int[] intArray3 = period2.getValues();
        org.joda.time.Period period5 = period2.plusSeconds(3);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.Period period12 = period8.plusSeconds((int) (short) 100);
        org.joda.time.Period period13 = period2.withFields((org.joda.time.ReadablePeriod) period8);
        int int14 = period13.getMillis();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0.002S" + "'", str10.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
        long long8 = offsetDateTimeField4.roundHalfFloor((-1L));
        boolean boolean9 = offsetDateTimeField4.isSupported();
        long long11 = offsetDateTimeField4.roundCeiling(32L);
        java.lang.String str13 = offsetDateTimeField4.getAsShortText((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) 'a');
        int int19 = offsetDateTimeField18.getMaximumValue();
        org.joda.time.DurationField durationField20 = offsetDateTimeField18.getLeapDurationField();
        int int21 = offsetDateTimeField18.getOffset();
        long long24 = offsetDateTimeField18.add((long) 100, (long) 100);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField18.getAsText(0, locale26);
        long long29 = offsetDateTimeField18.roundCeiling(2440588L);
        boolean boolean31 = offsetDateTimeField18.isLeap((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField18.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) 1, (java.lang.Number) 28800000L, (java.lang.Number) 2440587.5d);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType32, 3);
        long long40 = dividedDateTimeField38.roundFloor((long) (-32));
        int int42 = dividedDateTimeField38.get((long) (short) -1);
        int int45 = dividedDateTimeField38.getDifference((-1L), 0L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-10L) + "'", long6 == (-10L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-10L) + "'", long8 == (-10L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31535999990L + "'", long11 == 31535999990L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "167" + "'", str13.equals("167"));
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 196 + "'", int19 == 196);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3155760000100L + "'", long24 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 31535999990L + "'", long29 == 31535999990L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-63158400010L) + "'", long40 == (-63158400010L));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 55 + "'", int42 == 55);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int6 = offsetDateTimeField4.getLeapAmount((long) (byte) 0);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsText((int) '4', locale8);
        long long12 = offsetDateTimeField4.add(0L, 0L);
        java.util.Locale locale15 = null;
        try {
            long long16 = offsetDateTimeField4.set((long) (byte) 0, "GregorianChronology[America/Los_Angeles]", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "52" + "'", str9.equals("52"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.yearOfCentury();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType2, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.centuryOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology4.weekyearOfCentury();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
        long long8 = offsetDateTimeField4.roundHalfFloor((-1L));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText(readablePartial9, (-100), locale11);
        long long14 = offsetDateTimeField4.roundCeiling((long) 100);
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField4.getMaximumShortTextLength(locale15);
        long long19 = offsetDateTimeField4.addWrapField((long) (-6682), (-1));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-10L) + "'", long6 == (-10L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-10L) + "'", long8 == (-10L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-100" + "'", str12.equals("-100"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31535999990L + "'", long14 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31536006682L) + "'", long19 == (-31536006682L));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter8 = null;
        java.lang.String str9 = period7.toString(periodFormatter8);
        org.joda.time.Period period11 = period7.plusHours((int) (short) 100);
        boolean boolean12 = periodType2.equals((java.lang.Object) period11);
        int int13 = period11.getWeeks();
        org.joda.time.Period period15 = period11.withMinutes((int) (byte) -1);
        org.joda.time.Period period17 = period11.minusSeconds((int) '#');
        org.joda.time.Period period19 = period17.plusSeconds(196);
        org.joda.time.PeriodType periodType20 = period17.getPeriodType();
        org.joda.time.PeriodType periodType21 = periodType20.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0.002S" + "'", str9.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        org.joda.time.Period period7 = new org.joda.time.Period(1L, (long) '#', periodType4);
        org.joda.time.Period period8 = period7.normalizedStandard();
        org.joda.time.Weeks weeks9 = period7.toStandardWeeks();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(weeks9);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter3 = null;
        java.lang.String str4 = period2.toString(periodFormatter3);
        org.joda.time.Period period6 = period2.plusSeconds((int) (short) 100);
        org.joda.time.Period period8 = period2.withHours((int) (short) 1);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.Period period12 = period8.withHours((int) (byte) 1);
        int int13 = period8.getMonths();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0.002S" + "'", str4.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT1H0.002S" + "'", str10.equals("PT1H0.002S"));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int[] intArray5 = period4.getValues();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration7, readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period9.toDurationFrom(readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant6, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.Period period13 = period4.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.MutablePeriod mutablePeriod14 = period13.toMutablePeriod();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = iSOChronology16.eras();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.yearOfCentury();
        boolean boolean19 = mutablePeriod14.equals((java.lang.Object) dateTimeField18);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(mutablePeriod14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearDay();
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration8, readableInstant9, periodType10);
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 1, (-1), 2, (int) '4', (int) (byte) 0, 55, (int) (byte) 0, (int) (byte) -1, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int6 = offsetDateTimeField4.getLeapAmount((long) (byte) 0);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsText((int) (short) 10, locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) 'a');
        int int15 = offsetDateTimeField14.getMaximumValue();
        org.joda.time.DurationField durationField16 = offsetDateTimeField14.getLeapDurationField();
        int int17 = offsetDateTimeField14.getOffset();
        long long20 = offsetDateTimeField14.add((long) 100, (long) 100);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField14.getAsText(0, locale22);
        long long25 = offsetDateTimeField14.roundCeiling(2440588L);
        boolean boolean27 = offsetDateTimeField14.isLeap((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 1, (java.lang.Number) 28800000L, (java.lang.Number) 2440587.5d);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = illegalFieldValueException32.getDateTimeFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType33, 166);
        try {
            long long38 = remainderDateTimeField35.set(31536000001L, 110);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 276 for yearOfCentury must be in the range [97,196]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 196 + "'", int15 == 196);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3155760000100L + "'", long20 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31535999990L + "'", long25 == 31535999990L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5);
        org.joda.time.Period period8 = period6.minusSeconds((int) '#');
        org.joda.time.Period period10 = period8.minusHours((int) ' ');
        int int11 = period10.getSeconds();
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-35) + "'", int11 == (-35));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int6 = offsetDateTimeField4.getLeapAmount((long) (byte) 0);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsText((int) (short) 10, locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) 'a');
        int int15 = offsetDateTimeField14.getMaximumValue();
        org.joda.time.DurationField durationField16 = offsetDateTimeField14.getLeapDurationField();
        int int17 = offsetDateTimeField14.getOffset();
        long long20 = offsetDateTimeField14.add((long) 100, (long) 100);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField14.getAsText(0, locale22);
        long long25 = offsetDateTimeField14.roundCeiling(2440588L);
        boolean boolean27 = offsetDateTimeField14.isLeap((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 1, (java.lang.Number) 28800000L, (java.lang.Number) 2440587.5d);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = illegalFieldValueException32.getDateTimeFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType33, 166);
        long long38 = remainderDateTimeField35.addWrapField(0L, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.eras();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology40.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology40.dayOfWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone48 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int50 = fixedDateTimeZone48.getOffsetFromLocal((long) 3);
        java.lang.String str52 = fixedDateTimeZone48.getNameKey((long) (short) 1);
        int int54 = fixedDateTimeZone48.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone59 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean61 = fixedDateTimeZone59.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime62 = null;
        boolean boolean63 = fixedDateTimeZone59.isLocalDateTimeGap(localDateTime62);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone64 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone59);
        long long66 = fixedDateTimeZone48.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone64, 1560629643334L);
        org.joda.time.chrono.ZonedChronology zonedChronology67 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology40, (org.joda.time.DateTimeZone) fixedDateTimeZone48);
        java.lang.String str69 = fixedDateTimeZone48.getNameKey((long) 4);
        boolean boolean70 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 1, (java.lang.Object) fixedDateTimeZone48);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 196 + "'", int15 == 196);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3155760000100L + "'", long20 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31535999990L + "'", long25 == 31535999990L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 31536000000L + "'", long38 == 31536000000L);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "PT0.002S" + "'", str52.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 10 + "'", int54 == 10);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone64);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560629643334L + "'", long66 == 1560629643334L);
        org.junit.Assert.assertNotNull(zonedChronology67);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "PT0.002S" + "'", str69.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        long long6 = offsetDateTimeField4.roundFloor((long) (byte) -1);
        long long8 = offsetDateTimeField4.roundHalfFloor((-1L));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsShortText(readablePartial9, (-100), locale11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.yearOfCentury();
        org.joda.time.Period period22 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType17, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology19.centuryOfEra();
        org.joda.time.DurationField durationField24 = iSOChronology19.eras();
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = iSOChronology29.eras();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.yearOfCentury();
        org.joda.time.Period period32 = new org.joda.time.Period((long) 3, (long) (byte) 0, periodType27, (org.joda.time.Chronology) iSOChronology29);
        org.joda.time.Period period34 = period32.minusMonths(65);
        int[] intArray36 = iSOChronology19.get((org.joda.time.ReadablePeriod) period34, (long) (byte) -1);
        java.util.Locale locale38 = null;
        try {
            int[] intArray39 = offsetDateTimeField4.set(readablePartial13, 166, intArray36, "100", locale38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 166");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-10L) + "'", long6 == (-10L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-10L) + "'", long8 == (-10L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-100" + "'", str12.equals("-100"));
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(intArray36);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) 'a');
        int int2 = period1.getWeeks();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType8 = periodType7.withSecondsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant5, readableInstant6, periodType7);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period16 = period12.plusHours((int) (short) 100);
        boolean boolean17 = periodType7.equals((java.lang.Object) period16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology19);
        org.joda.time.DateTimeZone dateTimeZone21 = lenientChronology20.getZone();
        org.joda.time.Period period22 = new org.joda.time.Period(201965875201412L, 31536000001L, periodType7, (org.joda.time.Chronology) lenientChronology20);
        org.joda.time.Period period23 = period1.withPeriodType(periodType7);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0.002S" + "'", str14.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(period23);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getLeapDurationField();
        int int7 = offsetDateTimeField4.getOffset();
        long long10 = offsetDateTimeField4.add((long) 100, (long) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = offsetDateTimeField4.getAsText(readablePartial11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000100L + "'", long10 == 3155760000100L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str11 = cachedDateTimeZone9.getNameKey((long) '4');
        long long13 = cachedDateTimeZone9.nextTransition((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone9.getUncachedZone();
        long long18 = cachedDateTimeZone9.convertLocalToUTC(3155760000001L, true, (long) ' ');
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0.002S" + "'", str11.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3155759999991L + "'", long18 == 3155759999991L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 3);
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getName((-10L), locale8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.010" + "'", str9.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-10L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "PT0.002S", 10, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.Object obj8 = null;
        boolean boolean9 = gregorianChronology7.equals(obj8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 100, (long) (-100));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 200L + "'", long2 == 200L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.eras();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = iSOChronology1.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology1.withUTC();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.Period period12 = period8.plusSeconds((int) (short) 100);
        org.joda.time.Period period14 = period8.withHours((int) (short) 1);
        org.joda.time.format.PeriodFormatter periodFormatter15 = null;
        java.lang.String str16 = period14.toString(periodFormatter15);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        int int18 = period14.get(durationFieldType17);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.Period period22 = period14.minus((org.joda.time.ReadablePeriod) period21);
        boolean boolean23 = org.joda.time.field.FieldUtils.equals((java.lang.Object) chronology5, (java.lang.Object) period21);
        org.joda.time.Weeks weeks24 = period21.toStandardWeeks();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT0.002S" + "'", str10.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PT1H0.002S" + "'", str16.equals("PT1H0.002S"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(weeks24);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "hi!");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology1.months();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType8 = periodType7.withSecondsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant5, readableInstant6, periodType7);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (-1), 1L);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period16 = period12.plusHours((int) (short) 100);
        boolean boolean17 = periodType7.equals((java.lang.Object) period16);
        org.joda.time.PeriodType periodType18 = periodType7.withHoursRemoved();
        org.joda.time.Period period19 = period4.withPeriodType(periodType18);
        org.joda.time.Period period21 = period4.minusDays(360060000);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT0.002S" + "'", str14.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long7 = offsetDateTimeField4.remainder((long) (short) -1);
        int int10 = offsetDateTimeField4.getDifference((long) (-100), 0L);
        java.lang.String str11 = offsetDateTimeField4.getName();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9L + "'", long7 == 9L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "yearOfCentury" + "'", str11.equals("yearOfCentury"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long8 = offsetDateTimeField4.add(1L, (int) (short) 1);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsText(readablePartial9, (-68), locale11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = offsetDateTimeField4.getAsText(readablePartial13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 31536000001L + "'", long8 == 31536000001L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-68" + "'", str12.equals("-68"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) 'a');
        int int5 = offsetDateTimeField4.getMaximumValue();
        long long8 = offsetDateTimeField4.add(1L, (int) (short) 1);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsText(readablePartial9, (-68), locale11);
        long long14 = offsetDateTimeField4.roundCeiling(3155760000100L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 196 + "'", int5 == 196);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 31536000001L + "'", long8 == 31536000001L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-68" + "'", str12.equals("-68"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3187295999990L + "'", long14 == 3187295999990L);
    }
}

