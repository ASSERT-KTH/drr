import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1.0f), "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, (int) (byte) 0);
        try {
            mutableDateTime1.setMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test011");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560344831673L + "'", long0 == 1560344831673L);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test013");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 0);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PST" + "'", str2.equals("PST"));
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 100, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 132L + "'", long2 == 132L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        try {
            org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str1 = dateTimeZone0.toString();
//        long long4 = dateTimeZone0.convertLocalToUTC((long) (short) 1, false);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "America/Los_Angeles" + "'", str1.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28800001L + "'", long4 == 28800001L);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        java.util.Locale locale7 = null;
        try {
            long long8 = skipDateTimeField4.set((-1L), "America/Los_Angeles", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            long long3 = iSOChronology0.set(readablePartial1, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(1, (int) (byte) -1, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType7, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str7 = dateTimeZone6.toString();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 10, 0, (int) (byte) 10, 0, (int) (short) 1, (int) (short) -1, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:10" + "'", str7.equals("+00:10"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType5, 100, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.property(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfHour();
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = mutableDateTime3.toCalendar(locale5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.hourOfHalfday();
        org.joda.time.DurationField durationField9 = buddhistChronology7.days();
        boolean boolean10 = mutableDateTime3.equals((java.lang.Object) durationField9);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long6 = gregorianChronology1.getDateTimeMillis((int) (byte) 100, 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology2 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(292279536, 100, (int) '#', 100, 1, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        mutableDateTime0.addYears((int) (short) 100);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        try {
            long long10 = gJChronology2.getDateTimeMillis((int) ' ', 292279536, (int) (byte) 10, (int) ' ', 36600035, (int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        java.lang.String str5 = property4.getAsText();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.DateTime dateTime8 = property4.setCopy("America/Los_Angeles", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AD" + "'", str5.equals("AD"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(292279536, 100, (int) '4', 36600035, 1, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36600035 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 100, dateTimeZone3);
        org.joda.time.DateTime.Property property6 = dateTime5.era();
        org.joda.time.DateTime dateTime7 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime7.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (byte) -1);
        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.LocalDate localDate13 = dateTime11.toLocalDate();
        boolean boolean14 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate13);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2592000100L + "'", long12 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 132L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = mutableDateTime1.toCalendar(locale3);
        mutableDateTime1.addMinutes(36600035);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology7, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipDateTimeField11.getMaximumValue(readablePartial12);
        boolean boolean15 = skipDateTimeField11.isLeap((long) 'a');
        long long17 = skipDateTimeField11.roundHalfFloor(0L);
        try {
            mutableDateTime1.setRounding((org.joda.time.DateTimeField) skipDateTimeField11, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 59");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 292279536 + "'", int13 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-259800000L) + "'", long17 == (-259800000L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((-1));
        org.joda.time.MutableDateTime mutableDateTime5 = property2.roundHalfCeiling();
        org.joda.time.MutableDateTime mutableDateTime7 = property2.addWrapField(0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3);
        int int5 = mutableDateTime1.getSecondOfDay();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 600 + "'", int5 == 600);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(100, (int) '#', 0, (int) '#', 59, (int) (short) -1, (int) (byte) 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property11 = dateTime9.era();
        long long12 = dateTime9.getMillis();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2592000100L + "'", long10 == 2592000100L);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2592000100L + "'", long12 == 2592000100L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("17", "17");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("America/Los_Angeles", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        long long5 = dateTimeZone2.convertLocalToUTC(100L, false);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone2.getShortName((long) (short) 0, locale7);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-599900L) + "'", long5 == (-599900L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:10" + "'", str8.equals("+00:10"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 100, dateTimeZone3);
        org.joda.time.DateTime.Property property6 = dateTime5.era();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        org.joda.time.DateTime dateTime8 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = dateTime8.withZoneRetainFields(dateTimeZone9);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfEven();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 100, dateTimeZone5);
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime dateTime9 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime11 = dateTime9.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime13 = dateTime11.plusDays((int) (byte) -1);
        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.LocalDate localDate15 = dateTime13.toLocalDate();
        boolean boolean16 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate15);
        try {
            int int17 = property2.compareTo((org.joda.time.ReadablePartial) localDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2592000100L + "'", long14 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 36600035, (long) 600000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 21960021000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        int int2 = mutableDateTime1.getEra();
        mutableDateTime1.addHours((-1));
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        mutableDateTime1.add(readablePeriod5);
        mutableDateTime1.addSeconds(0);
        try {
            mutableDateTime1.setTime((int) (short) 0, 36600035, 600000, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36600035 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        int int5 = skipDateTimeField4.getMinimumValue();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField4, (int) (short) 1, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for weekyear must be in the range [0,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-292268512) + "'", int5 == (-292268512));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.Chronology chronology4 = gJChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType7, (int) (short) 1, 100, (-292268512));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        long long7 = buddhistChronology0.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 100, dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime12.era();
        org.joda.time.DateTime dateTime14 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime16 = dateTime14.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime18 = dateTime16.plusDays((int) (byte) -1);
        long long19 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.LocalDate localDate20 = dateTime18.toLocalDate();
        int[] intArray22 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate20, (long) 100);
        try {
            long long28 = buddhistChronology0.getDateTimeMillis((long) 10, (int) (short) 1, 600000, (int) (short) 10, (-292268512));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 600000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-538965L) + "'", long7 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2592000100L + "'", long19 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            long long6 = iSOChronology0.getDateTimeMillis(0L, 0, (int) (short) 100, 6, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(600, (int) (short) 1, (int) (short) 1, 600, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DurationField durationField7 = skipDateTimeField4.getRangeDurationField();
        boolean boolean9 = skipDateTimeField4.isLeap(1L);
        java.util.Locale locale12 = null;
        try {
            long long13 = skipDateTimeField4.set((-600000L), "+00:10", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:10\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        java.util.Locale locale8 = null;
        try {
            long long9 = offsetDateTimeField3.set((long) 10, "hi!", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0, (int) '#', 2, 0, (int) (byte) 1, (int) (byte) 1, 600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 600000 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 100, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        boolean boolean7 = gregorianChronology1.equals((java.lang.Object) dateTime5);
        boolean boolean9 = dateTime5.isEqual((long) (byte) -1);
        int int10 = dateTime5.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = dateTime3.minusWeeks(1970);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        boolean boolean11 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        int int12 = dateTime9.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime9.plusMillis((int) (byte) 0);
        java.util.Date date15 = dateTime14.toDate();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        org.joda.time.TimeOfDay timeOfDay11 = dateTime9.toTimeOfDay();
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) timeOfDay11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfYear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(timeOfDay11);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 100, 0);
        int int9 = offsetDateTimeField3.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 100, dateTimeZone11);
        org.joda.time.DateTime.Property property14 = dateTime13.era();
        org.joda.time.DateTime dateTime15 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime17 = dateTime15.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime19 = dateTime17.plusDays((int) (byte) -1);
        long long20 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
        boolean boolean22 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate21);
        int[] intArray25 = new int[] { 2019 };
        try {
            int[] intArray27 = offsetDateTimeField3.addWrapPartial((org.joda.time.ReadablePartial) localDate21, (-1), intArray25, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 33 + "'", int9 == 33);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2592000100L + "'", long20 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            int int2 = dateTime0.get(dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) 'a');
        boolean boolean8 = dateTime5.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfEven();
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = property2.set(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 100, dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime12.era();
        org.joda.time.DateTime dateTime14 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime16 = dateTime14.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime18 = dateTime16.plusDays((int) (byte) -1);
        long long19 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.LocalDate localDate20 = dateTime18.toLocalDate();
        int int21 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField24 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType22, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2592000100L + "'", long19 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-292268511) + "'", int21 == (-292268511));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone1);
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = dateTime7.toString("", locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 600000 + "'", int6 == 600000);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (byte) -1);
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.LocalDate localDate18 = dateTime16.toLocalDate();
        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate18);
        int int20 = skipDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate18);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) skipDateTimeField4, (java.lang.Object) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology23, dateTimeField25, 0);
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = skipDateTimeField27.getMaximumValue(readablePartial28);
        boolean boolean31 = skipDateTimeField27.isLeap((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime34 = org.joda.time.MutableDateTime.now(dateTimeZone33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 100, dateTimeZone33);
        org.joda.time.DateTime.Property property36 = dateTime35.era();
        org.joda.time.DateTime dateTime37 = dateTime35.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime39 = dateTime37.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime41 = dateTime39.plusDays((int) (byte) -1);
        long long42 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.LocalDate localDate43 = dateTime41.toLocalDate();
        int int44 = skipDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) localDate43);
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField47 = buddhistChronology46.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
        org.joda.time.ReadablePartial readablePartial50 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = buddhistChronology52.weekyear();
        long long59 = buddhistChronology52.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField60 = buddhistChronology52.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime63 = org.joda.time.MutableDateTime.now(dateTimeZone62);
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) 100, dateTimeZone62);
        org.joda.time.DateTime.Property property65 = dateTime64.era();
        org.joda.time.DateTime dateTime66 = dateTime64.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime68 = dateTime66.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime70 = dateTime68.plusDays((int) (byte) -1);
        long long71 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime70);
        org.joda.time.LocalDate localDate72 = dateTime70.toLocalDate();
        int[] intArray74 = buddhistChronology52.get((org.joda.time.ReadablePartial) localDate72, (long) 100);
        int[] intArray76 = offsetDateTimeField49.add(readablePartial50, 0, intArray74, 0);
        try {
            int[] intArray78 = skipDateTimeField4.addWrapField((org.joda.time.ReadablePartial) localDate43, (int) (byte) -1, intArray76, 600);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2592000100L + "'", long17 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292279536 + "'", int20 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292279536 + "'", int29 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2592000100L + "'", long42 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-292268511) + "'", int44 == (-292268511));
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(buddhistChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-538965L) + "'", long59 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(mutableDateTime63);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 2592000100L + "'", long71 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate72);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long8 = julianChronology0.getDateTimeMillis(0, (int) (byte) 0, (-292268511), (int) (short) 100, 292279536, 2, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withEra(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "+00:10");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(33, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 85 + "'", int2 == 85);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        mutableDateTime1.setTime((int) (byte) 10, 10, (int) (byte) 0, (int) '#');
        int int7 = mutableDateTime1.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 1, dateTimeZone6);
        int int8 = dateTime4.compareTo((org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime7.dayOfYear();
        try {
            org.joda.time.MutableDateTime mutableDateTime11 = property9.set("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((-292268511));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292268511 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4999999884d + "'", double1 == 2440587.4999999884d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime9 = dateTime5.withMillis((long) (-292268511));
        int int10 = dateTime5.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 600100 + "'", int10 == 600100);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        java.lang.String str5 = property4.getAsText();
        int int6 = property4.get();
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumTextLength(locale7);
        try {
            org.joda.time.DateTime dateTime10 = property4.setCopy(4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AD" + "'", str5.equals("AD"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) 59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 100, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 100, dateTimeZone9);
        org.joda.time.DateTime.Property property12 = dateTime11.era();
        org.joda.time.DateTime dateTime13 = dateTime11.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime15 = dateTime13.minusDays(0);
        try {
            org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology3, (org.joda.time.ReadableDateTime) dateTime7, (org.joda.time.ReadableDateTime) dateTime15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis(2);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra(0);
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 100, dateTimeZone13);
        org.joda.time.DateTime.Property property16 = dateTime15.era();
        org.joda.time.DateTime dateTime18 = dateTime15.minusMillis(2);
        int int19 = dateTimeZone10.getOffset((org.joda.time.ReadableInstant) dateTime18);
        try {
            org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((java.lang.Object) localDateTime9, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDateTime");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 600000 + "'", int19 == 600000);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 100, 0);
        int int9 = offsetDateTimeField3.getMinimumValue();
        java.util.Locale locale12 = null;
        try {
            long long13 = offsetDateTimeField3.set((long) (short) 10, "7", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 7 for dayOfYear must be in the range [33,398]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 33 + "'", int9 == 33);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 100, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        boolean boolean7 = gregorianChronology1.equals((java.lang.Object) dateTime5);
        try {
            long long15 = gregorianChronology1.getDateTimeMillis(600000, 0, 100, 0, (int) (byte) 1, (int) (short) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.set(0);
        int int9 = mutableDateTime8.getYearOfEra();
        int int10 = mutableDateTime8.getMonthOfYear();
        java.lang.String str11 = mutableDateTime8.toString();
        try {
            mutableDateTime8.setHourOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-01-01T00:00:00.006+00:10" + "'", str11.equals("1970-01-01T00:00:00.006+00:10"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfHour();
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = mutableDateTime3.toCalendar(locale5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.hourOfHalfday();
        org.joda.time.DurationField durationField9 = buddhistChronology7.days();
        boolean boolean10 = mutableDateTime3.equals((java.lang.Object) durationField9);
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime12 = instant11.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration14 = null;
        mutableDateTime12.add(readableDuration14, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime12.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime19 = property17.set(0);
        int int20 = mutableDateTime19.getYearOfEra();
        org.joda.time.ReadableInstant readableInstant21 = null;
        boolean boolean22 = mutableDateTime19.isBefore(readableInstant21);
        try {
            org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology1, (org.joda.time.ReadableDateTime) mutableDateTime3, (org.joda.time.ReadableDateTime) mutableDateTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1970 + "'", int20 == 1970);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-57538965L), "7");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        java.lang.String str4 = illegalInstantException2.toString();
        java.lang.Throwable throwable5 = null;
        try {
            illegalInstantException2.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T08:01:01.035 (7)" + "'", str4.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T08:01:01.035 (7)"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 100, dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime12.era();
        org.joda.time.DateTime dateTime14 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime16 = dateTime14.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime18 = dateTime16.plusDays((int) (byte) -1);
        long long19 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.LocalDate localDate20 = dateTime18.toLocalDate();
        int int21 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate20);
        boolean boolean22 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate20);
        try {
            org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((java.lang.Object) boolean22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2592000100L + "'", long19 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-292268511) + "'", int21 == (-292268511));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        int int5 = dateTimeZone2.getOffsetFromLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 600000 + "'", int5 == 600000);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = dateTimeZone1.getShortName(132L, locale9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 600000 + "'", int6 == 600000);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:10" + "'", str10.equals("+00:10"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfEven();
        org.joda.time.DurationField durationField4 = property2.getDurationField();
        long long7 = durationField4.subtract((-599900L), 0);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField10 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType8, 600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-599900L) + "'", long7 == (-599900L));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        long long7 = buddhistChronology0.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 100, dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime12.era();
        org.joda.time.DateTime dateTime14 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime16 = dateTime14.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime18 = dateTime16.plusDays((int) (byte) -1);
        long long19 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.LocalDate localDate20 = dateTime18.toLocalDate();
        int[] intArray22 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate20, (long) 100);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        try {
            int[] intArray26 = buddhistChronology0.get(readablePeriod23, (long) (byte) -1, (long) 600100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-538965L) + "'", long7 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2592000100L + "'", long19 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, (-292268512));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime8 = dateTime3.withEra(292279536);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279536 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.set(0);
        int int9 = mutableDateTime8.getYearOfEra();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime8.yearOfCentury();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        java.lang.String str5 = property4.getAsText();
        int int6 = property4.get();
        java.util.Locale locale8 = null;
        try {
            org.joda.time.DateTime dateTime9 = property4.setCopy("", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AD" + "'", str5.equals("AD"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 100, 0);
        int int9 = offsetDateTimeField3.getMinimumValue();
        org.joda.time.DurationField durationField10 = offsetDateTimeField3.getDurationField();
        try {
            long long13 = offsetDateTimeField3.set((long) 0, "org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 33 + "'", int9 == 33);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = mutableDateTime1.toCalendar(locale3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.hourOfHalfday();
        org.joda.time.DurationField durationField7 = buddhistChronology5.days();
        boolean boolean8 = mutableDateTime1.equals((java.lang.Object) durationField7);
        try {
            mutableDateTime1.setDayOfMonth(59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.set(0);
        int int9 = mutableDateTime8.getYearOfEra();
        int int10 = mutableDateTime8.getMonthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            mutableDateTime8.set(dateTimeFieldType11, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
        long long9 = offsetDateTimeField7.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) offsetDateTimeField7);
        java.util.Locale locale13 = null;
        try {
            long long14 = skipDateTimeField10.set((-1L), "1970", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for dayOfYear must be in the range [33,398]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-600000L) + "'", long9 == (-600000L));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000116d + "'", double1 == 2440587.500000116d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = buddhistChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 100, 0);
        int int9 = offsetDateTimeField3.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 100, dateTimeZone11);
        org.joda.time.DateTime.Property property14 = dateTime13.era();
        org.joda.time.TimeOfDay timeOfDay15 = dateTime13.toTimeOfDay();
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) timeOfDay15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfYear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 33 + "'", int9 == 33);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(timeOfDay15);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 1, dateTimeZone6);
        int int8 = dateTime4.compareTo((org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime4.toDateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime15 = dateTime4.minusYears(4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 100, dateTimeZone3);
        org.joda.time.DateTime.Property property6 = dateTime5.era();
        org.joda.time.TimeOfDay timeOfDay7 = dateTime5.toTimeOfDay();
        long long9 = buddhistChronology0.set((org.joda.time.ReadablePartial) timeOfDay7, 2592000100L);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2592000100L + "'", long9 == 2592000100L);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.hourOfHalfday();
        org.joda.time.DurationField durationField8 = buddhistChronology6.days();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology6, locale9, (java.lang.Integer) 2019);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now(dateTimeZone12);
        dateTimeParserBucket11.setZone(dateTimeZone12);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) (short) 1, (int) 'a', (int) (byte) 1, (int) (short) 1, (int) 'a', dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        mutableDateTime1.setZone(dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = dateTimeZone2.getOffset(readableInstant6);
        java.lang.String str8 = dateTimeZone2.toString();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, dateTimeZone2);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now(dateTimeZone12);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        mutableDateTime11.setZone(dateTimeZone12);
        try {
            org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) property10, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MutableDateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 600000 + "'", int7 == 600000);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:10" + "'", str8.equals("+00:10"));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(gJChronology14);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = mutableDateTime1.toCalendar(locale3);
        try {
            mutableDateTime1.setTime((int) (short) 100, 1970, 10, 398);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(calendar4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withHourOfDay((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.secondOfMinute();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, 2513, 0, 600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2513 for secondOfMinute must be in the range [0,600]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        long long7 = skipDateTimeField4.set(10L, (int) '4');
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField4.getWrappedField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) ' ');
        long long14 = offsetDateTimeField12.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField12.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField16 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-77661763199990L) + "'", long7 == (-77661763199990L));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-600000L) + "'", long14 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = dateTime6.withZoneRetainFields(dateTimeZone7);
        long long12 = dateTimeZone7.convertLocalToUTC((-599900L), false, (long) 33);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1199900L) + "'", long12 == (-1199900L));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(2);
        int int9 = property4.getLeapAmount();
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime11 = instant10.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration13 = null;
        mutableDateTime11.add(readableDuration13, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime11.weekyear();
        try {
            long long17 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long6 = dateTimeZone2.convertLocalToUTC((-600000L), false);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1200000L) + "'", long6 == (-1200000L));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfEven();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property2.getAsShortText(locale4);
        org.joda.time.DurationField durationField6 = property2.getLeapDurationField();
        org.joda.time.MutableDateTime mutableDateTime8 = property2.addWrapField((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = property2.roundHalfEven();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(10);
        org.joda.time.DateTime dateTime7 = property4.roundFloorCopy();
        int int8 = dateTime7.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(2019, (-1), 0, 292279536, 4, (int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279536 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        long long7 = buddhistChronology0.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology0.millisOfSecond();
        org.joda.time.DurationField durationField9 = buddhistChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-538965L) + "'", long7 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology1.days();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology1, locale4, (java.lang.Integer) 2019);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        dateTimeParserBucket6.setZone(dateTimeZone7);
        java.lang.String str10 = dateTimeZone7.getID();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:10" + "'", str10.equals("+00:10"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-17132083200000L));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(2);
        org.joda.time.DateTime dateTime9 = property4.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = dateTime6.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = null;
        org.joda.time.format.DateTimeParser dateTimeParser11 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter10, dateTimeParser11);
        try {
            java.lang.String str13 = dateTime9.toString(dateTimeFormatter12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
        try {
            org.joda.time.DateTime dateTime3 = dateTime0.withHourOfDay(398);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 398 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        mutableDateTime5.setZone(dateTimeZone6);
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = dateTimeZone6.getOffset(readableInstant10);
        java.lang.String str12 = dateTimeZone6.toString();
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(0L, dateTimeZone6);
        try {
            org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeField3, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.LimitChronology$LimitDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 600000 + "'", int11 == 600000);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:10" + "'", str12.equals("+00:10"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("7");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.set(0);
        int int9 = mutableDateTime8.getYearOfEra();
        int int10 = mutableDateTime8.getMonthOfYear();
        java.lang.String str11 = mutableDateTime8.toString();
        try {
            mutableDateTime8.setHourOfDay(292279536);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279536 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1427 + "'", int9 == 1427);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1427-02-09T00:00:00.000+00:10" + "'", str11.equals("1427-02-09T00:00:00.000+00:10"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType6, 2019, (int) (short) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for dayOfYear must be in the range [100,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.year();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.DurationField durationField5 = buddhistChronology0.centuries();
        try {
            org.joda.time.Instant instant6 = new org.joda.time.Instant((java.lang.Object) buddhistChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.BuddhistChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.set(0);
        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundCeiling();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        org.joda.time.DateTime.Property property10 = dateTime7.secondOfMinute();
        org.joda.time.DateTime dateTime12 = dateTime7.withMillis((-28857599900L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology1.days();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 1, (org.joda.time.Chronology) buddhistChronology1);
        java.lang.String str5 = buddhistChronology1.toString();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BuddhistChronology[+00:10]" + "'", str5.equals("BuddhistChronology[+00:10]"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.joda.time.TimeOfDay timeOfDay9 = dateTime8.toTimeOfDay();
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withHourOfDay(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(timeOfDay9);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField4 = buddhistChronology2.days();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology2, locale5, (java.lang.Integer) 2019);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        dateTimeParserBucket7.setZone(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(178010L, dateTimeZone8);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        java.util.Date date5 = dateTime3.toDate();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField4, 0);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = skipDateTimeField6.getMaximumValue(readablePartial7);
        boolean boolean10 = skipDateTimeField6.isLeap((long) 'a');
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) skipDateTimeField6);
        org.joda.time.DurationField durationField12 = skipDateTimeField6.getDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292279536 + "'", int8 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        boolean boolean9 = skipDateTimeField4.isLenient();
        long long11 = skipDateTimeField4.roundCeiling((long) 600000);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField4.getAsShortText(2, locale13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 100, dateTimeZone16);
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.minusMillis(2);
        org.joda.time.DateTime dateTime23 = dateTime21.withCenturyOfEra(0);
        org.joda.time.LocalDateTime localDateTime24 = dateTime23.toLocalDateTime();
        int int25 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDateTime24);
        int int27 = skipDateTimeField4.getLeapAmount((long) 2513);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31794600000L + "'", long11 == 31794600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2" + "'", str14.equals("2"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292268511) + "'", int25 == (-292268511));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (byte) -1);
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.LocalDate localDate18 = dateTime16.toLocalDate();
        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate18);
        int int20 = skipDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate18);
        int int21 = skipDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2592000100L + "'", long17 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292279536 + "'", int20 == 292279536);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-292268512) + "'", int21 == (-292268512));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfMonth();
        org.joda.time.DateTime dateTime8 = dateTime5.minus((long) 600000);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1970, (int) ' ', (-292279537), (int) 'a', 40, 40, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = buddhistChronology0.days();
        java.lang.String str3 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[+00:10]" + "'", str3.equals("BuddhistChronology[+00:10]"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        int int2 = mutableDateTime1.getEra();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime1);
        mutableDateTime1.setSecondOfDay((int) (byte) 0);
        try {
            mutableDateTime1.setSecondOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfDay must be in the range [0,86399]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withHourOfDay(36600035);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36600035 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean3 = iSOChronology1.equals((java.lang.Object) "");
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 1, (org.joda.time.Chronology) iSOChronology1, locale4);
        java.lang.Integer int6 = dateTimeParserBucket5.getPivotYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(int6);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        boolean boolean11 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime13 = dateTime3.minusHours(0);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMonths((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 100, dateTimeZone3);
        org.joda.time.DateTime.Property property6 = dateTime5.era();
        org.joda.time.DateTime dateTime8 = dateTime5.minusMillis(2);
        int int9 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime8);
        try {
            org.joda.time.DateTime dateTime13 = dateTime8.withDate((int) (byte) 10, 6, 36600035);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36600035 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 600000 + "'", int9 == 600000);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.withDayOfMonth((int) (short) 1);
        org.joda.time.DateTime.Property property14 = dateTime11.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        int int3 = mutableDateTime2.getEra();
        mutableDateTime2.addHours((-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.hourOfHalfday();
        org.joda.time.DurationField durationField8 = buddhistChronology6.days();
        mutableDateTime2.setChronology((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-292268512), (org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology6.dayOfWeek();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean3 = iSOChronology1.equals((java.lang.Object) "");
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 1, (org.joda.time.Chronology) iSOChronology1, locale4);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 2019);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        boolean boolean9 = skipDateTimeField4.isLenient();
        long long11 = skipDateTimeField4.roundCeiling((long) 600000);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 100, dateTimeZone13);
        org.joda.time.DateTime.Property property16 = dateTime15.era();
        org.joda.time.DateTime dateTime17 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime21 = dateTime19.plusDays((int) (byte) -1);
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.LocalDate localDate23 = dateTime21.toLocalDate();
        boolean boolean24 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate23);
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate23, locale25);
        int int27 = skipDateTimeField4.getMinimumValue();
        int int29 = skipDateTimeField4.get(132L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31794600000L + "'", long11 == 31794600000L);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2592000100L + "'", long22 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970" + "'", str26.equals("1970"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-292268512) + "'", int27 == (-292268512));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2513 + "'", int29 == 2513);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '0' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        try {
            long long9 = gJChronology0.getDateTimeMillis(1970, 600, 1969, 4, (int) (short) -1, 4, 85);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) ' ');
        long long7 = offsetDateTimeField5.roundHalfFloor((long) (short) 1);
        long long10 = offsetDateTimeField5.addWrapField((long) (short) 100, 0);
        int int11 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField5);
        int int13 = offsetDateTimeField5.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-600000L) + "'", long7 == (-600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 33 + "'", int13 == 33);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        long long10 = skipDateTimeField4.roundHalfFloor(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) ' ');
        long long16 = offsetDateTimeField14.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 100, dateTimeZone18);
        org.joda.time.DateTime.Property property21 = dateTime20.era();
        org.joda.time.DateTime dateTime22 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime24 = dateTime22.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime26 = dateTime24.plusDays((int) (byte) -1);
        long long27 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.LocalDate localDate28 = dateTime26.toLocalDate();
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate28, 600000, locale30);
        int int32 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate28);
        boolean boolean33 = skipDateTimeField4.isSupported();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259800000L) + "'", long10 == (-259800000L));
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-600000L) + "'", long16 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2592000100L + "'", long27 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "600000" + "'", str31.equals("600000"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-292268511) + "'", int32 == (-292268511));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        boolean boolean9 = skipDateTimeField4.isLenient();
        long long11 = skipDateTimeField4.roundCeiling((long) 600000);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField4.getAsShortText(2, locale13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 100, dateTimeZone16);
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.minusMillis(2);
        org.joda.time.DateTime dateTime23 = dateTime21.withCenturyOfEra(0);
        org.joda.time.LocalDateTime localDateTime24 = dateTime23.toLocalDateTime();
        int int25 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDateTime24);
        int int26 = skipDateTimeField4.getMinimumValue();
        int int28 = skipDateTimeField4.getLeapAmount((long) 9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology30.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology29, dateTimeField31, 0);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int int35 = skipDateTimeField33.getMaximumValue(readablePartial34);
        boolean boolean37 = skipDateTimeField33.isLeap((long) 'a');
        boolean boolean38 = skipDateTimeField33.isLenient();
        long long40 = skipDateTimeField33.roundCeiling((long) 600000);
        java.util.Locale locale42 = null;
        java.lang.String str43 = skipDateTimeField33.getAsShortText(2, locale42);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime46 = org.joda.time.MutableDateTime.now(dateTimeZone45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 100, dateTimeZone45);
        org.joda.time.DateTime.Property property48 = dateTime47.era();
        org.joda.time.DateTime dateTime50 = dateTime47.minusMillis(2);
        org.joda.time.DateTime dateTime52 = dateTime50.withCenturyOfEra(0);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        int int54 = skipDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDateTime53);
        int[] intArray56 = null;
        try {
            int[] intArray58 = skipDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) localDateTime53, 600000, intArray56, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31794600000L + "'", long11 == 31794600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2" + "'", str14.equals("2"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292268511) + "'", int25 == (-292268511));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292268512) + "'", int26 == (-292268512));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 292279536 + "'", int35 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 31794600000L + "'", long40 == 31794600000L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2" + "'", str43.equals("2"));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(mutableDateTime46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-292268511) + "'", int54 == (-292268511));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        boolean boolean11 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        java.util.GregorianCalendar gregorianCalendar12 = dateTime3.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("17", "17");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "17" + "'", str3.equals("17"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17" + "'", str5.equals("17"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        int int2 = mutableDateTime1.getEra();
        mutableDateTime1.addHours((-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.hourOfHalfday();
        org.joda.time.DurationField durationField7 = buddhistChronology5.days();
        mutableDateTime1.setChronology((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology5.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology5.yearOfCentury();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) ' ');
        long long7 = offsetDateTimeField5.roundHalfFloor((long) (short) 1);
        long long10 = offsetDateTimeField5.addWrapField((long) (short) 100, 0);
        int int11 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) ' ');
        long long18 = offsetDateTimeField16.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType19);
        org.joda.time.ReadablePartial readablePartial21 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) ' ');
        long long28 = offsetDateTimeField26.roundHalfFloor((long) (short) 1);
        long long31 = offsetDateTimeField26.addWrapField((long) (short) 100, 0);
        long long33 = offsetDateTimeField26.roundCeiling((long) 85);
        org.joda.time.ReadablePartial readablePartial34 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology35.weekyear();
        long long42 = buddhistChronology35.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology35.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime46 = org.joda.time.MutableDateTime.now(dateTimeZone45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 100, dateTimeZone45);
        org.joda.time.DateTime.Property property48 = dateTime47.era();
        org.joda.time.DateTime dateTime49 = dateTime47.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime51 = dateTime49.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime53 = dateTime51.plusDays((int) (byte) -1);
        long long54 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime53);
        org.joda.time.LocalDate localDate55 = dateTime53.toLocalDate();
        int[] intArray57 = buddhistChronology35.get((org.joda.time.ReadablePartial) localDate55, (long) 100);
        int int58 = offsetDateTimeField26.getMaximumValue(readablePartial34, intArray57);
        try {
            int[] intArray60 = offsetDateTimeField5.addWrapPartial(readablePartial21, (-292268511), intArray57, 398);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -292268511");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-600000L) + "'", long7 == (-600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-600000L) + "'", long18 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-600000L) + "'", long28 == (-600000L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 85800000L + "'", long33 == 85800000L);
        org.junit.Assert.assertNotNull(buddhistChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-538965L) + "'", long42 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(mutableDateTime46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2592000100L + "'", long54 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 398 + "'", int58 == 398);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        long long7 = buddhistChronology0.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 100, dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime12.era();
        org.joda.time.DateTime dateTime14 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime16 = dateTime14.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime18 = dateTime16.plusDays((int) (byte) -1);
        long long19 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.LocalDate localDate20 = dateTime18.toLocalDate();
        int[] intArray22 = buddhistChronology0.get((org.joda.time.ReadablePartial) localDate20, (long) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (int) ' ');
        long long29 = offsetDateTimeField27.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now(dateTimeZone31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 100, dateTimeZone31);
        org.joda.time.DateTime.Property property34 = dateTime33.era();
        org.joda.time.DateTime dateTime35 = dateTime33.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime37 = dateTime35.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime39 = dateTime37.plusDays((int) (byte) -1);
        long long40 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.LocalDate localDate41 = dateTime39.toLocalDate();
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDate41, 600000, locale43);
        java.lang.String str45 = dateTimeFormatter23.print((org.joda.time.ReadablePartial) localDate41);
        int[] intArray49 = new int[] { (-1), 10, (short) -1 };
        try {
            buddhistChronology0.validate((org.joda.time.ReadablePartial) localDate41, intArray49);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-538965L) + "'", long7 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2592000100L + "'", long19 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-600000L) + "'", long29 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2592000100L + "'", long40 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "600000" + "'", str44.equals("600000"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1970-01" + "'", str45.equals("1970-01"));
        org.junit.Assert.assertNotNull(intArray49);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = dateTime6.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds(0);
        org.joda.time.LocalDate localDate11 = dateTime8.toLocalDate();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        boolean boolean11 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        int int12 = dateTime3.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        boolean boolean9 = skipDateTimeField4.isLenient();
        long long11 = skipDateTimeField4.roundCeiling((long) 600000);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField4.getAsShortText(2, locale13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 100, dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withPeriodAdded(readablePeriod20, (int) (short) 10);
        org.joda.time.LocalDateTime localDateTime23 = dateTime22.toLocalDateTime();
        int int24 = skipDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDateTime23);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31794600000L + "'", long11 == 31794600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2" + "'", str14.equals("2"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 292279536 + "'", int24 == 292279536);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.set(0);
        int int9 = mutableDateTime8.getYearOfEra();
        int int10 = mutableDateTime8.getMonthOfYear();
        try {
            mutableDateTime8.setDayOfWeek(1427);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1427 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1427 + "'", int9 == 1427);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfEven();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property2.getAsShortText(locale4);
        org.joda.time.DurationField durationField6 = property2.getLeapDurationField();
        org.joda.time.MutableDateTime mutableDateTime8 = property2.addWrapField((int) (short) 10);
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime11 = instant10.toMutableDateTime();
        int int12 = mutableDateTime11.getEra();
        mutableDateTime11.addHours((-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.hourOfHalfday();
        org.joda.time.DurationField durationField17 = buddhistChronology15.days();
        mutableDateTime11.setChronology((org.joda.time.Chronology) buddhistChronology15);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology15.millisOfSecond();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-292268512), (org.joda.time.Chronology) buddhistChronology15);
        mutableDateTime8.setMillis((org.joda.time.ReadableInstant) dateTime20);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.minus(0L);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 1427);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500016516d + "'", double1 == 2440587.500016516d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        int int2 = mutableDateTime1.getEra();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime1);
        mutableDateTime1.setSecondOfDay((int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.dayOfMonth();
        int int7 = mutableDateTime1.getMillisOfDay();
        mutableDateTime1.setDate((-1), 1, 9);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((-1));
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfWeek();
        mutableDateTime4.setWeekyear(2513);
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime4.add(readableDuration8);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime3.withMillis((long) (short) 0);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withEra((-292279537));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292279537 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime7 = property4.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("1970-01-01T00:00:00.006+00:10");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-01-01T00:00:00.006+00:10\" is malformed at \"+00:10\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        int int3 = mutableDateTime2.getEra();
        mutableDateTime2.addHours((-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.hourOfHalfday();
        org.joda.time.DurationField durationField8 = buddhistChronology6.days();
        mutableDateTime2.setChronology((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-292268512), (org.joda.time.Chronology) buddhistChronology6);
        boolean boolean13 = buddhistChronology6.equals((java.lang.Object) 59);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (byte) -1);
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.LocalDate localDate18 = dateTime16.toLocalDate();
        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate18);
        int int20 = skipDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate18);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) skipDateTimeField4, (java.lang.Object) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) ' ');
        long long28 = offsetDateTimeField26.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField26.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType29, 2513);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType29, 0, (int) '#', 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [35,1970]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2592000100L + "'", long17 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292279536 + "'", int20 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-600000L) + "'", long28 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = dateTime6.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds(0);
        org.joda.time.DateTime dateTime12 = dateTime8.withMillis((-259800000L));
        int int13 = dateTime12.getYear();
        try {
            org.joda.time.DateTime dateTime18 = dateTime12.withTime((int) (byte) 1, 0, 600, (-292268512));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 600 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        long long10 = skipDateTimeField4.roundHalfFloor(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) ' ');
        long long16 = offsetDateTimeField14.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 100, dateTimeZone18);
        org.joda.time.DateTime.Property property21 = dateTime20.era();
        org.joda.time.DateTime dateTime22 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime24 = dateTime22.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime26 = dateTime24.plusDays((int) (byte) -1);
        long long27 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.LocalDate localDate28 = dateTime26.toLocalDate();
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate28, 600000, locale30);
        int int32 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate28);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259800000L) + "'", long10 == (-259800000L));
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-600000L) + "'", long16 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2592000100L + "'", long27 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "600000" + "'", str31.equals("600000"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-292268511) + "'", int32 == (-292268511));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("10");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"10/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(2);
        boolean boolean9 = dateTime8.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("17", "17");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "17" + "'", str3.equals("17"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(durationFieldType6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((-1));
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfWeek();
        int int6 = property5.getMinimumValue();
        int int7 = property5.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.LocalDate localDate11 = dateTime9.toLocalDate();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 0);
        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2592000100L + "'", long10 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField7, 0);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = skipDateTimeField9.getMaximumValue(readablePartial10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 100, dateTimeZone13);
        org.joda.time.DateTime.Property property16 = dateTime15.era();
        org.joda.time.DateTime dateTime17 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime21 = dateTime19.plusDays((int) (byte) -1);
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.LocalDate localDate23 = dateTime21.toLocalDate();
        boolean boolean24 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate23);
        int int25 = skipDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) localDate23);
        int int26 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate23);
        long long29 = skipDateTimeField4.getDifferenceAsLong(2591400000L, (long) 36600035);
        java.lang.String str30 = skipDateTimeField4.getName();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 292279536 + "'", int11 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2592000100L + "'", long22 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 292279536 + "'", int25 == 292279536);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292268511) + "'", int26 == (-292268511));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "weekyear" + "'", str30.equals("weekyear"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now(dateTimeZone12);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        mutableDateTime11.setZone(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant16 = null;
        int int17 = dateTimeZone12.getOffset(readableInstant16);
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime9.toMutableDateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime20 = dateTime9.plusMillis((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2592000100L + "'", long10 == 2592000100L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 600000 + "'", int17 == 600000);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        long long10 = skipDateTimeField4.roundHalfFloor(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) ' ');
        long long16 = offsetDateTimeField14.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 100, dateTimeZone18);
        org.joda.time.DateTime.Property property21 = dateTime20.era();
        org.joda.time.DateTime dateTime22 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime24 = dateTime22.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime26 = dateTime24.plusDays((int) (byte) -1);
        long long27 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.LocalDate localDate28 = dateTime26.toLocalDate();
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate28, 600000, locale30);
        int int32 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate28);
        java.lang.String str33 = skipDateTimeField4.getName();
        org.joda.time.DateTimeField dateTimeField34 = skipDateTimeField4.getWrappedField();
        org.joda.time.ReadablePartial readablePartial35 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology37.weekyear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology39, dateTimeField41, 0);
        org.joda.time.ReadablePartial readablePartial44 = null;
        int int45 = skipDateTimeField43.getMaximumValue(readablePartial44);
        boolean boolean47 = skipDateTimeField43.isLeap((long) 'a');
        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology37, (org.joda.time.DateTimeField) skipDateTimeField43);
        org.joda.time.ReadablePartial readablePartial49 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology50 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = buddhistChronology50.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) ' ');
        long long55 = offsetDateTimeField53.roundHalfFloor((long) (short) 1);
        long long58 = offsetDateTimeField53.addWrapField((long) (short) 100, 0);
        long long60 = offsetDateTimeField53.roundCeiling((long) 85);
        org.joda.time.ReadablePartial readablePartial61 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology62 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = buddhistChronology62.weekyear();
        long long69 = buddhistChronology62.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField70 = buddhistChronology62.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime73 = org.joda.time.MutableDateTime.now(dateTimeZone72);
        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime((long) 100, dateTimeZone72);
        org.joda.time.DateTime.Property property75 = dateTime74.era();
        org.joda.time.DateTime dateTime76 = dateTime74.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime78 = dateTime76.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime80 = dateTime78.plusDays((int) (byte) -1);
        long long81 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime80);
        org.joda.time.LocalDate localDate82 = dateTime80.toLocalDate();
        int[] intArray84 = buddhistChronology62.get((org.joda.time.ReadablePartial) localDate82, (long) 100);
        int int85 = offsetDateTimeField53.getMaximumValue(readablePartial61, intArray84);
        int int86 = skipDateTimeField43.getMinimumValue(readablePartial49, intArray84);
        try {
            int[] intArray88 = skipDateTimeField4.set(readablePartial35, (int) (short) 1, intArray84, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259800000L) + "'", long10 == (-259800000L));
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-600000L) + "'", long16 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2592000100L + "'", long27 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "600000" + "'", str31.equals("600000"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-292268511) + "'", int32 == (-292268511));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "weekyear" + "'", str33.equals("weekyear"));
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(buddhistChronology39);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279536 + "'", int45 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(buddhistChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-600000L) + "'", long55 == (-600000L));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 100L + "'", long58 == 100L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 85800000L + "'", long60 == 85800000L);
        org.junit.Assert.assertNotNull(buddhistChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-538965L) + "'", long69 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeZone72);
        org.junit.Assert.assertNotNull(mutableDateTime73);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(dateTime80);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 2592000100L + "'", long81 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate82);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 398 + "'", int85 == 398);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-292268511) + "'", int86 == (-292268511));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        mutableDateTime1.setZone(dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = dateTimeZone2.getOffset(readableInstant6);
        java.lang.String str8 = dateTimeZone2.toString();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, dateTimeZone2);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfWeek();
        try {
            mutableDateTime9.setDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 600000 + "'", int7 == 600000);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:10" + "'", str8.equals("+00:10"));
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.TimeOfDay timeOfDay5 = dateTime3.toTimeOfDay();
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withWeekOfWeekyear(1427);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1427 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(timeOfDay5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (byte) -1);
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.LocalDate localDate18 = dateTime16.toLocalDate();
        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate18);
        int int20 = skipDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate18);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) skipDateTimeField4, (java.lang.Object) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) ' ');
        long long28 = offsetDateTimeField26.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField26.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType29, 2513);
        long long34 = dividedDateTimeField31.add((long) 85, 85);
        long long37 = dividedDateTimeField31.add((long) 600000, 0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2592000100L + "'", long17 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292279536 + "'", int20 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-600000L) + "'", long28 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 6740722800000085L + "'", long34 == 6740722800000085L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 600000L + "'", long37 == 600000L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField7, 0);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = skipDateTimeField9.getMaximumValue(readablePartial10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 100, dateTimeZone13);
        org.joda.time.DateTime.Property property16 = dateTime15.era();
        org.joda.time.DateTime dateTime17 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime21 = dateTime19.plusDays((int) (byte) -1);
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.LocalDate localDate23 = dateTime21.toLocalDate();
        boolean boolean24 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate23);
        int int25 = skipDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) localDate23);
        int int26 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate23);
        org.joda.time.DurationField durationField27 = skipDateTimeField4.getRangeDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 292279536 + "'", int11 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2592000100L + "'", long22 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 292279536 + "'", int25 == 292279536);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292268511) + "'", int26 == (-292268511));
        org.junit.Assert.assertNull(durationField27);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        long long8 = offsetDateTimeField3.add((long) (short) 1, (long) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology9, dateTimeField11, 0);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = skipDateTimeField13.getMaximumValue(readablePartial14);
        boolean boolean17 = skipDateTimeField13.isLeap((long) 'a');
        long long19 = skipDateTimeField13.roundHalfFloor(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) ' ');
        long long25 = offsetDateTimeField23.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now(dateTimeZone27);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 100, dateTimeZone27);
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTime dateTime31 = dateTime29.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime33 = dateTime31.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime35 = dateTime33.plusDays((int) (byte) -1);
        long long36 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.LocalDate localDate37 = dateTime35.toLocalDate();
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField23.getAsText((org.joda.time.ReadablePartial) localDate37, 600000, locale39);
        int int41 = skipDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) localDate37);
        java.lang.String str42 = skipDateTimeField13.getName();
        boolean boolean43 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (byte) 10, (java.lang.Object) skipDateTimeField13);
        try {
            long long46 = skipDateTimeField13.set((long) (-292279537), "BuddhistChronology[+00:10]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"BuddhistChronology[+00:10]\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 864000001L + "'", long8 == 864000001L);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 292279536 + "'", int15 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259800000L) + "'", long19 == (-259800000L));
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-600000L) + "'", long25 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2592000100L + "'", long36 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "600000" + "'", str40.equals("600000"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-292268511) + "'", int41 == (-292268511));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "weekyear" + "'", str42.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField4, 0);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = skipDateTimeField6.getMaximumValue(readablePartial7);
        boolean boolean10 = skipDateTimeField6.isLeap((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 100, dateTimeZone12);
        org.joda.time.DateTime.Property property15 = dateTime14.era();
        org.joda.time.DateTime dateTime16 = dateTime14.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime18 = dateTime16.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime20 = dateTime18.plusDays((int) (byte) -1);
        long long21 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.LocalDate localDate22 = dateTime20.toLocalDate();
        int int23 = skipDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292279536 + "'", int8 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2592000100L + "'", long21 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268511) + "'", int23 == (-292268511));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.ReadablePartial readablePartial4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.weekyear();
        long long13 = buddhistChronology6.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 100, dateTimeZone16);
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime20 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime24 = dateTime22.plusDays((int) (byte) -1);
        long long25 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.LocalDate localDate26 = dateTime24.toLocalDate();
        int[] intArray28 = buddhistChronology6.get((org.joda.time.ReadablePartial) localDate26, (long) 100);
        int[] intArray30 = offsetDateTimeField3.add(readablePartial4, 0, intArray28, 0);
        long long32 = offsetDateTimeField3.roundHalfCeiling((long) (byte) 100);
        try {
            long long35 = offsetDateTimeField3.set((-599900L), "1");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for dayOfYear must be in the range [33,398]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-538965L) + "'", long13 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2592000100L + "'", long25 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-600000L) + "'", long32 == (-600000L));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone2);
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.plusDays((int) (byte) -1);
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.LocalDate localDate12 = dateTime10.toLocalDate();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime10.toDateTime(dateTimeZone13);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime(obj0, dateTimeZone13);
        int int19 = mutableDateTime18.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2592000100L + "'", long11 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal(10L);
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 600000 + "'", int2 == 600000);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.minusDays(0);
        int int15 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        java.lang.String str17 = gJChronology16.toString();
        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology16.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = iSOChronology19.months();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 600000 + "'", int6 == 600000);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 600000 + "'", int15 == 600000);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GJChronology[+00:10]" + "'", str17.equals("GJChronology[+00:10]"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField3, 0);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = skipDateTimeField5.getMaximumValue(readablePartial6);
        boolean boolean9 = skipDateTimeField5.isLeap((long) 'a');
        boolean boolean10 = skipDateTimeField5.isLenient();
        long long12 = skipDateTimeField5.roundCeiling((long) 600000);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipDateTimeField5.getAsShortText(2, locale14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 100, dateTimeZone17);
        org.joda.time.DateTime.Property property20 = dateTime19.era();
        org.joda.time.DateTime dateTime22 = dateTime19.minusMillis(2);
        org.joda.time.DateTime dateTime24 = dateTime22.withCenturyOfEra(0);
        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
        int int26 = skipDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDateTime25);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipDateTimeField5);
        boolean boolean28 = skipUndoDateTimeField27.isSupported();
        long long31 = skipUndoDateTimeField27.set(0L, 2513);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292279536 + "'", int7 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31794600000L + "'", long12 == 31794600000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2" + "'", str15.equals("2"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292268511) + "'", int26 == (-292268511));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("+00:10", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:10\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withDayOfYear(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        long long7 = buddhistChronology0.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology0.millisOfSecond();
        org.joda.time.DurationField durationField9 = buddhistChronology0.halfdays();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        try {
            int[] intArray13 = buddhistChronology0.get(readablePeriod10, 600000L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-538965L) + "'", long7 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        int int2 = mutableDateTime1.getEra();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime1);
        mutableDateTime1.setSecondOfDay((int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.dayOfMonth();
        int int7 = property6.getLeapAmount();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        boolean boolean11 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime13 = dateTime3.minusHours(0);
        try {
            org.joda.time.DateTime dateTime15 = dateTime3.withDayOfMonth(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 0, 2, 85, (int) (byte) 10, 0, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 85 for dayOfMonth must be in the range [1,29]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T08:01:01.035 (7)");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalInstantExce...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("17", "17");
        java.lang.String str3 = illegalFieldValueException2.toString();
        illegalFieldValueException2.prependMessage("0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) 59, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("-00:00:00.001");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-00:00:00.001\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.joda.time.TimeOfDay timeOfDay9 = dateTime8.toTimeOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.minusMonths(1);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.DateTime dateTime14 = dateTime8.withFieldAdded(durationFieldType12, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(timeOfDay9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("17", "17");
        illegalFieldValueException2.prependMessage("org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported");
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str1 = dateTimeZone0.toString();
        int int3 = dateTimeZone0.getOffsetFromLocal(0L);
        java.lang.String str5 = dateTimeZone0.getShortName(28800001L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "+00:10" + "'", str1.equals("+00:10"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 600000 + "'", int3 == 600000);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:10" + "'", str5.equals("+00:10"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
        long long9 = offsetDateTimeField7.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) offsetDateTimeField7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology11, dateTimeField13, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology16, dateTimeField18, 0);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int int22 = skipDateTimeField20.getMaximumValue(readablePartial21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 100, dateTimeZone24);
        org.joda.time.DateTime.Property property27 = dateTime26.era();
        org.joda.time.DateTime dateTime28 = dateTime26.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime30 = dateTime28.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime32 = dateTime30.plusDays((int) (byte) -1);
        long long33 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.LocalDate localDate34 = dateTime32.toLocalDate();
        boolean boolean35 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate34);
        int int36 = skipDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDate34);
        int int37 = skipDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate34);
        org.joda.time.chrono.BuddhistChronology buddhistChronology38 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = buddhistChronology38.weekyear();
        long long45 = buddhistChronology38.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology38.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime49 = org.joda.time.MutableDateTime.now(dateTimeZone48);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) 100, dateTimeZone48);
        org.joda.time.DateTime.Property property51 = dateTime50.era();
        org.joda.time.DateTime dateTime52 = dateTime50.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime54 = dateTime52.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime56 = dateTime54.plusDays((int) (byte) -1);
        long long57 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime56);
        org.joda.time.LocalDate localDate58 = dateTime56.toLocalDate();
        int[] intArray60 = buddhistChronology38.get((org.joda.time.ReadablePartial) localDate58, (long) 100);
        gJChronology2.validate((org.joda.time.ReadablePartial) localDate34, intArray60);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-600000L) + "'", long9 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292279536 + "'", int22 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2592000100L + "'", long33 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 292279536 + "'", int36 == 292279536);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-292268511) + "'", int37 == (-292268511));
        org.junit.Assert.assertNotNull(buddhistChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-538965L) + "'", long45 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2592000100L + "'", long57 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(intArray60);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology2 = instant1.getChronology();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) (-292268511), chronology2, locale3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        long long12 = offsetDateTimeField10.roundHalfFloor((long) (short) 1);
        long long15 = offsetDateTimeField10.addWrapField((long) (short) 100, 0);
        int int16 = offsetDateTimeField10.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, (org.joda.time.DateTimeField) offsetDateTimeField10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) ' ');
        long long23 = offsetDateTimeField21.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField21.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, dateTimeFieldType24);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.hourOfHalfday();
        org.joda.time.DurationField durationField30 = buddhistChronology28.days();
        java.util.Locale locale31 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology28, locale31, (java.lang.Integer) 2019);
        java.util.Locale locale34 = dateTimeParserBucket33.getLocale();
        dateTimeParserBucket4.saveField(dateTimeFieldType24, "AD", locale34);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.era();
        org.joda.time.DurationField durationField38 = buddhistChronology36.centuries();
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField40 = iSOChronology39.minutes();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField41 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType24, durationField38, durationField40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-600000L) + "'", long12 == (-600000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 33 + "'", int16 == 33);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-600000L) + "'", long23 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(locale34);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(durationField40);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology7, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipDateTimeField11.getMaximumValue(readablePartial12);
        boolean boolean15 = skipDateTimeField11.isLeap((long) 'a');
        long long17 = skipDateTimeField11.roundHalfFloor(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) ' ');
        long long23 = offsetDateTimeField21.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime26 = org.joda.time.MutableDateTime.now(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 100, dateTimeZone25);
        org.joda.time.DateTime.Property property28 = dateTime27.era();
        org.joda.time.DateTime dateTime29 = dateTime27.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime33 = dateTime31.plusDays((int) (byte) -1);
        long long34 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.LocalDate localDate35 = dateTime33.toLocalDate();
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDate35, 600000, locale37);
        int int39 = skipDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) localDate35);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology40, dateTimeField42, 0);
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField44.getMaximumValue(readablePartial45);
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime49 = org.joda.time.MutableDateTime.now(dateTimeZone48);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) 100, dateTimeZone48);
        org.joda.time.DateTime.Property property51 = dateTime50.era();
        org.joda.time.DateTime dateTime52 = dateTime50.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime54 = dateTime52.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime56 = dateTime54.plusDays((int) (byte) -1);
        long long57 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime56);
        org.joda.time.LocalDate localDate58 = dateTime56.toLocalDate();
        boolean boolean59 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate58);
        int int60 = skipDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
        boolean boolean62 = org.joda.time.field.FieldUtils.equals((java.lang.Object) skipDateTimeField44, (java.lang.Object) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology63 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField64 = buddhistChronology63.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField64, (int) ' ');
        long long68 = offsetDateTimeField66.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = offsetDateTimeField66.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField71 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField44, dateTimeFieldType69, 2513);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType69);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType69, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 292279536 + "'", int13 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-259800000L) + "'", long17 == (-259800000L));
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-600000L) + "'", long23 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2592000100L + "'", long34 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "600000" + "'", str38.equals("600000"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-292268511) + "'", int39 == (-292268511));
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 292279536 + "'", int46 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2592000100L + "'", long57 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 292279536 + "'", int60 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(buddhistChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-600000L) + "'", long68 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = buddhistChronology0.getZone();
        try {
            org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("GregorianChronology[+00:10]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[+00:10]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((-1));
        mutableDateTime4.setMillisOfSecond(0);
        org.joda.time.ReadableDuration readableDuration7 = null;
        mutableDateTime4.add(readableDuration7, 33);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2592000100L + "'", long10 == 2592000100L);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 100, 0);
        long long10 = offsetDateTimeField3.roundCeiling((long) 85);
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        long long19 = buddhistChronology12.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology12.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
        org.joda.time.DateTime.Property property25 = dateTime24.era();
        org.joda.time.DateTime dateTime26 = dateTime24.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime28 = dateTime26.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime30 = dateTime28.plusDays((int) (byte) -1);
        long long31 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.LocalDate localDate32 = dateTime30.toLocalDate();
        int[] intArray34 = buddhistChronology12.get((org.joda.time.ReadablePartial) localDate32, (long) 100);
        int int35 = offsetDateTimeField3.getMaximumValue(readablePartial11, intArray34);
        long long37 = offsetDateTimeField3.roundHalfEven(6L);
        java.lang.String str38 = offsetDateTimeField3.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 85800000L + "'", long10 == 85800000L);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-538965L) + "'", long19 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2592000100L + "'", long31 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 398 + "'", int35 == 398);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-600000L) + "'", long37 == (-600000L));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "DateTimeField[dayOfYear]" + "'", str38.equals("DateTimeField[dayOfYear]"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        java.util.GregorianCalendar gregorianCalendar5 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        org.joda.time.DateTime dateTime11 = property10.withMaximumValue();
        org.joda.time.DateTime dateTime12 = property10.roundHalfCeilingCopy();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.minus(readableDuration13);
        org.joda.time.TimeOfDay timeOfDay15 = dateTime14.toTimeOfDay();
        boolean boolean16 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(timeOfDay15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = buddhistChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, dateTimeZone7);
        try {
            long long13 = zonedChronology8.getDateTimeMillis(600, (int) (byte) 100, (int) (short) 10, 600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (byte) -1);
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.LocalDate localDate18 = dateTime16.toLocalDate();
        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate18);
        int int20 = skipDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate18);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) skipDateTimeField4, (java.lang.Object) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) ' ');
        long long28 = offsetDateTimeField26.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField26.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType29, 2513);
        long long33 = dividedDateTimeField31.roundFloor(1L);
        long long35 = dividedDateTimeField31.roundHalfEven((long) '#');
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) ' ');
        long long41 = offsetDateTimeField39.roundHalfFloor((long) (short) 1);
        long long44 = offsetDateTimeField39.add((long) (short) 1, (long) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField47 = buddhistChronology46.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
        long long51 = offsetDateTimeField49.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime54 = org.joda.time.MutableDateTime.now(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) 100, dateTimeZone53);
        org.joda.time.DateTime.Property property56 = dateTime55.era();
        org.joda.time.DateTime dateTime57 = dateTime55.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime59 = dateTime57.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime61 = dateTime59.plusDays((int) (byte) -1);
        long long62 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime61);
        org.joda.time.LocalDate localDate63 = dateTime61.toLocalDate();
        java.util.Locale locale65 = null;
        java.lang.String str66 = offsetDateTimeField49.getAsText((org.joda.time.ReadablePartial) localDate63, 600000, locale65);
        java.lang.String str67 = dateTimeFormatter45.print((org.joda.time.ReadablePartial) localDate63);
        int int68 = offsetDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate63);
        int int69 = dividedDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) localDate63);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2592000100L + "'", long17 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292279536 + "'", int20 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-600000L) + "'", long28 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-259800000L) + "'", long33 == (-259800000L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-259800000L) + "'", long35 == (-259800000L));
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-600000L) + "'", long41 == (-600000L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 864000001L + "'", long44 == 864000001L);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-600000L) + "'", long51 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(mutableDateTime54);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 2592000100L + "'", long62 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate63);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "600000" + "'", str66.equals("600000"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "1970-01" + "'", str67.equals("1970-01"));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 33 + "'", int68 == 33);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-116303) + "'", int69 == (-116303));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
        long long9 = offsetDateTimeField7.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) offsetDateTimeField7);
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) ' ');
        long long18 = offsetDateTimeField16.roundHalfFloor((long) (short) 1);
        long long21 = offsetDateTimeField16.addWrapField((long) (short) 100, 0);
        long long23 = offsetDateTimeField16.roundCeiling((long) 85);
        org.joda.time.ReadablePartial readablePartial24 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.weekyear();
        long long32 = buddhistChronology25.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology25.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime36 = org.joda.time.MutableDateTime.now(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 100, dateTimeZone35);
        org.joda.time.DateTime.Property property38 = dateTime37.era();
        org.joda.time.DateTime dateTime39 = dateTime37.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime41 = dateTime39.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime43 = dateTime41.plusDays((int) (byte) -1);
        long long44 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime43);
        org.joda.time.LocalDate localDate45 = dateTime43.toLocalDate();
        int[] intArray47 = buddhistChronology25.get((org.joda.time.ReadablePartial) localDate45, (long) 100);
        int int48 = offsetDateTimeField16.getMaximumValue(readablePartial24, intArray47);
        try {
            int[] intArray50 = skipDateTimeField10.addWrapField(readablePartial11, 1969, intArray47, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-600000L) + "'", long9 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-600000L) + "'", long18 == (-600000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 85800000L + "'", long23 == 85800000L);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-538965L) + "'", long32 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2592000100L + "'", long44 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 398 + "'", int48 == 398);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField4, 0);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = skipDateTimeField6.getMaximumValue(readablePartial7);
        boolean boolean10 = skipDateTimeField6.isLeap((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 100, dateTimeZone12);
        org.joda.time.DateTime.Property property15 = dateTime14.era();
        org.joda.time.DateTime dateTime16 = dateTime14.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime18 = dateTime16.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime20 = dateTime18.plusDays((int) (byte) -1);
        long long21 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.LocalDate localDate22 = dateTime20.toLocalDate();
        int int23 = skipDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292279536 + "'", int8 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2592000100L + "'", long21 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268511) + "'", int23 == (-292268511));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = property11.withMaximumValue();
        org.joda.time.DateTime dateTime13 = property11.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = dateTime13.withZoneRetainFields(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.TimeOfDay timeOfDay17 = dateTime16.toTimeOfDay();
        org.joda.time.DateTime.Property property18 = dateTime16.year();
        int int19 = property4.compareTo((org.joda.time.ReadableInstant) dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(timeOfDay17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        long long7 = skipDateTimeField4.set(10L, (int) '4');
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField4.getWrappedField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.weekyear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology13, dateTimeField15, 0);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = skipDateTimeField17.getMaximumValue(readablePartial18);
        boolean boolean21 = skipDateTimeField17.isLeap((long) 'a');
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology11, (org.joda.time.DateTimeField) skipDateTimeField17);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime24 = org.joda.time.MutableDateTime.now(dateTimeZone23);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23);
        org.joda.time.Instant instant26 = gJChronology25.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, (int) ' ');
        long long32 = offsetDateTimeField30.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology25, (org.joda.time.DateTimeField) offsetDateTimeField30);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.hourOfHalfday();
        org.joda.time.DurationField durationField38 = buddhistChronology36.days();
        java.util.Locale locale39 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket41 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology36, locale39, (java.lang.Integer) 2019);
        java.util.Locale locale42 = dateTimeParserBucket41.getLocale();
        java.lang.String str43 = skipDateTimeField33.getAsText((long) (short) -1, locale42);
        int int44 = skipDateTimeField17.getMaximumTextLength(locale42);
        long long45 = skipDateTimeField4.set((long) (byte) -1, "1", locale42);
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime48 = org.joda.time.MutableDateTime.now(dateTimeZone47);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) 100, dateTimeZone47);
        org.joda.time.DateTime.Property property50 = dateTime49.era();
        org.joda.time.DateTime dateTime51 = dateTime49.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime53 = dateTime51.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime55 = dateTime53.plusDays((int) (byte) -1);
        org.joda.time.ReadablePeriod readablePeriod56 = null;
        org.joda.time.DateTime dateTime57 = dateTime55.plus(readablePeriod56);
        org.joda.time.LocalDate localDate58 = dateTime57.toLocalDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology60 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField61 = buddhistChronology60.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, (int) ' ');
        org.joda.time.ReadablePartial readablePartial64 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology66 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField67 = buddhistChronology66.weekyear();
        long long73 = buddhistChronology66.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField74 = buddhistChronology66.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone76 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime77 = org.joda.time.MutableDateTime.now(dateTimeZone76);
        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime((long) 100, dateTimeZone76);
        org.joda.time.DateTime.Property property79 = dateTime78.era();
        org.joda.time.DateTime dateTime80 = dateTime78.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime82 = dateTime80.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime84 = dateTime82.plusDays((int) (byte) -1);
        long long85 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime84);
        org.joda.time.LocalDate localDate86 = dateTime84.toLocalDate();
        int[] intArray88 = buddhistChronology66.get((org.joda.time.ReadablePartial) localDate86, (long) 100);
        int[] intArray90 = offsetDateTimeField63.add(readablePartial64, 0, intArray88, 0);
        try {
            int[] intArray92 = skipDateTimeField4.addWrapField((org.joda.time.ReadablePartial) localDate58, (int) ' ', intArray88, 292279536);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-77661763199990L) + "'", long7 == (-77661763199990L));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 292279536 + "'", int19 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(instant26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-600000L) + "'", long32 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(locale42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "33" + "'", str43.equals("33"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 9 + "'", int44 == 9);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-79271136000001L) + "'", long45 == (-79271136000001L));
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(mutableDateTime48);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(buddhistChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(buddhistChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-538965L) + "'", long73 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertNotNull(dateTimeZone76);
        org.junit.Assert.assertNotNull(mutableDateTime77);
        org.junit.Assert.assertNotNull(property79);
        org.junit.Assert.assertNotNull(dateTime80);
        org.junit.Assert.assertNotNull(dateTime82);
        org.junit.Assert.assertNotNull(dateTime84);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 2592000100L + "'", long85 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate86);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertNotNull(intArray90);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        int int3 = mutableDateTime2.getEra();
        mutableDateTime2.addHours((-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.hourOfHalfday();
        org.joda.time.DurationField durationField8 = buddhistChronology6.days();
        mutableDateTime2.setChronology((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-292268512), (org.joda.time.Chronology) buddhistChronology6);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withEra(85);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 85 for era must be in the range [1,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("17", "17");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException2.getSuppressed();
        java.lang.String str7 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "17" + "'", str3.equals("17"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17" + "'", str7.equals("17"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((-1));
        long long5 = property2.remainder();
        org.joda.time.DurationField durationField6 = property2.getRangeDurationField();
        org.joda.time.MutableDateTime mutableDateTime7 = property2.roundCeiling();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) ' ', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) ' ');
        long long7 = offsetDateTimeField5.roundHalfFloor((long) (short) 1);
        long long10 = offsetDateTimeField5.addWrapField((long) (short) 100, 0);
        int int11 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField5);
        int int14 = skipDateTimeField12.getLeapAmount((-79271136000001L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-600000L) + "'", long7 == (-600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(59, 600000, 0, (int) (byte) -1, 36600035, (org.joda.time.Chronology) buddhistChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 600000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minus(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
        long long9 = offsetDateTimeField7.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField7.getType();
        long long13 = offsetDateTimeField7.set((-259800000L), 100);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.weekyear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology17, dateTimeField19, 0);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = skipDateTimeField21.getMaximumValue(readablePartial22);
        boolean boolean25 = skipDateTimeField21.isLeap((long) 'a');
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology15, (org.joda.time.DateTimeField) skipDateTimeField21);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now(dateTimeZone27);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27);
        org.joda.time.Instant instant30 = gJChronology29.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long36 = offsetDateTimeField34.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology29, (org.joda.time.DateTimeField) offsetDateTimeField34);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.hourOfHalfday();
        org.joda.time.DurationField durationField42 = buddhistChronology40.days();
        java.util.Locale locale43 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket45 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology40, locale43, (java.lang.Integer) 2019);
        java.util.Locale locale46 = dateTimeParserBucket45.getLocale();
        java.lang.String str47 = skipDateTimeField37.getAsText((long) (short) -1, locale46);
        int int48 = skipDateTimeField21.getMaximumTextLength(locale46);
        java.lang.String str49 = offsetDateTimeField7.getAsShortText((int) (byte) -1, locale46);
        try {
            java.lang.String str50 = dateTime0.toString("DateTimeField[dayOfYear]", locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-600000L) + "'", long9 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-25747800000L) + "'", long13 == (-25747800000L));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 292279536 + "'", int23 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(instant30);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-600000L) + "'", long36 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(locale46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "33" + "'", str47.equals("33"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 9 + "'", int48 == 9);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "-1" + "'", str49.equals("-1"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("33");
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfHour();
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = mutableDateTime3.toCalendar(locale5);
        mutableDateTime3.addSeconds((int) (short) 100);
        boolean boolean9 = jodaTimePermission1.equals((java.lang.Object) mutableDateTime3);
        java.lang.String str10 = jodaTimePermission1.getName();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        long long16 = dateTimeZone13.convertLocalToUTC(100L, false);
        boolean boolean17 = jodaTimePermission1.equals((java.lang.Object) 100L);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "33" + "'", str10.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-599900L) + "'", long16 == (-599900L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField3, 0);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = skipDateTimeField5.getMaximumValue(readablePartial6);
        boolean boolean9 = skipDateTimeField5.isLeap((long) 'a');
        boolean boolean10 = skipDateTimeField5.isLenient();
        long long12 = skipDateTimeField5.roundCeiling((long) 600000);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipDateTimeField5.getAsShortText(2, locale14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 100, dateTimeZone17);
        org.joda.time.DateTime.Property property20 = dateTime19.era();
        org.joda.time.DateTime dateTime22 = dateTime19.minusMillis(2);
        org.joda.time.DateTime dateTime24 = dateTime22.withCenturyOfEra(0);
        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
        int int26 = skipDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDateTime25);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipDateTimeField5);
        java.lang.String str29 = skipUndoDateTimeField27.getAsText(132L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292279536 + "'", int7 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31794600000L + "'", long12 == 31794600000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2" + "'", str15.equals("2"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292268511) + "'", int26 == (-292268511));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2513" + "'", str29.equals("2513"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(1427, (int) (short) 1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 27 + "'", int3 == 27);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        java.lang.String str5 = property4.getAsText();
        int int6 = property4.get();
        org.joda.time.DateTime dateTime7 = property4.getDateTime();
        java.lang.String str8 = property4.getAsText();
        try {
            org.joda.time.DateTime dateTime10 = property4.addToCopy(4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AD" + "'", str5.equals("AD"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AD" + "'", str8.equals("AD"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(2);
        int int9 = property4.getLeapAmount();
        org.joda.time.DateTime dateTime10 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(6);
        org.joda.time.DateTime dateTime14 = dateTime10.withMillis(0L);
        org.joda.time.DateTime dateTime16 = dateTime14.withYearOfEra((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        boolean boolean11 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("600000");
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((-1));
        mutableDateTime4.setDate((long) 292279536);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        boolean boolean9 = skipDateTimeField4.isLenient();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology14 = instant13.getChronology();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) (-292268511), chronology14, locale15);
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) ' ');
        long long24 = offsetDateTimeField22.roundHalfFloor((long) (short) 1);
        long long27 = offsetDateTimeField22.addWrapField((long) (short) 100, 0);
        int int28 = offsetDateTimeField22.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology17, (org.joda.time.DateTimeField) offsetDateTimeField22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology30.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) ' ');
        long long35 = offsetDateTimeField33.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField33.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, dateTimeFieldType36);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.hourOfHalfday();
        org.joda.time.DurationField durationField42 = buddhistChronology40.days();
        java.util.Locale locale43 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket45 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology40, locale43, (java.lang.Integer) 2019);
        java.util.Locale locale46 = dateTimeParserBucket45.getLocale();
        dateTimeParserBucket16.saveField(dateTimeFieldType36, "AD", locale46);
        java.lang.String str48 = skipDateTimeField4.getAsText(readablePartial10, 1969, locale46);
        long long50 = skipDateTimeField4.remainder((long) ' ');
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-600000L) + "'", long24 == (-600000L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 33 + "'", int28 == 33);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-600000L) + "'", long35 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(locale46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1969" + "'", str48.equals("1969"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 259800032L + "'", long50 == 259800032L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PST", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PST/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(7, (int) (byte) 0, 40, 292279536, (-1), 2513, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279536 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        java.lang.String str3 = gJChronology2.toString();
        try {
            long long9 = gJChronology2.getDateTimeMillis(51840000000000L, (int) (byte) 1, 398, 600100, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 398 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[+00:10]" + "'", str3.equals("GJChronology[+00:10]"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        java.lang.String str7 = property4.getAsText();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AD" + "'", str7.equals("AD"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property11 = dateTime9.era();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2592000100L + "'", long10 == 2592000100L);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        boolean boolean11 = dateTime9.isAfterNow();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) ' ');
        long long17 = offsetDateTimeField15.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 2592000100L, "hi!");
        try {
            org.joda.time.DateTime dateTime23 = dateTime9.withField(dateTimeFieldType18, 600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 600 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2592000100L + "'", long10 == 2592000100L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-600000L) + "'", long17 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        boolean boolean6 = property4.isLeap();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.hourOfHalfday();
        org.joda.time.DurationField durationField9 = buddhistChronology7.days();
        java.util.Locale locale10 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology7, locale10, (java.lang.Integer) 2019);
        java.util.Locale locale13 = dateTimeParserBucket12.getLocale();
        java.lang.String str14 = skipDateTimeField4.getAsShortText(0L, locale13);
        int int15 = skipDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(locale13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2513" + "'", str14.equals("2513"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-292268512) + "'", int15 == (-292268512));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("1969");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-599900L), (long) 398);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-600298L) + "'", long2 == (-600298L));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 100, 0);
        int int9 = offsetDateTimeField3.getMinimumValue();
        long long12 = offsetDateTimeField3.add(28800001L, (long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 100, dateTimeZone14);
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime18 = property17.withMaximumValue();
        org.joda.time.DateTime dateTime19 = property17.roundHalfCeilingCopy();
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
        org.joda.time.TimeOfDay timeOfDay22 = dateTime21.toTimeOfDay();
        int int23 = offsetDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay22);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 33 + "'", int9 == 33);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 892800001L + "'", long12 == 892800001L);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(timeOfDay22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        int int2 = mutableDateTime1.getEra();
        mutableDateTime1.addHours((-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.hourOfHalfday();
        org.joda.time.DurationField durationField7 = buddhistChronology5.days();
        mutableDateTime1.setChronology((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology5.millisOfSecond();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology5);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 2, 600L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-598L) + "'", long2 == (-598L));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 100, 0);
        long long10 = offsetDateTimeField3.roundCeiling((long) 85);
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        long long19 = buddhistChronology12.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology12.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
        org.joda.time.DateTime.Property property25 = dateTime24.era();
        org.joda.time.DateTime dateTime26 = dateTime24.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime28 = dateTime26.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime30 = dateTime28.plusDays((int) (byte) -1);
        long long31 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.LocalDate localDate32 = dateTime30.toLocalDate();
        int[] intArray34 = buddhistChronology12.get((org.joda.time.ReadablePartial) localDate32, (long) 100);
        int int35 = offsetDateTimeField3.getMaximumValue(readablePartial11, intArray34);
        long long37 = offsetDateTimeField3.roundHalfEven(6L);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField3, (-292268511), (int) 'a', 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292268511 for dayOfYear must be in the range [97,4]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 85800000L + "'", long10 == 85800000L);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-538965L) + "'", long19 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2592000100L + "'", long31 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 398 + "'", int35 == 398);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-600000L) + "'", long37 == (-600000L));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        mutableDateTime1.setZone(dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = dateTimeZone2.getOffset(readableInstant6);
        java.lang.String str8 = dateTimeZone2.toString();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, dateTimeZone2);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfWeek();
        java.lang.String str11 = property10.getAsString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 600000 + "'", int7 == 600000);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:10" + "'", str8.equals("+00:10"));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4" + "'", str11.equals("4"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (byte) -1);
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now(dateTimeZone19);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19);
        mutableDateTime18.setZone(dateTimeZone19);
        org.joda.time.ReadableInstant readableInstant23 = null;
        int int24 = dateTimeZone19.getOffset(readableInstant23);
        org.joda.time.MutableDateTime mutableDateTime25 = dateTime16.toMutableDateTime(dateTimeZone19);
        try {
            org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((int) '4', 40, 59, 600000, 33, 10, 600100, dateTimeZone19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 600000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2592000100L + "'", long17 == 2592000100L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 600000 + "'", int24 == 600000);
        org.junit.Assert.assertNotNull(mutableDateTime25);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (byte) -1);
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.LocalDate localDate18 = dateTime16.toLocalDate();
        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate18);
        int int20 = skipDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate18);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) skipDateTimeField4, (java.lang.Object) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) ' ');
        long long28 = offsetDateTimeField26.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField26.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType29, 2513);
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "weekyear");
        org.joda.time.DurationFieldType durationFieldType34 = illegalFieldValueException33.getDurationFieldType();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2592000100L + "'", long17 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292279536 + "'", int20 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-600000L) + "'", long28 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNull(durationFieldType34);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.DurationField durationField5 = buddhistChronology0.minutes();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.set(0);
        int int9 = mutableDateTime8.getYearOfEra();
        org.joda.time.ReadableInstant readableInstant10 = null;
        boolean boolean11 = mutableDateTime8.isBefore(readableInstant10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime8.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime13 = property12.roundCeiling();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField16, 0);
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = skipDateTimeField18.getMaximumValue(readablePartial19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
        org.joda.time.DateTime.Property property25 = dateTime24.era();
        org.joda.time.DateTime dateTime26 = dateTime24.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime28 = dateTime26.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime30 = dateTime28.plusDays((int) (byte) -1);
        long long31 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.LocalDate localDate32 = dateTime30.toLocalDate();
        boolean boolean33 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate32);
        int int34 = skipDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) localDate32);
        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) skipDateTimeField18, (java.lang.Object) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology37.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, (int) ' ');
        long long42 = offsetDateTimeField40.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField40.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType43, 2513);
        long long47 = dividedDateTimeField45.roundFloor(1L);
        long long49 = dividedDateTimeField45.roundHalfEven((long) '#');
        try {
            mutableDateTime13.setRounding((org.joda.time.DateTimeField) dividedDateTimeField45, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 1970");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1427 + "'", int9 == 1427);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292279536 + "'", int20 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2592000100L + "'", long31 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 292279536 + "'", int34 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-600000L) + "'", long42 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-259800000L) + "'", long47 == (-259800000L));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-259800000L) + "'", long49 == (-259800000L));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.dayOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = buddhistChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology6.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology6, dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now(dateTimeZone16);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        mutableDateTime15.setZone(dateTimeZone16);
        org.joda.time.ReadableInstant readableInstant20 = null;
        int int21 = dateTimeZone16.getOffset(readableInstant20);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime24 = org.joda.time.MutableDateTime.now(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 100, dateTimeZone23);
        org.joda.time.DateTime.Property property26 = dateTime25.era();
        org.joda.time.DateTime dateTime28 = dateTime25.minusMillis(2);
        org.joda.time.DateTime dateTime30 = dateTime28.withCenturyOfEra(0);
        org.joda.time.LocalDateTime localDateTime31 = dateTime30.toLocalDateTime();
        boolean boolean32 = dateTimeZone16.isLocalDateTimeGap(localDateTime31);
        boolean boolean33 = zonedChronology14.equals((java.lang.Object) dateTimeZone16);
        try {
            org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((int) (short) 1, 0, (int) (short) 0, 0, 7, (int) ' ', dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 600000 + "'", int21 == 600000);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime3.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        org.joda.time.DateTime dateTime11 = dateTime9.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = dateTime11.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime15 = dateTime13.plusDays((int) (byte) -1);
        long long16 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
        boolean boolean17 = dateTime15.isAfterNow();
        int int18 = property5.getDifference((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime19 = dateTime15.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2592000100L + "'", long16 == 2592000100L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        int int2 = mutableDateTime1.getEra();
        mutableDateTime1.addHours((-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.hourOfHalfday();
        org.joda.time.DurationField durationField7 = buddhistChronology5.days();
        mutableDateTime1.setChronology((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology5.yearOfEra();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.minusDays(0);
        int int15 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        int int17 = gJChronology16.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 600000 + "'", int6 == 600000);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 600000 + "'", int15 == 600000);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.set(0);
        int int9 = mutableDateTime8.getYearOfEra();
        int int10 = mutableDateTime8.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.secondOfDay();
        mutableDateTime8.addHours((int) (byte) -1);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1427 + "'", int9 == 1427);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        boolean boolean4 = julianChronology0.equals((java.lang.Object) dateTimeFormatter3);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) -1, 4, (int) (byte) 0, 600100, (-292268511));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 600100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = dateTime6.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
        org.joda.time.DateTime.Property property11 = dateTime9.year();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider12 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.Instant instant16 = gJChronology15.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) ' ');
        long long22 = offsetDateTimeField20.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, (org.joda.time.DateTimeField) offsetDateTimeField20);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.hourOfHalfday();
        org.joda.time.DurationField durationField28 = buddhistChronology26.days();
        java.util.Locale locale29 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology26, locale29, (java.lang.Integer) 2019);
        java.util.Locale locale32 = dateTimeParserBucket31.getLocale();
        java.lang.String str33 = skipDateTimeField23.getAsText((long) (short) -1, locale32);
        java.lang.String str36 = defaultNameProvider12.getName(locale32, "600000", "org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported");
        java.lang.String str37 = property11.getAsText(locale32);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(timeOfDay10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-600000L) + "'", long22 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(locale32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "33" + "'", str33.equals("33"));
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1" + "'", str37.equals("1"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((-1));
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfWeek();
        int int6 = mutableDateTime4.getEra();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 100, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        boolean boolean7 = gregorianChronology1.equals((java.lang.Object) dateTime5);
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withWeekOfWeekyear(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime6.hourOfDay();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withField(dateTimeFieldType8, (-292268511));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        long long5 = dateTimeZone2.convertLocalToUTC(100L, false);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        try {
            org.joda.time.Instant instant8 = new org.joda.time.Instant((java.lang.Object) dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-599900L) + "'", long5 == (-599900L));
        org.junit.Assert.assertNotNull(buddhistChronology7);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (byte) -1);
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.LocalDate localDate18 = dateTime16.toLocalDate();
        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate18);
        int int20 = skipDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate18);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) skipDateTimeField4, (java.lang.Object) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) ' ');
        long long28 = offsetDateTimeField26.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField26.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType29, 2513);
        long long33 = dividedDateTimeField31.roundFloor(1L);
        try {
            long long36 = dividedDateTimeField31.addWrapField((long) (byte) 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2592000100L + "'", long17 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292279536 + "'", int20 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-600000L) + "'", long28 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-259800000L) + "'", long33 == (-259800000L));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone2);
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.plusDays((int) (byte) -1);
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        mutableDateTime12.setZone(dateTimeZone13);
        org.joda.time.ReadableInstant readableInstant17 = null;
        int int18 = dateTimeZone13.getOffset(readableInstant17);
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime10.toMutableDateTime(dateTimeZone13);
        mutableDateTime19.addYears(9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology22, dateTimeField24, 0);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = skipDateTimeField26.getMaximumValue(readablePartial27);
        boolean boolean30 = skipDateTimeField26.isLeap((long) 'a');
        long long32 = skipDateTimeField26.roundHalfFloor(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology33.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) ' ');
        long long38 = offsetDateTimeField36.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime41 = org.joda.time.MutableDateTime.now(dateTimeZone40);
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) 100, dateTimeZone40);
        org.joda.time.DateTime.Property property43 = dateTime42.era();
        org.joda.time.DateTime dateTime44 = dateTime42.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime46 = dateTime44.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime48 = dateTime46.plusDays((int) (byte) -1);
        long long49 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime48);
        org.joda.time.LocalDate localDate50 = dateTime48.toLocalDate();
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField36.getAsText((org.joda.time.ReadablePartial) localDate50, 600000, locale52);
        int int54 = skipDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localDate50);
        org.joda.time.chrono.BuddhistChronology buddhistChronology55 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField57 = buddhistChronology56.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField59 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology55, dateTimeField57, 0);
        org.joda.time.ReadablePartial readablePartial60 = null;
        int int61 = skipDateTimeField59.getMaximumValue(readablePartial60);
        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime64 = org.joda.time.MutableDateTime.now(dateTimeZone63);
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((long) 100, dateTimeZone63);
        org.joda.time.DateTime.Property property66 = dateTime65.era();
        org.joda.time.DateTime dateTime67 = dateTime65.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime69 = dateTime67.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime71 = dateTime69.plusDays((int) (byte) -1);
        long long72 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime71);
        org.joda.time.LocalDate localDate73 = dateTime71.toLocalDate();
        boolean boolean74 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate73);
        int int75 = skipDateTimeField59.getMaximumValue((org.joda.time.ReadablePartial) localDate73);
        boolean boolean77 = org.joda.time.field.FieldUtils.equals((java.lang.Object) skipDateTimeField59, (java.lang.Object) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology78 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField79 = buddhistChronology78.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField81 = new org.joda.time.field.OffsetDateTimeField(dateTimeField79, (int) ' ');
        long long83 = offsetDateTimeField81.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType84 = offsetDateTimeField81.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField86 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField59, dateTimeFieldType84, 2513);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField87 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField26, dateTimeFieldType84);
        mutableDateTime19.set(dateTimeFieldType84, 33);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField91 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType84, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2592000100L + "'", long11 == 2592000100L);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 600000 + "'", int18 == 600000);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 292279536 + "'", int28 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-259800000L) + "'", long32 == (-259800000L));
        org.junit.Assert.assertNotNull(buddhistChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-600000L) + "'", long38 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2592000100L + "'", long49 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "600000" + "'", str53.equals("600000"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-292268511) + "'", int54 == (-292268511));
        org.junit.Assert.assertNotNull(buddhistChronology55);
        org.junit.Assert.assertNotNull(buddhistChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 292279536 + "'", int61 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(mutableDateTime64);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 2592000100L + "'", long72 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 292279536 + "'", int75 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(buddhistChronology78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + (-600000L) + "'", long83 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType84);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = buddhistChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, dateTimeZone7);
        org.joda.time.DurationField durationField9 = buddhistChronology0.minutes();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property11 = dateTime9.era();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime13 = property11.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2592000100L + "'", long10 == 2592000100L);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("1970");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 1970");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
        long long9 = offsetDateTimeField7.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) offsetDateTimeField7);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField10, (int) (short) 100, (int) 'a', 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfYear must be in the range [97,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-600000L) + "'", long9 == (-600000L));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        long long7 = skipDateTimeField4.set(10L, (int) '4');
        boolean boolean8 = skipDateTimeField4.isLenient();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4);
        boolean boolean11 = skipDateTimeField4.isLeap((long) 7);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-77661763199990L) + "'", long7 == (-77661763199990L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.io.Writer writer2 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTime();
        int int5 = mutableDateTime4.getEra();
        mutableDateTime4.addHours((-1));
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        mutableDateTime4.add(readablePeriod8);
        org.joda.time.ReadableDuration readableDuration10 = null;
        mutableDateTime4.add(readableDuration10, (int) (short) 1);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime4.weekyear();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) mutableDateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) ' ');
        long long7 = offsetDateTimeField5.roundHalfFloor((long) (short) 1);
        long long10 = offsetDateTimeField5.addWrapField((long) (short) 100, 0);
        int int11 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField5);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider14 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) ' ');
        long long24 = offsetDateTimeField22.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, (org.joda.time.DateTimeField) offsetDateTimeField22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.hourOfHalfday();
        org.joda.time.DurationField durationField30 = buddhistChronology28.days();
        java.util.Locale locale31 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology28, locale31, (java.lang.Integer) 2019);
        java.util.Locale locale34 = dateTimeParserBucket33.getLocale();
        java.lang.String str35 = skipDateTimeField25.getAsText((long) (short) -1, locale34);
        java.lang.String str38 = defaultNameProvider14.getName(locale34, "600000", "org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported");
        java.lang.String str39 = offsetDateTimeField5.getAsShortText((int) (short) 1, locale34);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) ' ');
        long long45 = offsetDateTimeField43.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = offsetDateTimeField43.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField48 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType46, 9);
        long long50 = remainderDateTimeField48.remainder((long) (short) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology51 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = buddhistChronology52.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField55 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology51, dateTimeField53, 0);
        org.joda.time.ReadablePartial readablePartial56 = null;
        int int57 = skipDateTimeField55.getMaximumValue(readablePartial56);
        boolean boolean59 = skipDateTimeField55.isLeap((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime62 = org.joda.time.MutableDateTime.now(dateTimeZone61);
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) 100, dateTimeZone61);
        org.joda.time.DateTime.Property property64 = dateTime63.era();
        org.joda.time.DateTime dateTime65 = dateTime63.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime67 = dateTime65.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime69 = dateTime67.plusDays((int) (byte) -1);
        long long70 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime69);
        org.joda.time.LocalDate localDate71 = dateTime69.toLocalDate();
        int int72 = skipDateTimeField55.getMinimumValue((org.joda.time.ReadablePartial) localDate71);
        org.joda.time.chrono.BuddhistChronology buddhistChronology74 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField75 = buddhistChronology74.weekyear();
        long long81 = buddhistChronology74.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField82 = buddhistChronology74.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone84 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime85 = org.joda.time.MutableDateTime.now(dateTimeZone84);
        org.joda.time.DateTime dateTime86 = new org.joda.time.DateTime((long) 100, dateTimeZone84);
        org.joda.time.DateTime.Property property87 = dateTime86.era();
        org.joda.time.DateTime dateTime88 = dateTime86.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime90 = dateTime88.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime92 = dateTime90.plusDays((int) (byte) -1);
        long long93 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime92);
        org.joda.time.LocalDate localDate94 = dateTime92.toLocalDate();
        int[] intArray96 = buddhistChronology74.get((org.joda.time.ReadablePartial) localDate94, (long) 100);
        try {
            int[] intArray98 = remainderDateTimeField48.add((org.joda.time.ReadablePartial) localDate71, 2513, intArray96, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2513");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-600000L) + "'", long7 == (-600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-600000L) + "'", long24 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(locale34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "33" + "'", str35.equals("33"));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-600000L) + "'", long45 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 600010L + "'", long50 == 600010L);
        org.junit.Assert.assertNotNull(buddhistChronology51);
        org.junit.Assert.assertNotNull(buddhistChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 292279536 + "'", int57 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(mutableDateTime62);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2592000100L + "'", long70 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-292268511) + "'", int72 == (-292268511));
        org.junit.Assert.assertNotNull(buddhistChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-538965L) + "'", long81 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField82);
        org.junit.Assert.assertNotNull(dateTimeZone84);
        org.junit.Assert.assertNotNull(mutableDateTime85);
        org.junit.Assert.assertNotNull(property87);
        org.junit.Assert.assertNotNull(dateTime88);
        org.junit.Assert.assertNotNull(dateTime90);
        org.junit.Assert.assertNotNull(dateTime92);
        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 2592000100L + "'", long93 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate94);
        org.junit.Assert.assertNotNull(intArray96);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.hourOfHalfday();
        org.joda.time.DurationField durationField6 = buddhistChronology4.days();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7, (-292279537));
        boolean boolean10 = skipDateTimeField9.isSupported();
        org.joda.time.DateTimeField dateTimeField11 = skipDateTimeField9.getWrappedField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        boolean boolean9 = skipDateTimeField4.isLenient();
        long long11 = skipDateTimeField4.roundCeiling((long) 600000);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 100, dateTimeZone13);
        org.joda.time.DateTime.Property property16 = dateTime15.era();
        org.joda.time.DateTime dateTime17 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime21 = dateTime19.plusDays((int) (byte) -1);
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.LocalDate localDate23 = dateTime21.toLocalDate();
        boolean boolean24 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate23);
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate23, locale25);
        org.joda.time.DateTimeField dateTimeField27 = skipDateTimeField4.getWrappedField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31794600000L + "'", long11 == 31794600000L);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2592000100L + "'", long22 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970" + "'", str26.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.centuryOfEra();
        org.joda.time.Chronology chronology5 = gJChronology2.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[+00:10]" + "'", str3.equals("GJChronology[+00:10]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        boolean boolean6 = offsetDateTimeField3.isLenient();
        boolean boolean8 = offsetDateTimeField3.isLeap(1L);
        boolean boolean10 = offsetDateTimeField3.isLeap(600010L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTimeISO();
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        long long12 = offsetDateTimeField10.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        boolean boolean14 = dateTime6.isSupported(dateTimeFieldType13);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "hi!");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) (short) 10, 4, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfYear must be in the range [4,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-600000L) + "'", long12 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(59, 4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) ' ');
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.weekyear();
        long long14 = buddhistChronology7.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology7.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 100, dateTimeZone17);
        org.joda.time.DateTime.Property property20 = dateTime19.era();
        org.joda.time.DateTime dateTime21 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime23 = dateTime21.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime25 = dateTime23.plusDays((int) (byte) -1);
        long long26 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.LocalDate localDate27 = dateTime25.toLocalDate();
        int[] intArray29 = buddhistChronology7.get((org.joda.time.ReadablePartial) localDate27, (long) 100);
        int[] intArray31 = offsetDateTimeField4.add(readablePartial5, 0, intArray29, 0);
        long long33 = offsetDateTimeField4.roundHalfCeiling((long) (byte) 100);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) offsetDateTimeField4);
        org.joda.time.ReadablePartial readablePartial35 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology37.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, (int) ' ');
        long long42 = offsetDateTimeField40.roundHalfFloor((long) (short) 1);
        long long45 = offsetDateTimeField40.addWrapField((long) (short) 100, 0);
        long long47 = offsetDateTimeField40.roundCeiling((long) 85);
        org.joda.time.ReadablePartial readablePartial48 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology49.weekyear();
        long long56 = buddhistChronology49.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField57 = buddhistChronology49.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime60 = org.joda.time.MutableDateTime.now(dateTimeZone59);
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) 100, dateTimeZone59);
        org.joda.time.DateTime.Property property62 = dateTime61.era();
        org.joda.time.DateTime dateTime63 = dateTime61.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime65 = dateTime63.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime67 = dateTime65.plusDays((int) (byte) -1);
        long long68 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime67);
        org.joda.time.LocalDate localDate69 = dateTime67.toLocalDate();
        int[] intArray71 = buddhistChronology49.get((org.joda.time.ReadablePartial) localDate69, (long) 100);
        int int72 = offsetDateTimeField40.getMaximumValue(readablePartial48, intArray71);
        try {
            int[] intArray74 = offsetDateTimeField4.set(readablePartial35, (-1), intArray71, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-538965L) + "'", long14 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2592000100L + "'", long26 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-600000L) + "'", long33 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-600000L) + "'", long42 == (-600000L));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 85800000L + "'", long47 == 85800000L);
        org.junit.Assert.assertNotNull(buddhistChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-538965L) + "'", long56 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(mutableDateTime60);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 2592000100L + "'", long68 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate69);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 398 + "'", int72 == 398);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readableDuration10);
        boolean boolean13 = dateTime9.isEqual((long) 33);
        org.joda.time.DateTime.Property property14 = dateTime9.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) ' ');
        long long6 = offsetDateTimeField4.roundHalfFloor((long) (short) 1);
        long long9 = offsetDateTimeField4.addWrapField((long) (short) 100, 0);
        int int10 = offsetDateTimeField4.getMinimumValue();
        long long13 = offsetDateTimeField4.add(28800001L, (long) (byte) 10);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField4, 10);
        long long19 = buddhistChronology0.add((long) (byte) 10, (long) 3, (int) (byte) 1);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-600000L) + "'", long6 == (-600000L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 892800001L + "'", long13 == 892800001L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 13L + "'", long19 == 13L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("7", "");
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = dateTime6.withZoneRetainFields(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) ' ');
        long long7 = offsetDateTimeField5.roundHalfFloor((long) (short) 1);
        long long10 = offsetDateTimeField5.addWrapField((long) (short) 100, 0);
        int int11 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField5);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider14 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) ' ');
        long long24 = offsetDateTimeField22.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, (org.joda.time.DateTimeField) offsetDateTimeField22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.hourOfHalfday();
        org.joda.time.DurationField durationField30 = buddhistChronology28.days();
        java.util.Locale locale31 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology28, locale31, (java.lang.Integer) 2019);
        java.util.Locale locale34 = dateTimeParserBucket33.getLocale();
        java.lang.String str35 = skipDateTimeField25.getAsText((long) (short) -1, locale34);
        java.lang.String str38 = defaultNameProvider14.getName(locale34, "600000", "org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported");
        java.lang.String str39 = offsetDateTimeField5.getAsShortText((int) (short) 1, locale34);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime41 = org.joda.time.MutableDateTime.now(dateTimeZone40);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40);
        org.joda.time.Instant instant43 = gJChronology42.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology44 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology45.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology44, dateTimeField46, 0);
        org.joda.time.ReadablePartial readablePartial49 = null;
        int int50 = skipDateTimeField48.getMaximumValue(readablePartial49);
        boolean boolean52 = skipDateTimeField48.isLeap((long) 'a');
        boolean boolean53 = skipDateTimeField48.isLenient();
        long long55 = skipDateTimeField48.roundCeiling((long) 600000);
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime58 = org.joda.time.MutableDateTime.now(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) 100, dateTimeZone57);
        org.joda.time.DateTime.Property property60 = dateTime59.era();
        org.joda.time.DateTime dateTime61 = dateTime59.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime63 = dateTime61.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime65 = dateTime63.plusDays((int) (byte) -1);
        long long66 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime65);
        org.joda.time.LocalDate localDate67 = dateTime65.toLocalDate();
        boolean boolean68 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate67);
        java.util.Locale locale69 = null;
        java.lang.String str70 = skipDateTimeField48.getAsText((org.joda.time.ReadablePartial) localDate67, locale69);
        long long72 = gJChronology42.set((org.joda.time.ReadablePartial) localDate67, 85800000L);
        int int73 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDate67);
        long long75 = offsetDateTimeField5.roundCeiling(40L);
        long long77 = offsetDateTimeField5.roundCeiling((-77661763199990L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-600000L) + "'", long7 == (-600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-600000L) + "'", long24 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(locale34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "33" + "'", str35.equals("33"));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(instant43);
        org.junit.Assert.assertNotNull(buddhistChronology44);
        org.junit.Assert.assertNotNull(buddhistChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 292279536 + "'", int50 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 31794600000L + "'", long55 == 31794600000L);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(mutableDateTime58);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2592000100L + "'", long66 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1970" + "'", str70.equals("1970"));
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 2591400000L + "'", long72 == 2591400000L);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 33 + "'", int73 == 33);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 85800000L + "'", long75 == 85800000L);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-77661677400000L) + "'", long77 == (-77661677400000L));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minus(0L);
        org.joda.time.DateTime dateTime5 = dateTime0.withDurationAdded((long) (byte) 10, 36600035);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        int int8 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        boolean boolean10 = gregorianChronology6.equals((java.lang.Object) dateTimeFormatter9);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(0, (int) 'a', (int) '4', 10, 292279536, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279536 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-292268512), (int) (byte) -1, (int) (byte) 1, 600, 1427, 0, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((-1));
        int int5 = property2.getMaximumValue();
        java.lang.String str6 = property2.toString();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[minuteOfHour]" + "'", str6.equals("Property[minuteOfHour]"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("33");
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfHour();
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = mutableDateTime3.toCalendar(locale5);
        mutableDateTime3.addSeconds((int) (short) 100);
        boolean boolean9 = jodaTimePermission1.equals((java.lang.Object) mutableDateTime3);
        java.lang.String str10 = jodaTimePermission1.getName();
        java.lang.String str11 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection12 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "33" + "'", str10.equals("33"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "33" + "'", str11.equals("33"));
        org.junit.Assert.assertNotNull(permissionCollection12);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.minusHours(59);
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfEven();
        mutableDateTime3.setYear((int) '4');
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.year();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.set(3);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.DateTimeField dateTimeField5 = skipDateTimeField4.getWrappedField();
        long long7 = skipDateTimeField4.roundFloor((long) 10);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-259800000L) + "'", long7 == (-259800000L));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) ' ');
        long long7 = offsetDateTimeField5.roundHalfFloor((long) (short) 1);
        long long10 = offsetDateTimeField5.addWrapField((long) (short) 100, 0);
        int int11 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField5);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider14 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) ' ');
        long long24 = offsetDateTimeField22.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, (org.joda.time.DateTimeField) offsetDateTimeField22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.hourOfHalfday();
        org.joda.time.DurationField durationField30 = buddhistChronology28.days();
        java.util.Locale locale31 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology28, locale31, (java.lang.Integer) 2019);
        java.util.Locale locale34 = dateTimeParserBucket33.getLocale();
        java.lang.String str35 = skipDateTimeField25.getAsText((long) (short) -1, locale34);
        java.lang.String str38 = defaultNameProvider14.getName(locale34, "600000", "org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported");
        java.lang.String str39 = offsetDateTimeField5.getAsShortText((int) (short) 1, locale34);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime41 = org.joda.time.MutableDateTime.now(dateTimeZone40);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40);
        org.joda.time.Instant instant43 = gJChronology42.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology44 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology45.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology44, dateTimeField46, 0);
        org.joda.time.ReadablePartial readablePartial49 = null;
        int int50 = skipDateTimeField48.getMaximumValue(readablePartial49);
        boolean boolean52 = skipDateTimeField48.isLeap((long) 'a');
        boolean boolean53 = skipDateTimeField48.isLenient();
        long long55 = skipDateTimeField48.roundCeiling((long) 600000);
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime58 = org.joda.time.MutableDateTime.now(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) 100, dateTimeZone57);
        org.joda.time.DateTime.Property property60 = dateTime59.era();
        org.joda.time.DateTime dateTime61 = dateTime59.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime63 = dateTime61.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime65 = dateTime63.plusDays((int) (byte) -1);
        long long66 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime65);
        org.joda.time.LocalDate localDate67 = dateTime65.toLocalDate();
        boolean boolean68 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate67);
        java.util.Locale locale69 = null;
        java.lang.String str70 = skipDateTimeField48.getAsText((org.joda.time.ReadablePartial) localDate67, locale69);
        long long72 = gJChronology42.set((org.joda.time.ReadablePartial) localDate67, 85800000L);
        int int73 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDate67);
        long long76 = offsetDateTimeField5.addWrapField((long) (-292268511), (int) (short) 10);
        boolean boolean77 = offsetDateTimeField5.isLenient();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-600000L) + "'", long7 == (-600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-600000L) + "'", long24 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(locale34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "33" + "'", str35.equals("33"));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(instant43);
        org.junit.Assert.assertNotNull(buddhistChronology44);
        org.junit.Assert.assertNotNull(buddhistChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 292279536 + "'", int50 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 31794600000L + "'", long55 == 31794600000L);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(mutableDateTime58);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2592000100L + "'", long66 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1970" + "'", str70.equals("1970"));
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 2591400000L + "'", long72 == 2591400000L);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 33 + "'", int73 == 33);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-31050668511L) + "'", long76 == (-31050668511L));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = buddhistChronology0.days();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology4 = buddhistChronology0.withUTC();
        org.joda.time.DurationField durationField5 = buddhistChronology0.centuries();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((-1));
        int int5 = property2.getMaximumValue();
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology7, dateTimeField9, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.hourOfHalfday();
        org.joda.time.DurationField durationField16 = buddhistChronology14.days();
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology14, locale17, (java.lang.Integer) 2019);
        java.util.Locale locale20 = dateTimeParserBucket19.getLocale();
        java.lang.String str21 = skipDateTimeField11.getAsShortText(0L, locale20);
        org.joda.time.MutableDateTime mutableDateTime22 = property2.set("1", locale20);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(locale20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2513" + "'", str21.equals("2513"));
        org.junit.Assert.assertNotNull(mutableDateTime22);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.LocalDate localDate11 = dateTime9.toLocalDate();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime9.toDateTime(dateTimeZone12);
        int int17 = dateTimeZone12.getOffsetFromLocal((long) 'a');
        long long20 = dateTimeZone12.adjustOffset((-1199900L), true);
        java.lang.String str22 = dateTimeZone12.getShortName((long) 398);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2592000100L + "'", long10 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 600000 + "'", int17 == 600000);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1199900L) + "'", long20 == (-1199900L));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:10" + "'", str22.equals("+00:10"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        mutableDateTime1.setZone(dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = dateTimeZone2.getOffset(readableInstant6);
        java.lang.String str8 = dateTimeZone2.toString();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, dateTimeZone2);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.dayOfWeek();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            mutableDateTime9.add(durationFieldType11, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 600000 + "'", int7 == 600000);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:10" + "'", str8.equals("+00:10"));
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1427-W06-5T00:00:00+00:10");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.TimeOfDay timeOfDay5 = dateTime3.toTimeOfDay();
        org.joda.time.DateTime.Property property6 = dateTime3.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1969");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
        long long9 = offsetDateTimeField3.set((-259800000L), 100);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.weekyear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology13, dateTimeField15, 0);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = skipDateTimeField17.getMaximumValue(readablePartial18);
        boolean boolean21 = skipDateTimeField17.isLeap((long) 'a');
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology11, (org.joda.time.DateTimeField) skipDateTimeField17);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime24 = org.joda.time.MutableDateTime.now(dateTimeZone23);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23);
        org.joda.time.Instant instant26 = gJChronology25.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, (int) ' ');
        long long32 = offsetDateTimeField30.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology25, (org.joda.time.DateTimeField) offsetDateTimeField30);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.hourOfHalfday();
        org.joda.time.DurationField durationField38 = buddhistChronology36.days();
        java.util.Locale locale39 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket41 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology36, locale39, (java.lang.Integer) 2019);
        java.util.Locale locale42 = dateTimeParserBucket41.getLocale();
        java.lang.String str43 = skipDateTimeField33.getAsText((long) (short) -1, locale42);
        int int44 = skipDateTimeField17.getMaximumTextLength(locale42);
        java.lang.String str45 = offsetDateTimeField3.getAsShortText((int) (byte) -1, locale42);
        int int46 = offsetDateTimeField3.getMaximumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-25747800000L) + "'", long9 == (-25747800000L));
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 292279536 + "'", int19 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(instant26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-600000L) + "'", long32 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(locale42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "33" + "'", str43.equals("33"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 9 + "'", int44 == 9);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "-1" + "'", str45.equals("-1"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 398 + "'", int46 == 398);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime2 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfWeek(4);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("33");
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfHour();
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = mutableDateTime3.toCalendar(locale5);
        mutableDateTime3.addSeconds((int) (short) 100);
        boolean boolean9 = jodaTimePermission1.equals((java.lang.Object) mutableDateTime3);
        org.joda.time.JodaTimePermission jodaTimePermission11 = new org.joda.time.JodaTimePermission("33");
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime13 = instant12.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.minuteOfHour();
        java.util.Locale locale15 = null;
        java.util.Calendar calendar16 = mutableDateTime13.toCalendar(locale15);
        mutableDateTime13.addSeconds((int) (short) 100);
        boolean boolean19 = jodaTimePermission11.equals((java.lang.Object) mutableDateTime13);
        boolean boolean20 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission11);
        org.joda.time.JodaTimePermission jodaTimePermission22 = new org.joda.time.JodaTimePermission("33");
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime24 = instant23.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime24.minuteOfHour();
        java.util.Locale locale26 = null;
        java.util.Calendar calendar27 = mutableDateTime24.toCalendar(locale26);
        mutableDateTime24.addSeconds((int) (short) 100);
        boolean boolean30 = jodaTimePermission22.equals((java.lang.Object) mutableDateTime24);
        org.joda.time.JodaTimePermission jodaTimePermission32 = new org.joda.time.JodaTimePermission("33");
        org.joda.time.Instant instant33 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime34 = instant33.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.minuteOfHour();
        java.util.Locale locale36 = null;
        java.util.Calendar calendar37 = mutableDateTime34.toCalendar(locale36);
        mutableDateTime34.addSeconds((int) (short) 100);
        boolean boolean40 = jodaTimePermission32.equals((java.lang.Object) mutableDateTime34);
        boolean boolean41 = jodaTimePermission22.implies((java.security.Permission) jodaTimePermission32);
        boolean boolean42 = jodaTimePermission11.implies((java.security.Permission) jodaTimePermission22);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(calendar16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(calendar27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(calendar37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 100, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        boolean boolean7 = gregorianChronology1.equals((java.lang.Object) dateTime5);
        try {
            long long15 = gregorianChronology1.getDateTimeMillis((int) (short) 10, 2, (int) (short) -1, 1970, 0, (int) 'a', 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(2);
        int int9 = property4.getLeapAmount();
        org.joda.time.DateTime dateTime10 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime11 = property4.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.set(0);
        int int9 = mutableDateTime8.getYearOfEra();
        mutableDateTime8.addMillis(36600035);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime8.dayOfMonth();
        mutableDateTime8.addHours(8);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1427 + "'", int9 == 1427);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported");
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        boolean boolean9 = skipDateTimeField4.isLenient();
        long long11 = skipDateTimeField4.roundCeiling((long) 600000);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 100, dateTimeZone13);
        org.joda.time.DateTime.Property property16 = dateTime15.era();
        org.joda.time.DateTime dateTime17 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime21 = dateTime19.plusDays((int) (byte) -1);
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.LocalDate localDate23 = dateTime21.toLocalDate();
        boolean boolean24 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate23);
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate23, locale25);
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology29.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) ' ');
        long long34 = offsetDateTimeField32.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField32.getType();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime38 = org.joda.time.MutableDateTime.now(dateTimeZone37);
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37);
        org.joda.time.Instant instant40 = gJChronology39.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) ' ');
        long long46 = offsetDateTimeField44.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField47 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology39, (org.joda.time.DateTimeField) offsetDateTimeField44);
        org.joda.time.chrono.BuddhistChronology buddhistChronology50 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = buddhistChronology50.hourOfHalfday();
        org.joda.time.DurationField durationField52 = buddhistChronology50.days();
        java.util.Locale locale53 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology50, locale53, (java.lang.Integer) 2019);
        java.util.Locale locale56 = dateTimeParserBucket55.getLocale();
        java.lang.String str57 = skipDateTimeField47.getAsText((long) (short) -1, locale56);
        java.lang.String str58 = offsetDateTimeField32.getAsShortText((-28858200000L), locale56);
        try {
            long long59 = skipDateTimeField4.set((-28857599900L), "Property[minuteOfHour]", locale56);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[minuteOfHour]\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31794600000L + "'", long11 == 31794600000L);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2592000100L + "'", long22 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970" + "'", str26.equals("1970"));
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-600000L) + "'", long34 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(instant40);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-600000L) + "'", long46 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(locale56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "33" + "'", str57.equals("33"));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "64" + "'", str58.equals("64"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("weekyear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'weekyear' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        mutableDateTime1.setZone(dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = dateTimeZone2.getOffset(readableInstant6);
        java.lang.String str8 = dateTimeZone2.toString();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, dateTimeZone2);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getName((long) 33, locale11);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 600000 + "'", int7 == 600000);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:10" + "'", str8.equals("+00:10"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:10" + "'", str12.equals("+00:10"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("33");
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfHour();
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = mutableDateTime3.toCalendar(locale5);
        mutableDateTime3.addSeconds((int) (short) 100);
        boolean boolean9 = jodaTimePermission1.equals((java.lang.Object) mutableDateTime3);
        org.joda.time.JodaTimePermission jodaTimePermission11 = new org.joda.time.JodaTimePermission("33");
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime13 = instant12.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.minuteOfHour();
        java.util.Locale locale15 = null;
        java.util.Calendar calendar16 = mutableDateTime13.toCalendar(locale15);
        mutableDateTime13.addSeconds((int) (short) 100);
        boolean boolean19 = jodaTimePermission11.equals((java.lang.Object) mutableDateTime13);
        boolean boolean20 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission11);
        java.security.PermissionCollection permissionCollection21 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(calendar16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(permissionCollection21);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology1.days();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology1, locale4, (java.lang.Integer) 2019);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        dateTimeParserBucket6.setZone(dateTimeZone7);
        dateTimeParserBucket6.setPivotYear((java.lang.Integer) 2);
        org.joda.time.Chronology chronology12 = dateTimeParserBucket6.getChronology();
        dateTimeParserBucket6.setOffset((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
        long long9 = offsetDateTimeField7.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) offsetDateTimeField7);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology2.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-600000L) + "'", long9 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        long long8 = offsetDateTimeField3.addWrapField((long) (short) 100, 0);
        long long10 = offsetDateTimeField3.roundCeiling((long) 85);
        long long12 = offsetDateTimeField3.roundFloor(2440587L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 85800000L + "'", long10 == 85800000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-600000L) + "'", long12 == (-600000L));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy(2);
        int int9 = property4.getLeapAmount();
        org.joda.time.DurationField durationField10 = property4.getLeapDurationField();
        java.lang.String str11 = property4.getAsText();
        org.joda.time.DateTime dateTime12 = property4.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime14 = property4.addWrapFieldToCopy(1969);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "AD" + "'", str11.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 100, dateTimeZone6);
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime10 = property9.withMaximumValue();
        org.joda.time.DateTime dateTime11 = property9.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        long long16 = dateTimeZone12.adjustOffset((long) 40, false);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (byte) 10, 0, 40, (-292268512), (int) (short) 100, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292268512 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 40L + "'", long16 == 40L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        boolean boolean9 = skipDateTimeField4.isLenient();
        long long11 = skipDateTimeField4.roundCeiling((long) 600000);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 100, dateTimeZone13);
        org.joda.time.DateTime.Property property16 = dateTime15.era();
        org.joda.time.DateTime dateTime17 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime21 = dateTime19.plusDays((int) (byte) -1);
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.LocalDate localDate23 = dateTime21.toLocalDate();
        boolean boolean24 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate23);
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate23, locale25);
        int int27 = skipDateTimeField4.getMinimumValue();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology29.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology28, dateTimeField30, 0);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = skipDateTimeField32.getMaximumValue(readablePartial33);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime37 = org.joda.time.MutableDateTime.now(dateTimeZone36);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) 100, dateTimeZone36);
        org.joda.time.DateTime.Property property39 = dateTime38.era();
        org.joda.time.DateTime dateTime40 = dateTime38.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime42 = dateTime40.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime44 = dateTime42.plusDays((int) (byte) -1);
        long long45 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.LocalDate localDate46 = dateTime44.toLocalDate();
        boolean boolean47 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate46);
        int int48 = skipDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDate46);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime51 = org.joda.time.MutableDateTime.now(dateTimeZone50);
        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50);
        org.joda.time.Instant instant53 = gJChronology52.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) ' ');
        long long59 = offsetDateTimeField57.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField60 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology52, (org.joda.time.DateTimeField) offsetDateTimeField57);
        org.joda.time.chrono.BuddhistChronology buddhistChronology63 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField64 = buddhistChronology63.hourOfHalfday();
        org.joda.time.DurationField durationField65 = buddhistChronology63.days();
        java.util.Locale locale66 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket68 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology63, locale66, (java.lang.Integer) 2019);
        java.util.Locale locale69 = dateTimeParserBucket68.getLocale();
        java.lang.String str70 = skipDateTimeField60.getAsText((long) (short) -1, locale69);
        java.lang.String str71 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate46, 40, locale69);
        java.util.Locale locale73 = null;
        java.lang.String str74 = skipDateTimeField4.getAsText(0L, locale73);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31794600000L + "'", long11 == 31794600000L);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2592000100L + "'", long22 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970" + "'", str26.equals("1970"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-292268512) + "'", int27 == (-292268512));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 292279536 + "'", int34 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2592000100L + "'", long45 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 292279536 + "'", int48 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(mutableDateTime51);
        org.junit.Assert.assertNotNull(gJChronology52);
        org.junit.Assert.assertNotNull(instant53);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-600000L) + "'", long59 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(locale69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "33" + "'", str70.equals("33"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "40" + "'", str71.equals("40"));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "2513" + "'", str74.equals("2513"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) ' ');
        long long7 = offsetDateTimeField5.roundHalfFloor((long) (short) 1);
        long long10 = offsetDateTimeField5.addWrapField((long) (short) 100, 0);
        int int11 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField5);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider14 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) ' ');
        long long24 = offsetDateTimeField22.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, (org.joda.time.DateTimeField) offsetDateTimeField22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.hourOfHalfday();
        org.joda.time.DurationField durationField30 = buddhistChronology28.days();
        java.util.Locale locale31 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology28, locale31, (java.lang.Integer) 2019);
        java.util.Locale locale34 = dateTimeParserBucket33.getLocale();
        java.lang.String str35 = skipDateTimeField25.getAsText((long) (short) -1, locale34);
        java.lang.String str38 = defaultNameProvider14.getName(locale34, "600000", "org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported");
        java.lang.String str39 = offsetDateTimeField5.getAsShortText((int) (short) 1, locale34);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) ' ');
        long long45 = offsetDateTimeField43.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = offsetDateTimeField43.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField48 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType46, 9);
        long long50 = remainderDateTimeField48.remainder(0L);
        int int51 = remainderDateTimeField48.getMaximumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-600000L) + "'", long7 == (-600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-600000L) + "'", long24 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(locale34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "33" + "'", str35.equals("33"));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-600000L) + "'", long45 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 600000L + "'", long50 == 600000L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 8 + "'", int51 == 8);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime3.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        org.joda.time.DateTime dateTime11 = dateTime9.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = dateTime11.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime15 = dateTime13.plusDays((int) (byte) -1);
        long long16 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
        boolean boolean17 = dateTime15.isAfterNow();
        int int18 = property5.getDifference((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime19 = dateTime15.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 100, dateTimeZone21);
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime25 = dateTime23.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime27 = dateTime25.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime29 = dateTime27.plusDays((int) (byte) -1);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.plus(readablePeriod30);
        org.joda.time.DateTime.Property property32 = dateTime31.secondOfMinute();
        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfHour();
        boolean boolean34 = dateTime15.equals((java.lang.Object) property33);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2592000100L + "'", long16 == 2592000100L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("4", 2513, 0, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2513 for 4 must be in the range [0,1970]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) 85, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        boolean boolean11 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        int int12 = dateTime9.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime9.plusMillis((int) (byte) 0);
        try {
            org.joda.time.DateTime dateTime16 = dateTime9.withMinuteOfHour((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime9 = dateTime5.withMillis((long) (-292268511));
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.weekyear();
        long long17 = buddhistChronology10.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology10.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 100, dateTimeZone20);
        org.joda.time.DateTime.Property property23 = dateTime22.era();
        org.joda.time.DateTime dateTime24 = dateTime22.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime26 = dateTime24.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime28 = dateTime26.plusDays((int) (byte) -1);
        long long29 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.LocalDate localDate30 = dateTime28.toLocalDate();
        int[] intArray32 = buddhistChronology10.get((org.joda.time.ReadablePartial) localDate30, (long) 100);
        org.joda.time.DateTime dateTime33 = dateTime9.withFields((org.joda.time.ReadablePartial) localDate30);
        org.joda.time.DateTime dateTime35 = dateTime9.withMillisOfDay((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-538965L) + "'", long17 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2592000100L + "'", long29 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = buddhistChronology1.years();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2019, (org.joda.time.Chronology) buddhistChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        boolean boolean7 = dateTime3.isBeforeNow();
        org.joda.time.YearMonthDay yearMonthDay8 = dateTime3.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(yearMonthDay8);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((-1));
        org.joda.time.MutableDateTime mutableDateTime5 = property2.roundHalfCeiling();
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = property2.set("1970");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        org.joda.time.DateTime dateTime11 = dateTime9.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = dateTime11.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime15 = dateTime13.plusDays((int) (byte) -1);
        long long16 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = dateTime15.toLocalDate();
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate17, 600000, locale19);
        long long22 = offsetDateTimeField3.roundHalfEven(2592000100L);
        long long25 = offsetDateTimeField3.getDifferenceAsLong((long) (byte) 0, (long) 0);
        java.lang.String str27 = offsetDateTimeField3.getAsText(0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2592000100L + "'", long16 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "600000" + "'", str20.equals("600000"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2591400000L + "'", long22 == 2591400000L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "33" + "'", str27.equals("33"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        long long6 = dateTimeZone1.convertLocalToUTC(13L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-599987L) + "'", long6 == (-599987L));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipDateTimeField4.getType();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) skipDateTimeField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.SkipDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology1.days();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology1, locale4, (java.lang.Integer) 2019);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        dateTimeParserBucket6.setZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeParserBucket6.getZone();
        long long13 = dateTimeZone10.convertLocalToUTC(0L, true);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-600000L) + "'", long13 == (-600000L));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.Instant instant4 = gJChronology2.getGregorianCutover();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.ReadablePartial readablePartial4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.weekyear();
        long long13 = buddhistChronology6.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 100, dateTimeZone16);
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime20 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime24 = dateTime22.plusDays((int) (byte) -1);
        long long25 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.LocalDate localDate26 = dateTime24.toLocalDate();
        int[] intArray28 = buddhistChronology6.get((org.joda.time.ReadablePartial) localDate26, (long) 100);
        int[] intArray30 = offsetDateTimeField3.add(readablePartial4, 0, intArray28, 0);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime33 = dateTime31.withYearOfCentury(6);
        org.joda.time.DateTime dateTime35 = dateTime31.minusHours(36600035);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.hourOfHalfday();
        org.joda.time.DurationField durationField38 = buddhistChronology36.days();
        org.joda.time.DateTimeField dateTimeField39 = buddhistChronology36.hourOfDay();
        org.joda.time.Chronology chronology40 = buddhistChronology36.withUTC();
        org.joda.time.DateTime dateTime41 = dateTime31.toDateTime((org.joda.time.Chronology) buddhistChronology36);
        try {
            org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) 0, (org.joda.time.Chronology) buddhistChronology36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-538965L) + "'", long13 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2592000100L + "'", long25 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTime41);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        mutableDateTime1.setZone(dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = dateTimeZone2.getOffset(readableInstant6);
        java.lang.String str8 = dateTimeZone2.toString();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, dateTimeZone2);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = mutableDateTime9.getRoundingField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 600000 + "'", int7 == 600000);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:10" + "'", str8.equals("+00:10"));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNull(dateTimeField11);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.hourOfHalfday();
        org.joda.time.DurationField durationField6 = buddhistChronology4.days();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7, (-292279537));
        java.lang.String str10 = skipDateTimeField9.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[hourOfDay]" + "'", str10.equals("DateTimeField[hourOfDay]"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.weekyears();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration5 = null;
        mutableDateTime3.add(readableDuration5, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime3.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set(0);
        int int11 = mutableDateTime10.getYearOfEra();
        mutableDateTime10.addMillis(36600035);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime10.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime15 = property14.roundHalfFloor();
        boolean boolean16 = julianChronology0.equals((java.lang.Object) mutableDateTime15);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1427 + "'", int11 == 1427);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.set(0);
        int int9 = mutableDateTime8.getYearOfEra();
        mutableDateTime8.setYear(0);
        mutableDateTime8.setHourOfDay(2);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime8.millisOfSecond();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1427 + "'", int9 == 1427);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipDateTimeField4.getAsShortText(0L, locale10);
        int int12 = skipDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268512) + "'", int12 == (-292268512));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = mutableDateTime1.toCalendar(locale3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.hourOfHalfday();
        org.joda.time.DurationField durationField7 = buddhistChronology5.days();
        boolean boolean8 = mutableDateTime1.equals((java.lang.Object) durationField7);
        org.joda.time.Instant instant9 = mutableDateTime1.toInstant();
        try {
            mutableDateTime1.setHourOfDay(600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 600000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T08:01:01.035 (7)");
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        mutableDateTime2.setTime(readableInstant3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.hourOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology3, dateTimeField5, 0);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        int int9 = mutableDateTime2.get(dateTimeField8);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = mutableDateTime1.toCalendar(locale3);
        mutableDateTime1.addMinutes(36600035);
        int int7 = mutableDateTime1.getMillisOfSecond();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime1.yearOfEra();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfEven();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property2.getAsShortText(locale4);
        org.joda.time.DurationField durationField6 = property2.getLeapDurationField();
        org.joda.time.MutableDateTime mutableDateTime8 = property2.addWrapField((int) (short) 10);
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = property2.set("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYearOfCentury(6);
        org.joda.time.DateTime dateTime4 = dateTime0.withCenturyOfEra(85);
        org.joda.time.DateTime dateTime6 = dateTime0.minusWeeks((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        int int2 = mutableDateTime1.getEra();
        mutableDateTime1.addHours((-1));
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        mutableDateTime1.add(readablePeriod5);
        mutableDateTime1.addSeconds(0);
        mutableDateTime1.setDate((-28857599900L));
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology3 = instant2.getChronology();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (-292268511), chronology3, locale4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) ' ');
        long long13 = offsetDateTimeField11.roundHalfFloor((long) (short) 1);
        long long16 = offsetDateTimeField11.addWrapField((long) (short) 100, 0);
        int int17 = offsetDateTimeField11.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology6, (org.joda.time.DateTimeField) offsetDateTimeField11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) ' ');
        long long24 = offsetDateTimeField22.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField22.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField11, dateTimeFieldType25);
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology29.hourOfHalfday();
        org.joda.time.DurationField durationField31 = buddhistChronology29.days();
        java.util.Locale locale32 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology29, locale32, (java.lang.Integer) 2019);
        java.util.Locale locale35 = dateTimeParserBucket34.getLocale();
        dateTimeParserBucket5.saveField(dateTimeFieldType25, "AD", locale35);
        java.lang.String str39 = defaultNameProvider0.getShortName(locale35, "33", "1427-W06-5T00:00:00+00:10");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-600000L) + "'", long13 == (-600000L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 33 + "'", int17 == 33);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-600000L) + "'", long24 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(locale35);
        org.junit.Assert.assertNull(str39);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
        long long8 = offsetDateTimeField3.roundHalfFloor((-28857599900L));
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime11 = instant10.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration13 = null;
        mutableDateTime11.add(readableDuration13, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime11.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime18 = property16.set(0);
        int int19 = mutableDateTime18.getYearOfEra();
        org.joda.time.ReadableInstant readableInstant20 = null;
        boolean boolean21 = mutableDateTime18.isBefore(readableInstant20);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime18.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime24 = property22.addWrapField((int) ' ');
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.hourOfHalfday();
        org.joda.time.DurationField durationField29 = buddhistChronology27.days();
        java.util.Locale locale30 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology27, locale30, (java.lang.Integer) 2019);
        java.util.Locale locale33 = dateTimeParserBucket32.getLocale();
        org.joda.time.MutableDateTime mutableDateTime34 = property22.set("4", locale33);
        java.lang.String str35 = offsetDateTimeField3.getAsShortText(8, locale33);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28858200000L) + "'", long8 == (-28858200000L));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1427 + "'", int19 == 1427);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "8" + "'", str35.equals("8"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone2);
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTimeISO();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) ' ');
        long long13 = offsetDateTimeField11.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        boolean boolean15 = dateTime7.isSupported(dateTimeFieldType14);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField16 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-600000L) + "'", long13 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField3.getType();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider9 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology12 = instant11.getChronology();
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) (-292268511), chronology12, locale13);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) ' ');
        long long22 = offsetDateTimeField20.roundHalfFloor((long) (short) 1);
        long long25 = offsetDateTimeField20.addWrapField((long) (short) 100, 0);
        int int26 = offsetDateTimeField20.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology15, (org.joda.time.DateTimeField) offsetDateTimeField20);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) ' ');
        long long33 = offsetDateTimeField31.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = offsetDateTimeField31.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField20, dateTimeFieldType34);
        org.joda.time.chrono.BuddhistChronology buddhistChronology38 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = buddhistChronology38.hourOfHalfday();
        org.joda.time.DurationField durationField40 = buddhistChronology38.days();
        java.util.Locale locale41 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket43 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology38, locale41, (java.lang.Integer) 2019);
        java.util.Locale locale44 = dateTimeParserBucket43.getLocale();
        dateTimeParserBucket14.saveField(dateTimeFieldType34, "AD", locale44);
        java.lang.String str48 = defaultNameProvider9.getShortName(locale44, "33", "1427-W06-5T00:00:00+00:10");
        try {
            long long49 = offsetDateTimeField3.set((long) (byte) 0, "+00:10", locale44);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:10\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-600000L) + "'", long22 == (-600000L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 33 + "'", int26 == 33);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-600000L) + "'", long33 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(buddhistChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(locale44);
        org.junit.Assert.assertNull(str48);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) ' ');
        long long7 = offsetDateTimeField5.roundHalfFloor((long) (short) 1);
        long long10 = offsetDateTimeField5.addWrapField((long) (short) 100, 0);
        int int11 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField5);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider14 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) ' ');
        long long24 = offsetDateTimeField22.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, (org.joda.time.DateTimeField) offsetDateTimeField22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.hourOfHalfday();
        org.joda.time.DurationField durationField30 = buddhistChronology28.days();
        java.util.Locale locale31 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology28, locale31, (java.lang.Integer) 2019);
        java.util.Locale locale34 = dateTimeParserBucket33.getLocale();
        java.lang.String str35 = skipDateTimeField25.getAsText((long) (short) -1, locale34);
        java.lang.String str38 = defaultNameProvider14.getName(locale34, "600000", "org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported");
        java.lang.String str39 = offsetDateTimeField5.getAsShortText((int) (short) 1, locale34);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime41 = org.joda.time.MutableDateTime.now(dateTimeZone40);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40);
        org.joda.time.Instant instant43 = gJChronology42.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology44 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology45.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology44, dateTimeField46, 0);
        org.joda.time.ReadablePartial readablePartial49 = null;
        int int50 = skipDateTimeField48.getMaximumValue(readablePartial49);
        boolean boolean52 = skipDateTimeField48.isLeap((long) 'a');
        boolean boolean53 = skipDateTimeField48.isLenient();
        long long55 = skipDateTimeField48.roundCeiling((long) 600000);
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime58 = org.joda.time.MutableDateTime.now(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) 100, dateTimeZone57);
        org.joda.time.DateTime.Property property60 = dateTime59.era();
        org.joda.time.DateTime dateTime61 = dateTime59.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime63 = dateTime61.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime65 = dateTime63.plusDays((int) (byte) -1);
        long long66 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime65);
        org.joda.time.LocalDate localDate67 = dateTime65.toLocalDate();
        boolean boolean68 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate67);
        java.util.Locale locale69 = null;
        java.lang.String str70 = skipDateTimeField48.getAsText((org.joda.time.ReadablePartial) localDate67, locale69);
        long long72 = gJChronology42.set((org.joda.time.ReadablePartial) localDate67, 85800000L);
        int int73 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDate67);
        int int74 = offsetDateTimeField5.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-600000L) + "'", long7 == (-600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-600000L) + "'", long24 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(locale34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "33" + "'", str35.equals("33"));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(instant43);
        org.junit.Assert.assertNotNull(buddhistChronology44);
        org.junit.Assert.assertNotNull(buddhistChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 292279536 + "'", int50 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 31794600000L + "'", long55 == 31794600000L);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(mutableDateTime58);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2592000100L + "'", long66 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1970" + "'", str70.equals("1970"));
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 2591400000L + "'", long72 == 2591400000L);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 33 + "'", int73 == 33);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 33 + "'", int74 == 33);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        int int2 = mutableDateTime1.getEra();
        mutableDateTime1.addHours((-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.hourOfHalfday();
        org.joda.time.DurationField durationField7 = buddhistChronology5.days();
        mutableDateTime1.setChronology((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology5.millisOfSecond();
        java.lang.String str10 = buddhistChronology5.toString();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "BuddhistChronology[+00:10]" + "'", str10.equals("BuddhistChronology[+00:10]"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        long long10 = skipDateTimeField4.roundHalfFloor(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) ' ');
        long long16 = offsetDateTimeField14.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 100, dateTimeZone18);
        org.joda.time.DateTime.Property property21 = dateTime20.era();
        org.joda.time.DateTime dateTime22 = dateTime20.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime24 = dateTime22.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime26 = dateTime24.plusDays((int) (byte) -1);
        long long27 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.LocalDate localDate28 = dateTime26.toLocalDate();
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDate28, 600000, locale30);
        int int32 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate28);
        java.lang.String str33 = skipDateTimeField4.getName();
        org.joda.time.DateTimeField dateTimeField34 = skipDateTimeField4.getWrappedField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) ' ');
        long long41 = offsetDateTimeField39.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime44 = org.joda.time.MutableDateTime.now(dateTimeZone43);
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) 100, dateTimeZone43);
        org.joda.time.DateTime.Property property46 = dateTime45.era();
        org.joda.time.DateTime dateTime47 = dateTime45.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime49 = dateTime47.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime51 = dateTime49.plusDays((int) (byte) -1);
        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
        org.joda.time.LocalDate localDate53 = dateTime51.toLocalDate();
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField39.getAsText((org.joda.time.ReadablePartial) localDate53, 600000, locale55);
        java.lang.String str57 = dateTimeFormatter35.print((org.joda.time.ReadablePartial) localDate53);
        int[] intArray58 = null;
        int int59 = skipDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate53, intArray58);
        int int61 = skipDateTimeField4.get((long) 59);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259800000L) + "'", long10 == (-259800000L));
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-600000L) + "'", long16 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2592000100L + "'", long27 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "600000" + "'", str31.equals("600000"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-292268511) + "'", int32 == (-292268511));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "weekyear" + "'", str33.equals("weekyear"));
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-600000L) + "'", long41 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(mutableDateTime44);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 2592000100L + "'", long52 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "600000" + "'", str56.equals("600000"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "1970-01" + "'", str57.equals("1970-01"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 292279536 + "'", int59 == 292279536);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2513 + "'", int61 == 2513);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.String str2 = dateTimeFormatter0.print((-77661763621990L));
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 100, dateTimeZone5);
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime dateTime9 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime11 = dateTime9.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime13 = dateTime11.plusDays((int) (byte) -1);
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-0492W534" + "'", str2.equals("-0492W534"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10, 3, (int) (byte) 100, 3, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime3 = dateTime0.minusMonths((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = buddhistChronology0.days();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Instant instant4 = dateTime3.toInstant();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, (int) (short) 10);
        boolean boolean9 = dateTime7.isEqual((long) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime7.withHourOfDay(0);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withMonthOfYear(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 2019);
        boolean boolean7 = offsetDateTimeField3.isLeap(199208213913000000L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant3.minus(readableDuration4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        int int2 = mutableDateTime1.getEra();
        mutableDateTime1.addHours((-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.hourOfHalfday();
        org.joda.time.DurationField durationField7 = buddhistChronology5.days();
        mutableDateTime1.setChronology((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DurationField durationField9 = buddhistChronology5.hours();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField9, durationFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        int int5 = property4.getLeapAmount();
        org.joda.time.DateTime dateTime7 = property4.addWrapFieldToCopy((-292279537));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        int int2 = mutableDateTime1.getEra();
        mutableDateTime1.addHours((-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.hourOfHalfday();
        org.joda.time.DurationField durationField7 = buddhistChronology5.days();
        mutableDateTime1.setChronology((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime1.dayOfWeek();
        java.lang.String str10 = property9.toString();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[dayOfWeek]" + "'", str10.equals("Property[dayOfWeek]"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withPivotYear((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        int int3 = dateTime2.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.ReadablePartial readablePartial4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.weekyear();
        long long13 = buddhistChronology6.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 100, dateTimeZone16);
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime20 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime24 = dateTime22.plusDays((int) (byte) -1);
        long long25 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.LocalDate localDate26 = dateTime24.toLocalDate();
        int[] intArray28 = buddhistChronology6.get((org.joda.time.ReadablePartial) localDate26, (long) 100);
        int[] intArray30 = offsetDateTimeField3.add(readablePartial4, 0, intArray28, 0);
        java.lang.String str32 = offsetDateTimeField3.getAsText((long) 398);
        long long34 = offsetDateTimeField3.roundCeiling((long) (short) 100);
        long long36 = offsetDateTimeField3.roundHalfEven((long) 40);
        int int38 = offsetDateTimeField3.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-538965L) + "'", long13 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2592000100L + "'", long25 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "33" + "'", str32.equals("33"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 85800000L + "'", long34 == 85800000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-600000L) + "'", long36 == (-600000L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2019);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.minusDays(0);
        int int15 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        java.lang.String str17 = gJChronology16.toString();
        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology16.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Chronology chronology20 = iSOChronology19.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 600000 + "'", int6 == 600000);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 600000 + "'", int15 == 600000);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GJChronology[+00:10]" + "'", str17.equals("GJChronology[+00:10]"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.halfdayOfDay();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology3, dateTimeField5, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology8, dateTimeField10, 0);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = skipDateTimeField12.getMaximumValue(readablePartial13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 100, dateTimeZone16);
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime20 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime22 = dateTime20.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime24 = dateTime22.plusDays((int) (byte) -1);
        long long25 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.LocalDate localDate26 = dateTime24.toLocalDate();
        boolean boolean27 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate26);
        int int28 = skipDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDate26);
        int int29 = skipDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) localDate26);
        long long31 = buddhistChronology0.set((org.joda.time.ReadablePartial) localDate26, 0L);
        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology0.weekOfWeekyear();
        org.joda.time.tz.NameProvider nameProvider33 = org.joda.time.DateTimeZone.getNameProvider();
        boolean boolean34 = buddhistChronology0.equals((java.lang.Object) nameProvider33);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 292279536 + "'", int14 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2592000100L + "'", long25 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 292279536 + "'", int28 == 292279536);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292268511) + "'", int29 == (-292268511));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-17132083200000L) + "'", long31 == (-17132083200000L));
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(nameProvider33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        long long10 = skipDateTimeField4.roundHalfFloor(0L);
        long long12 = skipDateTimeField4.roundHalfFloor(170122200007L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259800000L) + "'", long10 == (-259800000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 157593000000L + "'", long12 == 157593000000L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        boolean boolean9 = skipDateTimeField4.isLenient();
        int int11 = skipDateTimeField4.get((long) 59);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 100, dateTimeZone13);
        org.joda.time.DateTime.Property property16 = dateTime15.era();
        org.joda.time.DateTime dateTime17 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime17.minusDays(0);
        org.joda.time.DateTime dateTime21 = dateTime17.withMillis((long) (-292268511));
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology22.weekyear();
        long long29 = buddhistChronology22.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology22.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime33 = org.joda.time.MutableDateTime.now(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) 100, dateTimeZone32);
        org.joda.time.DateTime.Property property35 = dateTime34.era();
        org.joda.time.DateTime dateTime36 = dateTime34.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime38 = dateTime36.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime40 = dateTime38.plusDays((int) (byte) -1);
        long long41 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.LocalDate localDate42 = dateTime40.toLocalDate();
        int[] intArray44 = buddhistChronology22.get((org.joda.time.ReadablePartial) localDate42, (long) 100);
        org.joda.time.DateTime dateTime45 = dateTime21.withFields((org.joda.time.ReadablePartial) localDate42);
        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology47.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        org.joda.time.ReadablePartial readablePartial51 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField54 = buddhistChronology53.weekyear();
        long long60 = buddhistChronology53.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField61 = buddhistChronology53.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime64 = org.joda.time.MutableDateTime.now(dateTimeZone63);
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((long) 100, dateTimeZone63);
        org.joda.time.DateTime.Property property66 = dateTime65.era();
        org.joda.time.DateTime dateTime67 = dateTime65.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime69 = dateTime67.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime71 = dateTime69.plusDays((int) (byte) -1);
        long long72 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime71);
        org.joda.time.LocalDate localDate73 = dateTime71.toLocalDate();
        int[] intArray75 = buddhistChronology53.get((org.joda.time.ReadablePartial) localDate73, (long) 100);
        int[] intArray77 = offsetDateTimeField50.add(readablePartial51, 0, intArray75, 0);
        int[] intArray79 = skipDateTimeField4.add((org.joda.time.ReadablePartial) localDate42, 0, intArray75, (-1));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2513 + "'", int11 == 2513);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-538965L) + "'", long29 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2592000100L + "'", long41 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(buddhistChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(buddhistChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-538965L) + "'", long60 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(mutableDateTime64);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 2592000100L + "'", long72 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray79);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        org.joda.time.DateTime dateTime11 = dateTime9.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = dateTime11.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime15 = dateTime13.plusDays((int) (byte) -1);
        long long16 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = dateTime15.toLocalDate();
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate17, 600000, locale19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField3.getAsShortText(0, locale22);
        long long26 = offsetDateTimeField3.add((-25747800000L), 9);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2592000100L + "'", long16 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "600000" + "'", str20.equals("600000"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-24970200000L) + "'", long26 == (-24970200000L));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) ' ');
        long long7 = offsetDateTimeField5.roundHalfFloor((long) (short) 1);
        long long10 = offsetDateTimeField5.addWrapField((long) (short) 100, 0);
        int int11 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField5);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider14 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) ' ');
        long long24 = offsetDateTimeField22.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, (org.joda.time.DateTimeField) offsetDateTimeField22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.hourOfHalfday();
        org.joda.time.DurationField durationField30 = buddhistChronology28.days();
        java.util.Locale locale31 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology28, locale31, (java.lang.Integer) 2019);
        java.util.Locale locale34 = dateTimeParserBucket33.getLocale();
        java.lang.String str35 = skipDateTimeField25.getAsText((long) (short) -1, locale34);
        java.lang.String str38 = defaultNameProvider14.getName(locale34, "600000", "org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported");
        java.lang.String str39 = offsetDateTimeField5.getAsShortText((int) (short) 1, locale34);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) ' ');
        long long45 = offsetDateTimeField43.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = offsetDateTimeField43.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField48 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType46, 9);
        long long50 = remainderDateTimeField48.remainder(0L);
        int int51 = remainderDateTimeField48.getDivisor();
        int int52 = remainderDateTimeField48.getMaximumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-600000L) + "'", long7 == (-600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-600000L) + "'", long24 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(locale34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "33" + "'", str35.equals("33"));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-600000L) + "'", long45 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 600000L + "'", long50 == 600000L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 9 + "'", int51 == 9);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 8 + "'", int52 == 8);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        java.lang.String str5 = property4.getAsText();
        int int6 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime7 = property4.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AD" + "'", str5.equals("AD"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minus(0L);
        org.joda.time.LocalTime localTime3 = dateTime2.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localTime3);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.hourOfHalfday();
        org.joda.time.DurationField durationField6 = buddhistChronology4.days();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7, (-292279537));
        boolean boolean10 = skipDateTimeField9.isSupported();
        int int13 = skipDateTimeField9.getDifference((long) (byte) -1, (long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        long long7 = buddhistChronology0.getDateTimeMillis((long) 'a', 0, (int) (short) 1, 1, (int) '#');
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology0.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        mutableDateTime9.setZone(dateTimeZone10);
        org.joda.time.ReadableInstant readableInstant14 = null;
        int int15 = dateTimeZone10.getOffset(readableInstant14);
        java.lang.String str16 = dateTimeZone10.toString();
        org.joda.time.Chronology chronology17 = buddhistChronology0.withZone(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-538965L) + "'", long7 == (-538965L));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 600000 + "'", int15 == 600000);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:10" + "'", str16.equals("+00:10"));
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone2);
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime6 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTimeISO();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) ' ');
        long long13 = offsetDateTimeField11.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField11.getType();
        boolean boolean15 = dateTime7.isSupported(dateTimeFieldType14);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType14, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-600000L) + "'", long13 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        long long5 = dateTimeZone0.convertLocalToUTC(864000001L, false);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 863400001L + "'", long5 == 863400001L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 1427, 33);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 47091L + "'", long2 == 47091L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("AD", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"AD/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 600007L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 600, (org.joda.time.Chronology) buddhistChronology1, locale4, (java.lang.Integer) 2513);
        dateTimeParserBucket6.setOffset((java.lang.Integer) 1);
        java.lang.Integer int9 = dateTimeParserBucket6.getPivotYear();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2513 + "'", int9.equals(2513));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DurationField durationField7 = skipDateTimeField4.getRangeDurationField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.dayOfYear();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology8.halfdayOfDay();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology11, dateTimeField13, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology16, dateTimeField18, 0);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int int22 = skipDateTimeField20.getMaximumValue(readablePartial21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 100, dateTimeZone24);
        org.joda.time.DateTime.Property property27 = dateTime26.era();
        org.joda.time.DateTime dateTime28 = dateTime26.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime30 = dateTime28.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime32 = dateTime30.plusDays((int) (byte) -1);
        long long33 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.LocalDate localDate34 = dateTime32.toLocalDate();
        boolean boolean35 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate34);
        int int36 = skipDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDate34);
        int int37 = skipDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate34);
        long long39 = buddhistChronology8.set((org.joda.time.ReadablePartial) localDate34, 0L);
        int int40 = skipDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate34);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292279536 + "'", int22 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2592000100L + "'", long33 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 292279536 + "'", int36 == 292279536);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-292268511) + "'", int37 == (-292268511));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-17132083200000L) + "'", long39 == (-17132083200000L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 292279536 + "'", int40 == 292279536);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((int) (byte) -1);
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        boolean boolean11 = dateTime9.isAfterNow();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2592000100L + "'", long10 == 2592000100L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) ' ');
        long long7 = offsetDateTimeField5.roundHalfFloor((long) (short) 1);
        long long10 = offsetDateTimeField5.addWrapField((long) (short) 100, 0);
        int int11 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField5);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider14 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) ' ');
        long long24 = offsetDateTimeField22.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, (org.joda.time.DateTimeField) offsetDateTimeField22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.hourOfHalfday();
        org.joda.time.DurationField durationField30 = buddhistChronology28.days();
        java.util.Locale locale31 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology28, locale31, (java.lang.Integer) 2019);
        java.util.Locale locale34 = dateTimeParserBucket33.getLocale();
        java.lang.String str35 = skipDateTimeField25.getAsText((long) (short) -1, locale34);
        java.lang.String str38 = defaultNameProvider14.getName(locale34, "600000", "org.joda.time.IllegalFieldValueException: Value \"17\" for 17 is not supported");
        java.lang.String str39 = offsetDateTimeField5.getAsShortText((int) (short) 1, locale34);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) ' ');
        long long45 = offsetDateTimeField43.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = offsetDateTimeField43.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField48 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType46, 9);
        long long50 = remainderDateTimeField48.remainder((long) 2513);
        long long52 = remainderDateTimeField48.roundCeiling((long) (-1));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-600000L) + "'", long7 == (-600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-600000L) + "'", long24 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(locale34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "33" + "'", str35.equals("33"));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-600000L) + "'", long45 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 602513L + "'", long50 == 602513L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 85800000L + "'", long52 == 85800000L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 6);
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology1.days();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology1, locale4, (java.lang.Integer) 2019);
        dateTimeParserBucket6.setPivotYear((java.lang.Integer) 1970);
        dateTimeParserBucket6.setOffset(0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        boolean boolean9 = skipDateTimeField4.isLenient();
        long long11 = skipDateTimeField4.roundCeiling((long) 600000);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 100, dateTimeZone13);
        org.joda.time.DateTime.Property property16 = dateTime15.era();
        org.joda.time.DateTime dateTime17 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime21 = dateTime19.plusDays((int) (byte) -1);
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.LocalDate localDate23 = dateTime21.toLocalDate();
        boolean boolean24 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate23);
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate23, locale25);
        java.lang.String str27 = skipDateTimeField4.getName();
        long long29 = skipDateTimeField4.roundFloor(2591400000L);
        int int30 = skipDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31794600000L + "'", long11 == 31794600000L);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2592000100L + "'", long22 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970" + "'", str26.equals("1970"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "weekyear" + "'", str27.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-259800000L) + "'", long29 == (-259800000L));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-292268512) + "'", int30 == (-292268512));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
        int int2 = property1.get();
        org.joda.time.DateTime dateTime4 = property1.addToCopy(33);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40 + "'", int2 == 40);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        org.joda.time.DateTime dateTime11 = dateTime9.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = dateTime11.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime15 = dateTime13.plusDays((int) (byte) -1);
        long long16 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.LocalDate localDate17 = dateTime15.toLocalDate();
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate17, 600000, locale19);
        long long22 = offsetDateTimeField3.roundHalfEven(2592000100L);
        long long24 = offsetDateTimeField3.roundHalfFloor(864000001L);
        long long27 = offsetDateTimeField3.add(0L, (long) 600000);
        long long29 = offsetDateTimeField3.remainder((long) 7);
        long long32 = offsetDateTimeField3.addWrapField((long) (-116303), 2019);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-600000L) + "'", long5 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2592000100L + "'", long16 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "600000" + "'", str20.equals("600000"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2591400000L + "'", long22 == 2591400000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 863400000L + "'", long24 == 863400000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 51840000000000L + "'", long27 == 51840000000000L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 600007L + "'", long29 == 600007L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 16329483697L + "'", long32 == 16329483697L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology1.days();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology1, locale4, (java.lang.Integer) 2019);
        org.joda.time.DateTimeField dateTimeField7 = null;
        dateTimeParserBucket6.saveField(dateTimeField7, 8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) ' ');
        long long15 = offsetDateTimeField13.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField13.getType();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean21 = iSOChronology19.equals((java.lang.Object) "");
        java.util.Locale locale22 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket((long) 1, (org.joda.time.Chronology) iSOChronology19, locale22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (int) ' ');
        long long29 = offsetDateTimeField27.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField27.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 2592000100L, "hi!");
        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology35, dateTimeField37, 0);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = skipDateTimeField39.getMaximumValue(readablePartial40);
        boolean boolean43 = skipDateTimeField39.isLeap((long) 'a');
        boolean boolean44 = skipDateTimeField39.isLenient();
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Instant instant48 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology49 = instant48.getChronology();
        java.util.Locale locale50 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket51 = new org.joda.time.format.DateTimeParserBucket((long) (-292268511), chronology49, locale50);
        org.joda.time.chrono.BuddhistChronology buddhistChronology52 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = buddhistChronology52.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) ' ');
        long long59 = offsetDateTimeField57.roundHalfFloor((long) (short) 1);
        long long62 = offsetDateTimeField57.addWrapField((long) (short) 100, 0);
        int int63 = offsetDateTimeField57.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField64 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology52, (org.joda.time.DateTimeField) offsetDateTimeField57);
        org.joda.time.chrono.BuddhistChronology buddhistChronology65 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField66 = buddhistChronology65.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, (int) ' ');
        long long70 = offsetDateTimeField68.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType71 = offsetDateTimeField68.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField57, dateTimeFieldType71);
        org.joda.time.chrono.BuddhistChronology buddhistChronology75 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField76 = buddhistChronology75.hourOfHalfday();
        org.joda.time.DurationField durationField77 = buddhistChronology75.days();
        java.util.Locale locale78 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket80 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology75, locale78, (java.lang.Integer) 2019);
        java.util.Locale locale81 = dateTimeParserBucket80.getLocale();
        dateTimeParserBucket51.saveField(dateTimeFieldType71, "AD", locale81);
        java.lang.String str83 = skipDateTimeField39.getAsText(readablePartial45, 1969, locale81);
        dateTimeParserBucket23.saveField(dateTimeFieldType30, "GregorianChronology[+00:10]", locale81);
        dateTimeParserBucket6.saveField(dateTimeFieldType16, "", locale81);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-600000L) + "'", long15 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-600000L) + "'", long29 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(buddhistChronology35);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 292279536 + "'", int41 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(buddhistChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-600000L) + "'", long59 == (-600000L));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 100L + "'", long62 == 100L);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 33 + "'", int63 == 33);
        org.junit.Assert.assertNotNull(buddhistChronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-600000L) + "'", long70 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType71);
        org.junit.Assert.assertNotNull(buddhistChronology75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertNotNull(locale81);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "1969" + "'", str83.equals("1969"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = buddhistChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, dateTimeZone7);
        try {
            long long13 = zonedChronology8.getDateTimeMillis((int) (byte) -1, 4, (int) ' ', 292279536);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.DurationField durationField6 = iSOChronology4.months();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0L, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DurationField durationField8 = iSOChronology4.minutes();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (byte) -1);
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.LocalDate localDate18 = dateTime16.toLocalDate();
        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate18);
        int int20 = skipDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate18);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) skipDateTimeField4, (java.lang.Object) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) ' ');
        long long28 = offsetDateTimeField26.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField26.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType29, 2513);
        long long33 = dividedDateTimeField31.roundFloor(1L);
        boolean boolean35 = dividedDateTimeField31.isLeap((-259800000L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2592000100L + "'", long17 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292279536 + "'", int20 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-600000L) + "'", long28 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-259800000L) + "'", long33 == (-259800000L));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.set(0);
        int int9 = mutableDateTime8.getYearOfEra();
        org.joda.time.Chronology chronology10 = null;
        mutableDateTime8.setChronology(chronology10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology12, dateTimeField14, 0);
        long long19 = skipDateTimeField16.set(10L, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipDateTimeField16.getType();
        mutableDateTime8.set(dateTimeFieldType20, (int) (short) 10);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1427 + "'", int9 == 1427);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-77661763199990L) + "'", long19 == (-77661763199990L));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfEven();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property2.getAsShortText(locale4);
        org.joda.time.DurationField durationField6 = property2.getLeapDurationField();
        org.joda.time.MutableDateTime mutableDateTime8 = property2.add((-259800000L));
        mutableDateTime8.addDays(0);
        mutableDateTime8.setWeekyear((int) (short) 10);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime13 = dateTime10.minusMillis(2);
        org.joda.time.DateTime dateTime15 = dateTime13.withCenturyOfEra(0);
        org.joda.time.LocalDateTime localDateTime16 = dateTime15.toLocalDateTime();
        boolean boolean17 = dateTimeZone1.isLocalDateTimeGap(localDateTime16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 100, dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTime();
        int int23 = dateTime22.getYear();
        org.joda.time.DateTime dateTime25 = dateTime22.minusYears((int) (byte) 10);
        try {
            org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime22, (-116303));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -116303");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 600000 + "'", int6 == 600000);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = instant0.withMillis((long) '#');
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) instant2);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (byte) 1, dateTimeZone6);
        int int8 = dateTime4.compareTo((org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime4.toDateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.longTime();
        java.lang.Integer int15 = dateTimeFormatter14.getPivotYear();
        org.joda.time.Chronology chronology16 = dateTimeFormatter14.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter14.withOffsetParsed();
        java.lang.String str18 = dateTime4.toString(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNull(int15);
        org.junit.Assert.assertNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "12:10:00 AM +00:10" + "'", str18.equals("12:10:00 AM +00:10"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
        int int7 = property6.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) ' ');
        long long6 = offsetDateTimeField4.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime12 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (byte) -1);
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.LocalDate localDate18 = dateTime16.toLocalDate();
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate18, 600000, locale20);
        java.lang.String str22 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate18);
        java.lang.Appendable appendable23 = null;
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime26 = org.joda.time.MutableDateTime.now(dateTimeZone25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        mutableDateTime24.setZone(dateTimeZone25);
        org.joda.time.ReadableInstant readableInstant29 = null;
        int int30 = dateTimeZone25.getOffset(readableInstant29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime33 = org.joda.time.MutableDateTime.now(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) 100, dateTimeZone32);
        org.joda.time.DateTime.Property property35 = dateTime34.era();
        org.joda.time.DateTime dateTime36 = dateTime34.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime38 = dateTime36.minusDays(0);
        int int39 = dateTimeZone25.getOffset((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime43 = org.joda.time.MutableDateTime.now(dateTimeZone42);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) 100, dateTimeZone42);
        org.joda.time.DateTime dateTime45 = dateTime44.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) (short) 10);
        org.joda.time.LocalDateTime localDateTime49 = dateTime48.toLocalDateTime();
        boolean boolean50 = dateTimeZone25.isLocalDateTimeGap(localDateTime49);
        try {
            dateTimeFormatter0.printTo(appendable23, (org.joda.time.ReadablePartial) localDateTime49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-600000L) + "'", long6 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2592000100L + "'", long17 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "600000" + "'", str21.equals("600000"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970-01" + "'", str22.equals("1970-01"));
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 600000 + "'", int30 == 600000);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 600000 + "'", int39 == 600000);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(mutableDateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(localDateTime49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYearOfCentury(6);
        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(36600035);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.hourOfHalfday();
        org.joda.time.DurationField durationField7 = buddhistChronology5.days();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology5.hourOfDay();
        org.joda.time.Chronology chronology9 = buddhistChronology5.withUTC();
        org.joda.time.DateTime dateTime10 = dateTime0.toDateTime((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(5);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.weekyears();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        mutableDateTime7.setZone(dateTimeZone8);
        org.joda.time.ReadableInstant readableInstant12 = null;
        int int13 = dateTimeZone8.getOffset(readableInstant12);
        java.lang.String str14 = dateTimeZone8.toString();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime(0L, dateTimeZone8);
        org.joda.time.Chronology chronology16 = buddhistChronology2.withZone(dateTimeZone8);
        boolean boolean17 = julianChronology0.equals((java.lang.Object) dateTimeZone8);
        boolean boolean19 = julianChronology0.equals((java.lang.Object) 9);
        try {
            long long27 = julianChronology0.getDateTimeMillis(0, (int) ' ', 0, (-292268511), 0, 7, 40);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292268511 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 600000 + "'", int13 == 600000);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:10" + "'", str14.equals("+00:10"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(0);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime4 = dateTime2.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-17132083200000L) + "'", long3 == (-17132083200000L));
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, 600000, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 600, (org.joda.time.Chronology) buddhistChronology1, locale4, (java.lang.Integer) 2513);
        dateTimeParserBucket6.setOffset((java.lang.Integer) 1);
        org.joda.time.Chronology chronology9 = dateTimeParserBucket6.getChronology();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        boolean boolean5 = offsetDateTimeField3.isLeap((long) 2019);
        int int7 = offsetDateTimeField3.getLeapAmount(2591400000L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 6);
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTimeISO();
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        long long12 = offsetDateTimeField10.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField10.getType();
        boolean boolean14 = dateTime6.isSupported(dateTimeFieldType13);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "ISOChronology[UTC]");
        java.lang.Throwable[] throwableArray19 = illegalFieldValueException18.getSuppressed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-600000L) + "'", long12 == (-600000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = skipDateTimeField4.getMaximumValue(readablePartial5);
        boolean boolean8 = skipDateTimeField4.isLeap((long) 'a');
        boolean boolean9 = skipDateTimeField4.isLenient();
        int int11 = skipDateTimeField4.getMaximumValue((long) 59);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology12, dateTimeField14, 0);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = skipDateTimeField16.getMaximumValue(readablePartial17);
        boolean boolean20 = skipDateTimeField16.isLeap((long) 'a');
        boolean boolean21 = skipDateTimeField16.isLenient();
        long long23 = skipDateTimeField16.roundCeiling((long) 600000);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime26 = org.joda.time.MutableDateTime.now(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 100, dateTimeZone25);
        org.joda.time.DateTime.Property property28 = dateTime27.era();
        org.joda.time.DateTime dateTime29 = dateTime27.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime31 = dateTime29.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime33 = dateTime31.plusDays((int) (byte) -1);
        long long34 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.LocalDate localDate35 = dateTime33.toLocalDate();
        boolean boolean36 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate35);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate35, locale37);
        int int39 = skipDateTimeField16.getMinimumValue();
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology40, dateTimeField42, 0);
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = skipDateTimeField44.getMaximumValue(readablePartial45);
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime49 = org.joda.time.MutableDateTime.now(dateTimeZone48);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) 100, dateTimeZone48);
        org.joda.time.DateTime.Property property51 = dateTime50.era();
        org.joda.time.DateTime dateTime52 = dateTime50.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime54 = dateTime52.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime56 = dateTime54.plusDays((int) (byte) -1);
        long long57 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime56);
        org.joda.time.LocalDate localDate58 = dateTime56.toLocalDate();
        boolean boolean59 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate58);
        int int60 = skipDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime63 = org.joda.time.MutableDateTime.now(dateTimeZone62);
        org.joda.time.chrono.GJChronology gJChronology64 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone62);
        org.joda.time.Instant instant65 = gJChronology64.getGregorianCutover();
        org.joda.time.chrono.BuddhistChronology buddhistChronology66 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField67 = buddhistChronology66.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField69 = new org.joda.time.field.OffsetDateTimeField(dateTimeField67, (int) ' ');
        long long71 = offsetDateTimeField69.roundHalfFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField72 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology64, (org.joda.time.DateTimeField) offsetDateTimeField69);
        org.joda.time.chrono.BuddhistChronology buddhistChronology75 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField76 = buddhistChronology75.hourOfHalfday();
        org.joda.time.DurationField durationField77 = buddhistChronology75.days();
        java.util.Locale locale78 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket80 = new org.joda.time.format.DateTimeParserBucket((long) (-292268512), (org.joda.time.Chronology) buddhistChronology75, locale78, (java.lang.Integer) 2019);
        java.util.Locale locale81 = dateTimeParserBucket80.getLocale();
        java.lang.String str82 = skipDateTimeField72.getAsText((long) (short) -1, locale81);
        java.lang.String str83 = skipDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate58, 40, locale81);
        int int84 = skipDateTimeField4.getMaximumTextLength(locale81);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292279536 + "'", int6 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 292279536 + "'", int11 == 292279536);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292279536 + "'", int18 == 292279536);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 31794600000L + "'", long23 == 31794600000L);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2592000100L + "'", long34 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970" + "'", str38.equals("1970"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-292268512) + "'", int39 == (-292268512));
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 292279536 + "'", int46 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2592000100L + "'", long57 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 292279536 + "'", int60 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(mutableDateTime63);
        org.junit.Assert.assertNotNull(gJChronology64);
        org.junit.Assert.assertNotNull(instant65);
        org.junit.Assert.assertNotNull(buddhistChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-600000L) + "'", long71 == (-600000L));
        org.junit.Assert.assertNotNull(buddhistChronology75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertNotNull(locale81);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "33" + "'", str82.equals("33"));
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "40" + "'", str83.equals("40"));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 9 + "'", int84 == 9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField7, 0);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int int11 = skipDateTimeField9.getMaximumValue(readablePartial10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 100, dateTimeZone13);
        org.joda.time.DateTime.Property property16 = dateTime15.era();
        org.joda.time.DateTime dateTime17 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) ' ');
        org.joda.time.DateTime dateTime21 = dateTime19.plusDays((int) (byte) -1);
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.LocalDate localDate23 = dateTime21.toLocalDate();
        boolean boolean24 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate23);
        int int25 = skipDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) localDate23);
        int int26 = skipDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate23);
        long long29 = skipDateTimeField4.getDifferenceAsLong((long) (short) -1, (long) (short) 10);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 292279536 + "'", int11 == 292279536);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2592000100L + "'", long22 == 2592000100L);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 292279536 + "'", int25 == 292279536);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292268511) + "'", int26 == (-292268511));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = dateTime6.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds(0);
        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfSecond(0);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime12.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        try {
            org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(7, 59, 3, 0, (int) '#', (int) (byte) -1, (int) (byte) -1, (org.joda.time.Chronology) gJChronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 100, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime5 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        java.lang.String str9 = property8.getAsShortText();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 100, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        boolean boolean7 = gregorianChronology1.equals((java.lang.Object) dateTime5);
        org.joda.time.Chronology chronology8 = gregorianChronology1.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology8);
    }
}

