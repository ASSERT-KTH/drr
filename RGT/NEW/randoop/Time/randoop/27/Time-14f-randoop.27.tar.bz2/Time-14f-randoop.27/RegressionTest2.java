import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, 14);
        long long17 = offsetDateTimeField15.roundCeiling((long) 21);
        int int18 = offsetDateTimeField15.getMinimumValue();
        int int20 = offsetDateTimeField15.getMinimumValue((long) (-28800000));
        int int21 = offsetDateTimeField15.getOffset();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 14 + "'", int18 == 14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 14 + "'", int20 == 14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 14 + "'", int21 == 14);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withOffsetParsed();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 10);
        int int11 = dateTime10.getSecondOfDay();
        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = dateTime10.plus((long) (short) 100);
        org.joda.time.LocalDateTime localDateTime15 = dateTime10.toLocalDateTime();
        org.joda.time.DateTime dateTime17 = dateTime10.withYearOfEra((int) '#');
        java.lang.String str18 = dateTimeFormatter7.print((org.joda.time.ReadableInstant) dateTime10);
        boolean boolean19 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime10);
        int int20 = dateTime10.getDayOfYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str18.equals("1969-12-31T16:00:00.010-08:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 365 + "'", int20 == 365);
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test04");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        int int3 = property2.getMinimumValueOverall();
//        org.joda.time.DurationField durationField4 = property2.getDurationField();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(durationField4);
//    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test05");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField3 = property2.getField();
//        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
//        int int7 = dateTime6.getSecondOfDay();
//        int int8 = dateTime6.getSecondOfMinute();
//        java.util.Date date9 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        boolean boolean13 = dateTime6.isBefore(259200052L);
//        int int14 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 10);
//        int int17 = dateTime16.getSecondOfDay();
//        int int18 = dateTime16.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime16.getZone();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getName(28800000L, locale21);
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone26 = gJChronology23.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTime dateTime28 = dateTime4.withZoneRetainFields(dateTimeZone26);
//        org.joda.time.DateTime.Property property29 = dateTime4.minuteOfHour();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600 + "'", int7 == 57600);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 57600 + "'", int17 == 57600);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pacific Standard Time" + "'", str22.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(buddhistChronology27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test06");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField25);
//        org.joda.time.DurationField durationField30 = remainderDateTimeField29.getRangeDurationField();
//        org.joda.time.DurationField durationField31 = remainderDateTimeField29.getRangeDurationField();
//        org.joda.time.DurationFieldType durationFieldType32 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField34 = new org.joda.time.field.ScaledDurationField(durationField31, durationFieldType32, 15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(durationField31);
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusYears((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime1.withMillis((long) (byte) -1);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond(14);
        org.joda.time.DateTime.Property property9 = dateTime6.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime6.millisOfSecond();
        org.joda.time.Instant instant12 = new org.joda.time.Instant((long) 15);
        org.joda.time.Instant instant14 = instant12.minus((-4L));
        org.joda.time.DateTime dateTime15 = instant14.toDateTimeISO();
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) property10, (java.lang.Object) dateTime15);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test08");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        int int2 = dateTime1.getEra();
//        int int3 = dateTime1.getMinuteOfHour();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        java.lang.String str5 = property4.getName();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "minuteOfHour" + "'", str5.equals("minuteOfHour"));
//    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology3.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test10");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
//        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now(dateTimeZone11);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 10);
//        int int16 = dateTime15.getSecondOfDay();
//        int int17 = dateTime15.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone18 = dateTime15.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology19.getZone();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
//        long long25 = dateTimeZone21.adjustOffset((long) (byte) 10, false);
//        long long27 = dateTimeZone11.getMillisKeepLocal(dateTimeZone21, (long) 0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57600 + "'", int16 == 57600);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-9));
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int9 = dateTime8.getMonthOfYear();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10);
        int int12 = dateTime11.getSecondOfDay();
        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.LocalTime localTime14 = dateTime11.toLocalTime();
        org.joda.time.DateTime dateTime15 = dateTime8.withFields((org.joda.time.ReadablePartial) localTime14);
        int int16 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long19 = cachedDateTimeZone17.nextTransition(0L);
        long long21 = cachedDateTimeZone17.previousTransition((long) 12);
        boolean boolean22 = cachedDateTimeZone17.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone23 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        java.lang.String str25 = cachedDateTimeZone23.getNameKey((long) 59);
        boolean boolean26 = cachedDateTimeZone23.isFixed();
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.Chronology chronology30 = julianChronology27.withZone(dateTimeZone28);
        boolean boolean31 = cachedDateTimeZone23.equals((java.lang.Object) julianChronology27);
        java.util.Locale locale33 = null;
        java.lang.String str34 = cachedDateTimeZone23.getName((-16L), locale33);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600 + "'", int12 == 57600);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-9) + "'", int16 == (-9));
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 12L + "'", long21 == 12L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone23);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "-00:00:00.009" + "'", str34.equals("-00:00:00.009"));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        java.lang.String str6 = property5.getAsString();
        org.joda.time.Interval interval7 = property5.toInterval();
        int int8 = property5.getMinimumValue();
        org.joda.time.DateTime dateTime10 = property5.setCopy("52");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "960" + "'", str6.equals("960"));
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "141502.075-0700", "32");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "141536.181-0700", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
        int int7 = dateTime6.getSecondOfDay();
        int int8 = dateTime6.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime6.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(12, (int) (short) 1, 15, (int) (byte) 10, (int) ' ', dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600 + "'", int7 == 57600);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, 14);
        long long17 = offsetDateTimeField15.roundCeiling((long) 21);
        long long19 = offsetDateTimeField15.roundHalfFloor((long) 999);
        boolean boolean21 = offsetDateTimeField15.isLeap((long) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField15.getType();
        long long24 = offsetDateTimeField15.roundFloor((long) 69);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-57600000L) + "'", long24 == (-57600000L));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime5 = dateTime1.plus((long) (short) 100);
        boolean boolean6 = dateTime5.isAfterNow();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((-9));
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int16 = dateTime15.getMonthOfYear();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 10);
        int int19 = dateTime18.getSecondOfDay();
        long long20 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.LocalTime localTime21 = dateTime18.toLocalTime();
        org.joda.time.DateTime dateTime22 = dateTime15.withFields((org.joda.time.ReadablePartial) localTime21);
        int int23 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        long long26 = cachedDateTimeZone24.previousTransition(1324800000L);
        int int28 = cachedDateTimeZone24.getOffset((long) 9);
        long long30 = cachedDateTimeZone24.nextTransition((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime31 = dateTime5.toMutableDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57600 + "'", int19 == 57600);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-9) + "'", int23 == (-9));
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1324800000L + "'", long26 == 1324800000L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-9) + "'", int28 == (-9));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertNotNull(mutableDateTime31);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) (short) 10);
        org.joda.time.Chronology chronology7 = julianChronology0.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.Instant instant9 = dateTime8.toInstant();
        boolean boolean10 = instant9.isAfterNow();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Instant instant12 = instant9.plus(readableDuration11);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(instant12);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.fromDateFields(date3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.append(dateTimeFormatter8);
        org.joda.time.Chronology chronology10 = dateTimeFormatter8.getChronology();
        boolean boolean11 = dateTimeFormatter8.isPrinter();
        java.lang.String str12 = monthDay4.toString(dateTimeFormatter8);
        org.joda.time.MonthDay.Property property13 = monthDay4.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "����W���T������.000" + "'", str12.equals("����W���T������.000"));
        org.junit.Assert.assertNotNull(property13);
    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test20");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTime dateTime5 = dateTime4.withTimeAtStartOfDay();
//        java.util.Date date6 = dateTime5.toDate();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.fromDateFields(date6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfHalfday((int) (short) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.append(dateTimeFormatter11);
//        org.joda.time.Chronology chronology13 = dateTimeFormatter11.getChronology();
//        boolean boolean14 = dateTimeFormatter11.isPrinter();
//        java.lang.String str15 = monthDay7.toString(dateTimeFormatter11);
//        org.joda.time.DateTimeField[] dateTimeFieldArray16 = monthDay7.getFields();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology18, dateTimeField22, (int) (byte) 0);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField24.getAsText((int) '4', locale26);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay();
//        int int32 = monthDay31.getDayOfMonth();
//        org.joda.time.MonthDay.Property property33 = monthDay31.dayOfMonth();
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = property33.getAsShortText(locale34);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = property33.getAsText(locale36);
//        org.joda.time.DateTimeField dateTimeField38 = property33.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property33.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder28.appendText(dateTimeFieldType39);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType39, 2);
//        int int43 = monthDay7.indexOf(dateTimeFieldType39);
//        int int44 = monthDay2.get(dateTimeFieldType39);
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) 10);
//        int int47 = dateTime46.getSecondOfDay();
//        int int48 = dateTime46.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone49 = dateTime46.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49);
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology50.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology50.getZone();
//        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology50.hourOfDay();
//        org.joda.time.DurationField durationField54 = gregorianChronology50.days();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField54);
//        try {
//            long long57 = unsupportedDateTimeField55.roundHalfCeiling(115200000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNull(chronology13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "����W���T������.000" + "'", str15.equals("����W���T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldArray16);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "52" + "'", str27.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "15" + "'", str35.equals("15"));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "15" + "'", str37.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 15 + "'", int44 == 15);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 57600 + "'", int47 == 57600);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(gregorianChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
//    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test21");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        int int30 = dividedDateTimeField25.get(0L);
//        int int32 = dividedDateTimeField25.getMinimumValue((long) 59);
//        int int33 = dividedDateTimeField25.getDivisor();
//        int int36 = dividedDateTimeField25.getDifference((long) (short) 100, (long) (short) 10);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//    }

//    @Test
//    public void test22() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test22");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay();
//        int int10 = monthDay9.getDayOfMonth();
//        org.joda.time.MonthDay.Property property11 = monthDay9.dayOfMonth();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsShortText(locale12);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property11.getAsText(locale14);
//        org.joda.time.DateTimeField dateTimeField16 = property11.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property11.getFieldType();
//        boolean boolean18 = dateTime8.isSupported(dateTimeFieldType17);
//        boolean boolean19 = dateTime1.isSupported(dateTimeFieldType17);
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay();
//        int int21 = monthDay20.getDayOfMonth();
//        org.joda.time.MonthDay.Property property22 = monthDay20.dayOfMonth();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property22.getAsShortText(locale23);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property22.getAsText(locale25);
//        org.joda.time.DateTimeField dateTimeField27 = property22.getField();
//        org.joda.time.DurationField durationField28 = property22.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, durationField28);
//        java.lang.String str30 = unsupportedDateTimeField29.toString();
//        boolean boolean31 = unsupportedDateTimeField29.isSupported();
//        try {
//            long long33 = unsupportedDateTimeField29.roundFloor(100L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "15" + "'", str15.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "15" + "'", str24.equals("15"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "15" + "'", str26.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDateTimeField" + "'", str30.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.withPeriodAdded(readablePeriod9, 0);
        int int12 = dateTime7.getYearOfCentury();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
    }

//    @Test
//    public void test25() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test25");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay();
//        int int10 = monthDay9.getDayOfMonth();
//        org.joda.time.MonthDay.Property property11 = monthDay9.dayOfMonth();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsShortText(locale12);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property11.getAsText(locale14);
//        org.joda.time.DateTimeField dateTimeField16 = property11.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property11.getFieldType();
//        boolean boolean18 = dateTime8.isSupported(dateTimeFieldType17);
//        boolean boolean19 = dateTime1.isSupported(dateTimeFieldType17);
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay();
//        int int21 = monthDay20.getDayOfMonth();
//        org.joda.time.MonthDay.Property property22 = monthDay20.dayOfMonth();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property22.getAsShortText(locale23);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property22.getAsText(locale25);
//        org.joda.time.DateTimeField dateTimeField27 = property22.getField();
//        org.joda.time.DurationField durationField28 = property22.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, durationField28);
//        java.lang.String str30 = unsupportedDateTimeField29.toString();
//        boolean boolean31 = unsupportedDateTimeField29.isSupported();
//        try {
//            long long33 = unsupportedDateTimeField29.roundHalfCeiling((long) (-97));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "15" + "'", str15.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "15" + "'", str24.equals("15"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "15" + "'", str26.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDateTimeField" + "'", str30.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readableDuration9);
        org.joda.time.DateMidnight dateMidnight11 = dateTime7.toDateMidnight();
        boolean boolean12 = dateMidnight11.isEqualNow();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test27");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
//        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
//        int int6 = monthDay5.getDayOfMonth();
//        org.joda.time.MonthDay.Property property7 = monthDay5.dayOfMonth();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsShortText(locale8);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property7.getAsText(locale10);
//        org.joda.time.DateTimeField dateTimeField12 = property7.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property7.getFieldType();
//        boolean boolean14 = dateTime4.isSupported(dateTimeFieldType13);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19);
//        org.joda.time.Instant instant21 = gJChronology20.getGregorianCutover();
//        org.joda.time.DurationField durationField22 = gJChronology20.minutes();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology20);
//        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay();
//        int int25 = monthDay24.getDayOfMonth();
//        org.joda.time.MonthDay.Property property26 = monthDay24.dayOfMonth();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = property26.getAsShortText(locale27);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = property26.getAsText(locale29);
//        org.joda.time.DateTimeField dateTimeField31 = property26.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property26.getFieldType();
//        boolean boolean33 = dateTime23.isSupported(dateTimeFieldType32);
//        boolean boolean34 = dateTime16.isSupported(dateTimeFieldType32);
//        int int35 = dateTime4.get(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(instant21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "15" + "'", str28.equals("15"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "15" + "'", str30.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
//    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(9, '#', 7, 999, 1969, false, 19);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setStandardOffset(21);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        try {
            long long10 = copticChronology2.getDateTimeMillis((int) (byte) 0, 1970, 7, (int) 'a', 0, 3, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
        int int10 = dateTime9.getSecondOfDay();
        int int11 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime9.getZone();
        java.lang.String str13 = dateTimeZone12.toString();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone12);
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now(dateTimeZone12);
        int[] intArray20 = new int[] { 19, 'a', 0, 'a' };
        int int21 = skipUndoDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay15, intArray20);
        java.lang.String str23 = monthDay15.toString("141532.594-0700");
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "141532.594-0700" + "'", str23.equals("141532.594-0700"));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.DurationField durationField4 = gJChronology2.minutes();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gJChronology2);
        int int6 = dateTime5.getMillisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime5.withMinuteOfHour(16);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 15);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 52);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.Instant instant8 = instant6.minus(0L);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean10 = skipUndoDateTimeField7.isLenient();
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipUndoDateTimeField7.getAsText((-28800000), locale12);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-28800000" + "'", str13.equals("-28800000"));
    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test34");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField3 = property2.getField();
//        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
//        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfEra(14);
//        int int7 = dateTime6.getMinuteOfHour();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusYears(9);
//        int int10 = dateTime9.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime3.plusSeconds((int) (byte) 0);
        long long6 = dateTime5.getMillis();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withPeriodAdded(readablePeriod7, 3);
        int int10 = dateTime9.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 104138006400010L + "'", long6 == 104138006400010L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime5 = dateTime1.plus((long) (short) 100);
        org.joda.time.DateTime.Property property6 = dateTime1.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.withMinimumValue();
        org.joda.time.DurationField durationField8 = property6.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test38() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test38");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField25);
//        long long31 = remainderDateTimeField29.roundCeiling(57600015L);
//        long long33 = remainderDateTimeField29.roundFloor((-62111167561000L));
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 115200000L + "'", long31 == 115200000L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62111203622000L) + "'", long33 == (-62111203622000L));
//    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(9, '#', 7, 999, 1969, false, 19);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("141538.457-0700", 4, 31, 3, ' ', 2000, (-1), 19, false, 1970);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder30 = dateTimeZoneBuilder19.addRecurringSavings("25121231T160000-0800", (-292275054), 3, (int) (short) 0, '#', 0, 15, 1, false, 14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder30);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gJChronology5);
        int int9 = dateTime8.getMillisOfSecond();
        int int10 = property2.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime11 = property2.roundHalfCeilingCopy();
        int int12 = dateTime11.getYearOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(2000);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test42() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test42");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField25);
//        long long31 = dividedDateTimeField25.roundHalfEven((long) 365);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 28800000L + "'", long31 == 28800000L);
//    }

//    @Test
//    public void test43() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test43");
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
//        int int7 = dateTime6.getMonthOfYear();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
//        int int10 = dateTime9.getSecondOfDay();
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.LocalTime localTime12 = dateTime9.toLocalTime();
//        org.joda.time.DateTime dateTime13 = dateTime6.withFields((org.joda.time.ReadablePartial) localTime12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.Object obj15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(obj15);
//        java.lang.String str17 = dateTimeFormatter14.print((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 10);
//        int int20 = dateTime19.getSecondOfDay();
//        int int21 = dateTime19.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone22 = dateTime19.getZone();
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter14.withZone(dateTimeZone22);
//        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter26.withOffsetParsed();
//        boolean boolean28 = copticChronology25.equals((java.lang.Object) dateTimeFormatter27);
//        java.lang.String str29 = dateTime13.toString(dateTimeFormatter27);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(localTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "141617.239-0700" + "'", str17.equals("141617.239-0700"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 57600 + "'", int20 == 57600);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(copticChronology25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0001-10-10T16:00:00.010-07:52:58" + "'", str29.equals("0001-10-10T16:00:00.010-07:52:58"));
//    }

//    @Test
//    public void test44() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test44");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        int int31 = dividedDateTimeField25.getDifference((long) 960, (long) 41);
//        int int33 = dividedDateTimeField25.getMaximumValue(215999999L);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
//    }

//    @Test
//    public void test45() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test45");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay();
//        int int10 = monthDay9.getDayOfMonth();
//        org.joda.time.MonthDay.Property property11 = monthDay9.dayOfMonth();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsShortText(locale12);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property11.getAsText(locale14);
//        org.joda.time.DateTimeField dateTimeField16 = property11.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property11.getFieldType();
//        boolean boolean18 = dateTime8.isSupported(dateTimeFieldType17);
//        boolean boolean19 = dateTime1.isSupported(dateTimeFieldType17);
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay();
//        int int21 = monthDay20.getDayOfMonth();
//        org.joda.time.MonthDay.Property property22 = monthDay20.dayOfMonth();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property22.getAsShortText(locale23);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property22.getAsText(locale25);
//        org.joda.time.DateTimeField dateTimeField27 = property22.getField();
//        org.joda.time.DurationField durationField28 = property22.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, durationField28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = unsupportedDateTimeField29.getType();
//        java.lang.String str31 = unsupportedDateTimeField29.getName();
//        java.util.Locale locale33 = null;
//        try {
//            java.lang.String str34 = unsupportedDateTimeField29.getAsText((int) (short) -1, locale33);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "15" + "'", str15.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "15" + "'", str24.equals("15"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "15" + "'", str26.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "dayOfMonth" + "'", str31.equals("dayOfMonth"));
//    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
        java.util.Locale locale11 = null;
        int int12 = skipUndoDateTimeField7.getMaximumShortTextLength(locale11);
        int int13 = skipUndoDateTimeField7.getMaximumValue();
        long long16 = skipUndoDateTimeField7.add(21L, (long) 100);
        int int17 = skipUndoDateTimeField7.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 8640000021L + "'", long16 == 8640000021L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("BuddhistChronology[America/Los_Angeles]", (java.lang.Number) (short) 10, (java.lang.Number) 230400000L, (java.lang.Number) 30);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        java.util.Locale locale14 = null;
        int int15 = skipUndoDateTimeField7.getMaximumTextLength(locale14);
        boolean boolean16 = skipUndoDateTimeField7.isSupported();
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField7.getAsShortText((int) ' ', locale18);
        try {
            long long22 = skipUndoDateTimeField7.set((long) 31, 69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for dayOfWeek must be in the range [0,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "32" + "'", str19.equals("32"));
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10);
        int int3 = dateTime2.getSecondOfDay();
        int int4 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTime2.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.clockhourOfHalfday();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(28800000L, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology6.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600 + "'", int3 == 57600);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology13 = monthDay12.getChronology();
        int int14 = monthDay12.size();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay16 = monthDay12.plus(readablePeriod15);
        int int18 = monthDay16.getValue((int) (short) 0);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) monthDay16, 21, locale20);
        org.joda.time.MonthDay.Property property22 = monthDay16.monthOfYear();
        org.joda.time.MonthDay monthDay23 = property22.getMonthDay();
        java.util.Locale locale24 = null;
        int int25 = property22.getMaximumTextLength(locale24);
        int int26 = property22.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "21" + "'", str21.equals("21"));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test51");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField25);
//        long long31 = remainderDateTimeField29.roundCeiling(57600015L);
//        long long33 = remainderDateTimeField29.roundFloor((long) 4);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 115200000L + "'", long31 == 115200000L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-57600000L) + "'", long33 == (-57600000L));
//    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        int int10 = dateTime7.getYear();
        org.joda.time.DateTime dateTime12 = dateTime7.withWeekyear(0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField7.getLeapDurationField();
        int int13 = skipUndoDateTimeField7.get((long) (-97));
        try {
            long long16 = skipUndoDateTimeField7.set((long) 59, "PST");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PST\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, 14);
        long long17 = offsetDateTimeField15.roundCeiling((long) 21);
        int int18 = offsetDateTimeField15.getMinimumValue();
        long long20 = offsetDateTimeField15.roundCeiling(59L);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime23 = dateTime22.withTimeAtStartOfDay();
        java.util.Date date24 = dateTime23.toDate();
        org.joda.time.MonthDay monthDay25 = org.joda.time.MonthDay.fromDateFields(date24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder26.append(dateTimeFormatter29);
        org.joda.time.Chronology chronology31 = dateTimeFormatter29.getChronology();
        boolean boolean32 = dateTimeFormatter29.isPrinter();
        java.lang.String str33 = monthDay25.toString(dateTimeFormatter29);
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) monthDay25, 100, locale35);
        long long39 = offsetDateTimeField15.add((long) 10, (int) (short) -1);
        try {
            long long42 = offsetDateTimeField15.set(57600015L, "753");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 753 for dayOfWeek must be in the range [14,21]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 14 + "'", int18 == 14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNull(chronology31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "����W���T������.000" + "'", str33.equals("����W���T������.000"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-86399990L) + "'", long39 == (-86399990L));
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 15);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 52);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.Instant instant8 = instant4.plus((-1L));
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 4);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test59() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test59");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        org.joda.time.DateTimeField dateTimeField7 = property2.getField();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((-9));
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
//        int int17 = dateTime16.getMonthOfYear();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 10);
//        int int20 = dateTime19.getSecondOfDay();
//        long long21 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.LocalTime localTime22 = dateTime19.toLocalTime();
//        org.joda.time.DateTime dateTime23 = dateTime16.withFields((org.joda.time.ReadablePartial) localTime22);
//        int int24 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        long long27 = cachedDateTimeZone25.nextTransition(0L);
//        long long29 = cachedDateTimeZone25.previousTransition((long) 12);
//        org.joda.time.DateTimeZone dateTimeZone30 = cachedDateTimeZone25.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis((-9));
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
//        int int40 = dateTime39.getMonthOfYear();
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) 10);
//        int int43 = dateTime42.getSecondOfDay();
//        long long44 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime42);
//        org.joda.time.LocalTime localTime45 = dateTime42.toLocalTime();
//        org.joda.time.DateTime dateTime46 = dateTime39.withFields((org.joda.time.ReadablePartial) localTime45);
//        int int47 = dateTimeZone32.getOffset((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone48 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone32);
//        long long50 = cachedDateTimeZone48.nextTransition(0L);
//        long long52 = cachedDateTimeZone48.previousTransition((long) 12);
//        org.joda.time.DateTimeZone dateTimeZone53 = cachedDateTimeZone48.getUncachedZone();
//        long long55 = dateTimeZone30.getMillisKeepLocal(dateTimeZone53, (long) (-97));
//        try {
//            org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((java.lang.Object) property2, dateTimeZone30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MonthDay$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 57600 + "'", int20 == 57600);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
//        org.junit.Assert.assertNotNull(localTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-9) + "'", int24 == (-9));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 12L + "'", long29 == 12L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 57600 + "'", int43 == 57600);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
//        org.junit.Assert.assertNotNull(localTime45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-9) + "'", int47 == (-9));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 12L + "'", long52 == 12L);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-97L) + "'", long55 == (-97L));
//    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        boolean boolean4 = instant2.isEqual((long) (byte) 1);
        org.joda.time.Instant instant6 = instant2.minus((long) 57600);
        org.joda.time.Instant instant8 = instant2.minus((long) 9);
        org.joda.time.Instant instant11 = instant8.withDurationAdded((long) (short) 1, 52);
        org.joda.time.Chronology chronology12 = instant8.getChronology();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(chronology12);
    }

//    @Test
//    public void test61() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test61");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
//        boolean boolean4 = dateTime3.isEqualNow();
//        org.joda.time.LocalDate localDate5 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime6 = dateTime3.toDateTimeISO();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

//    @Test
//    public void test62() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test62");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay();
//        int int10 = monthDay9.getDayOfMonth();
//        org.joda.time.MonthDay.Property property11 = monthDay9.dayOfMonth();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsShortText(locale12);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property11.getAsText(locale14);
//        org.joda.time.DateTimeField dateTimeField16 = property11.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property11.getFieldType();
//        boolean boolean18 = dateTime8.isSupported(dateTimeFieldType17);
//        boolean boolean19 = dateTime1.isSupported(dateTimeFieldType17);
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay();
//        int int21 = monthDay20.getDayOfMonth();
//        org.joda.time.MonthDay.Property property22 = monthDay20.dayOfMonth();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property22.getAsShortText(locale23);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property22.getAsText(locale25);
//        org.joda.time.DateTimeField dateTimeField27 = property22.getField();
//        org.joda.time.DurationField durationField28 = property22.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, durationField28);
//        boolean boolean30 = unsupportedDateTimeField29.isSupported();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "15" + "'", str15.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "15" + "'", str24.equals("15"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "15" + "'", str26.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

//    @Test
//    public void test63() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test63");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay();
//        int int10 = monthDay9.getDayOfMonth();
//        org.joda.time.MonthDay.Property property11 = monthDay9.dayOfMonth();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsShortText(locale12);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property11.getAsText(locale14);
//        org.joda.time.DateTimeField dateTimeField16 = property11.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property11.getFieldType();
//        boolean boolean18 = dateTime8.isSupported(dateTimeFieldType17);
//        boolean boolean19 = dateTime1.isSupported(dateTimeFieldType17);
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay();
//        int int21 = monthDay20.getDayOfMonth();
//        org.joda.time.MonthDay.Property property22 = monthDay20.dayOfMonth();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property22.getAsShortText(locale23);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property22.getAsText(locale25);
//        org.joda.time.DateTimeField dateTimeField27 = property22.getField();
//        org.joda.time.DurationField durationField28 = property22.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, durationField28);
//        java.lang.String str30 = unsupportedDateTimeField29.toString();
//        boolean boolean31 = unsupportedDateTimeField29.isSupported();
//        try {
//            java.lang.String str33 = unsupportedDateTimeField29.getAsShortText((long) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "15" + "'", str15.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "15" + "'", str24.equals("15"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "15" + "'", str26.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDateTimeField" + "'", str30.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

//    @Test
//    public void test64() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test64");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        java.util.Date date4 = dateTime1.toDate();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusHours((int) (byte) 1);
//        java.lang.Class<?> wildcardClass10 = dateTime7.getClass();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfHalfday((int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfYear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendYearOfEra(57600, 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendLiteral('a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendClockhourOfHalfday((int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendDayOfYear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendYearOfEra(57600, 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay();
//        int int35 = monthDay34.getDayOfMonth();
//        org.joda.time.MonthDay.Property property36 = monthDay34.dayOfMonth();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = property36.getAsShortText(locale37);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = property36.getAsText(locale39);
//        org.joda.time.DateTimeField dateTimeField41 = property36.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder31.appendText(dateTimeFieldType42);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 0L, (java.lang.Number) (-1), (java.lang.Number) 9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder30.appendFraction(dateTimeFieldType42, 12, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder21.appendShortText(dateTimeFieldType42);
//        boolean boolean52 = dateTime7.isSupported(dateTimeFieldType42);
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.DateTime dateTime54 = dateTime7.toDateTime(chronology53);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "15" + "'", str38.equals("15"));
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "15" + "'", str40.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(dateTime54);
//    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYear(7, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendDayOfMonth((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test67() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test67");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay();
//        int int7 = monthDay6.getDayOfMonth();
//        org.joda.time.MonthDay.Property property8 = monthDay6.dayOfMonth();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property8.getAsShortText(locale9);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property8.getAsText(locale11);
//        org.joda.time.DateTimeField dateTimeField13 = property8.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property8.getFieldType();
//        boolean boolean15 = buddhistChronology2.equals((java.lang.Object) dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "15" + "'", str10.equals("15"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "15" + "'", str12.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test68() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test68");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay();
//        int int3 = monthDay2.getDayOfMonth();
//        org.joda.time.MonthDay.Property property4 = monthDay2.dayOfMonth();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property4.getAsText(locale7);
//        org.joda.time.MonthDay monthDay10 = property4.addWrapFieldToCopy(19);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "15" + "'", str8.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay10);
//    }

//    @Test
//    public void test69() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test69");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(57600);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(54000010, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendClockhourOfHalfday((int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendDayOfYear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendYearOfEra(57600, 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay();
//        int int19 = monthDay18.getDayOfMonth();
//        org.joda.time.MonthDay.Property property20 = monthDay18.dayOfMonth();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = property20.getAsShortText(locale21);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property20.getAsText(locale23);
//        org.joda.time.DateTimeField dateTimeField25 = property20.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property20.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType26);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 0L, (java.lang.Number) (-1), (java.lang.Number) 9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType26, 12, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder5.appendFixedSignedDecimal(dateTimeFieldType26, 6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = dateTimeFormatter37.withPivotYear((java.lang.Integer) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter37.withOffsetParsed();
//        org.joda.time.format.DateTimePrinter dateTimePrinter41 = dateTimeFormatter40.getPrinter();
//        org.joda.time.format.DateTimeParser dateTimeParser42 = null;
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder5.append(dateTimePrinter41, dateTimeParser42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "15" + "'", str22.equals("15"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "15" + "'", str24.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTimePrinter41);
//    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test70");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 10);
        int int5 = dateTime4.getSecondOfDay();
        int int6 = dateTime4.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.hourOfDay();
        boolean boolean12 = iSOChronology1.equals((java.lang.Object) gregorianChronology8);
        java.lang.Object obj13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = property15.setCopy((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
        org.joda.time.Chronology chronology19 = gregorianChronology8.withZone(dateTimeZone18);
        long long22 = dateTimeZone18.adjustOffset(104138006400010L, false);
        try {
            org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone18, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600 + "'", int5 == 57600);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 104138006400010L + "'", long22 == 104138006400010L);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test71");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(1969, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2069 + "'", int2 == 2069);
    }

//    @Test
//    public void test73() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test73");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
//        int int10 = dateTime9.getSecondOfDay();
//        int int11 = dateTime9.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTime9.getZone();
//        java.lang.String str13 = dateTimeZone12.toString();
//        org.joda.time.Chronology chronology14 = buddhistChronology1.withZone(dateTimeZone12);
//        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 10);
//        int int18 = dateTime17.getSecondOfDay();
//        long long19 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime21 = dateTime17.plus((long) (short) 100);
//        org.joda.time.DateTime.Property property22 = dateTime17.monthOfYear();
//        org.joda.time.DateTime dateTime23 = property22.withMinimumValue();
//        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology25 = monthDay24.getChronology();
//        int int26 = monthDay24.size();
//        org.joda.time.MonthDay monthDay28 = monthDay24.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTime dateTime32 = dateTime30.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33);
//        org.joda.time.Instant instant35 = gJChronology34.getGregorianCutover();
//        org.joda.time.DurationField durationField36 = gJChronology34.minutes();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology34);
//        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay();
//        int int39 = monthDay38.getDayOfMonth();
//        org.joda.time.MonthDay.Property property40 = monthDay38.dayOfMonth();
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = property40.getAsShortText(locale41);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = property40.getAsText(locale43);
//        org.joda.time.DateTimeField dateTimeField45 = property40.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property40.getFieldType();
//        boolean boolean47 = dateTime37.isSupported(dateTimeFieldType46);
//        boolean boolean48 = dateTime30.isSupported(dateTimeFieldType46);
//        int int49 = monthDay24.indexOf(dateTimeFieldType46);
//        int int50 = property22.compareTo((org.joda.time.ReadablePartial) monthDay24);
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        org.joda.time.MonthDay monthDay53 = monthDay24.withPeriodAdded(readablePeriod51, (int) (byte) 1);
//        long long55 = copticChronology15.set((org.joda.time.ReadablePartial) monthDay24, 104138006400010L);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(copticChronology15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 57600 + "'", int18 == 57600);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(instant35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 15 + "'", int39 == 15);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "15" + "'", str42.equals("15"));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "15" + "'", str44.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(monthDay53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 104144655600010L + "'", long55 == 104144655600010L);
//    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test74");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test75() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test75");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay();
//        int int10 = monthDay9.getDayOfMonth();
//        org.joda.time.MonthDay.Property property11 = monthDay9.dayOfMonth();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsShortText(locale12);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property11.getAsText(locale14);
//        org.joda.time.DateTimeField dateTimeField16 = property11.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType17);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType17, 7, (int) (short) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendPattern("--12-31");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendTimeZoneId();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "15" + "'", str15.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test76");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField7.getDurationField();
        int int13 = skipUndoDateTimeField7.getMinimumValue();
        boolean boolean14 = skipUndoDateTimeField7.isSupported();
        long long16 = skipUndoDateTimeField7.roundCeiling(518400000L);
        int int18 = skipUndoDateTimeField7.getLeapAmount((-57600000L));
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 547200000L + "'", long16 == 547200000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test77");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        java.lang.String str6 = property5.getAsString();
        org.joda.time.Interval interval7 = property5.toInterval();
        int int8 = property5.getMinimumValue();
        org.joda.time.DateTime dateTime9 = property5.getDateTime();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "960" + "'", str6.equals("960"));
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test78");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusYears((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime1.withMillis((long) (byte) -1);
        org.joda.time.DateTime dateTime8 = dateTime1.minusWeeks((-16));
        int int9 = dateTime1.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property10 = dateTime1.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test79");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, 14);
        long long18 = offsetDateTimeField15.set((long) 2000, 19);
        boolean boolean19 = offsetDateTimeField15.isSupported();
        org.joda.time.DurationField durationField20 = offsetDateTimeField15.getRangeDurationField();
        long long22 = offsetDateTimeField15.roundHalfEven((long) 1970);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 172802000L + "'", long18 == 172802000L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800000L + "'", long22 == 28800000L);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test80");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        long long15 = skipUndoDateTimeField7.roundHalfCeiling(28800001L);
        boolean boolean16 = skipUndoDateTimeField7.isLenient();
        java.util.Locale locale17 = null;
        int int18 = skipUndoDateTimeField7.getMaximumShortTextLength(locale17);
        long long20 = skipUndoDateTimeField7.roundHalfEven((-31872499622000L));
        try {
            long long23 = skipUndoDateTimeField7.set((long) ' ', "141446.251-0700");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"141446.251-0700\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-31872499622000L) + "'", long20 == (-31872499622000L));
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test81");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfMinute(9, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute((int) (byte) 100);
        boolean boolean11 = dateTimeFormatterBuilder8.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendSecondOfMinute(1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test82");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) (short) 10);
        org.joda.time.Chronology chronology7 = julianChronology0.withZone(dateTimeZone6);
        org.joda.time.DurationField durationField8 = julianChronology0.seconds();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test83() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test83");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay();
//        int int10 = monthDay9.getDayOfMonth();
//        org.joda.time.MonthDay.Property property11 = monthDay9.dayOfMonth();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsShortText(locale12);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property11.getAsText(locale14);
//        org.joda.time.DateTimeField dateTimeField16 = property11.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property11.getFieldType();
//        boolean boolean18 = dateTime8.isSupported(dateTimeFieldType17);
//        boolean boolean19 = dateTime1.isSupported(dateTimeFieldType17);
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay();
//        int int21 = monthDay20.getDayOfMonth();
//        org.joda.time.MonthDay.Property property22 = monthDay20.dayOfMonth();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property22.getAsShortText(locale23);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property22.getAsText(locale25);
//        org.joda.time.DateTimeField dateTimeField27 = property22.getField();
//        org.joda.time.DurationField durationField28 = property22.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, durationField28);
//        java.lang.String str30 = unsupportedDateTimeField29.toString();
//        boolean boolean31 = unsupportedDateTimeField29.isSupported();
//        try {
//            long long33 = unsupportedDateTimeField29.roundCeiling(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "15" + "'", str15.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "15" + "'", str24.equals("15"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "15" + "'", str26.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDateTimeField" + "'", str30.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test84");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.hourOfHalfday();
        org.joda.time.DurationField durationField7 = gJChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.clockhourOfHalfday();
        org.joda.time.Chronology chronology9 = gJChronology5.withUTC();
        org.joda.time.DurationField durationField10 = gJChronology5.halfdays();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

//    @Test
//    public void test85() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test85");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField25);
//        int int31 = dividedDateTimeField25.get(4976866800000L);
//        int int32 = dividedDateTimeField25.getDivisor();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
//    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test86");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = gJChronology1.withZone(dateTimeZone2);
        java.lang.Object obj4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.DurationField durationField8 = gJChronology6.minutes();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(obj4, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay11 = monthDay9.minusMonths((int) '4');
        org.joda.time.DateTimeField[] dateTimeFieldArray12 = monthDay9.getFields();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField18, (int) (byte) 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField20.getAsText((int) '4', locale22);
        org.joda.time.DurationField durationField24 = skipUndoDateTimeField20.getLeapDurationField();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime27 = dateTime26.withTimeAtStartOfDay();
        java.util.GregorianCalendar gregorianCalendar28 = dateTime27.toGregorianCalendar();
        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar28);
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar28);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.parse("");
        int[] intArray33 = monthDay32.getValues();
        int int34 = skipUndoDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) monthDay30, intArray33);
        gJChronology1.validate((org.joda.time.ReadablePartial) monthDay9, intArray33);
        try {
            long long43 = gJChronology1.getDateTimeMillis(9, 59, (int) (byte) 10, (int) (byte) 0, 0, 82800010, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82800010 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTimeFieldArray12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "52" + "'", str23.equals("52"));
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianCalendar28);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 7 + "'", int34 == 7);
    }

//    @Test
//    public void test87() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test87");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 215999999L, "32");
//        org.joda.time.DurationFieldType durationFieldType29 = illegalFieldValueException28.getDurationFieldType();
//        java.lang.String str30 = illegalFieldValueException28.getIllegalValueAsString();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNull(durationFieldType29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "215999999" + "'", str30.equals("215999999"));
//    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test88");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime5 = dateTime1.plus((long) (short) 100);
        org.joda.time.DateTime.Property property6 = dateTime1.monthOfYear();
        org.joda.time.DateTime dateTime7 = property6.withMinimumValue();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        java.util.Locale locale10 = null;
        try {
            org.joda.time.DateTime dateTime11 = property8.setCopy("1969", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test89");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(230400000L, (long) 355);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 81792000000L + "'", long2 == 81792000000L);
    }

    @Test
    public void test90() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test90");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusYears((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusMinutes((-1));
        int int7 = dateTime1.getYear();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime1.toMutableDateTime(chronology8);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

//    @Test
//    public void test91() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test91");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        int int30 = dividedDateTimeField25.get(0L);
//        int int32 = dividedDateTimeField25.getMinimumValue((long) 59);
//        long long35 = dividedDateTimeField25.add((long) 16, 59);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField36 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField25);
//        long long38 = remainderDateTimeField36.roundHalfCeiling((long) 19);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10191600016L + "'", long35 == 10191600016L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 28800000L + "'", long38 == 28800000L);
//    }

//    @Test
//    public void test92() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test92");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField3 = property2.getField();
//        java.lang.String str4 = property2.getAsString();
//        java.util.Locale locale5 = null;
//        int int6 = property2.getMaximumShortTextLength(locale5);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "54" + "'", str4.equals("54"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
//    }

    @Test
    public void test93() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test93");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime3 = property2.roundFloorCopy();
        int int4 = property2.getMaximumValueOverall();
        org.joda.time.DateTime dateTime5 = property2.roundFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 999 + "'", int4 == 999);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test94() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test94");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, 14);
        long long18 = offsetDateTimeField15.addWrapField(10L, (int) '#');
        org.joda.time.DurationField durationField19 = offsetDateTimeField15.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 259200010L + "'", long18 == 259200010L);
        org.junit.Assert.assertNull(durationField19);
    }

    @Test
    public void test95() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test95");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField7.getDurationField();
        long long15 = skipUndoDateTimeField7.getDifferenceAsLong((-6L), 10191600016L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-118L) + "'", long15 == (-118L));
    }

    @Test
    public void test96() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test96");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        long long15 = skipUndoDateTimeField7.roundHalfCeiling(28800001L);
        boolean boolean16 = skipUndoDateTimeField7.isLenient();
        java.util.Locale locale17 = null;
        int int18 = skipUndoDateTimeField7.getMaximumShortTextLength(locale17);
        long long20 = skipUndoDateTimeField7.roundHalfEven((-31872499622000L));
        long long23 = skipUndoDateTimeField7.set(4976866800000L, 7);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-31872499622000L) + "'", long20 == (-31872499622000L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 4977212400000L + "'", long23 == 4977212400000L);
    }

    @Test
    public void test97() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test97");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-98), number2, (java.lang.Number) 69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test98() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test98");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.clockhourOfHalfday();
        org.joda.time.DurationField durationField7 = gregorianChronology5.hours();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology5);
        try {
            long long13 = gregorianChronology5.getDateTimeMillis(7, 51341010, 29, (-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(chronology8);
    }
}

