import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) (byte) 100, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 100, 0, (int) (byte) 0, (int) (short) -1, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.parse("");
        int[] intArray10 = new int[] { (short) 0, (byte) -1, (short) 1, 1, (short) 1 };
        try {
            buddhistChronology1.validate((org.joda.time.ReadablePartial) monthDay4, intArray10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType3, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 100, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) '#', 1, (int) (short) 0, (-1), (int) (byte) -1, (int) (byte) 100, (int) (byte) 100, (org.joda.time.Chronology) buddhistChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 0.0d, chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test016");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        int int2 = dateTime1.getEra();
//        int int3 = dateTime1.getMinuteOfHour();
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560633283315L + "'", long4 == 1560633283315L);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (long) 14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYear(10, 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfDay((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        java.lang.Object obj8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.Instant instant11 = gJChronology10.getGregorianCutover();
        org.joda.time.DurationField durationField12 = gJChronology10.minutes();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(obj8, (org.joda.time.Chronology) gJChronology10);
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = skipUndoDateTimeField7.getAsText((org.joda.time.ReadablePartial) monthDay13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int8 = skipUndoDateTimeField7.getMaximumValue();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay();
        org.joda.time.MonthDay monthDay11 = monthDay9.plusDays((int) (short) 0);
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.parse("");
        int[] intArray15 = monthDay14.getValues();
        try {
            int[] intArray17 = skipUndoDateTimeField7.addWrapField((org.joda.time.ReadablePartial) monthDay9, (int) (short) 10, intArray15, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10);
        int int3 = dateTime2.getSecondOfDay();
        int int4 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTime2.getZone();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600 + "'", int3 == 57600);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test027");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendText(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) ' ', (int) (byte) -1, 2000, (int) (short) -1, (int) '#', 10, (org.joda.time.Chronology) buddhistChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.MonthDay monthDay2 = monthDay0.plusDays((int) (short) 0);
        try {
            int int4 = monthDay0.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.field.FieldUtils.verifyValueBounds("", (-1), (int) (short) -1, 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMonthOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime5 = dateTime1.plus((long) (short) 100);
        org.joda.time.LocalDateTime localDateTime6 = dateTime1.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            int int8 = dateTime1.get(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((long) 100);
        org.joda.time.LocalDate localDate11 = monthDay9.toLocalDate((int) (short) 1);
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.parse("");
        int[] intArray15 = monthDay14.getValues();
        try {
            int[] intArray17 = skipUndoDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) monthDay9, (-1), intArray15, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(2000, 100, (int) (short) 100, (int) (short) 10, 15, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        try {
//            org.joda.time.MonthDay monthDay4 = property2.setCopy("141446.251-0700");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"141446.251-0700\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("");
        int[] intArray2 = monthDay1.getValues();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.MonthDay monthDay5 = monthDay1.withFieldAdded(durationFieldType3, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        org.joda.time.DurationField durationField6 = property5.getLeapDurationField();
        java.lang.String str7 = property5.getAsString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "960" + "'", str7.equals("960"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.toString();
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        long long7 = dateTimeZone4.convertLocalToUTC(1L, true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800001L + "'", long7 == 28800001L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.centuries();
        org.joda.time.MonthDay monthDay4 = monthDay0.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology2);
        try {
            org.joda.time.MonthDay monthDay6 = monthDay4.plusMonths((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeParser5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.withPeriodAdded(readablePeriod9, 0);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        org.joda.time.DurationField durationField14 = buddhistChronology13.millis();
        try {
            org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((java.lang.Object) 0, (org.joda.time.Chronology) buddhistChronology13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        try {
            long long12 = skipUndoDateTimeField7.set((long) (short) 1, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [0,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.parse("");
        int[] intArray12 = monthDay11.getValues();
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.parse("");
        int[] intArray16 = monthDay15.getValues();
        try {
            int[] intArray18 = skipUndoDateTimeField7.set((org.joda.time.ReadablePartial) monthDay11, (int) (byte) -1, intArray16, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray16);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
//        int int7 = dateTime6.getSecondOfDay();
//        int int8 = dateTime6.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime6.getZone();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(28800000L, locale11);
//        try {
//            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0, (int) (byte) 0, 0, (int) (byte) 10, (int) '4', dateTimeZone9);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600 + "'", int7 == 57600);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays((int) (short) 0);
        java.lang.String str8 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) monthDay7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����W���T������.000" + "'", str8.equals("����W���T������.000"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray5 = new org.joda.time.format.DateTimeParser[] { dateTimeParser4 };
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeParserArray5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYear(10, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral(' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType8, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int8 = skipUndoDateTimeField7.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.parse("");
        int[] intArray13 = monthDay12.getValues();
        try {
            int[] intArray15 = skipUndoDateTimeField7.addWrapPartial(readablePartial9, (int) (short) -1, intArray13, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int7 = dateTime6.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
        int int10 = dateTime9.getSecondOfDay();
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.LocalTime localTime12 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime13 = dateTime6.withFields((org.joda.time.ReadablePartial) localTime12);
        org.joda.time.DateTime dateTime15 = dateTime6.withMillisOfDay((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("GregorianChronology[America/Los_Angeles]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[America/Los_...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1, (int) ' ', 0, (int) (byte) 0, (int) (byte) 10, (int) (byte) 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYear(10, 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendDayOfWeek((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        org.joda.time.DurationField durationField6 = property5.getLeapDurationField();
        boolean boolean7 = property5.isLeap();
        org.joda.time.DateTime dateTime8 = property5.roundHalfEvenCopy();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 10);
//        int int11 = dateTime10.getSecondOfDay();
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime14 = dateTime10.plus((long) (short) 100);
//        org.joda.time.LocalDateTime localDateTime15 = dateTime10.toLocalDateTime();
//        boolean boolean16 = dateTimeZone4.isLocalDateTimeGap(localDateTime15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.centuries();
        org.joda.time.MonthDay monthDay4 = monthDay0.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        try {
            java.lang.String str7 = monthDay4.toString(dateTimeFormatter5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.centuries();
        org.joda.time.MonthDay monthDay4 = monthDay0.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            boolean boolean6 = monthDay4.isEqual(readablePartial5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 4, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6L) + "'", long2 == (-6L));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        org.joda.time.DurationField durationField6 = property5.getLeapDurationField();
        org.joda.time.DateTime dateTime7 = property5.roundHalfCeilingCopy();
        int int8 = dateTime7.getSecondOfDay();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long8 = julianChronology0.getDateTimeMillis(0, 1, (int) (short) 0, 0, (-1), 0, 14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.withPeriodAdded(readablePeriod9, 0);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withDayOfWeek((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.centuries();
        org.joda.time.MonthDay monthDay4 = monthDay0.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.MonthDay monthDay7 = monthDay4.withFieldAdded(durationFieldType5, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withFieldAdded(durationFieldType3, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        try {
            org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((long) 100);
        org.joda.time.LocalDate localDate4 = monthDay2.toLocalDate((int) (short) 1);
        try {
            int int5 = monthDay0.compareTo((org.joda.time.ReadablePartial) localDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, 1560633283315L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.withPeriodAdded(readablePeriod9, 0);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withEra((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DurationField durationField3 = property2.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField4 = property2.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType5, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        int int2 = dateTime1.getEra();
//        int int3 = dateTime1.getMinuteOfHour();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gJChronology1.add(readablePeriod3, (long) (byte) 1, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.Instant instant9 = gJChronology8.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        long long13 = gJChronology8.add(readablePeriod10, (long) (byte) 1, (int) 'a');
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) gJChronology1, (org.joda.time.Chronology) gJChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-9) + "'", int1 == (-9));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 10);
        int int4 = dateTime3.getSecondOfDay();
        int int5 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime3.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.Chronology chronology10 = iSOChronology1.withZone(dateTimeZone9);
        try {
            org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (long) (-9), 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600 + "'", int4 == 57600);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.MonthDay monthDay3 = monthDay0.withFieldAdded(durationFieldType1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
        int int7 = dateTime6.getSecondOfDay();
        int int8 = dateTime6.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime6.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology10.getZone();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) '#', (int) (byte) 1, (-1), (int) ' ', (int) (byte) 10, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600 + "'", int7 == 57600);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int7 = dateTime6.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
        int int10 = dateTime9.getSecondOfDay();
        int int11 = dateTime9.getSecondOfMinute();
        java.util.Date date12 = dateTime9.toDate();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime9.toDateTime(dateTimeZone13);
        org.joda.time.DateMidnight dateMidnight16 = dateTime15.toDateMidnight();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime15);
        int int18 = dateTime15.getMonthOfYear();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.LocalDateTime localDateTime5 = null;
        try {
            boolean boolean6 = dateTimeZone4.isLocalDateTimeGap(localDateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.hourOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField8, (int) (short) 10, 9, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        java.lang.String str6 = property5.getAsString();
        org.joda.time.Interval interval7 = property5.toInterval();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "960" + "'", str6.equals("960"));
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.era();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("141446.251-0700", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"141446.251-0700\" is malformed at \".251-0700\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DurationField durationField3 = property2.getLeapDurationField();
        java.lang.String str4 = property2.getName();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "millisOfSecond" + "'", str4.equals("millisOfSecond"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
        int int9 = dateTime8.getSecondOfDay();
        int int10 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime8.getZone();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        long long14 = dateTimeZone6.getMillisKeepLocal(dateTimeZone11, (long) (-1));
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(7, (int) ' ', (int) (short) -1, 0, (int) (short) 1, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 215999999L + "'", long14 == 215999999L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime5 = dateTime1.plus((long) (short) 100);
        org.joda.time.LocalDateTime localDateTime6 = dateTime1.toLocalDateTime();
        int int7 = dateTime1.getWeekOfWeekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1.0f), "org.joda.time.IllegalFieldValueException: Value \"141446.251-0700\" for GregorianChronology[America/Los_Angeles] is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("����W���T������.000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����W���T������.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        org.joda.time.MonthDay monthDay6 = property2.setCopy(2);
//        org.joda.time.MonthDay monthDay8 = monthDay6.withMonthOfYear(3);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(monthDay8);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType6, (-16));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) '#', 14, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        try {
//            org.joda.time.MonthDay monthDay8 = property2.setCopy(57600);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType3, 2, (-9));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        java.util.Locale locale14 = null;
        int int15 = skipUndoDateTimeField7.getMaximumTextLength(locale14);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay();
        org.joda.time.MonthDay monthDay18 = monthDay16.plusDays((int) (short) 0);
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = skipUndoDateTimeField7.getAsText((org.joda.time.ReadablePartial) monthDay16, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertNotNull(monthDay18);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology8.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology8.halfdayOfDay();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-16), 3, 0, (int) ' ', 2000, 100, 15, (org.joda.time.Chronology) buddhistChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str3 = dateTimeZone1.getName((long) 2);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 57600);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 57600");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
//        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
//        org.joda.time.DurationField durationField4 = gJChronology2.minutes();
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(obj0, (org.joda.time.Chronology) gJChronology2);
//        org.joda.time.MonthDay monthDay7 = monthDay5.minusMonths((int) '4');
//        int int8 = monthDay7.getDayOfMonth();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMinuteOfHour((-16));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("");
        int[] intArray2 = monthDay1.getValues();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay1.getFieldType((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        try {
            org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) gJChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        int int4 = mutableDateTime3.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 41 + "'", int4 == 41);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int7 = dateTime6.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime6.minusMinutes(14);
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(0L, 0);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean10 = skipUndoDateTimeField7.isLenient();
        long long12 = skipUndoDateTimeField7.roundHalfEven(1560633283315L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668400000L + "'", long12 == 1560668400000L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.MonthDay monthDay2 = monthDay0.plusDays((int) (short) 0);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 10);
        int int5 = dateTime4.getSecondOfDay();
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.LocalTime localTime7 = dateTime4.toLocalTime();
        try {
            boolean boolean8 = monthDay0.isAfter((org.joda.time.ReadablePartial) localTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600 + "'", int5 == 57600);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(localTime7);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendFractionOfHour((int) ' ', (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYear(10, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear(7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYear(10, 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay();
//        int int10 = monthDay9.getDayOfMonth();
//        org.joda.time.MonthDay.Property property11 = monthDay9.dayOfMonth();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsShortText(locale12);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property11.getAsText(locale14);
//        org.joda.time.DateTimeField dateTimeField16 = property11.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType17);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder5.appendDecimal(dateTimeFieldType17, (-16), 9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "15" + "'", str15.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) (-28799988L), number2, (java.lang.Number) (-1L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.toString();
        java.lang.String str5 = illegalFieldValueException2.getIllegalStringValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, (long) 14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        org.joda.time.MonthDay monthDay2 = monthDay0.plusDays((int) (short) 0);
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay();
//        int int4 = monthDay3.getDayOfMonth();
//        org.joda.time.MonthDay.Property property5 = monthDay3.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        org.joda.time.MonthDay monthDay9 = property5.setCopy(2);
//        boolean boolean10 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay9);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        try {
//            org.joda.time.MonthDay.Property property12 = monthDay0.property(dateTimeFieldType11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.centuries();
        org.joda.time.MonthDay monthDay4 = monthDay0.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology2);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType6 = monthDay4.getFieldType((-9));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        try {
//            int[] intArray11 = gJChronology8.get(readablePeriod9, 0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.secondOfMinute();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
        int int9 = dateTime8.getSecondOfDay();
        int int10 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime8.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        java.lang.String str13 = dateTimeZone11.toString();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 10);
        int int16 = dateTime15.getSecondOfDay();
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime19 = dateTime15.plus((long) (short) 100);
        org.joda.time.LocalDateTime localDateTime20 = dateTime15.toLocalDateTime();
        boolean boolean21 = dateTimeZone11.isLocalDateTimeGap(localDateTime20);
        long long25 = dateTimeZone11.convertLocalToUTC((long) 54000010, true, 28800000L);
        try {
            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 1, 54000010, (-9), 9, 2000, 54000010, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57600 + "'", int16 == 57600);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 82800010L + "'", long25 == 82800010L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        int int6 = dateTime1.getCenturyOfEra();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
//        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
//        java.util.Locale locale12 = null;
//        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
//        long long15 = skipUndoDateTimeField7.roundHalfEven((long) (byte) 10);
//        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay();
//        int int17 = monthDay16.getDayOfMonth();
//        org.joda.time.MonthDay.Property property18 = monthDay16.dayOfMonth();
//        int int19 = skipUndoDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay16);
//        boolean boolean20 = skipUndoDateTimeField7.isSupported();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        java.lang.String str1 = copticChronology0.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str1.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 54000010, 15, 54000010, 2, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54000010 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder5.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYearOfCentury(9, 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendYear((-1), 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        int int7 = property2.getMinimumValueOverall();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology9 = monthDay8.getChronology();
//        int int10 = monthDay8.size();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.MonthDay monthDay13 = monthDay8.withPeriodAdded(readablePeriod11, 0);
//        int int14 = property2.compareTo((org.joda.time.ReadablePartial) monthDay8);
//        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay();
//        int int16 = monthDay15.getDayOfMonth();
//        org.joda.time.MonthDay.Property property17 = monthDay15.dayOfMonth();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = property17.getAsShortText(locale18);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = property17.getAsText(locale20);
//        org.joda.time.DateTimeField dateTimeField22 = property17.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property17.getFieldType();
//        try {
//            org.joda.time.MonthDay monthDay25 = monthDay8.withField(dateTimeFieldType23, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "15" + "'", str19.equals("15"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "15" + "'", str21.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        long long15 = skipUndoDateTimeField7.roundHalfCeiling(28800001L);
        boolean boolean16 = skipUndoDateTimeField7.isLenient();
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((long) 100);
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.parse("");
        int[] intArray22 = monthDay21.getValues();
        try {
            int[] intArray24 = skipUndoDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) monthDay18, (int) (byte) 10, intArray22, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long8 = julianChronology0.getDateTimeMillis((int) '4', (int) '4', 0, (int) (short) -1, (int) (short) 10, (int) (short) 0, 54000010);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        java.util.Locale locale14 = null;
        int int15 = skipUndoDateTimeField7.getMaximumTextLength(locale14);
        java.util.Locale locale18 = null;
        try {
            long long19 = skipUndoDateTimeField7.set((long) (short) 10, "dayOfWeek", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"dayOfWeek\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        long long15 = skipUndoDateTimeField7.roundHalfCeiling(28800001L);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology21, dateTimeField25, (int) (byte) 0);
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipUndoDateTimeField27.getAsText((int) '4', locale29);
        int int32 = skipUndoDateTimeField27.get((long) (byte) -1);
        java.lang.String str33 = skipUndoDateTimeField27.getName();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 10);
        int int36 = dateTime35.getSecondOfDay();
        long long37 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime dateTime39 = dateTime35.plus((long) (short) 100);
        org.joda.time.LocalDateTime localDateTime40 = dateTime35.toLocalDateTime();
        int[] intArray43 = new int[] { (byte) -1, 4 };
        int int44 = skipUndoDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) localDateTime40, intArray43);
        try {
            int[] intArray46 = skipUndoDateTimeField7.add((org.joda.time.ReadablePartial) monthDay18, 4, intArray43, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "52" + "'", str30.equals("52"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "dayOfWeek" + "'", str33.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 57600 + "'", int36 == 57600);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 10);
//        int int11 = dateTime10.getSecondOfDay();
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime14 = dateTime10.plus((long) (short) 100);
//        org.joda.time.LocalDateTime localDateTime15 = dateTime10.toLocalDateTime();
//        boolean boolean16 = dateTimeZone4.isLocalDateTimeGap(localDateTime15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        java.lang.String str19 = dateTimeZone4.getName((long) 100);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Pacific Standard Time" + "'", str19.equals("Pacific Standard Time"));
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
        int int12 = skipUndoDateTimeField7.get((long) (byte) -1);
        java.util.Locale locale13 = null;
        int int14 = skipUndoDateTimeField7.getMaximumShortTextLength(locale13);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        java.lang.String str4 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime3);
//        try {
//            org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.parse("52", dateTimeFormatter1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"52\" is too short");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "141459.719-0700" + "'", str4.equals("141459.719-0700"));
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DurationField durationField4 = buddhistChronology1.centuries();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("141453.816-0700", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"141453.816-0700/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfDay((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendTimeZoneOffset("", false, (-16), 54000010);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendFractionOfDay(1, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readableDuration9);
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime7.toYearMonthDay();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(yearMonthDay11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.hourOfDay();
        try {
            long long16 = gregorianChronology5.getDateTimeMillis(4, (int) (short) 0, 10, 1, (int) (short) 1, 15, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean10 = skipUndoDateTimeField7.isLenient();
        long long13 = skipUndoDateTimeField7.add(28800000L, (long) 15);
        org.joda.time.DurationField durationField14 = skipUndoDateTimeField7.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1324800000L + "'", long13 == 1324800000L);
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = property2.getField();
        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.setCopy("960");
        org.joda.time.DateTime dateTime7 = property2.withMinimumValue();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.append(dateTimeFormatter9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder6.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.append(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DurationField durationField3 = property2.getLeapDurationField();
        org.joda.time.DateTime dateTime4 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(57600, (int) (short) 0, (int) (byte) 10, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DurationField durationField4 = buddhistChronology1.centuries();
        long long8 = buddhistChronology1.add((long) 0, (long) (byte) -1, 4);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.Chronology chronology12 = gJChronology10.withZone(dateTimeZone11);
        java.lang.String str13 = gJChronology10.toString();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology10.dayOfMonth();
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0, (java.lang.Object) dateTimeField14);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-4L) + "'", long8 == (-4L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str13.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        try {
//            org.joda.time.MonthDay monthDay8 = property2.setCopy("org.joda.time.IllegalFieldValueException: Value \"141446.251-0700\" for GregorianChronology[America/Los_Angeles] is not supported");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value \"141446.251-0700\" for GregorianChronology[America/Los_Angeles] is not supported\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1L, (long) 19);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        int int4 = dateTime1.getSecondOfDay();
        int int5 = dateTime1.getMillisOfSecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600 + "'", int4 == 57600);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 10);
//        int int6 = dateTime5.getSecondOfDay();
//        int int7 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone8);
//        java.lang.StringBuffer stringBuffer11 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime18.toTimeOfDay();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer11, (org.joda.time.ReadablePartial) timeOfDay19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141501.506-0700" + "'", str3.equals("141501.506-0700"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600 + "'", int6 == 57600);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfDay((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime4 = property2.setCopy((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime7 = dateTime6.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.minusYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 10);
        int int14 = dateTime13.getSecondOfDay();
        int int15 = dateTime13.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime13.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
        org.joda.time.Chronology chronology20 = iSOChronology11.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = dateTime9.toDateTime(dateTimeZone19);
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) (short) 10, dateTimeZone19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 57600 + "'", int14 == 57600);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        long long15 = skipUndoDateTimeField7.roundHalfCeiling(28800001L);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime18 = dateTime17.withTimeAtStartOfDay();
        java.util.Date date19 = dateTime18.toDate();
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.fromDateFields(date19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder21.append(dateTimeFormatter24);
        org.joda.time.Chronology chronology26 = dateTimeFormatter24.getChronology();
        boolean boolean27 = dateTimeFormatter24.isPrinter();
        java.lang.String str28 = monthDay20.toString(dateTimeFormatter24);
        int[] intArray30 = null;
        java.util.Locale locale32 = null;
        try {
            int[] intArray33 = skipUndoDateTimeField7.set((org.joda.time.ReadablePartial) monthDay20, 15, intArray30, "", locale32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNull(chronology26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "����W���T������.000" + "'", str28.equals("����W���T������.000"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("141446.251-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"141446.251-0700\" is malformed at \".251-0700\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime dateTime6 = dateTime1.plusYears(100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 41);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology12 = monthDay11.getChronology();
        int int13 = monthDay11.size();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay11.withPeriodAdded(readablePeriod14, 0);
        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.parse("");
        int[] intArray20 = monthDay19.getValues();
        try {
            int[] intArray22 = skipUndoDateTimeField7.addWrapField((org.joda.time.ReadablePartial) monthDay11, 54000010, intArray20, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 54000010");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray20);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay();
//        int int4 = monthDay3.getDayOfMonth();
//        org.joda.time.MonthDay.Property property5 = monthDay3.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property5.getAsText(locale8);
//        org.joda.time.DateTimeField dateTimeField10 = property5.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property5.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType11);
//        org.joda.time.DurationField durationField13 = null;
//        try {
//            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField14 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 10);
        int int4 = dateTime3.getSecondOfDay();
        int int5 = dateTime3.getSecondOfMinute();
        java.util.Date date6 = dateTime3.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime3.toDateTime(dateTimeZone7);
        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readableDuration11);
        org.joda.time.DateMidnight dateMidnight13 = dateTime9.toDateMidnight();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateMidnight13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600 + "'", int4 == 57600);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime5 = dateTime1.plus((long) (short) 100);
        boolean boolean7 = dateTime5.isEqual(0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        try {
            long long10 = copticChronology2.getDateTimeMillis((-16), (int) (byte) 10, (int) (short) 100, 19, (-16), 54000010, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -16 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GJChronology[America/Los_Angeles]", "millisOfSecond");
        java.lang.Throwable throwable3 = null;
        try {
            illegalFieldValueException2.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime4 = property2.setCopy((int) (short) 10);
        int int5 = property2.getLeapAmount();
        int int6 = property2.getMinimumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendFractionOfHour((int) ' ', (int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((long) 2);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        try {
//            org.joda.time.DateTime dateTime5 = dateTime2.withMinuteOfHour(54000010);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54000010 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141503.325-0700" + "'", str3.equals("141503.325-0700"));
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
//        java.lang.Appendable appendable4 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
//        int int7 = dateTime6.getSecondOfDay();
//        int int8 = dateTime6.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime6.getZone();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(28800000L, locale11);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 10);
//        int int16 = dateTime15.getSecondOfDay();
//        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime19 = dateTime15.plus((long) (short) 100);
//        org.joda.time.LocalDateTime localDateTime20 = dateTime15.toLocalDateTime();
//        boolean boolean21 = dateTimeZone9.isLocalDateTimeGap(localDateTime20);
//        try {
//            dateTimeFormatter3.printTo(appendable4, (org.joda.time.ReadablePartial) localDateTime20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600 + "'", int7 == 57600);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57600 + "'", int16 == 57600);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "141446.251-0700");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology(chronology3);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now(chronology4);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(monthDay5);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 10);
//        int int6 = dateTime5.getSecondOfDay();
//        int int7 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone8);
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        java.lang.String str14 = dateTimeZone8.getShortName((long) (short) 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141503.549-0700" + "'", str3.equals("141503.549-0700"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600 + "'", int6 == 57600);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PST" + "'", str14.equals("PST"));
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        java.lang.String str6 = property5.getAsString();
        org.joda.time.Interval interval7 = property5.toInterval();
        org.joda.time.DateTimeField dateTimeField8 = property5.getField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "960" + "'", str6.equals("960"));
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfDay();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.Chronology chronology5 = dateTimeFormatter3.getChronology();
        boolean boolean6 = dateTimeFormatter3.isPrinter();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter3.getZone();
        java.lang.StringBuffer stringBuffer8 = null;
        try {
            dateTimeFormatter3.printTo(stringBuffer8, (long) 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(dateTimeZone7);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) ' ', 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 64L + "'", long2 == 64L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int21 = dateTime20.getMonthOfYear();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 10);
        int int24 = dateTime23.getSecondOfDay();
        long long25 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.LocalTime localTime26 = dateTime23.toLocalTime();
        org.joda.time.DateTime dateTime27 = dateTime20.withFields((org.joda.time.ReadablePartial) localTime26);
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.parse("");
        int[] intArray31 = monthDay30.getValues();
        try {
            int[] intArray33 = skipUndoDateTimeField7.set((org.joda.time.ReadablePartial) localTime26, 0, intArray31, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 57600 + "'", int24 == 57600);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertNotNull(localTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        int int6 = gJChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.parse("");
        long long10 = gJChronology5.set((org.joda.time.ReadablePartial) monthDay8, 8640000052L);
        org.joda.time.DurationField durationField11 = gJChronology5.years();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 86400052L + "'", long10 == 86400052L);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("141458.702-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '141458.702-0700' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(2000, 0, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        boolean boolean4 = instant2.isEqual((long) (byte) 1);
        org.joda.time.Instant instant6 = instant2.minus((long) 57600);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant6.minus(readableDuration7);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("millisOfSecond", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: millisOfSecond");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYear(7, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendFractionOfSecond((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatterBuilder18.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser20 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter19, dateTimeParser20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder22.append(dateTimeFormatter25);
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatterBuilder22.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder7.append(dateTimePrinter19, dateTimeParser27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder29.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder34.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendYear(7, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder36.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder44.appendFractionOfSecond((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter48 = dateTimeFormatterBuilder47.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser49 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter48, dateTimeParser49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder51.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder51.append(dateTimeFormatter54);
        org.joda.time.format.DateTimeParser dateTimeParser56 = dateTimeFormatterBuilder51.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder36.append(dateTimePrinter48, dateTimeParser56);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter19, dateTimeParser56);
        try {
            org.joda.time.DateTime dateTime60 = dateTimeFormatter58.parseDateTime("32");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"32\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimePrinter48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatter54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeParser56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.withZone(dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime4 = property2.setCopy((int) (short) 10);
        org.joda.time.Interval interval5 = property2.toInterval();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval5);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime();
        java.lang.Class<?> wildcardClass7 = dateTime6.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isAfterNow();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 82800010L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.Chronology chronology7 = gregorianChronology5.withUTC();
        try {
            long long12 = gregorianChronology5.getDateTimeMillis((int) (short) -1, (int) (byte) 0, (int) '4', 54000010);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYear(7, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendFractionOfSecond((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatterBuilder18.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser20 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter19, dateTimeParser20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder22.append(dateTimeFormatter25);
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatterBuilder22.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder7.append(dateTimePrinter19, dateTimeParser27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendFractionOfDay(1969, 57600);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalDate localDate5 = dateTimeFormatter3.parseLocalDate("141502.075-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"141502.075-0700\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime5 = dateTime1.plus((long) (short) 100);
        boolean boolean6 = dateTime5.isAfterNow();
        org.joda.time.DateTime.Property property7 = dateTime5.millisOfSecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean10 = skipUndoDateTimeField7.isLenient();
        long long13 = skipUndoDateTimeField7.add(28800000L, (long) 15);
        int int16 = skipUndoDateTimeField7.getDifference((-4L), 1L);
        java.lang.String str18 = skipUndoDateTimeField7.getAsText((long) 14);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 10);
        int int21 = dateTime20.getSecondOfDay();
        int int22 = dateTime20.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime20.getZone();
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23);
        int int25 = gJChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.parse("");
        long long29 = gJChronology24.set((org.joda.time.ReadablePartial) monthDay27, 8640000052L);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.parse("");
        int[] intArray33 = monthDay32.getValues();
        try {
            int[] intArray35 = skipUndoDateTimeField7.set((org.joda.time.ReadablePartial) monthDay27, (int) (short) -1, intArray33, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1324800000L + "'", long13 == 1324800000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wednesday" + "'", str18.equals("Wednesday"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 57600 + "'", int21 == 57600);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 86400052L + "'", long29 == 86400052L);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(intArray33);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
//        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
//        org.joda.time.DateTime dateTime7 = property3.setCopy("960");
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
//        int int10 = dateTime9.getSecondOfDay();
//        int int11 = dateTime9.getSecondOfMinute();
//        java.util.Date date12 = dateTime9.toDate();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = dateTime9.toDateTime(dateTimeZone13);
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfYear();
//        boolean boolean17 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay();
//        int int19 = monthDay18.getDayOfMonth();
//        org.joda.time.MonthDay.Property property20 = monthDay18.dayOfMonth();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = property20.getAsShortText(locale21);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property20.getAsText(locale23);
//        org.joda.time.DateTimeField dateTimeField25 = property20.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property20.getFieldType();
//        org.joda.time.DateTime dateTime28 = dateTime7.withField(dateTimeFieldType26, 12);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "15" + "'", str22.equals("15"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "15" + "'", str24.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        int int4 = mutableDateTime3.getMonthOfYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime3 = property2.roundFloorCopy();
        org.joda.time.DurationField durationField4 = property2.getRangeDurationField();
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays((int) (short) 0);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
        int int10 = dateTime9.getSecondOfDay();
        int int11 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime9.getZone();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now(dateTimeZone12);
        boolean boolean15 = monthDay5.isEqual((org.joda.time.ReadablePartial) monthDay14);
        try {
            int int16 = property2.compareTo((org.joda.time.ReadablePartial) monthDay14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        int int3 = copticChronology2.getMinimumDaysInFirstWeek();
        try {
            long long11 = copticChronology2.getDateTimeMillis(3, 1, 41, (int) (short) 0, 12, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 41 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        org.joda.time.MonthDay monthDay2 = monthDay0.plusDays((int) (short) 0);
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay();
//        int int4 = monthDay3.getDayOfMonth();
//        org.joda.time.MonthDay.Property property5 = monthDay3.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        org.joda.time.MonthDay monthDay9 = property5.setCopy(2);
//        boolean boolean10 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay9);
//        int int11 = monthDay0.getMonthOfYear();
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int7 = dateTime6.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
        int int10 = dateTime9.getSecondOfDay();
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.LocalTime localTime12 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime13 = dateTime6.withFields((org.joda.time.ReadablePartial) localTime12);
        org.joda.time.DateTime dateTime15 = dateTime6.plusHours(0);
        int int16 = dateTime6.getEra();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.DurationField durationField4 = gJChronology2.minutes();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.Instant instant6 = gJChronology2.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("Pacific Standard Time", (int) (short) 100, 54000010, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for Pacific Standard Time must be in the range [54000010,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 10);
//        int int4 = dateTime3.getSecondOfDay();
//        int int5 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone6 = dateTime3.getZone();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName(28800000L, locale8);
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 10);
//        int int13 = dateTime12.getSecondOfDay();
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime16 = dateTime12.plus((long) (short) 100);
//        org.joda.time.LocalDateTime localDateTime17 = dateTime12.toLocalDateTime();
//        boolean boolean18 = dateTimeZone6.isLocalDateTimeGap(localDateTime17);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(28800001L, dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
//        org.joda.time.Instant instant23 = gJChronology22.getGregorianCutover();
//        org.joda.time.MutableDateTime mutableDateTime24 = instant23.toMutableDateTime();
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology25 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime20, (org.joda.time.ReadableDateTime) mutableDateTime24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600 + "'", int4 == 57600);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pacific Standard Time" + "'", str9.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600 + "'", int13 == 57600);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(instant23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        long long15 = skipUndoDateTimeField7.roundHalfEven((long) (byte) 10);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField7.getAsText((long) 15, locale17);
        try {
            long long21 = skipUndoDateTimeField7.set(100L, "org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wednesday" + "'", str18.equals("Wednesday"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withFieldAdded(durationFieldType4, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime4 = property2.setCopy((int) (short) 10);
        int int5 = property2.getLeapAmount();
        org.joda.time.Interval interval6 = property2.toInterval();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(interval6);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.hourOfDay();
        org.joda.time.DurationField durationField9 = gregorianChronology5.days();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology5.dayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 10);
//        int int11 = dateTime10.getSecondOfDay();
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime14 = dateTime10.plus((long) (short) 100);
//        org.joda.time.LocalDateTime localDateTime15 = dateTime10.toLocalDateTime();
//        boolean boolean16 = dateTimeZone4.isLocalDateTimeGap(localDateTime15);
//        int int18 = dateTimeZone4.getOffsetFromLocal(0L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        int int8 = dateTime1.getWeekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
        try {
            long long11 = julianChronology0.getDateTimeMillis((int) (short) 100, (int) (short) 0, 14, 6, 0, 4, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        try {
            org.joda.time.LocalTime localTime6 = dateTimeFormatter3.parseLocalTime("����-02-15T��:��:��.000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����-02-15T��:��:��.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10, 10, 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int9 = dateTime8.getMonthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime8.minusMinutes(14);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded(0L, 0);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10);
        int int3 = dateTime2.getSecondOfDay();
        int int4 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTime2.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.hourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.yearOfCentury();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 1969, (org.joda.time.Chronology) gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600 + "'", int3 == 57600);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 10);
        int int4 = dateTime3.getSecondOfDay();
        int int5 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime3.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.Chronology chronology10 = iSOChronology1.withZone(dateTimeZone9);
        org.joda.time.DurationField durationField11 = iSOChronology1.seconds();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600 + "'", int4 == 57600);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10);
//        int int3 = dateTime2.getSecondOfDay();
//        int int4 = dateTime2.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime2.getZone();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName(28800000L, locale7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 1324800000L, dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600 + "'", int3 == 57600);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField7.getLeapDurationField();
        java.lang.String str12 = skipUndoDateTimeField7.getName();
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField7.getAsShortText(31, locale14);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfWeek" + "'", str12.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31" + "'", str15.equals("31"));
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        int int7 = property2.getMinimumValueOverall();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology9 = monthDay8.getChronology();
//        int int10 = monthDay8.size();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.MonthDay monthDay13 = monthDay8.withPeriodAdded(readablePeriod11, 0);
//        int int14 = property2.compareTo((org.joda.time.ReadablePartial) monthDay8);
//        int int15 = property2.get();
//        java.util.Locale locale16 = null;
//        int int17 = property2.getMaximumTextLength(locale16);
//        java.util.Locale locale18 = null;
//        int int19 = property2.getMaximumTextLength(locale18);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = dateTimeZone4.toString();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
        int int9 = dateTime8.getSecondOfDay();
        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) (short) 100);
        org.joda.time.LocalDateTime localDateTime13 = dateTime8.toLocalDateTime();
        boolean boolean14 = dateTimeZone4.isLocalDateTimeGap(localDateTime13);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "America/Los_Angeles" + "'", str6.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("960");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.era();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
        int int7 = dateTime6.getSecondOfDay();
        int int8 = dateTime6.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime6.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology10.getZone();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.hourOfDay();
        boolean boolean14 = iSOChronology3.equals((java.lang.Object) gregorianChronology10);
        java.lang.Object obj15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(obj15);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        org.joda.time.DateTime dateTime19 = property17.setCopy((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone20 = dateTime19.getZone();
        org.joda.time.Chronology chronology21 = gregorianChronology10.withZone(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime22 = instant1.toMutableDateTime(dateTimeZone20);
        long long23 = instant1.getMillis();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600 + "'", int7 == 57600);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-31872499622000L) + "'", long23 == (-31872499622000L));
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay();
//        int int4 = monthDay3.getDayOfMonth();
//        org.joda.time.MonthDay.Property property5 = monthDay3.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property5.getAsText(locale8);
//        org.joda.time.DateTimeField dateTimeField10 = property5.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property5.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType11);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 0L, (java.lang.Number) (-1), (java.lang.Number) 9);
//        java.lang.Throwable throwable17 = null;
//        try {
//            illegalFieldValueException16.addSuppressed(throwable17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusYears((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime1.withMillis((long) (byte) -1);
        try {
            org.joda.time.DateTime dateTime10 = dateTime6.withDate(0, (-9), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(57600);
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay();
//        int int4 = monthDay3.getDayOfMonth();
//        org.joda.time.MonthDay.Property property5 = monthDay3.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property5.getAsText(locale8);
//        org.joda.time.DateTimeField dateTimeField10 = property5.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property5.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType11);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.Chronology chronology16 = gJChronology14.withZone(dateTimeZone15);
//        org.joda.time.DurationField durationField17 = gJChronology14.eras();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.Instant instant20 = gJChronology19.getGregorianCutover();
//        org.joda.time.DurationField durationField21 = gJChronology19.minutes();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField22 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType11, durationField17, durationField21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The unit milliseconds must be at least 1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(instant20);
//        org.junit.Assert.assertNotNull(durationField21);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-1L));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfMinute(2, (int) ' ');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendSecondOfMinute((-9));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(4, (int) (byte) 0, (-28800000), 999, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("960");
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusMonths((-1));
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        java.lang.Class<?> wildcardClass5 = dateTimeFormatterBuilder4.getClass();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitYear(0, true);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder5.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMinuteOfHour(2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean10 = skipUndoDateTimeField7.isLenient();
        long long13 = skipUndoDateTimeField7.add(28800000L, (long) 15);
        int int16 = skipUndoDateTimeField7.getDifference((-4L), 1L);
        java.lang.String str18 = skipUndoDateTimeField7.getAsText((long) 14);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField7, (int) (byte) 100, 6, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [6,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1324800000L + "'", long13 == 1324800000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wednesday" + "'", str18.equals("Wednesday"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumValue(readablePartial12);
        java.lang.String str15 = skipUndoDateTimeField7.getAsText(0L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Wednesday" + "'", str15.equals("Wednesday"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField7.getLeapDurationField();
        int int13 = skipUndoDateTimeField7.getLeapAmount((long) 30);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.fromDateFields(date3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.append(dateTimeFormatter8);
        org.joda.time.Chronology chronology10 = dateTimeFormatter8.getChronology();
        boolean boolean11 = dateTimeFormatter8.isPrinter();
        java.lang.String str12 = monthDay4.toString(dateTimeFormatter8);
        try {
            org.joda.time.MonthDay monthDay14 = monthDay4.withMonthOfYear(19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "����W���T������.000" + "'", str12.equals("����W���T������.000"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
        int int9 = dateTime8.getSecondOfDay();
        int int10 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime8.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology6.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime4.toDateTime(dateTimeZone14);
        try {
            org.joda.time.DateTime dateTime18 = dateTime4.withDayOfMonth(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean10 = skipUndoDateTimeField7.isLenient();
        long long13 = skipUndoDateTimeField7.add(28800000L, (long) 15);
        int int16 = skipUndoDateTimeField7.getDifference((-4L), 1L);
        org.joda.time.DurationField durationField17 = skipUndoDateTimeField7.getLeapDurationField();
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology19 = monthDay18.getChronology();
        int int20 = monthDay18.size();
        org.joda.time.MonthDay monthDay22 = monthDay18.withDayOfMonth((int) (short) 10);
        int[] intArray28 = new int[] { (short) -1, (short) 100, 4, 2000 };
        try {
            int[] intArray30 = skipUndoDateTimeField7.addWrapField((org.joda.time.ReadablePartial) monthDay18, 30, intArray28, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 30");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1324800000L + "'", long13 == 1324800000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime9 = dateTime7.minusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.millisOfDay();
        int int13 = dateTime9.get(dateTimeField12);
        org.joda.time.DateTime dateTime15 = dateTime9.minusSeconds((int) ' ');
        int int16 = dateTime15.getWeekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 54000010 + "'", int13 == 54000010);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        long long14 = skipUndoDateTimeField7.set((long) 3, (int) (byte) 1);
        java.lang.Object obj15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.DurationField durationField19 = gJChronology17.minutes();
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(obj15, (org.joda.time.Chronology) gJChronology17);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
        org.joda.time.Instant instant23 = gJChronology22.getGregorianCutover();
        org.joda.time.DurationField durationField24 = gJChronology22.minutes();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology22);
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay();
        int int27 = monthDay26.getDayOfMonth();
        org.joda.time.MonthDay.Property property28 = monthDay26.dayOfMonth();
        java.util.Locale locale29 = null;
        java.lang.String str30 = property28.getAsShortText(locale29);
        java.util.Locale locale31 = null;
        java.lang.String str32 = property28.getAsText(locale31);
        org.joda.time.DateTimeField dateTimeField33 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property28.getFieldType();
        boolean boolean35 = dateTime25.isSupported(dateTimeFieldType34);
        int int36 = monthDay20.indexOf(dateTimeFieldType34);
        int[] intArray39 = new int[] { 19 };
        try {
            int[] intArray41 = skipUndoDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) monthDay20, 10, intArray39, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-172799997L) + "'", long14 == (-172799997L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(instant23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31" + "'", str30.equals("31"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31" + "'", str32.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        long long15 = skipUndoDateTimeField7.roundHalfEven((long) (byte) 10);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay();
        int int17 = monthDay16.getDayOfMonth();
        org.joda.time.MonthDay.Property property18 = monthDay16.dayOfMonth();
        int int19 = skipUndoDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int27 = dateTime26.getMonthOfYear();
        org.joda.time.DateTime dateTime29 = dateTime26.minusMinutes(14);
        org.joda.time.DateTime dateTime30 = monthDay16.toDateTime((org.joda.time.ReadableInstant) dateTime26);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        int int6 = gJChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.parse("");
        long long10 = gJChronology5.set((org.joda.time.ReadablePartial) monthDay8, 8640000052L);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay8.minus(readablePeriod11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 86400052L + "'", long10 == 86400052L);
        org.junit.Assert.assertNotNull(monthDay12);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime3.plusSeconds((int) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 14, (int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime5.weekOfWeekyear();
        int int10 = dateTime5.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 960 + "'", int10 == 960);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        int int1 = monthDay0.getDayOfMonth();
        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
        int int3 = property2.getMinimumValue();
        org.joda.time.MonthDay monthDay4 = property2.getMonthDay();
        java.lang.String str5 = property2.getName();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.MonthDay monthDay8 = property2.setCopy("141500.005-0700", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"141500.005-0700\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 10);
        int int4 = dateTime3.getSecondOfDay();
        int int5 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime3.getZone();
        org.joda.time.DateTime.Property property7 = dateTime3.minuteOfDay();
        org.joda.time.DurationField durationField8 = property7.getLeapDurationField();
        org.joda.time.DateTime dateTime9 = property7.roundHalfCeilingCopy();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600 + "'", int4 == 57600);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.field.FieldUtils.verifyValueBounds("141503.549-0700", 1, 0, (int) ' ');
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean10 = skipUndoDateTimeField7.isLenient();
        long long13 = skipUndoDateTimeField7.add(28800000L, (long) 15);
        int int16 = skipUndoDateTimeField7.getDifference((-4L), 1L);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology18, dateTimeField22, (int) (byte) 0);
        int int25 = skipUndoDateTimeField24.getMaximumValue();
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay();
        int int27 = monthDay26.getDayOfMonth();
        org.joda.time.MonthDay.Property property28 = monthDay26.dayOfMonth();
        java.util.Locale locale29 = null;
        java.lang.String str30 = property28.getAsShortText(locale29);
        java.util.Locale locale31 = null;
        java.lang.String str32 = property28.getAsText(locale31);
        int int33 = property28.getMinimumValueOverall();
        org.joda.time.MonthDay monthDay34 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology35 = monthDay34.getChronology();
        int int36 = monthDay34.size();
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay39 = monthDay34.withPeriodAdded(readablePeriod37, 0);
        int int40 = property28.compareTo((org.joda.time.ReadablePartial) monthDay34);
        java.util.Locale locale42 = null;
        java.lang.String str43 = skipUndoDateTimeField24.getAsText((org.joda.time.ReadablePartial) monthDay34, (int) (byte) 10, locale42);
        org.joda.time.MonthDay monthDay46 = org.joda.time.MonthDay.parse("");
        int[] intArray47 = monthDay46.getValues();
        try {
            int[] intArray49 = skipUndoDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) monthDay34, (-9), intArray47, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1324800000L + "'", long13 == 1324800000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31" + "'", str30.equals("31"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31" + "'", str32.equals("31"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10" + "'", str43.equals("10"));
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        int int1 = monthDay0.getDayOfMonth();
        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
        int int3 = property2.getMinimumValue();
        org.joda.time.MonthDay monthDay4 = property2.getMonthDay();
        java.lang.String str5 = property2.getAsShortText();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31" + "'", str5.equals("31"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusYears((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime1.withMillis((long) (byte) -1);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond(14);
        try {
            org.joda.time.DateTime dateTime13 = dateTime6.withTime(52, 19, 10, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitYear(54000010);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DurationField durationField3 = property2.getLeapDurationField();
        org.joda.time.DateTime dateTime4 = property2.roundHalfCeilingCopy();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime5.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
        int int9 = dateTime8.getSecondOfDay();
        int int10 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime8.getZone();
        org.joda.time.DateTime dateTime12 = mutableDateTime5.toDateTime(dateTimeZone11);
        int int13 = mutableDateTime5.getYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        int int3 = dateTimeFormatter0.getDefaultYear();
        boolean boolean4 = dateTimeFormatter0.isOffsetParsed();
        try {
            org.joda.time.LocalDateTime localDateTime6 = dateTimeFormatter0.parseLocalDateTime("32");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"32\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.minutes();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(obj1, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay monthDay8 = monthDay6.minusMonths((int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str10 = monthDay8.toString(dateTimeFormatter9);
        boolean boolean11 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter9);
        java.lang.Object obj12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(obj12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfSecond();
        org.joda.time.DateTime dateTime16 = property14.setCopy((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime16.getZone();
        org.joda.time.Chronology chronology18 = gregorianChronology0.withZone(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "����-08-31T��:��:��.000" + "'", str10.equals("����-08-31T��:��:��.000"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        java.lang.Appendable appendable3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withOffsetParsed();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
        int int8 = dateTime7.getSecondOfDay();
        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = dateTime7.plus((long) (short) 100);
        org.joda.time.LocalDateTime localDateTime12 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime dateTime14 = dateTime7.withYearOfEra((int) '#');
        java.lang.String str15 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime7);
        try {
            dateTimeFormatter2.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str15.equals("1969-12-31T16:00:00.010-08:00"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("960", "10");
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(259200052L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 259200052 + "'", int2 == 259200052);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        try {
//            long long17 = gJChronology8.getDateTimeMillis((int) (short) 10, (-28800000), (int) (byte) 100, 0, 259200052, (int) (byte) 1, 1970);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 259200052 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
        int int8 = dateTime7.getSecondOfDay();
        int int9 = dateTime7.getSecondOfMinute();
        java.util.Date date10 = dateTime7.toDate();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime7.toDateTime(dateTimeZone11);
        org.joda.time.DateMidnight dateMidnight14 = dateTime13.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        boolean boolean17 = gregorianChronology5.equals((java.lang.Object) dateTime16);
        org.joda.time.LocalTime localTime18 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime20 = dateTime16.withDayOfYear(14);
        org.joda.time.Chronology chronology21 = dateTime16.getChronology();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateMidnight14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekyearOfCentury();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.MonthDay monthDay2 = monthDay0.plusDays((int) (short) 0);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay();
        int int4 = monthDay3.getDayOfMonth();
        org.joda.time.MonthDay.Property property5 = monthDay3.dayOfMonth();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsShortText(locale6);
        org.joda.time.MonthDay monthDay9 = property5.setCopy(2);
        boolean boolean10 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay9);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.MonthDay monthDay13 = monthDay0.withFieldAdded(durationFieldType11, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31" + "'", str7.equals("31"));
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
        int int8 = dateTime7.getSecondOfDay();
        int int9 = dateTime7.getSecondOfMinute();
        java.util.Date date10 = dateTime7.toDate();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime7.toDateTime(dateTimeZone11);
        org.joda.time.DateMidnight dateMidnight14 = dateTime13.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        boolean boolean17 = gregorianChronology5.equals((java.lang.Object) dateTime16);
        org.joda.time.LocalTime localTime18 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime20 = dateTime16.withDayOfYear(14);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.minus(readablePeriod21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateMidnight14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.lang.Object obj1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 10);
        int int6 = dateTime5.getSecondOfDay();
        int int7 = dateTime5.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone8);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        java.util.TimeZone timeZone13 = dateTimeZone8.toTimeZone();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone8);
        try {
            org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "155959.999-0800" + "'", str3.equals("155959.999-0800"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600 + "'", int6 == 57600);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.hourOfDay();
        org.joda.time.DurationField durationField9 = gregorianChronology5.days();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMillisOfSecond(57600);
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
        int int15 = monthDay14.getDayOfMonth();
        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
        java.util.Locale locale17 = null;
        java.lang.String str18 = property16.getAsShortText(locale17);
        java.util.Locale locale19 = null;
        java.lang.String str20 = property16.getAsText(locale19);
        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType22);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31" + "'", str18.equals("31"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31" + "'", str20.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
        int int15 = monthDay14.getDayOfMonth();
        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
        java.util.Locale locale17 = null;
        java.lang.String str18 = property16.getAsShortText(locale17);
        java.util.Locale locale19 = null;
        java.lang.String str20 = property16.getAsText(locale19);
        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
        long long28 = dividedDateTimeField25.getDifferenceAsLong(0L, 215999999L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31" + "'", str18.equals("31"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31" + "'", str20.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1L) + "'", long28 == (-1L));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("����-02-15T��:��:��.000", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"����-02-15T��:��:��.000/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("960");
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay();
        int int4 = monthDay3.getDayOfMonth();
        org.joda.time.MonthDay.Property property5 = monthDay3.dayOfMonth();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsShortText(locale6);
        java.util.Locale locale8 = null;
        java.lang.String str9 = property5.getAsText(locale8);
        org.joda.time.DateTimeField dateTimeField10 = property5.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property5.getFieldType();
        org.joda.time.DateTime.Property property12 = dateTime2.property(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31" + "'", str7.equals("31"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31" + "'", str9.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime1.toMutableDateTimeISO();
        int int6 = mutableDateTime5.getSecondOfDay();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600 + "'", int6 == 57600);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology2.yearOfCentury();
        try {
            long long11 = buddhistChronology2.getDateTimeMillis((int) ' ', (-28800000), 9, 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("52", "32");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) 100);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.weekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 10);
//        int int13 = dateTime12.getSecondOfDay();
//        int int14 = dateTime12.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime12.getZone();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName(28800000L, locale17);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology19.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology19.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField23, (int) (byte) -1);
//        int int27 = skipDateTimeField25.get((long) '#');
//        int int28 = skipDateTimeField25.getMinimumValue();
//        int int30 = skipDateTimeField25.get((long) 9);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600 + "'", int13 == 57600);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 10);
        int int3 = dateTime2.getSecondOfDay();
        int int4 = dateTime2.getSecondOfMinute();
        java.util.Date date5 = dateTime2.toDate();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.withPeriodAdded(readablePeriod10, 0);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((long) (-16), chronology13);
        java.lang.String str16 = monthDay14.toString("141508.063-0700");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600 + "'", int3 == 57600);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "141508.063-0700" + "'", str16.equals("141508.063-0700"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 10);
        int int5 = dateTime4.getSecondOfDay();
        int int6 = dateTime4.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.hourOfDay();
        boolean boolean12 = iSOChronology1.equals((java.lang.Object) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology8.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600 + "'", int5 == 57600);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.withZone(dateTimeZone5);
        boolean boolean7 = dateTime6.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology(chronology3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(chronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds(0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        int int3 = copticChronology2.getMinimumDaysInFirstWeek();
        int int4 = copticChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime3.plusSeconds((int) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 14, (int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime5.weekOfWeekyear();
        java.util.Locale locale11 = null;
        try {
            org.joda.time.DateTime dateTime12 = property9.setCopy("141504.614-0700", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"141504.614-0700\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.weekOfWeekyear();
        java.lang.String str4 = buddhistChronology1.toString();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str4.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withLocale(locale6);
        java.lang.String str9 = dateTimeFormatter5.print(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "25121231T160000-0800" + "'", str9.equals("25121231T160000-0800"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean10 = skipUndoDateTimeField7.isLenient();
        long long12 = skipUndoDateTimeField7.roundCeiling((-31872499622000L));
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31872499622000L) + "'", long12 == (-31872499622000L));
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        java.util.Locale locale31 = null;
//        try {
//            long long32 = dividedDateTimeField25.set((long) (-16), "", locale31);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("10", (java.lang.Number) 0.0f, (java.lang.Number) (-1), (java.lang.Number) (-28800000));
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
        int int8 = dateTime7.getSecondOfDay();
        int int9 = dateTime7.getSecondOfMinute();
        java.util.Date date10 = dateTime7.toDate();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime7.toDateTime(dateTimeZone11);
        org.joda.time.DateMidnight dateMidnight14 = dateTime13.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        boolean boolean17 = gregorianChronology5.equals((java.lang.Object) dateTime16);
        org.joda.time.LocalTime localTime18 = dateTime16.toLocalTime();
        org.joda.time.DateTimeZone dateTimeZone19 = dateTime16.getZone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateMidnight14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        long long15 = skipUndoDateTimeField7.roundHalfCeiling(28800001L);
        boolean boolean16 = skipUndoDateTimeField7.isLenient();
        try {
            long long19 = skipUndoDateTimeField7.set((long) 960, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        java.util.Locale locale14 = null;
        int int15 = skipUndoDateTimeField7.getMaximumTextLength(locale14);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology17, dateTimeField21, (int) (byte) 0);
        int int25 = skipUndoDateTimeField23.getMaximumValue(0L);
        long long27 = skipUndoDateTimeField23.roundHalfCeiling((long) 7);
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = skipUndoDateTimeField23.getMaximumValue(readablePartial28);
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31);
        org.joda.time.Instant instant33 = gJChronology32.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        long long37 = gJChronology32.add(readablePeriod34, (long) (byte) 1, (int) 'a');
        org.joda.time.MonthDay monthDay38 = monthDay30.withChronologyRetainFields((org.joda.time.Chronology) gJChronology32);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone42);
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology40, dateTimeField44, (int) (byte) 0);
        java.util.Locale locale48 = null;
        java.lang.String str49 = skipUndoDateTimeField46.getAsText((int) '4', locale48);
        org.joda.time.DurationField durationField50 = skipUndoDateTimeField46.getLeapDurationField();
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime53 = dateTime52.withTimeAtStartOfDay();
        java.util.GregorianCalendar gregorianCalendar54 = dateTime53.toGregorianCalendar();
        org.joda.time.MonthDay monthDay55 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar54);
        org.joda.time.MonthDay monthDay56 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar54);
        org.joda.time.MonthDay monthDay58 = org.joda.time.MonthDay.parse("");
        int[] intArray59 = monthDay58.getValues();
        int int60 = skipUndoDateTimeField46.getMaximumValue((org.joda.time.ReadablePartial) monthDay56, intArray59);
        int int61 = skipUndoDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) monthDay30, intArray59);
        org.joda.time.MonthDay monthDay64 = org.joda.time.MonthDay.parse("");
        int[] intArray65 = monthDay64.getValues();
        java.util.Locale locale67 = null;
        try {
            int[] intArray68 = skipUndoDateTimeField7.set((org.joda.time.ReadablePartial) monthDay30, 0, intArray65, "52", locale67);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800000L + "'", long27 == 28800000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(instant33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1L + "'", long37 == 1L);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "52" + "'", str49.equals("52"));
        org.junit.Assert.assertNull(durationField50);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(gregorianCalendar54);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(monthDay58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 7 + "'", int60 == 7);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 7 + "'", int61 == 7);
        org.junit.Assert.assertNotNull(monthDay64);
        org.junit.Assert.assertNotNull(intArray65);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
        java.util.Locale locale11 = null;
        int int12 = skipUndoDateTimeField7.getMaximumShortTextLength(locale11);
        int int13 = skipUndoDateTimeField7.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int7 = dateTime6.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
        int int10 = dateTime9.getSecondOfDay();
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.LocalTime localTime12 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime13 = dateTime6.withFields((org.joda.time.ReadablePartial) localTime12);
        try {
            org.joda.time.DateTime dateTime15 = dateTime13.withMinuteOfHour(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField7.getLeapDurationField();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime14 = dateTime13.withTimeAtStartOfDay();
        java.util.GregorianCalendar gregorianCalendar15 = dateTime14.toGregorianCalendar();
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar15);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar15);
        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.parse("");
        int[] intArray20 = monthDay19.getValues();
        int int21 = skipUndoDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay17, intArray20);
        java.util.Locale locale22 = null;
        int int23 = skipUndoDateTimeField7.getMaximumShortTextLength(locale22);
        try {
            long long26 = skipUndoDateTimeField7.set((long) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianCalendar15);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
        org.joda.time.MonthDay monthDay7 = monthDay5.plusDays((int) (short) 0);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
        int int10 = dateTime9.getSecondOfDay();
        int int11 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime9.getZone();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now(dateTimeZone12);
        boolean boolean15 = monthDay5.isEqual((org.joda.time.ReadablePartial) monthDay14);
        java.lang.String str16 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) monthDay14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "����W���T������.000" + "'", str16.equals("����W���T������.000"));
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        org.joda.time.DurationField durationField3 = property2.getDurationField();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(durationField3);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        try {
            long long7 = copticChronology2.getDateTimeMillis((int) (short) 100, 15, 7, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) 100);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology3, dateTimeField7, (int) (byte) 0);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = skipUndoDateTimeField9.getAsText((int) '4', locale11);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay();
//        int int17 = monthDay16.getDayOfMonth();
//        org.joda.time.MonthDay.Property property18 = monthDay16.dayOfMonth();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property18.getAsShortText(locale19);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = property18.getAsText(locale21);
//        org.joda.time.DateTimeField dateTimeField23 = property18.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property18.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType24);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType24, 2);
//        long long30 = dividedDateTimeField27.getDifferenceAsLong((long) 1969, (long) ' ');
//        int int32 = dividedDateTimeField27.get(0L);
//        org.joda.time.DurationField durationField33 = dividedDateTimeField27.getDurationField();
//        boolean boolean34 = monthDay1.equals((java.lang.Object) durationField33);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "15" + "'", str22.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder5.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter6, dateTimeParser7);
        java.lang.StringBuffer stringBuffer9 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10);
        int int12 = dateTime11.getSecondOfDay();
        int int13 = dateTime11.getSecondOfMinute();
        java.util.Date date14 = dateTime11.toDate();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = dateTime11.toDateTime(dateTimeZone15);
        org.joda.time.DateTime dateTime19 = dateTime17.minusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.millisOfDay();
        int int23 = dateTime19.get(dateTimeField22);
        org.joda.time.DateTime dateTime25 = dateTime19.minusSeconds((int) ' ');
        try {
            dateTimeFormatter8.printTo(stringBuffer9, (org.joda.time.ReadableInstant) dateTime25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600 + "'", int12 == 57600);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 54000010 + "'", int23 == 54000010);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, 0, (int) (byte) -1, 15, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.plusMillis((int) '4');
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withDate(59, 999, (-16));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 10);
        int int5 = dateTime4.getSecondOfDay();
        int int6 = dateTime4.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.hourOfDay();
        boolean boolean12 = iSOChronology1.equals((java.lang.Object) gregorianChronology8);
        java.lang.String str13 = iSOChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600 + "'", int5 == 57600);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str13.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField7.getDurationField();
        long long15 = durationField12.subtract((long) (-16), 0);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField17 = new org.joda.time.field.DecoratedDurationField(durationField12, durationFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-16L) + "'", long15 == (-16L));
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 215999999L, "32");
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType22, 355, 2000, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 355 for dayOfMonth must be in the range [2000,0]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay();
//        int int4 = monthDay3.getDayOfMonth();
//        org.joda.time.MonthDay.Property property5 = monthDay3.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property5.getAsText(locale8);
//        org.joda.time.DateTimeField dateTimeField10 = property5.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property5.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType11);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 0L, (java.lang.Number) (-1), (java.lang.Number) 9);
//        java.lang.String str17 = illegalFieldValueException16.getIllegalValueAsString();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        int int7 = property2.getMinimumValue();
//        int int8 = property2.getMinimumValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DurationField durationField3 = property2.getLeapDurationField();
        org.joda.time.DateTime dateTime4 = property2.roundHalfCeilingCopy();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime5.toMutableDateTimeISO();
        int int7 = mutableDateTime5.getCenturyOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendDecimal(dateTimeFieldType7, 3, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int7 = dateTime6.getMonthOfYear();
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime();
        org.joda.time.DateTime.Property property9 = dateTime6.dayOfYear();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
        int int9 = dateTime8.getSecondOfDay();
        int int10 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime8.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology6.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime4.toDateTime(dateTimeZone14);
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        org.joda.time.Chronology chronology18 = copticChronology17.withUTC();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-9));
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int9 = dateTime8.getMonthOfYear();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10);
        int int12 = dateTime11.getSecondOfDay();
        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.LocalTime localTime14 = dateTime11.toLocalTime();
        org.joda.time.DateTime dateTime15 = dateTime8.withFields((org.joda.time.ReadablePartial) localTime14);
        int int16 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long19 = cachedDateTimeZone17.previousTransition(1324800000L);
        int int21 = cachedDateTimeZone17.getOffset((long) 9);
        long long23 = cachedDateTimeZone17.previousTransition((long) 59);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600 + "'", int12 == 57600);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-9) + "'", int16 == (-9));
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1324800000L + "'", long19 == 1324800000L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-9) + "'", int21 == (-9));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 59L + "'", long23 == 59L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        java.lang.Class<?> wildcardClass5 = dateTimeFormatterBuilder4.getClass();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitYear(0, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendYear(7, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendFractionOfSecond((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatterBuilder27.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser29 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter28, dateTimeParser29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder31.append(dateTimeFormatter34);
        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatterBuilder31.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder16.append(dateTimePrinter28, dateTimeParser36);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder38.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder43.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.appendYear(7, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder45.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder51.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder53.appendFractionOfSecond((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter57 = dateTimeFormatterBuilder56.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser58 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter57, dateTimeParser58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder60.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder60.append(dateTimeFormatter63);
        org.joda.time.format.DateTimeParser dateTimeParser65 = dateTimeFormatterBuilder60.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder45.append(dateTimePrinter57, dateTimeParser65);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter28, dateTimeParser65);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder68.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder68.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder72.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder74.appendFractionOfSecond((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter78 = dateTimeFormatterBuilder77.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser79 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter80 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter78, dateTimeParser79);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder81.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter84 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder85 = dateTimeFormatterBuilder81.append(dateTimeFormatter84);
        org.joda.time.format.DateTimeParser dateTimeParser86 = dateTimeFormatterBuilder81.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder87 = dateTimeFormatterBuilder68.append(dateTimePrinter78, dateTimeParser86);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder88 = dateTimeFormatterBuilder8.append(dateTimePrinter28, dateTimeParser86);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap89 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder90 = dateTimeFormatterBuilder88.appendTimeZoneName(strMap89);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeParser36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimePrinter57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatter63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimeParser65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
        org.junit.Assert.assertNotNull(dateTimePrinter78);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertNotNull(dateTimeFormatter84);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder85);
        org.junit.Assert.assertNotNull(dateTimeParser86);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder87);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder88);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder90);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        int int3 = property2.getMinimumValue();
//        org.joda.time.MonthDay monthDay4 = property2.getMonthDay();
//        java.lang.String str5 = property2.getName();
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        try {
//            int int7 = property2.compareTo(readablePartial6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("960");
//        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 10);
//        int int5 = dateTime4.getSecondOfDay();
//        int int6 = dateTime4.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        java.lang.String str9 = dateTimeZone7.toString();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10);
//        int int12 = dateTime11.getSecondOfDay();
//        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime15 = dateTime11.plus((long) (short) 100);
//        org.joda.time.LocalDateTime localDateTime16 = dateTime11.toLocalDateTime();
//        boolean boolean17 = dateTimeZone7.isLocalDateTimeGap(localDateTime16);
//        long long19 = dateTimeZone7.convertUTCToLocal((long) 12);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone7.getShortName(1560668400000L, locale21);
//        org.joda.time.MutableDateTime mutableDateTime23 = instant1.toMutableDateTime(dateTimeZone7);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600 + "'", int5 == 57600);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600 + "'", int12 == 57600);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-28799988L) + "'", long19 == (-28799988L));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PDT" + "'", str22.equals("PDT"));
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        java.util.GregorianCalendar gregorianCalendar3 = dateTime2.toGregorianCalendar();
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar3);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar3);
        boolean boolean6 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay5);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gregorianCalendar3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 10);
//        int int5 = dateTime4.getSecondOfDay();
//        int int6 = dateTime4.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.hourOfDay();
//        boolean boolean12 = iSOChronology1.equals((java.lang.Object) gregorianChronology8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.Object obj14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(obj14);
//        java.lang.String str16 = dateTimeFormatter13.print((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 10);
//        int int19 = dateTime18.getSecondOfDay();
//        int int20 = dateTime18.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTime18.getZone();
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter13.withZone(dateTimeZone21);
//        org.joda.time.Chronology chronology24 = iSOChronology1.withZone(dateTimeZone21);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600 + "'", int5 == 57600);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "141519.147-0700" + "'", str16.equals("141519.147-0700"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57600 + "'", int19 == 57600);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(chronology24);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTwoDigitYear(57600, true);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendTimeZoneOffset("141453.816-0700", "dayOfWeek", false, 960, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        java.lang.Class<?> wildcardClass5 = dateTimeFormatterBuilder4.getClass();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitYear(0, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendDayOfYear(54000010);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 10);
        int int5 = dateTime4.getSecondOfDay();
        int int6 = dateTime4.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.hourOfDay();
        boolean boolean12 = iSOChronology1.equals((java.lang.Object) gregorianChronology8);
        java.lang.Object obj13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = property15.setCopy((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
        org.joda.time.Chronology chronology19 = gregorianChronology8.withZone(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology8.era();
        java.lang.Class<?> wildcardClass21 = gregorianChronology8.getClass();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600 + "'", int5 == 57600);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        try {
            long long9 = julianChronology0.getDateTimeMillis(31, 0, 69, 2000, 100, 1970, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        try {
            long long13 = gregorianChronology5.getDateTimeMillis(0, (-16), 2000, 1970, (int) '4', (-1), 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean10 = skipUndoDateTimeField7.isLenient();
        long long13 = skipUndoDateTimeField7.add(28800000L, (long) 15);
        int int16 = skipUndoDateTimeField7.getDifference((-4L), 1L);
        java.lang.String str18 = skipUndoDateTimeField7.getAsText((long) 14);
        try {
            long long21 = skipUndoDateTimeField7.set((long) 0, "141508.063-0700");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"141508.063-0700\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1324800000L + "'", long13 == 1324800000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wednesday" + "'", str18.equals("Wednesday"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        org.joda.time.DurationField durationField6 = property5.getLeapDurationField();
        boolean boolean7 = property5.isLeap();
        java.lang.String str8 = property5.getAsString();
        org.joda.time.DurationField durationField9 = property5.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField10 = property5.getField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "960" + "'", str8.equals("960"));
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
        java.util.Date date5 = dateTime1.toDate();
        boolean boolean7 = dateTime1.isAfter(100L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        try {
            long long10 = julianChronology1.getDateTimeMillis((int) (short) -1, 31, 3, (int) (short) 1, (int) (byte) 10, 54000010, 21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54000010 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusYears((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
        int int9 = dateTime8.getSecondOfDay();
        int int10 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime8.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
        org.joda.time.Chronology chronology15 = iSOChronology6.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime4.toDateTime(dateTimeZone14);
        org.joda.time.DateTime.Property property17 = dateTime4.weekyear();
        org.joda.time.DurationFieldType durationFieldType18 = null;
        try {
            org.joda.time.DateTime dateTime20 = dateTime4.withFieldAdded(durationFieldType18, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 10);
//        int int6 = dateTime5.getSecondOfDay();
//        int int7 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone8);
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        java.util.TimeZone timeZone13 = dateTimeZone8.toTimeZone();
//        int int15 = dateTimeZone8.getOffsetFromLocal((long) '4');
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141520.244-0700" + "'", str3.equals("141520.244-0700"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600 + "'", int6 == 57600);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder5.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYearOfCentury(9, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendLiteral('#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        int int10 = dateTime8.getSecondOfMinute();
//        java.util.Date date11 = dateTime8.toDate();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime8.toMutableDateTime(dateTimeZone12);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 10);
//        int int16 = dateTime15.getSecondOfDay();
//        int int17 = dateTime15.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone18 = dateTime15.getZone();
//        java.lang.String str19 = dateTimeZone18.toString();
//        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime13.toMutableDateTime(dateTimeZone18);
//        int int21 = property2.compareTo((org.joda.time.ReadableInstant) mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57600 + "'", int16 == 57600);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "America/Los_Angeles" + "'", str19.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("4");
        org.junit.Assert.assertNotNull(monthDay1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int7 = dateTime6.getMonthOfYear();
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime();
        long long9 = dateTime6.getMillis();
        int int10 = dateTime6.getWeekyear();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62111167561000L) + "'", long9 == (-62111167561000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "����-02-15T��:��:��.000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
        int int8 = dateTime7.getSecondOfDay();
        int int9 = dateTime7.getSecondOfMinute();
        java.util.Date date10 = dateTime7.toDate();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime7.toDateTime(dateTimeZone11);
        org.joda.time.DateMidnight dateMidnight14 = dateTime13.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        boolean boolean17 = gregorianChronology5.equals((java.lang.Object) dateTime16);
        org.joda.time.LocalTime localTime18 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime20 = dateTime16.withDayOfYear(14);
        org.joda.time.DateTime.Property property21 = dateTime16.dayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateMidnight14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-97) + "'", int1 == (-97));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean11 = skipUndoDateTimeField7.isLeap((long) 355);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(readableInterval4);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.toString();
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported"));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int7 = dateTime6.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
        int int10 = dateTime9.getSecondOfDay();
        int int11 = dateTime9.getSecondOfMinute();
        java.util.Date date12 = dateTime9.toDate();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime9.toDateTime(dateTimeZone13);
        org.joda.time.DateMidnight dateMidnight16 = dateTime15.toDateMidnight();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime21 = dateTime15.withDate((-16), 2, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusYears((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime1.withMillis((long) (byte) -1);
        org.joda.time.DateTime dateTime8 = dateTime1.minusWeeks((-16));
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
        int int9 = dateTime8.getSecondOfDay();
        int int10 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime8.getZone();
        java.lang.String str12 = dateTimeZone11.toString();
        org.joda.time.MutableDateTime mutableDateTime13 = mutableDateTime6.toMutableDateTime(dateTimeZone11);
        boolean boolean15 = mutableDateTime6.isBefore(86400052L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 10);
//        int int6 = dateTime5.getSecondOfDay();
//        int int7 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone8);
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology11.getZone();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTime dateTime15 = dateTime14.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime17 = dateTime14.minusYears((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 10);
//        int int22 = dateTime21.getSecondOfDay();
//        int int23 = dateTime21.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone24 = dateTime21.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
//        org.joda.time.Chronology chronology28 = iSOChronology19.withZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = dateTime17.toDateTime(dateTimeZone27);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField31 = buddhistChronology30.centuries();
//        org.joda.time.DateTime dateTime32 = dateTime29.toDateTime((org.joda.time.Chronology) buddhistChronology30);
//        boolean boolean33 = copticChronology11.equals((java.lang.Object) dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141521.758-0700" + "'", str3.equals("141521.758-0700"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600 + "'", int6 == 57600);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 57600 + "'", int22 == 57600);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(buddhistChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        java.lang.String str10 = property9.toString();
        int int11 = property9.getMinimumValueOverall();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[year]" + "'", str10.equals("Property[year]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-292275054) + "'", int11 == (-292275054));
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long27 = dividedDateTimeField25.roundHalfFloor((long) 19);
//        java.util.Locale locale30 = null;
//        try {
//            long long31 = dividedDateTimeField25.set(104138006400010L, "dayOfWeek", locale30);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"dayOfWeek\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800000L + "'", long27 == 28800000L);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.plus(readablePeriod10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-62111167561000L));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusYears((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime1.withMillis((long) (byte) -1);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond(14);
        org.joda.time.DateTime.Property property9 = dateTime6.yearOfEra();
        org.joda.time.DateTime dateTime11 = dateTime6.plusSeconds(0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.weekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 10);
//        int int13 = dateTime12.getSecondOfDay();
//        int int14 = dateTime12.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime12.getZone();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName(28800000L, locale17);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology19.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology19.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField23, (int) (byte) -1);
//        long long28 = skipDateTimeField25.addWrapField(0L, 0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600 + "'", int13 == 57600);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.hourOfHalfday();
        try {
            long long14 = gJChronology5.getDateTimeMillis(1, 31, 54000010, (int) (byte) -1, 4, 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYear(10, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneId();
        boolean boolean7 = dateTimeFormatterBuilder5.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1970);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        org.joda.time.DurationField durationField3 = iSOChronology1.months();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean10 = skipUndoDateTimeField7.isLenient();
        long long13 = skipUndoDateTimeField7.add(28800000L, (long) 15);
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology16, dateTimeField20, (int) (byte) 0);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField22.getAsText((int) '4', locale24);
        int int27 = skipUndoDateTimeField22.get((long) (byte) -1);
        java.lang.String str28 = skipUndoDateTimeField22.getName();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 10);
        int int31 = dateTime30.getSecondOfDay();
        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime34 = dateTime30.plus((long) (short) 100);
        org.joda.time.LocalDateTime localDateTime35 = dateTime30.toLocalDateTime();
        int[] intArray38 = new int[] { (byte) -1, 4 };
        int int39 = skipUndoDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) localDateTime35, intArray38);
        int int40 = skipUndoDateTimeField7.getMaximumValue(readablePartial14, intArray38);
        long long42 = skipUndoDateTimeField7.roundCeiling(1560633283315L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1324800000L + "'", long13 == 1324800000L);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "52" + "'", str25.equals("52"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "dayOfWeek" + "'", str28.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 57600 + "'", int31 == 57600);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDateTime35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 7 + "'", int40 == 7);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560668400000L + "'", long42 == 1560668400000L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.withPeriodAdded(readablePeriod9, 0);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes((int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType14 = null;
        try {
            org.joda.time.DateTime dateTime16 = dateTime11.withFieldAdded(durationFieldType14, (-16));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(57600);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(54000010, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear(52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime4 = property2.setCopy((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTime4.getZone();
        org.joda.time.DateTime.Property property6 = dateTime4.weekyear();
        java.lang.String str7 = property6.getAsString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = dividedDateTimeField25.getAsText(57600, locale30);
//        try {
//            long long34 = dividedDateTimeField25.set(215999999L, "141519.147-0700");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"141519.147-0700\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "57600" + "'", str31.equals("57600"));
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DurationField durationField3 = property2.getLeapDurationField();
        org.joda.time.DateTime dateTime4 = property2.roundHalfCeilingCopy();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime5.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 10);
        int int9 = dateTime8.getSecondOfDay();
        int int10 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime8.getZone();
        org.joda.time.DateTime dateTime12 = mutableDateTime5.toDateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime15 = dateTime13.plusMillis((int) (byte) -1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
        int int8 = dateTime7.getSecondOfDay();
        int int9 = dateTime7.getSecondOfMinute();
        java.util.Date date10 = dateTime7.toDate();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime7.toDateTime(dateTimeZone11);
        org.joda.time.DateMidnight dateMidnight14 = dateTime13.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        boolean boolean17 = gregorianChronology5.equals((java.lang.Object) dateTime16);
        org.joda.time.LocalTime localTime18 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime20 = dateTime16.withDayOfYear(14);
        int int21 = dateTime20.getYearOfEra();
        org.joda.time.DateTime dateTime23 = dateTime20.withYearOfEra(41);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateMidnight14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime4 = property2.setCopy((int) (short) 10);
        int int5 = property2.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 999 + "'", int5 == 999);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        long long16 = skipUndoDateTimeField7.add(104138006400010L, 0);
        java.lang.Object obj17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.Instant instant20 = gJChronology19.getGregorianCutover();
        org.joda.time.DurationField durationField21 = gJChronology19.minutes();
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(obj17, (org.joda.time.Chronology) gJChronology19);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay22.minus(readablePeriod23);
        java.util.Locale locale25 = null;
        try {
            java.lang.String str26 = skipUndoDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) monthDay22, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 104138006400010L + "'", long16 == 104138006400010L);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(monthDay24);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime1.minusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
        int int8 = dateTime7.getSecondOfDay();
        int int9 = dateTime7.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = dateTime1.withZoneRetainFields(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        int int2 = dateTime1.getEra();
//        int int3 = dateTime1.getMinuteOfHour();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendCenturyOfEra(3, (int) (short) 1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendHourOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-9));
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) 54000010);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName((long) 57600, locale5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.009" + "'", str6.equals("-00:00:00.009"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("141458.702-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"141458.702-0700\" is malformed at \".702-0700\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime1.toDateTime(dateTimeZone5);
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        int int9 = dateMidnight8.getMonthOfYear();
        int int10 = dateMidnight8.getMillisOfSecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYear(7, 54000010);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendWeekOfWeekyear((int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.append(dateTimeFormatter4);
        org.joda.time.Chronology chronology6 = dateTimeFormatter4.getChronology();
        boolean boolean7 = dateTimeFormatter4.isPrinter();
        try {
            org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.parse("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported", dateTimeFormatter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField7.getLeapDurationField();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime14 = dateTime13.withTimeAtStartOfDay();
        java.util.GregorianCalendar gregorianCalendar15 = dateTime14.toGregorianCalendar();
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar15);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar15);
        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.parse("");
        int[] intArray20 = monthDay19.getValues();
        int int21 = skipUndoDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay17, intArray20);
        java.util.Locale locale22 = null;
        int int23 = skipUndoDateTimeField7.getMaximumShortTextLength(locale22);
        try {
            org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((java.lang.Object) skipUndoDateTimeField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.field.SkipUndoDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianCalendar15);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        org.joda.time.DurationField durationField6 = property5.getLeapDurationField();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "960" + "'", str8.equals("960"));
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
//        org.joda.time.DurationField durationField3 = property2.getLeapDurationField();
//        org.joda.time.DateTimeField dateTimeField4 = property2.getField();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        org.joda.time.DateTime dateTime8 = property2.setCopy(0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "628" + "'", str6.equals("628"));
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.Instant instant17 = gJChronology16.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        long long21 = gJChronology16.add(readablePeriod18, (long) (byte) 1, (int) 'a');
        org.joda.time.MonthDay monthDay22 = monthDay14.withChronologyRetainFields((org.joda.time.Chronology) gJChronology16);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology24, dateTimeField28, (int) (byte) 0);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField30.getAsText((int) '4', locale32);
        org.joda.time.DurationField durationField34 = skipUndoDateTimeField30.getLeapDurationField();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime37 = dateTime36.withTimeAtStartOfDay();
        java.util.GregorianCalendar gregorianCalendar38 = dateTime37.toGregorianCalendar();
        org.joda.time.MonthDay monthDay39 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar38);
        org.joda.time.MonthDay monthDay40 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar38);
        org.joda.time.MonthDay monthDay42 = org.joda.time.MonthDay.parse("");
        int[] intArray43 = monthDay42.getValues();
        int int44 = skipUndoDateTimeField30.getMaximumValue((org.joda.time.ReadablePartial) monthDay40, intArray43);
        int int45 = skipUndoDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay14, intArray43);
        try {
            long long48 = skipUndoDateTimeField7.set((-16L), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [0,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "52" + "'", str33.equals("52"));
        org.junit.Assert.assertNull(durationField34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(gregorianCalendar38);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 7 + "'", int44 == 7);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 7 + "'", int45 == 7);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 10);
//        int int6 = dateTime5.getSecondOfDay();
//        int int7 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone8);
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.Chronology chronology14 = gregorianChronology13.withUTC();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141525.693-0700" + "'", str3.equals("141525.693-0700"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600 + "'", int6 == 57600);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        org.joda.time.DateTimeField dateTimeField7 = property2.getField();
//        org.joda.time.MonthDay monthDay9 = property2.addToCopy(59);
//        java.util.Locale locale11 = null;
//        try {
//            org.joda.time.MonthDay monthDay12 = property2.setCopy("PDT", locale11);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PDT\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(monthDay9);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField9 = gJChronology8.months();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(readableInterval3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.minus(readablePeriod6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now(dateTimeZone4);
        long long10 = dateTimeZone4.convertLocalToUTC(215999999L, true, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 244799999L + "'", long10 == 244799999L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        java.util.GregorianCalendar gregorianCalendar3 = dateTime2.toGregorianCalendar();
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar3);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar3);
        org.joda.time.MonthDay monthDay7 = monthDay5.withMonthOfYear(4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = null;
        java.lang.String str9 = monthDay5.toString(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gregorianCalendar3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "--12-31" + "'", str9.equals("--12-31"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (byte) 1, (int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatterBuilder9.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser11 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter10, dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.append(dateTimeFormatter16);
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatterBuilder13.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder0.append(dateTimePrinter10, dateTimeParser18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(7, true);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.appendYear((-97), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.DurationField durationField4 = gJChronology2.minutes();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 10);
        int int8 = dateTime7.getSecondOfDay();
        int int9 = dateTime7.getSecondOfMinute();
        java.util.Date date10 = dateTime7.toDate();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime7.toDateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.millisOfDay();
        int int19 = dateTime15.get(dateTimeField18);
        int int20 = dateTime5.get(dateTimeField18);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 54000010 + "'", int19 == 54000010);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 57600010 + "'", int20 == 57600010);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 10);
//        int int6 = dateTime5.getSecondOfDay();
//        int int7 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone8);
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        try {
//            int[] intArray15 = copticChronology11.get(readablePeriod12, 230400000L, (long) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141526.473-0700" + "'", str3.equals("141526.473-0700"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600 + "'", int6 == 57600);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(copticChronology11);
//    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        int int6 = gJChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField7 = gJChronology5.minutes();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gJChronology5.withZone(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        long long10 = gJChronology5.add(readablePeriod7, (long) (byte) 1, (int) 'a');
//        org.joda.time.MonthDay monthDay11 = monthDay3.withChronologyRetainFields((org.joda.time.Chronology) gJChronology5);
//        boolean boolean12 = monthDay0.isAfter((org.joda.time.ReadablePartial) monthDay11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        try {
//            boolean boolean14 = monthDay11.isBefore(readablePartial13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("141517.179-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"141517.179-0700\" is malformed at \".179-0700\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0, (java.lang.Number) 3, (java.lang.Number) 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        try {
            long long2 = dateTimeFormatter0.parseMillis("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfMinute(9, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear((int) ' ', true);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendTimeZoneOffset("", false, 57600010, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.halfdayOfDay();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(59, 3, (int) 'a', 10, 0, (org.joda.time.Chronology) buddhistChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField7.getDurationField();
        int int13 = skipUndoDateTimeField7.getMinimumValue();
        int int14 = skipUndoDateTimeField7.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        int int7 = property2.getMinimumValueOverall();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology9 = monthDay8.getChronology();
//        int int10 = monthDay8.size();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.MonthDay monthDay13 = monthDay8.withPeriodAdded(readablePeriod11, 0);
//        int int14 = property2.compareTo((org.joda.time.ReadablePartial) monthDay8);
//        int int15 = property2.get();
//        int int16 = property2.getMaximumValue();
//        org.joda.time.MonthDay monthDay17 = property2.getMonthDay();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 30 + "'", int16 == 30);
//        org.junit.Assert.assertNotNull(monthDay17);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 960, 999, (-9), 2000, (int) (byte) -1, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
//        org.joda.time.DurationField durationField3 = property2.getLeapDurationField();
//        org.joda.time.DateTimeField dateTimeField4 = property2.getField();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        org.joda.time.DateTime dateTime8 = property2.setCopy(999);
//        int int9 = dateTime8.getMonthOfYear();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "371" + "'", str6.equals("371"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumValue(readablePartial12);
        boolean boolean14 = skipUndoDateTimeField7.isSupported();
        java.lang.String str16 = skipUndoDateTimeField7.getAsShortText(86400052L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Thu" + "'", str16.equals("Thu"));
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology8.centuryOfEra();
//        org.joda.time.DurationField durationField14 = gJChronology8.years();
//        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology8.getZone();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfDay((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendCenturyOfEra(52, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 10);
//        int int6 = dateTime5.getSecondOfDay();
//        int int7 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone8);
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendClockhourOfHalfday((int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendClockhourOfHalfday((int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendFractionOfSecond((int) (byte) 1, (int) (short) -1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter24 = dateTimeFormatterBuilder23.toPrinter();
//        org.joda.time.format.DateTimeParser dateTimeParser25 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter24, dateTimeParser25);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendClockhourOfHalfday((int) (short) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder27.append(dateTimeFormatter30);
//        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatterBuilder27.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder14.append(dateTimePrinter24, dateTimeParser32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(7, true);
//        boolean boolean37 = gregorianChronology13.equals((java.lang.Object) dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141527.685-0700" + "'", str3.equals("141527.685-0700"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600 + "'", int6 == 57600);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimePrinter24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeParser32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
//        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
//        org.joda.time.DurationField durationField4 = gJChronology2.minutes();
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(obj0, (org.joda.time.Chronology) gJChronology2);
//        org.joda.time.MonthDay monthDay7 = monthDay5.minusMonths((int) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        java.lang.String str9 = monthDay7.toString(dateTimeFormatter8);
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.Chronology chronology13 = julianChronology10.withZone(dateTimeZone11);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getChronology(chronology13);
//        org.joda.time.MonthDay monthDay15 = monthDay7.withChronologyRetainFields(chronology14);
//        org.joda.time.MonthDay monthDay17 = monthDay15.plusMonths(15);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        try {
//            boolean boolean19 = monthDay17.isBefore(readablePartial18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "����-02-15T��:��:��.000" + "'", str9.equals("����-02-15T��:��:��.000"));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(monthDay17);
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
//        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology13 = monthDay12.getChronology();
//        int int14 = monthDay12.size();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.MonthDay monthDay16 = monthDay12.plus(readablePeriod15);
//        int int18 = monthDay16.getValue((int) (short) 0);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = skipUndoDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) monthDay16, 21, locale20);
//        org.joda.time.MonthDay.Property property22 = monthDay16.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 10);
//        int int27 = dateTime26.getSecondOfDay();
//        int int28 = dateTime26.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone29 = dateTime26.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone32 = gregorianChronology30.getZone();
//        org.joda.time.Chronology chronology33 = iSOChronology24.withZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 10);
//        int int36 = dateTime35.getSecondOfDay();
//        int int37 = dateTime35.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone38 = dateTime35.getZone();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dateTimeZone38.getName(28800000L, locale40);
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) 10);
//        int int45 = dateTime44.getSecondOfDay();
//        long long46 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTime dateTime48 = dateTime44.plus((long) (short) 100);
//        org.joda.time.LocalDateTime localDateTime49 = dateTime44.toLocalDateTime();
//        boolean boolean50 = dateTimeZone38.isLocalDateTimeGap(localDateTime49);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology51 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.Chronology chronology52 = iSOChronology24.withZone(dateTimeZone38);
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology24.dayOfWeek();
//        try {
//            org.joda.time.MonthDay monthDay54 = new org.joda.time.MonthDay((java.lang.Object) property22, (org.joda.time.Chronology) iSOChronology24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.MonthDay$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "21" + "'", str21.equals("21"));
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 57600 + "'", int27 == 57600);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 57600 + "'", int36 == 57600);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Pacific Standard Time" + "'", str41.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 57600 + "'", int45 == 57600);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(localDateTime49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology51);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = dividedDateTimeField25.getAsText(57600, locale30);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dividedDateTimeField25.getAsText((long) 1969, locale33);
//        long long36 = dividedDateTimeField25.remainder((long) (-292275054));
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "57600" + "'", str31.equals("57600"));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-637875054L) + "'", long36 == (-637875054L));
//    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField25);
//        long long32 = remainderDateTimeField29.addWrapField((long) (-1), 7);
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone38);
//        org.joda.time.DateTimeField dateTimeField40 = buddhistChronology39.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology36, dateTimeField40, (int) (byte) 0);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = skipUndoDateTimeField42.getAsText((int) '4', locale44);
//        org.joda.time.DurationField durationField46 = skipUndoDateTimeField42.getLeapDurationField();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 10);
//        org.joda.time.DateTime dateTime49 = dateTime48.withTimeAtStartOfDay();
//        java.util.GregorianCalendar gregorianCalendar50 = dateTime49.toGregorianCalendar();
//        org.joda.time.MonthDay monthDay51 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar50);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar50);
//        org.joda.time.MonthDay monthDay54 = org.joda.time.MonthDay.parse("");
//        int[] intArray55 = monthDay54.getValues();
//        int int56 = skipUndoDateTimeField42.getMaximumValue((org.joda.time.ReadablePartial) monthDay52, intArray55);
//        try {
//            int[] intArray58 = remainderDateTimeField29.addWrapPartial(readablePartial33, (int) (short) 0, intArray55, 2000);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-86400001L) + "'", long32 == (-86400001L));
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "52" + "'", str45.equals("52"));
//        org.junit.Assert.assertNull(durationField46);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(gregorianCalendar50);
//        org.junit.Assert.assertNotNull(monthDay51);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 7 + "'", int56 == 7);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.millisOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours(999);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        java.util.Locale locale12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumShortTextLength(locale12);
        java.util.Locale locale14 = null;
        int int15 = skipUndoDateTimeField7.getMaximumTextLength(locale14);
        boolean boolean16 = skipUndoDateTimeField7.isSupported();
        long long18 = skipUndoDateTimeField7.roundHalfEven((-6L));
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField7.getAsText(259200052, locale20);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "259200052" + "'", str21.equals("259200052"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-9));
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int9 = dateTime8.getMonthOfYear();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10);
        int int12 = dateTime11.getSecondOfDay();
        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.LocalTime localTime14 = dateTime11.toLocalTime();
        org.joda.time.DateTime dateTime15 = dateTime8.withFields((org.joda.time.ReadablePartial) localTime14);
        int int16 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean19 = dateTimeZone1.isStandardOffset((long) 20);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600 + "'", int12 == 57600);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-9) + "'", int16 == (-9));
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        int int7 = dateTime6.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
        int int10 = dateTime9.getSecondOfDay();
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.LocalTime localTime12 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime13 = dateTime6.withFields((org.joda.time.ReadablePartial) localTime12);
        org.joda.time.DateTime dateTime14 = dateTime6.toDateTimeISO();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        org.joda.time.MonthDay monthDay8 = property2.addWrapFieldToCopy(19);
//        java.util.Locale locale9 = null;
//        int int10 = property2.getMaximumTextLength(locale9);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(28800000L, locale6);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology8.centuryOfEra();
//        org.joda.time.DurationField durationField14 = gJChronology8.hours();
//        try {
//            long long22 = gJChronology8.getDateTimeMillis(2, 19, 59, 21, 6, 0, 19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
        int int10 = dateTime9.getSecondOfDay();
        int int11 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime9.getZone();
        java.lang.String str13 = dateTimeZone12.toString();
        org.joda.time.Chronology chronology14 = buddhistChronology1.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField15 = buddhistChronology1.years();
        long long18 = durationField15.subtract((long) (short) -1, (long) (-16));
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 504921599999L + "'", long18 == 504921599999L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("141519.521-0700", 0, 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for 141519.521-0700 must be in the range [1,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology2 = monthDay1.getChronology();
//        int int3 = monthDay1.size();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay1.withPeriodAdded(readablePeriod4, 0);
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay();
//        org.joda.time.MonthDay monthDay9 = monthDay7.plusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 10);
//        int int12 = dateTime11.getSecondOfDay();
//        int int13 = dateTime11.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime11.getZone();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14);
//        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone14);
//        boolean boolean17 = monthDay7.isEqual((org.joda.time.ReadablePartial) monthDay16);
//        boolean boolean18 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay16);
//        java.lang.String str19 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600 + "'", int12 == 57600);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "�, June 15, ����" + "'", str19.equals("�, June 15, ����"));
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 10, (int) (byte) 10, 10, (int) (short) 1, (int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfMinute();
        try {
            org.joda.time.DateTime dateTime9 = property7.setCopy("141517.179-0700");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"141517.179-0700\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
//        org.joda.time.DurationField durationField3 = gJChronology1.minutes();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay();
//        int int6 = monthDay5.getDayOfMonth();
//        org.joda.time.MonthDay.Property property7 = monthDay5.dayOfMonth();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsShortText(locale8);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property7.getAsText(locale10);
//        org.joda.time.DateTimeField dateTimeField12 = property7.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property7.getFieldType();
//        boolean boolean14 = dateTime4.isSupported(dateTimeFieldType13);
//        org.joda.time.DateTime dateTime16 = dateTime4.minusHours(1);
//        try {
//            org.joda.time.DateTime dateTime18 = dateTime4.withMillisOfDay((-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay();
//        int int4 = monthDay3.getDayOfMonth();
//        org.joda.time.MonthDay.Property property5 = monthDay3.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property5.getAsText(locale8);
//        org.joda.time.DateTimeField dateTimeField10 = property5.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property5.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType11);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 0L, (java.lang.Number) (-1), (java.lang.Number) 9);
//        org.joda.time.DurationFieldType durationFieldType17 = illegalFieldValueException16.getDurationFieldType();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNull(durationFieldType17);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean10 = skipUndoDateTimeField7.isLenient();
        int int12 = skipUndoDateTimeField7.get((long) (-9));
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        long long11 = skipUndoDateTimeField7.roundHalfCeiling((long) 7);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = skipUndoDateTimeField7.getMaximumValue(readablePartial12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, 14);
        long long17 = offsetDateTimeField15.roundCeiling((long) 21);
        int int18 = offsetDateTimeField15.getMinimumValue();
        long long20 = offsetDateTimeField15.roundCeiling(59L);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 10);
        org.joda.time.DateTime dateTime23 = dateTime22.withTimeAtStartOfDay();
        java.util.Date date24 = dateTime23.toDate();
        org.joda.time.MonthDay monthDay25 = org.joda.time.MonthDay.fromDateFields(date24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder26.append(dateTimeFormatter29);
        org.joda.time.Chronology chronology31 = dateTimeFormatter29.getChronology();
        boolean boolean32 = dateTimeFormatter29.isPrinter();
        java.lang.String str33 = monthDay25.toString(dateTimeFormatter29);
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) monthDay25, 100, locale35);
        int int37 = offsetDateTimeField15.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 14 + "'", int18 == 14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNull(chronology31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "����W���T������.000" + "'", str33.equals("����W���T������.000"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 14 + "'", int37 == 14);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = skipUndoDateTimeField7.getAsText((int) '4', locale9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfDay(0);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay();
//        int int15 = monthDay14.getDayOfMonth();
//        org.joda.time.MonthDay.Property property16 = monthDay14.dayOfMonth();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsShortText(locale17);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property16.getAsText(locale19);
//        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType22);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField7, dateTimeFieldType22, 2);
//        long long28 = dividedDateTimeField25.getDifferenceAsLong((long) 1969, (long) ' ');
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = dividedDateTimeField25.getAsText(57600, locale30);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dividedDateTimeField25.getAsText((long) 1969, locale33);
//        java.lang.String str36 = dividedDateTimeField25.getAsShortText((long) 52);
//        long long38 = dividedDateTimeField25.remainder(100L);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52" + "'", str10.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "15" + "'", str20.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "57600" + "'", str31.equals("57600"));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1" + "'", str36.equals("1"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 172800100L + "'", long38 == 172800100L);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime5 = dateTime1.plus((long) (short) 100);
        org.joda.time.DateTime.Property property6 = dateTime1.monthOfYear();
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        int int7 = property2.getMinimumValueOverall();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology9 = monthDay8.getChronology();
//        int int10 = monthDay8.size();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.MonthDay monthDay13 = monthDay8.withPeriodAdded(readablePeriod11, 0);
//        int int14 = property2.compareTo((org.joda.time.ReadablePartial) monthDay8);
//        org.joda.time.MonthDay.Property property15 = monthDay8.dayOfMonth();
//        org.joda.time.MonthDay monthDay16 = property15.getMonthDay();
//        int int17 = property15.getMinimumValueOverall();
//        java.lang.String str18 = property15.getAsText();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "15" + "'", str18.equals("15"));
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5, (int) (byte) 0);
        int int9 = skipUndoDateTimeField7.getMaximumValue(0L);
        boolean boolean10 = skipUndoDateTimeField7.isLenient();
        long long13 = skipUndoDateTimeField7.add(28800000L, (long) 15);
        int int16 = skipUndoDateTimeField7.getDifference((-4L), 1L);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField7.getAsShortText((long) 1, locale18);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1324800000L + "'", long13 == 1324800000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Wed" + "'", str19.equals("Wed"));
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 10);
//        int int5 = dateTime4.getSecondOfDay();
//        int int6 = dateTime4.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.hourOfDay();
//        boolean boolean12 = iSOChronology1.equals((java.lang.Object) gregorianChronology8);
//        java.lang.Object obj13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
//        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
//        org.joda.time.DateTime dateTime17 = property15.setCopy((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
//        org.joda.time.Chronology chronology19 = gregorianChronology8.withZone(dateTimeZone18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone18.getName((long) 69, locale21);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600 + "'", int5 == 57600);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pacific Standard Time" + "'", str22.equals("Pacific Standard Time"));
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime4 = property2.setCopy((int) (short) 10);
        org.joda.time.Interval interval5 = property2.toInterval();
        java.util.Locale locale7 = null;
        org.joda.time.DateTime dateTime8 = property2.setCopy("10", locale7);
        java.util.Date date9 = dateTime8.toDate();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 10);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        try {
            long long12 = gregorianChronology5.getDateTimeMillis(4, 10, 2000, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
//        int int1 = monthDay0.getDayOfMonth();
//        org.joda.time.MonthDay.Property property2 = monthDay0.dayOfMonth();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = property2.getAsShortText(locale3);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsText(locale5);
//        org.joda.time.MonthDay monthDay8 = property2.addWrapFieldToCopy(19);
//        int int9 = property2.getMinimumValueOverall();
//        int int10 = property2.getMinimumValue();
//        org.joda.time.DateTimeField dateTimeField11 = property2.getField();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "15" + "'", str4.equals("15"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.Object obj5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj5);
//        java.lang.String str7 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 10);
//        int int10 = dateTime9.getSecondOfDay();
//        int int11 = dateTime9.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTime9.getZone();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter4.withZone(dateTimeZone12);
//        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        java.util.TimeZone timeZone17 = dateTimeZone12.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        org.joda.time.Chronology chronology19 = julianChronology0.withZone(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology0.getZone();
//        org.joda.time.Chronology chronology21 = julianChronology0.withUTC();
//        try {
//            long long29 = julianChronology0.getDateTimeMillis((-97), 20, 21, 1970, 1970, 355, 3);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "141529.724-0700" + "'", str7.equals("141529.724-0700"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(copticChronology15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(chronology21);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.weekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(0, 100, 3, 0, 0, (int) (short) 1, 20, (org.joda.time.Chronology) buddhistChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = property2.getField();
        org.joda.time.DateTime dateTime4 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 10);
        int int7 = dateTime6.getSecondOfDay();
        int int8 = dateTime6.getSecondOfMinute();
        java.util.Date date9 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
        boolean boolean13 = dateTime6.isBefore(259200052L);
        int int14 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime16 = dateTime4.minusDays(3);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600 + "'", int7 == 57600);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYear(7, 54000010);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendMinuteOfDay(30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(10, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }
}

