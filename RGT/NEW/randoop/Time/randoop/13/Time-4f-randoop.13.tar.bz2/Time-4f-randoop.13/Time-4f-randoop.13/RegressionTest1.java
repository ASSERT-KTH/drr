import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.plusDays((int) (short) 1);
        org.joda.time.LocalDate localDate5 = localDate3.withYear((int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate3.minus(readablePeriod6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int9 = gregorianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField10 = gregorianChronology8.seconds();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate15 = localDate13.plus(readablePeriod14);
        org.joda.time.LocalTime localTime16 = null;
        org.joda.time.DateTime dateTime17 = localDate13.toDateTime(localTime16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) localTime16);
        int int19 = dateTime18.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
        org.joda.time.DurationField durationField28 = delegatedDateTimeField27.getDurationField();
        java.util.Locale locale30 = null;
        java.lang.String str31 = delegatedDateTimeField27.getAsShortText((long) (short) 100, locale30);
        int int32 = delegatedDateTimeField27.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField27.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, durationField24, dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter35.withChronology((org.joda.time.Chronology) buddhistChronology36);
        org.joda.time.DurationField durationField38 = buddhistChronology36.minutes();
        org.joda.time.DurationField durationField39 = buddhistChronology36.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField40 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField39);
        boolean boolean41 = dateTime18.isSupported(dateTimeFieldType33);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField43 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType33, 1995);
        int int44 = localDate7.indexOf(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2513" + "'", str31.equals("2513"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-292268511) + "'", int32 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) (short) 100, locale5);
        long long9 = delegatedDateTimeField2.getDifferenceAsLong((long) 56789, (long) 9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField12.getDurationField();
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField12.getAsShortText((long) (short) 100, locale15);
        int int17 = delegatedDateTimeField12.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.clockhourOfHalfday();
        org.joda.time.Partial partial22 = new org.joda.time.Partial(dateTimeFieldType18, 0, (org.joda.time.Chronology) iSOChronology20);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType18, 999);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2513" + "'", str16.equals("2513"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-292268511) + "'", int17 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(9, true);
        boolean boolean7 = julianChronology0.equals((java.lang.Object) dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.DurationFieldType durationFieldType2 = null;
//        boolean boolean3 = localDate1.isSupported(durationFieldType2);
//        int int4 = localDate1.getDayOfWeek();
//        org.joda.time.Partial partial5 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.Partial partial8 = partial5.withPeriodAdded(readablePeriod6, (-7));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(partial8);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(757814399993L, (long) 948);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 757814400941L + "'", long2 == 757814400941L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) (short) 100, locale5);
        int int7 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField2.getType();
        int int10 = delegatedDateTimeField2.getMinimumValue(6L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292268511) + "'", int10 == (-292268511));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial3 = partial0.withPeriodAdded(readablePeriod1, 0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial0.minus(readablePeriod4);
        org.joda.time.Chronology chronology6 = partial0.getChronology();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.Partial partial9 = partial0.withFieldAddWrapped(durationFieldType7, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(partial3);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        int int4 = localDate3.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = localDate3.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property8 = localDate3.dayOfMonth();
        java.util.Locale locale9 = null;
        int int10 = property8.getMaximumTextLength(locale9);
        org.joda.time.LocalDate localDate12 = property8.setCopy(24);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) 9);
        org.joda.time.LocalDate localDate15 = localDate12.withFields((org.joda.time.ReadablePartial) localDate14);
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate15);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970W013T������" + "'", str16.equals("1970W013T������"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField4.getAsShortText((long) (short) 100, locale7);
        int int9 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField4.getType();
        org.joda.time.DurationField durationField11 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) -1);
        long long16 = skipUndoDateTimeField13.set((long) 56789, 48);
        int int17 = skipUndoDateTimeField13.getMinimumValue();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2513" + "'", str8.equals("2513"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292268511) + "'", int9 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-77788166343211L) + "'", long16 == (-77788166343211L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-292268510) + "'", int17 == (-292268510));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
        org.joda.time.Instant instant8 = dateTime7.toInstant();
        org.joda.time.DateTime dateTime9 = instant8.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime4.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = dateTime4.plusDays(2000);
        org.joda.time.DateTime dateTime14 = dateTime4.plusMonths(0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) '#', (-13));
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendYearOfEra((int) (short) -1, 166);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property7.addToCopy((long) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime9.minusWeeks((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime4.minusSeconds(100);
        org.joda.time.DateTime dateTime9 = dateTime4.withLaterOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime11 = dateTime4.withHourOfDay((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) -1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        int int6 = dateTimeZone4.getOffsetFromLocal((long) 1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 69, dateTimeZone4);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.halfdays();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField12.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology6, (org.joda.time.DateTimeField) delegatedDateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
        int int17 = localDate16.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime(dateTimeZone18);
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime19.toYearMonthDay();
        org.joda.time.DateTime.Property property21 = dateTime19.millisOfSecond();
        org.joda.time.DateTime dateTime23 = dateTime19.minusSeconds(100);
        org.joda.time.DateTime dateTime24 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime26 = dateTime19.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        org.joda.time.DurationField durationField30 = delegatedDateTimeField29.getDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField29.getAsShortText((long) (short) 100, locale32);
        int int34 = delegatedDateTimeField29.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = delegatedDateTimeField29.getType();
        org.joda.time.DateTime.Property property36 = dateTime19.property(dateTimeFieldType35);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType35, 99);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendClockhourOfHalfday((-292268512));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(yearMonthDay20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2513" + "'", str33.equals("2513"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-292268511) + "'", int34 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(24);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, (int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(0);
        org.joda.time.DateTime dateTime14 = dateTime10.minusWeeks(19);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.halfdays();
        boolean boolean18 = iSOChronology15.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField21.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology15, (org.joda.time.DateTimeField) delegatedDateTimeField21);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone24);
        int int26 = localDate25.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = localDate25.toDateTimeAtCurrentTime(dateTimeZone27);
        org.joda.time.YearMonthDay yearMonthDay29 = dateTime28.toYearMonthDay();
        org.joda.time.DateTime.Property property30 = dateTime28.millisOfSecond();
        org.joda.time.DateTime dateTime32 = dateTime28.minusSeconds(100);
        org.joda.time.DateTime dateTime33 = dateTime28.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime35 = dateTime28.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
        org.joda.time.DurationField durationField39 = delegatedDateTimeField38.getDurationField();
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField38.getAsShortText((long) (short) 100, locale41);
        int int43 = delegatedDateTimeField38.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = delegatedDateTimeField38.getType();
        org.joda.time.DateTime.Property property45 = dateTime28.property(dateTimeFieldType44);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType44);
        org.joda.time.DateTime dateTime48 = dateTime10.withField(dateTimeFieldType44, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendHourOfHalfday(2000);
        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField56 = iSOChronology55.halfdays();
        boolean boolean58 = iSOChronology55.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology59 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = buddhistChronology59.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField61 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField60);
        org.joda.time.DurationField durationField62 = delegatedDateTimeField61.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField63 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology55, (org.joda.time.DateTimeField) delegatedDateTimeField61);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.LocalDate localDate65 = new org.joda.time.LocalDate(dateTimeZone64);
        int int66 = localDate65.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.DateTime dateTime68 = localDate65.toDateTimeAtCurrentTime(dateTimeZone67);
        org.joda.time.YearMonthDay yearMonthDay69 = dateTime68.toYearMonthDay();
        org.joda.time.DateTime.Property property70 = dateTime68.millisOfSecond();
        org.joda.time.DateTime dateTime72 = dateTime68.minusSeconds(100);
        org.joda.time.DateTime dateTime73 = dateTime68.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime75 = dateTime68.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology76 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField77 = buddhistChronology76.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField78 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField77);
        org.joda.time.DurationField durationField79 = delegatedDateTimeField78.getDurationField();
        java.util.Locale locale81 = null;
        java.lang.String str82 = delegatedDateTimeField78.getAsShortText((long) (short) 100, locale81);
        int int83 = delegatedDateTimeField78.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType84 = delegatedDateTimeField78.getType();
        org.joda.time.DateTime.Property property85 = dateTime68.property(dateTimeFieldType84);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField86 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField63, dateTimeFieldType84);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder88 = dateTimeFormatterBuilder52.appendFixedDecimal(dateTimeFieldType84, 99);
        int int89 = dateTime10.get(dateTimeFieldType84);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(yearMonthDay29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2513" + "'", str42.equals("2513"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-292268511) + "'", int43 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(iSOChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(buddhistChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 19 + "'", int66 == 19);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(yearMonthDay69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(buddhistChronology76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(durationField79);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "2513" + "'", str82.equals("2513"));
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-292268511) + "'", int83 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType84);
        org.junit.Assert.assertNotNull(property85);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1995 + "'", int89 == 1995);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("[]");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("[]");
        boolean boolean5 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType6);
        jodaTimePermission1.checkGuard((java.lang.Object) periodType6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[]" + "'", str2.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfHalfday(2000);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField11 = iSOChronology10.halfdays();
        boolean boolean13 = iSOChronology10.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField16.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology10, (org.joda.time.DateTimeField) delegatedDateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        int int21 = localDate20.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = localDate20.toDateTimeAtCurrentTime(dateTimeZone22);
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        org.joda.time.DateTime.Property property25 = dateTime23.millisOfSecond();
        org.joda.time.DateTime dateTime27 = dateTime23.minusSeconds(100);
        org.joda.time.DateTime dateTime28 = dateTime23.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime30 = dateTime23.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
        org.joda.time.DurationField durationField34 = delegatedDateTimeField33.getDurationField();
        java.util.Locale locale36 = null;
        java.lang.String str37 = delegatedDateTimeField33.getAsShortText((long) (short) 100, locale36);
        int int38 = delegatedDateTimeField33.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = delegatedDateTimeField33.getType();
        org.joda.time.DateTime.Property property40 = dateTime23.property(dateTimeFieldType39);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder7.appendFixedDecimal(dateTimeFieldType39, 99);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType39, (-7));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -7");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 19 + "'", int21 == 19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2513" + "'", str37.equals("2513"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-292268511) + "'", int38 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 1970, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1L);
        org.joda.time.Instant instant3 = instant1.minus(6L);
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant3.plus(readableDuration5);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("2019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DurationField durationField5 = buddhistChronology3.minutes();
        org.joda.time.DurationField durationField6 = buddhistChronology3.weekyears();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime1.toMutableDateTime((org.joda.time.Chronology) buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.plus(readablePeriod1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.Partial partial5 = partial2.withFieldAdded(durationFieldType3, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(partial2);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
//        org.joda.time.DateTime dateTime9 = property7.addToCopy((long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        int int12 = localDate11.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = localDate11.toDateTimeAtCurrentTime(dateTimeZone13);
//        int int15 = dateTime14.getYearOfCentury();
//        org.joda.time.DateTime dateTime17 = dateTime14.minusYears(24);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(readableDuration18, (int) (byte) -1);
//        long long21 = property7.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime22 = property7.roundFloorCopy();
//        org.joda.time.DateTimeField dateTimeField23 = property7.getField();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone24);
//        int int26 = localDate25.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = localDate25.toDateTimeAtCurrentTime(dateTimeZone27);
//        org.joda.time.YearMonthDay yearMonthDay29 = dateTime28.toYearMonthDay();
//        org.joda.time.DateTime.Property property30 = dateTime28.millisOfSecond();
//        org.joda.time.DateTime dateTime32 = dateTime28.minusSeconds(100);
//        org.joda.time.DateTime dateTime33 = dateTime28.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime35 = dateTime28.withMonthOfYear((int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone36);
//        int int38 = localDate37.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.DateTime dateTime40 = localDate37.toDateTimeAtCurrentTime(dateTimeZone39);
//        org.joda.time.YearMonthDay yearMonthDay41 = dateTime40.toYearMonthDay();
//        org.joda.time.DateTime dateTime43 = dateTime40.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime45 = dateTime40.withCenturyOfEra((int) (byte) 100);
//        boolean boolean46 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime35, (java.lang.Object) (byte) 100);
//        long long47 = property7.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime35);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 23L + "'", long21 == 23L);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(yearMonthDay29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 19 + "'", int38 == 19);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(yearMonthDay41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.eras();
        org.joda.time.Instant instant3 = org.joda.time.Instant.now();
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) instant3);
        org.joda.time.Instant instant7 = instant3.withDurationAdded(1814400000L, 843);
        org.joda.time.Instant instant8 = instant3.toInstant();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Instant instant10 = instant8.plus(readableDuration9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
//        int int11 = dateTime10.getMonthOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField16 = iSOChronology15.months();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
//        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
//        int int24 = delegatedDateTimeField19.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
//        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
//        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
//        org.joda.time.DurationField durationField36 = dividedDateTimeField35.getDurationField();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate(dateTimeZone37);
//        boolean boolean40 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate38, (java.lang.Object) (-1.0d));
//        int int41 = localDate38.getWeekOfWeekyear();
//        int int42 = localDate38.getDayOfWeek();
//        org.joda.time.LocalDate.Property property43 = localDate38.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate(dateTimeZone45);
//        org.joda.time.LocalDate localDate48 = localDate46.plusDays((int) (short) 1);
//        org.joda.time.LocalDate localDate50 = localDate48.withYear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property51 = localDate50.dayOfYear();
//        int[] intArray52 = localDate50.getValues();
//        try {
//            int[] intArray54 = dividedDateTimeField35.addWrapField((org.joda.time.ReadablePartial) localDate38, (int) (short) -1, intArray52, (-8));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 24 + "'", int41 == 24);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(intArray52);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        int int23 = unsupportedDateTimeField20.getDifference((long) (byte) 0, 0L);
        try {
            long long25 = unsupportedDateTimeField20.roundHalfFloor((long) 38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) (short) 100, locale5);
        int int7 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.clockhourOfHalfday();
        org.joda.time.Partial partial12 = new org.joda.time.Partial(dateTimeFieldType8, 0, (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.Partial partial14 = partial12.plus(readablePeriod13);
        int int15 = partial12.size();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(partial14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 0, locale3);
//        long long7 = dateTimeZone1.adjustOffset((-189302399948L), false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        boolean boolean10 = cachedDateTimeZone8.equals((java.lang.Object) 10.0d);
//        boolean boolean11 = cachedDateTimeZone8.isFixed();
//        int int13 = cachedDateTimeZone8.getStandardOffset(947L);
//        long long15 = cachedDateTimeZone8.previousTransition((long) (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-189302399948L) + "'", long7 == (-189302399948L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-5756400001L) + "'", long15 == (-5756400001L));
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.days();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(24);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, (int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(0);
        org.joda.time.DateTime.Property property13 = dateTime12.minuteOfDay();
        org.joda.time.DateTime dateTime14 = property13.withMinimumValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateMidnight dateMidnight2 = localDate1.toDateMidnight();
        int int3 = localDate1.getMonthOfYear();
        org.joda.time.LocalDate.Property property4 = localDate1.centuryOfEra();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = localDate1.getFieldTypes();
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(25L, dateTimeZone1);
        boolean boolean3 = dateTime2.isEqualNow();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) '#', (-13));
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder5.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = localDate1.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property6 = localDate1.dayOfMonth();
        java.util.Locale locale7 = null;
        int int8 = property6.getMaximumTextLength(locale7);
        org.joda.time.LocalDate localDate10 = property6.setCopy(24);
        org.joda.time.Chronology chronology11 = localDate10.getChronology();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.Chronology chronology7 = gJChronology4.withZone(dateTimeZone6);
        org.joda.time.Instant instant8 = gJChronology4.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology4.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        int int4 = localDate3.getYearOfCentury();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        boolean boolean6 = localDate3.isSupported(durationFieldType5);
        int int7 = localDate3.getWeekyear();
        org.joda.time.DateTime dateTime8 = localDate3.toDateTimeAtCurrentTime();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
//        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) 0, locale7);
//        long long11 = dateTimeZone5.adjustOffset((-189302399948L), false);
//        long long13 = dateTimeZone1.getMillisKeepLocal(dateTimeZone5, (-8L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-189302399948L) + "'", long11 == (-189302399948L));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-8L) + "'", long13 == (-8L));
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTimeZoneOffset("JulianChronology[America/Los_Angeles]", true, (-146504), (-7));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = localDate3.isSupported(durationFieldType4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalTime localTime10 = null;
        org.joda.time.DateTime dateTime11 = localDate7.toDateTime(localTime10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) localTime10);
        int int13 = dateTime12.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField18 = iSOChronology17.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField21.getDurationField();
        java.util.Locale locale24 = null;
        java.lang.String str25 = delegatedDateTimeField21.getAsShortText((long) (short) 100, locale24);
        int int26 = delegatedDateTimeField21.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = delegatedDateTimeField21.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, durationField18, dateTimeFieldType27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withChronology((org.joda.time.Chronology) buddhistChronology30);
        org.joda.time.DurationField durationField32 = buddhistChronology30.minutes();
        org.joda.time.DurationField durationField33 = buddhistChronology30.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField33);
        boolean boolean35 = dateTime12.isSupported(dateTimeFieldType27);
        try {
            org.joda.time.LocalDate localDate37 = localDate3.withField(dateTimeFieldType27, (-5));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (BuddhistChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2513" + "'", str25.equals("2513"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292268511) + "'", int26 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 948);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        int int6 = localDate5.getYearOfCentury();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = localDate5.isSupported(durationFieldType7);
        try {
            dateTimeFormatter1.printTo(stringBuffer3, (org.joda.time.ReadablePartial) localDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withDefaultYear(2513);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        boolean boolean6 = localDate3.equals((java.lang.Object) localDate5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone8);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = localDate9.isSupported(durationFieldType10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtCurrentTime(dateTimeZone12);
        org.joda.time.LocalTime localTime14 = null;
        org.joda.time.DateTime dateTime15 = localDate9.toDateTime(localTime14);
        java.util.Locale locale16 = null;
        java.util.Calendar calendar17 = dateTime15.toCalendar(locale16);
        org.joda.time.LocalDate localDate18 = org.joda.time.LocalDate.fromCalendarFields(calendar17);
        boolean boolean19 = partial7.equals((java.lang.Object) calendar17);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(calendar17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = dateTime4.withCenturyOfEra((int) (byte) 100);
//        int int10 = dateTime4.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = dateTime4.withWeekyear(1969);
//        org.joda.time.DateTime dateTime13 = dateTime12.toDateTimeISO();
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime13.withEra(4);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 9);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        int int5 = dateTime4.getEra();
//        org.joda.time.LocalDate localDate6 = dateTime4.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        int int9 = localDate8.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = localDate8.toDateTimeAtCurrentTime(dateTimeZone10);
//        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
//        org.joda.time.DateTime.Property property13 = dateTime11.millisOfSecond();
//        org.joda.time.DateTime dateTime15 = dateTime11.minusSeconds(100);
//        int int16 = dateTime15.getMillisOfSecond();
//        boolean boolean17 = dateTime4.isEqual((org.joda.time.ReadableInstant) dateTime15);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(yearMonthDay12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 684 + "'", int16 == 684);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendHourOfHalfday(1969);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        boolean boolean7 = dateTimeFormatterBuilder5.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.Chronology chronology9 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTwoDigitYear(208, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(35, (-7));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(208);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-757209599999L));
        boolean boolean3 = dateTime1.isEqual((long) (-48));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = localDate1.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property6 = localDate1.dayOfMonth();
        java.util.Locale locale7 = null;
        int int8 = property6.getMaximumTextLength(locale7);
        org.joda.time.LocalDate localDate10 = property6.setCopy(24);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) 9);
        org.joda.time.LocalDate localDate13 = localDate10.withFields((org.joda.time.ReadablePartial) localDate12);
        java.util.Date date14 = localDate12.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        long long7 = property6.remainder();
        boolean boolean9 = property6.equals((java.lang.Object) 19);
        int int10 = property6.getMinimumValueOverall();
        org.joda.time.DateTime dateTime12 = property6.setCopy((int) (short) 10);
        org.joda.time.DateTime dateTime13 = property6.getDateTime();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial3 = partial0.withPeriodAdded(readablePeriod1, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.weekyear();
        org.joda.time.Partial partial6 = partial3.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology4);
        boolean boolean7 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) partial6);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType9 = partial6.getFieldType(12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(partial3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(partial6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.LocalDate localDate3 = localDate1.plus(readablePeriod2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.LocalDate localDate5 = localDate3.plus(readablePeriod4);
        int int6 = localDate3.getMonthOfYear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getRangeDurationField();
        try {
            long long24 = unsupportedDateTimeField20.set((long) 19, 10019);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
        try {
            long long23 = unsupportedDateTimeField20.roundHalfFloor((-259200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.year();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-2L), (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime4.withCenturyOfEra((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime13 = dateTime9.minusYears((-292268511));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField4.getAsShortText((long) (short) 100, locale7);
        int int9 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField4.getType();
        org.joda.time.DurationField durationField11 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) -1);
        int int14 = skipUndoDateTimeField13.getMinimumValue();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2513" + "'", str8.equals("2513"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292268511) + "'", int9 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292268510) + "'", int14 == (-292268510));
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        java.lang.String str7 = property6.toString();
//        org.joda.time.DateTime dateTime8 = property6.getDateTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        int int11 = localDate10.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = localDate10.toDateTimeAtCurrentTime(dateTimeZone12);
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime13.withCenturyOfEra((int) (byte) 100);
//        int int19 = property6.getDifference((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
//        int int22 = localDate21.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = localDate21.toDateTimeAtCurrentTime(dateTimeZone23);
//        org.joda.time.YearMonthDay yearMonthDay25 = dateTime24.toYearMonthDay();
//        org.joda.time.DateTime.Property property26 = dateTime24.millisOfSecond();
//        org.joda.time.DateTime dateTime28 = dateTime24.minusSeconds(100);
//        org.joda.time.DateTime dateTime29 = dateTime24.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime31 = dateTime24.withMonthOfYear((int) (byte) 10);
//        int int32 = property6.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = property6.getAsText(locale33);
//        org.joda.time.DateTime dateTime35 = property6.withMinimumValue();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[millisOfSecond]" + "'", str7.equals("Property[millisOfSecond]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-2) + "'", int19 == (-2));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19 + "'", int22 == 19);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(yearMonthDay25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-3) + "'", int32 == (-3));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "127" + "'", str34.equals("127"));
//        org.junit.Assert.assertNotNull(dateTime35);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2489", "", 2000, 1970);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 4);
        long long10 = fixedDateTimeZone4.nextTransition((long) 947);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2000 + "'", int6 == 2000);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 947L + "'", long10 == 947L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) (short) 10, (java.lang.Number) (byte) 1, number3);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        long long7 = property6.remainder();
        boolean boolean9 = property6.equals((java.lang.Object) 19);
        int int10 = property6.getMinimumValueOverall();
        org.joda.time.DateTime dateTime12 = property6.setCopy((int) (short) 10);
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.DateTime dateTime15 = dateTime12.withFieldAdded(durationFieldType13, (-7));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate4.plusDays((int) (short) 1);
        int int7 = delegatedDateTimeField2.getMinimumValue((org.joda.time.ReadablePartial) localDate6);
        long long9 = delegatedDateTimeField2.roundHalfFloor((long) (short) 10);
        int int10 = delegatedDateTimeField2.getMinimumValue();
        java.util.Locale locale11 = null;
        int int12 = delegatedDateTimeField2.getMaximumTextLength(locale11);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 1995);
        int int15 = offsetDateTimeField14.getOffset();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292268511) + "'", int10 == (-292268511));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1995 + "'", int15 == 1995);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = localDate1.toDateTimeAtMidnight();
//        org.joda.time.LocalDate.Property property6 = localDate1.dayOfMonth();
//        java.util.Locale locale7 = null;
//        int int8 = property6.getMaximumTextLength(locale7);
//        java.lang.String str9 = property6.getAsString();
//        java.util.Locale locale11 = null;
//        org.joda.time.LocalDate localDate12 = property6.setCopy("10", locale11);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
//        org.junit.Assert.assertNotNull(localDate12);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial6 = partial3.withPeriodAdded(readablePeriod4, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.weekyear();
        org.joda.time.Partial partial9 = partial6.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology7);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) partial9);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(partial6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(partial9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292279536 + "'", int10 == 292279536);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.parse("2019-06-15T15:47:57.033-07:00", dateTimeFormatter1);
        try {
            org.joda.time.LocalDate localDate5 = localDate3.withEra((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-292268536L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        int int5 = dateTime4.getEra();
//        int int6 = dateTime4.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (byte) -1, (-13));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        boolean boolean3 = localDate1.isSupported(durationFieldType2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = localDate1.toDateTimeAtCurrentTime(dateTimeZone4);
        org.joda.time.LocalTime localTime6 = null;
        org.joda.time.DateTime dateTime7 = localDate1.toDateTime(localTime6);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime7.toCalendar(locale8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("2489", "", 2000, 1970);
        int int16 = fixedDateTimeZone14.getOffsetFromLocal(0L);
        java.lang.String str18 = fixedDateTimeZone14.getNameKey((long) 4);
        org.joda.time.DateTime dateTime19 = dateTime7.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2000 + "'", int16 == 2000);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(dateTimeZone3);
        org.joda.time.DateMidnight dateMidnight5 = localDate4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone6 = dateMidnight5.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DurationField durationField10 = buddhistChronology8.minutes();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology8.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime12 = dateMidnight5.toMutableDateTime((org.joda.time.Chronology) buddhistChronology8);
        int int15 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime12, "DateTimeField[weekyear]", (-13));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-13) + "'", int15 == (-13));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(24);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, (int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime12 = dateTime7.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        long long8 = dateTimeZone5.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.Chronology chronology11 = zonedChronology9.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) zonedChronology9);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsShortText((long) (-25200000));
        org.joda.time.DurationField durationField38 = dividedDateTimeField35.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertNull(durationField38);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        java.lang.String str7 = property6.toString();
//        org.joda.time.DateTime dateTime8 = property6.getDateTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        int int11 = localDate10.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = localDate10.toDateTimeAtCurrentTime(dateTimeZone12);
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime13.withCenturyOfEra((int) (byte) 100);
//        int int19 = property6.getDifference((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
//        int int22 = localDate21.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = localDate21.toDateTimeAtCurrentTime(dateTimeZone23);
//        org.joda.time.YearMonthDay yearMonthDay25 = dateTime24.toYearMonthDay();
//        org.joda.time.DateTime.Property property26 = dateTime24.millisOfSecond();
//        org.joda.time.DateTime dateTime28 = dateTime24.minusSeconds(100);
//        org.joda.time.DateTime dateTime29 = dateTime24.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime31 = dateTime24.withMonthOfYear((int) (byte) 10);
//        int int32 = property6.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        java.util.Locale locale33 = null;
//        int int34 = property6.getMaximumTextLength(locale33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(dateTimeZone35);
//        int int37 = localDate36.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = localDate36.toDateTimeAtCurrentTime(dateTimeZone38);
//        org.joda.time.YearMonthDay yearMonthDay40 = dateTime39.toYearMonthDay();
//        org.joda.time.DateTime dateTime42 = dateTime39.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime44 = dateTime39.withCenturyOfEra((int) (byte) 100);
//        int int45 = dateTime44.getYearOfEra();
//        int int46 = property6.compareTo((org.joda.time.ReadableInstant) dateTime44);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[millisOfSecond]" + "'", str7.equals("Property[millisOfSecond]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-2) + "'", int19 == (-2));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19 + "'", int22 == 19);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(yearMonthDay25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-5) + "'", int32 == (-5));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 19 + "'", int37 == 19);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(yearMonthDay40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10019 + "'", int45 == 10019);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(24);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, (int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(0);
        org.joda.time.DateTime dateTime14 = dateTime10.minusWeeks(19);
        int int15 = dateTime10.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1995 + "'", int15 == 1995);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
//        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
//        boolean boolean4 = delegatedDateTimeField2.isLenient();
//        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) 10019);
//        boolean boolean7 = delegatedDateTimeField2.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone8);
//        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate9, (java.lang.Object) (-1.0d));
//        int int12 = localDate9.getWeekOfWeekyear();
//        int int13 = localDate9.getDayOfWeek();
//        int[] intArray19 = new int[] { 365, (-2), (byte) 1, 10, (byte) 1 };
//        int int20 = delegatedDateTimeField2.getMinimumValue((org.joda.time.ReadablePartial) localDate9, intArray19);
//        try {
//            int int22 = localDate9.getValue((int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 35");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292268511) + "'", int20 == (-292268511));
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, 0L, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2489", "", 2000, 1970);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 4);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey(1814400000L);
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedDateTimeZone4.equals(obj11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2000 + "'", int6 == 2000);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = localDate1.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property6 = localDate1.dayOfMonth();
        java.util.Locale locale7 = null;
        int int8 = property6.getMaximumTextLength(locale7);
        org.joda.time.LocalDate localDate10 = property6.setCopy(24);
        try {
            org.joda.time.LocalDate localDate12 = localDate10.withEra(24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = localDate1.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property6 = localDate1.dayOfMonth();
        java.util.Locale locale7 = null;
        int int8 = property6.getMaximumTextLength(locale7);
        org.joda.time.LocalDate localDate10 = property6.setCopy(24);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) 9);
        org.joda.time.LocalDate localDate13 = localDate10.withFields((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField20 = iSOChronology19.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        org.joda.time.DurationField durationField24 = delegatedDateTimeField23.getDurationField();
        java.util.Locale locale26 = null;
        java.lang.String str27 = delegatedDateTimeField23.getAsShortText((long) (short) 100, locale26);
        int int28 = delegatedDateTimeField23.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField23.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, durationField20, dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withChronology((org.joda.time.Chronology) buddhistChronology32);
        org.joda.time.DurationField durationField34 = buddhistChronology32.minutes();
        org.joda.time.DurationField durationField35 = buddhistChronology32.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField35);
        int int37 = localDate15.get(dateTimeFieldType29);
        boolean boolean38 = localDate10.isSupported(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2513" + "'", str27.equals("2513"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-292268511) + "'", int28 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1970 + "'", int37 == 1970);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) 947);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
//        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getDurationField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        int int11 = localDate10.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = localDate10.toDateTimeAtCurrentTime(dateTimeZone12);
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime.Property property15 = dateTime13.millisOfSecond();
//        org.joda.time.DateTime dateTime17 = dateTime13.minusSeconds(100);
//        org.joda.time.DateTime dateTime18 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = dateTime13.withMonthOfYear((int) (byte) 10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
//        org.joda.time.DurationField durationField24 = delegatedDateTimeField23.getDurationField();
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = delegatedDateTimeField23.getAsShortText((long) (short) 100, locale26);
//        int int28 = delegatedDateTimeField23.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField23.getType();
//        org.joda.time.DateTime.Property property30 = dateTime13.property(dateTimeFieldType29);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, dateTimeFieldType29);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone32);
//        int int34 = localDate33.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = localDate33.toDateTimeAtCurrentTime(dateTimeZone35);
//        org.joda.time.YearMonthDay yearMonthDay37 = dateTime36.toYearMonthDay();
//        org.joda.time.DateTime dateTime39 = dateTime36.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime41 = dateTime36.withCenturyOfEra((int) (byte) 100);
//        int int42 = dateTime36.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime44 = dateTime36.minusDays((int) (short) 100);
//        org.joda.time.DateTime dateTime45 = dateTime44.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField47 = buddhistChronology46.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField47);
//        org.joda.time.DurationField durationField49 = delegatedDateTimeField48.getDurationField();
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = delegatedDateTimeField48.getAsShortText((long) (short) 100, locale51);
//        int int53 = delegatedDateTimeField48.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = delegatedDateTimeField48.getType();
//        int int55 = dateTime44.get(dateTimeFieldType54);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField31, dateTimeFieldType54, 2000, (int) (byte) 0, (int) (byte) -1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2513" + "'", str27.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-292268511) + "'", int28 == (-292268511));
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 19 + "'", int34 == 19);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(yearMonthDay37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 24 + "'", int42 == 24);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2513" + "'", str52.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-292268511) + "'", int53 == (-292268511));
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendTimeZoneOffset("", false, 38, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
//        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
//        boolean boolean4 = delegatedDateTimeField2.isLenient();
//        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) 10019);
//        boolean boolean7 = delegatedDateTimeField2.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone8);
//        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate9, (java.lang.Object) (-1.0d));
//        int int12 = localDate9.getWeekOfWeekyear();
//        int int13 = localDate9.getDayOfWeek();
//        int[] intArray19 = new int[] { 365, (-2), (byte) 1, 10, (byte) 1 };
//        int int20 = delegatedDateTimeField2.getMinimumValue((org.joda.time.ReadablePartial) localDate9, intArray19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        int int23 = localDate22.getYearOfCentury();
//        org.joda.time.DurationFieldType durationFieldType24 = null;
//        boolean boolean25 = localDate22.isSupported(durationFieldType24);
//        int int26 = localDate22.getWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(dateTimeZone28);
//        int int30 = localDate29.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = localDate29.toDateTimeAtCurrentTime(dateTimeZone31);
//        org.joda.time.YearMonthDay yearMonthDay33 = dateTime32.toYearMonthDay();
//        boolean boolean34 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay33);
//        int[] intArray35 = yearMonthDay33.getValues();
//        int[] intArray37 = delegatedDateTimeField2.add((org.joda.time.ReadablePartial) localDate22, 56791, intArray35, 0);
//        int int39 = delegatedDateTimeField2.getMinimumValue(251824464000000L);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292268511) + "'", int20 == (-292268511));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 19 + "'", int30 == 19);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(yearMonthDay33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-292268511) + "'", int39 == (-292268511));
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "Property[millisOfSecond]", "hi!");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("996", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"996\" is malformed at \"6\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, (long) 6, 10);
        org.joda.time.DurationField durationField6 = iSOChronology0.years();
        java.lang.String str7 = iSOChronology0.toString();
        org.joda.time.DurationField durationField8 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 6L + "'", long5 == 6L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str7.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.LocalDate localDate7 = localDate5.plusDays((int) (short) 1);
        int int8 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate7);
        long long10 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        int int11 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField3);
        java.lang.String str14 = skipUndoDateTimeField12.getAsText((long) (byte) -1);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField12.getAsText(0L, locale16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292268511) + "'", int8 == (-292268511));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259200000L) + "'", long10 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-292268511) + "'", int11 == (-292268511));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2513" + "'", str14.equals("2513"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2513" + "'", str17.equals("2513"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime4.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(10019);
        boolean boolean14 = dateTime12.isAfter((long) (-5));
        org.joda.time.DateTime dateTime16 = dateTime12.withWeekyear(0);
        org.joda.time.DateTime dateTime18 = dateTime16.plusSeconds(166);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("2019");
        java.lang.Throwable throwable2 = null;
        try {
            illegalInstantException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField3 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfMonth();
        org.joda.time.DurationField durationField5 = buddhistChronology1.months();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendWeekOfWeekyear((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendTwoDigitYear(2513, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        long long8 = dateTimeZone5.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
        try {
            long long16 = zonedChronology9.getDateTimeMillis(35L, 166, (-4), (int) '#', 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate4.plus(readablePeriod5);
        org.joda.time.LocalTime localTime7 = null;
        org.joda.time.DateTime dateTime8 = localDate4.toDateTime(localTime7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) localTime7);
        int int10 = dateTime9.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField15 = iSOChronology14.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField18.getDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField18.getAsShortText((long) (short) 100, locale21);
        int int23 = delegatedDateTimeField18.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField18.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, durationField15, dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) buddhistChronology27);
        org.joda.time.DurationField durationField29 = buddhistChronology27.minutes();
        org.joda.time.DurationField durationField30 = buddhistChronology27.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField30);
        boolean boolean32 = dateTime9.isSupported(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType24, 292279536);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2513" + "'", str22.equals("2513"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292268511) + "'", int23 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(24);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, (int) (byte) -1);
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfCentury();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        long long6 = dateTimeZone3.adjustOffset(0L, false);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology0.getZone();
        try {
            long long14 = copticChronology0.getDateTimeMillis(24, 69, 947, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = localDate1.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property6 = localDate1.dayOfMonth();
        org.joda.time.LocalDate localDate7 = property6.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate8 = property6.getLocalDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial3 = partial0.withPeriodAdded(readablePeriod1, 0);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial0.minus(readablePeriod4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.Partial partial8 = partial0.withFieldAdded(durationFieldType6, (-8));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(partial3);
        org.junit.Assert.assertNotNull(partial5);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[millisOfSecond]", (java.lang.Number) (byte) 100, number2, (java.lang.Number) 2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.plusDays((int) (short) 1);
        org.joda.time.LocalDate localDate5 = localDate3.withYear((int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate3.minus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate localDate11 = localDate7.withCenturyOfEra((int) 'a');
        org.joda.time.LocalDate.Property property12 = localDate7.centuryOfEra();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.LocalDate localDate7 = localDate5.plusDays((int) (short) 1);
        int int8 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate7);
        long long10 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        int int11 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField3);
        int int13 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292268511) + "'", int8 == (-292268511));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259200000L) + "'", long10 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-292268511) + "'", int11 == (-292268511));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        long long7 = property6.remainder();
        long long8 = property6.remainder();
        org.joda.time.DateTime dateTime10 = property6.setCopy("208");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(24);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, (int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(0);
        org.joda.time.DateTime dateTime14 = dateTime10.minusWeeks(19);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.halfdays();
        boolean boolean18 = iSOChronology15.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField21.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology15, (org.joda.time.DateTimeField) delegatedDateTimeField21);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone24);
        int int26 = localDate25.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = localDate25.toDateTimeAtCurrentTime(dateTimeZone27);
        org.joda.time.YearMonthDay yearMonthDay29 = dateTime28.toYearMonthDay();
        org.joda.time.DateTime.Property property30 = dateTime28.millisOfSecond();
        org.joda.time.DateTime dateTime32 = dateTime28.minusSeconds(100);
        org.joda.time.DateTime dateTime33 = dateTime28.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime35 = dateTime28.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
        org.joda.time.DurationField durationField39 = delegatedDateTimeField38.getDurationField();
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField38.getAsShortText((long) (short) 100, locale41);
        int int43 = delegatedDateTimeField38.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = delegatedDateTimeField38.getType();
        org.joda.time.DateTime.Property property45 = dateTime28.property(dateTimeFieldType44);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType44);
        org.joda.time.DateTime dateTime48 = dateTime10.withField(dateTimeFieldType44, (int) (short) 100);
        org.joda.time.DateTime dateTime49 = dateTime48.withLaterOffsetAtOverlap();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(yearMonthDay29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2513" + "'", str42.equals("2513"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-292268511) + "'", int43 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime49);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        long long6 = dateTimeZone3.adjustOffset(0L, false);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone7);
//        java.lang.String str10 = dateTimeZone7.getShortName((long) 0);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.hourOfDay();
        try {
            long long12 = julianChronology0.getDateTimeMillis((int) (short) 1, (-4), 31606, (int) ' ', 292279636, 960, 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.plusDays((int) (short) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.weekyear();
        org.joda.time.DurationField durationField6 = buddhistChronology4.halfdays();
        org.joda.time.Chronology chronology7 = buddhistChronology4.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        long long12 = dateTimeZone9.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime15 = localDate1.toDateTimeAtCurrentTime(dateTimeZone14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.LocalDate localDate17 = localDate1.plus(readablePeriod16);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate17);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.LocalDate localDate7 = localDate5.plusDays((int) (short) 1);
        int int8 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate7);
        long long10 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        int int11 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292268511) + "'", int8 == (-292268511));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259200000L) + "'", long10 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-292268511) + "'", int11 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        int int23 = unsupportedDateTimeField20.getDifference((long) (byte) 0, 0L);
        long long26 = unsupportedDateTimeField20.add((long) 232, 31619);
        try {
            boolean boolean28 = unsupportedDateTimeField20.isLeap((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 997799644800232L + "'", long26 == 997799644800232L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        long long8 = dateTimeZone5.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(int2);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        boolean boolean1 = instant0.isAfterNow();
//        org.joda.time.Chronology chronology2 = instant0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime3 = instant0.toMutableDateTime();
//        int int4 = mutableDateTime3.getWeekOfWeekyear();
//        int int5 = mutableDateTime3.getWeekyear();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1L);
        org.joda.time.Instant instant3 = instant1.minus(6L);
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DurationField durationField8 = buddhistChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.dayOfMonth();
        boolean boolean10 = instant3.equals((java.lang.Object) dateTimeField9);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, 31702879, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        long long4 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        try {
            org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (long) 10, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1969");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField4 = iSOChronology3.months();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
//        int int12 = delegatedDateTimeField7.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
//        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
//        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add((-292268536L), (int) (byte) 10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
//        org.joda.time.DurationField durationField28 = delegatedDateTimeField27.getDurationField();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = delegatedDateTimeField27.getAsShortText((long) (short) 100, locale30);
//        int int32 = delegatedDateTimeField27.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField27.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.clockhourOfHalfday();
//        org.joda.time.Partial partial37 = new org.joda.time.Partial(dateTimeFieldType33, 0, (org.joda.time.Chronology) iSOChronology35);
//        org.joda.time.ReadablePeriod readablePeriod38 = null;
//        org.joda.time.Partial partial39 = partial37.plus(readablePeriod38);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField43 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField42);
//        org.joda.time.DurationField durationField44 = delegatedDateTimeField43.getDurationField();
//        boolean boolean45 = delegatedDateTimeField43.isLenient();
//        java.lang.String str47 = delegatedDateTimeField43.getAsShortText((long) 10019);
//        boolean boolean48 = delegatedDateTimeField43.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate(dateTimeZone49);
//        boolean boolean52 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate50, (java.lang.Object) (-1.0d));
//        int int53 = localDate50.getWeekOfWeekyear();
//        int int54 = localDate50.getDayOfWeek();
//        int[] intArray60 = new int[] { 365, (-2), (byte) 1, 10, (byte) 1 };
//        int int61 = delegatedDateTimeField43.getMinimumValue((org.joda.time.ReadablePartial) localDate50, intArray60);
//        try {
//            int[] intArray63 = unsupportedDateTimeField20.addWrapField((org.joda.time.ReadablePartial) partial39, 31606, intArray60, 2000);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 315413331464L + "'", long24 == 315413331464L);
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2513" + "'", str31.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-292268511) + "'", int32 == (-292268511));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(partial39);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2513" + "'", str47.equals("2513"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 24 + "'", int53 == 24);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-292268511) + "'", int61 == (-292268511));
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfDay((-292268511));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.DurationFieldType durationFieldType2 = null;
//        boolean boolean3 = localDate1.isSupported(durationFieldType2);
//        int int4 = localDate1.getDayOfWeek();
//        org.joda.time.Partial partial5 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        int int9 = localDate8.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = localDate8.toDateTimeAtCurrentTime(dateTimeZone10);
//        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
//        org.joda.time.DateTime dateTime14 = dateTime11.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime11.toDateTime(dateTimeZone15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
//        java.lang.String str19 = dateTime17.toString(dateTimeFormatter18);
//        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter6, dateTimeParser20);
//        try {
//            java.lang.String str22 = localDate1.toString(dateTimeFormatter21);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(yearMonthDay12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019W246" + "'", str19.equals("2019W246"));
//        org.junit.Assert.assertNotNull(dateTimeParser20);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfMonth(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        try {
            boolean boolean22 = unsupportedDateTimeField20.isLeap(315705600100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.io.Writer writer2 = null;
        org.joda.time.Partial partial3 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial6 = partial3.withPeriodAdded(readablePeriod4, 0);
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) partial3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(partial6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfHour(6);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendDayOfWeek((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField4.getAsShortText((long) (short) 100, locale7);
//        int int9 = delegatedDateTimeField4.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField4.getType();
//        org.joda.time.DurationField durationField11 = delegatedDateTimeField4.getRangeDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone14);
//        boolean boolean17 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate15, (java.lang.Object) (-1.0d));
//        int int18 = localDate15.getWeekOfWeekyear();
//        int int19 = localDate15.getDayOfWeek();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.LocalDate localDate21 = localDate15.minus(readablePeriod20);
//        org.joda.time.DateTime dateTime22 = localDate21.toDateTimeAtStartOfDay();
//        int int23 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate21);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2513" + "'", str8.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292268511) + "'", int9 == (-292268511));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNull(durationField11);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 292279536 + "'", int23 == 292279536);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DurationField durationField4 = buddhistChronology2.minutes();
        org.joda.time.DurationField durationField5 = buddhistChronology2.centuries();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendHourOfHalfday(2000);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField13 = iSOChronology12.halfdays();
        boolean boolean15 = iSOChronology12.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField18.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
        int int23 = localDate22.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = localDate22.toDateTimeAtCurrentTime(dateTimeZone24);
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime25.toYearMonthDay();
        org.joda.time.DateTime.Property property27 = dateTime25.millisOfSecond();
        org.joda.time.DateTime dateTime29 = dateTime25.minusSeconds(100);
        org.joda.time.DateTime dateTime30 = dateTime25.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime32 = dateTime25.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology33.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
        org.joda.time.DurationField durationField36 = delegatedDateTimeField35.getDurationField();
        java.util.Locale locale38 = null;
        java.lang.String str39 = delegatedDateTimeField35.getAsShortText((long) (short) 100, locale38);
        int int40 = delegatedDateTimeField35.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField35.getType();
        org.joda.time.DateTime.Property property42 = dateTime25.property(dateTimeFieldType41);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField43 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType41, 99);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField5, dateTimeFieldType41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(buddhistChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2513" + "'", str39.equals("2513"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-292268511) + "'", int40 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("ISOChronology[America/Los_Angeles]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ISOChronology[America/Los_Angeles]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) (short) 10, (java.lang.Number) (byte) 1, number3);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.String str8 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10 for Pacific Standard Time must not be smaller than 1" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value 10 for Pacific Standard Time must not be smaller than 1"));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateMidnight dateMidnight2 = localDate1.toDateMidnight();
        int int3 = localDate1.getMonthOfYear();
        org.joda.time.LocalDate.Property property4 = localDate1.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsShortText(locale5);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "20" + "'", str6.equals("20"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField3 = buddhistChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = buddhistChronology1.withZone(dateTimeZone5);
        long long8 = dateTimeZone5.convertUTCToLocal((long) 31636);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28768364L) + "'", long8 == (-28768364L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        long long4 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        try {
            org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 20");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) (short) 100, locale5);
        int int7 = delegatedDateTimeField2.getMinimumValue();
        int int10 = delegatedDateTimeField2.getDifference((-35L), (long) (short) -1);
        long long13 = delegatedDateTimeField2.add(0L, (int) (byte) 1);
        java.util.Locale locale16 = null;
        try {
            long long17 = delegatedDateTimeField2.set((long) (byte) 0, "PST", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PST\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32054400000L + "'", long13 == 32054400000L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(24);
        java.lang.Class<?> wildcardClass8 = dateTime7.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getRangeDurationField();
        long long24 = unsupportedDateTimeField20.add((long) 20, 86399999);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2726520621350400020L + "'", long24 == 2726520621350400020L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(24);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, (int) (byte) -1);
        org.joda.time.DateTime.Property property11 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime12 = property11.roundHalfFloorCopy();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime4.minusSeconds(100);
        org.joda.time.DateTime dateTime9 = dateTime4.withLaterOffsetAtOverlap();
        java.util.GregorianCalendar gregorianCalendar10 = dateTime4.toGregorianCalendar();
        boolean boolean11 = dateTime4.isAfterNow();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withLocale(locale2);
        try {
            org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.parse("Property[yearOfCentury]", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[yearOfCentury]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime4.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(10019);
//        boolean boolean14 = dateTime12.isAfter((long) (-5));
//        org.joda.time.DateTime dateTime16 = dateTime12.withWeekyear(0);
//        int int17 = dateTime12.getWeekOfWeekyear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.DurationFieldType durationFieldType2 = null;
//        boolean boolean3 = localDate1.isSupported(durationFieldType2);
//        int int4 = localDate1.getDayOfWeek();
//        org.joda.time.Partial partial5 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        org.joda.time.DurationFieldType durationFieldType6 = null;
//        try {
//            org.joda.time.Partial partial8 = partial5.withFieldAdded(durationFieldType6, (-13));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(24);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, (int) (byte) -1);
        org.joda.time.DateTime.Property property11 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime12 = dateTime7.withLaterOffsetAtOverlap();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateMidnight dateMidnight2 = localDate1.toDateMidnight();
        int int3 = dateMidnight2.getYearOfEra();
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getRangeDurationField();
        long long24 = unsupportedDateTimeField20.add((long) (-7), (long) 24);
        int int27 = unsupportedDateTimeField20.getDifference((long) (-13), (long) 'a');
        boolean boolean28 = unsupportedDateTimeField20.isLenient();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 757814399993L + "'", long24 == 757814399993L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.LocalDate localDate3 = localDate1.plus(readablePeriod2);
//        int int4 = localDate3.size();
//        org.joda.time.LocalDate localDate6 = localDate3.withWeekyear(843);
//        java.lang.String str7 = localDate6.toString();
//        org.joda.time.LocalDate localDate9 = localDate6.minusDays(0);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0843-06-13" + "'", str7.equals("0843-06-13"));
//        org.junit.Assert.assertNotNull(localDate9);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("2019");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '2019' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateMidnight dateMidnight2 = localDate1.toDateMidnight();
        int int3 = localDate1.getMonthOfYear();
        org.joda.time.LocalDate localDate5 = localDate1.withYearOfEra(10019);
        org.joda.time.LocalDate localDate7 = localDate5.minusYears((int) (byte) -1);
        org.joda.time.LocalDate localDate9 = localDate7.plusMonths(4);
        org.joda.time.LocalDate localDate11 = localDate9.withYearOfEra(1970);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) (short) 10, (java.lang.Number) (byte) 1, number3);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) 1 + "'", number8.equals((byte) 1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) (short) 10, (java.lang.Number) (byte) 1, number3);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.LocalDate localDate7 = localDate5.plusDays((int) (short) 1);
        int int8 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate7);
        long long10 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        int int11 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField3);
        int int14 = skipUndoDateTimeField12.get((long) 843);
        int int16 = skipUndoDateTimeField12.getMaximumValue(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int18 = gregorianChronology17.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField19 = gregorianChronology17.seconds();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.year();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate24 = localDate22.plus(readablePeriod23);
        org.joda.time.LocalTime localTime25 = null;
        org.joda.time.DateTime dateTime26 = localDate22.toDateTime(localTime25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) localTime25);
        int int28 = dateTime27.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology29.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField33 = iSOChronology32.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology34.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        org.joda.time.DurationField durationField37 = delegatedDateTimeField36.getDurationField();
        java.util.Locale locale39 = null;
        java.lang.String str40 = delegatedDateTimeField36.getAsShortText((long) (short) 100, locale39);
        int int41 = delegatedDateTimeField36.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = delegatedDateTimeField36.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField43 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30, durationField33, dateTimeFieldType42);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter44.withChronology((org.joda.time.Chronology) buddhistChronology45);
        org.joda.time.DurationField durationField47 = buddhistChronology45.minutes();
        org.joda.time.DurationField durationField48 = buddhistChronology45.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField49 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField48);
        boolean boolean50 = dateTime27.isSupported(dateTimeFieldType42);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField52 = new org.joda.time.field.DividedDateTimeField(dateTimeField20, dateTimeFieldType42, 1995);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType42, 1995);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292268511) + "'", int8 == (-292268511));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259200000L) + "'", long10 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-292268511) + "'", int11 == (-292268511));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2513 + "'", int14 == 2513);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 292279536 + "'", int16 == 292279536);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2513" + "'", str40.equals("2513"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-292268511) + "'", int41 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(buddhistChronology45);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("0010-06-16", (int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder3.setStandardOffset((-4));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 31607);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) 0, locale5);
//        org.joda.time.Chronology chronology7 = iSOChronology0.withZone(dateTimeZone3);
//        long long10 = dateTimeZone3.adjustOffset((long) 31636, false);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pacific Standard Time" + "'", str6.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 31636L + "'", long10 == 31636L);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate4.plusDays((int) (short) 1);
        int int7 = delegatedDateTimeField2.getMinimumValue((org.joda.time.ReadablePartial) localDate6);
        long long9 = delegatedDateTimeField2.roundHalfFloor((long) (short) 10);
        long long12 = delegatedDateTimeField2.add(100L, (long) (short) 10);
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField2.getAsText(31606, locale14);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 315705600100L + "'", long12 == 315705600100L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31606" + "'", str15.equals("31606"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(24);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, (int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(0);
        org.joda.time.DateTime dateTime14 = dateTime10.minusWeeks(19);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.halfdays();
        boolean boolean18 = iSOChronology15.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField21.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology15, (org.joda.time.DateTimeField) delegatedDateTimeField21);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone24);
        int int26 = localDate25.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = localDate25.toDateTimeAtCurrentTime(dateTimeZone27);
        org.joda.time.YearMonthDay yearMonthDay29 = dateTime28.toYearMonthDay();
        org.joda.time.DateTime.Property property30 = dateTime28.millisOfSecond();
        org.joda.time.DateTime dateTime32 = dateTime28.minusSeconds(100);
        org.joda.time.DateTime dateTime33 = dateTime28.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime35 = dateTime28.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
        org.joda.time.DurationField durationField39 = delegatedDateTimeField38.getDurationField();
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField38.getAsShortText((long) (short) 100, locale41);
        int int43 = delegatedDateTimeField38.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = delegatedDateTimeField38.getType();
        org.joda.time.DateTime.Property property45 = dateTime28.property(dateTimeFieldType44);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType44);
        org.joda.time.DateTime dateTime48 = dateTime10.withField(dateTimeFieldType44, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate(dateTimeZone49);
        int int51 = localDate50.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = localDate50.toDateTimeAtCurrentTime(dateTimeZone52);
        org.joda.time.LocalDate localDate55 = localDate50.withCenturyOfEra((int) (short) 1);
        org.joda.time.LocalDate.Property property56 = localDate50.weekyear();
        org.joda.time.LocalDate localDate57 = property56.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime58 = localDate57.toDateTimeAtCurrentTime();
        boolean boolean59 = dateTime48.equals((java.lang.Object) dateTime58);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(yearMonthDay29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2513" + "'", str42.equals("2513"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-292268511) + "'", int43 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 19 + "'", int51 == 19);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
//        int int8 = dateTime4.getDayOfYear();
//        org.joda.time.DateTime dateTime10 = dateTime4.withHourOfDay(1);
//        org.joda.time.DateTime.Property property11 = dateTime4.year();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 166 + "'", int8 == 166);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.LocalDate localDate3 = localDate1.plus(readablePeriod2);
        org.joda.time.LocalTime localTime4 = null;
        org.joda.time.DateTime dateTime5 = localDate1.toDateTime(localTime4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) localTime4);
        int int7 = dateTime6.getMonthOfYear();
        boolean boolean9 = dateTime6.isBefore((long) (byte) 100);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        boolean boolean3 = localDate1.isSupported(durationFieldType2);
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfYear();
        org.joda.time.DurationField durationField5 = property4.getLeapDurationField();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNull(durationField5);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        int int5 = dateTime4.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = dateTime4.withZone(dateTimeZone7);
//        java.lang.String str10 = dateTime4.toString();
//        boolean boolean11 = dateTime4.isAfterNow();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withChronology((org.joda.time.Chronology) buddhistChronology13);
//        org.joda.time.DurationField durationField15 = buddhistChronology13.minutes();
//        org.joda.time.DurationField durationField16 = buddhistChronology13.weekyears();
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology13.clockhourOfDay();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTime4, (org.joda.time.Chronology) buddhistChronology13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15T08:49:00.006-07:00" + "'", str10.equals("2019-06-15T08:49:00.006-07:00"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        int int9 = skipDateTimeField8.getMinimumValue();
        java.lang.String str11 = skipDateTimeField8.getAsText(0L);
        long long13 = skipDateTimeField8.roundHalfFloor((-77788166343211L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292268512) + "'", int9 == (-292268512));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-77788425600000L) + "'", long13 == (-77788425600000L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        boolean boolean4 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) 10019);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
        int int9 = localDate8.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = localDate8.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = dateTime11.getYearOfCentury();
        org.joda.time.DateTime dateTime14 = dateTime11.minusYears(24);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(readableDuration15, (int) (byte) -1);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekyear(0);
        org.joda.time.DateTime dateTime21 = dateTime17.minusWeeks(19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField23 = iSOChronology22.halfdays();
        boolean boolean25 = iSOChronology22.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        org.joda.time.DurationField durationField29 = delegatedDateTimeField28.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology22, (org.joda.time.DateTimeField) delegatedDateTimeField28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone31);
        int int33 = localDate32.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = localDate32.toDateTimeAtCurrentTime(dateTimeZone34);
        org.joda.time.YearMonthDay yearMonthDay36 = dateTime35.toYearMonthDay();
        org.joda.time.DateTime.Property property37 = dateTime35.millisOfSecond();
        org.joda.time.DateTime dateTime39 = dateTime35.minusSeconds(100);
        org.joda.time.DateTime dateTime40 = dateTime35.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime42 = dateTime35.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
        org.joda.time.DurationField durationField46 = delegatedDateTimeField45.getDurationField();
        java.util.Locale locale48 = null;
        java.lang.String str49 = delegatedDateTimeField45.getAsShortText((long) (short) 100, locale48);
        int int50 = delegatedDateTimeField45.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = delegatedDateTimeField45.getType();
        org.joda.time.DateTime.Property property52 = dateTime35.property(dateTimeFieldType51);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField30, dateTimeFieldType51);
        org.joda.time.DateTime dateTime55 = dateTime17.withField(dateTimeFieldType51, (int) (short) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType51, (int) (short) 100);
        java.lang.String str58 = offsetDateTimeField57.toString();
        java.util.Locale locale59 = null;
        int int60 = offsetDateTimeField57.getMaximumTextLength(locale59);
        long long63 = offsetDateTimeField57.add((long) 31606, (-48));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 19 + "'", int33 == 19);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(yearMonthDay36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2513" + "'", str49.equals("2513"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-292268511) + "'", int50 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "DateTimeField[weekyear]" + "'", str58.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 9 + "'", int60 == 9);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-1514419168394L) + "'", long63 == (-1514419168394L));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((-189302399948L), (org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime4.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(10019);
        boolean boolean14 = dateTime12.isAfter((long) (-5));
        org.joda.time.DateTime dateTime16 = dateTime12.withMillis((long) (-1));
        org.joda.time.DateTime.Property property17 = dateTime16.dayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.append(dateTimePrinter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendClockhourOfDay((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = dateTime4.minusSeconds(100);
//        org.joda.time.DateTime dateTime9 = dateTime4.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime11 = dateTime4.withCenturyOfEra((int) (byte) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusDays(1);
//        int int14 = dateTime13.getMillisOfDay();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31740630 + "'", int14 == 31740630);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsText(0L);
        int int39 = dividedDateTimeField35.getMinimumValue((long) 31702879);
        long long42 = dividedDateTimeField35.addWrapField(0L, 4);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(dateTimeZone43);
        org.joda.time.LocalDate localDate46 = localDate44.plusDays((int) (short) 1);
        java.util.Locale locale48 = null;
        java.lang.String str49 = dividedDateTimeField35.getAsShortText((org.joda.time.ReadablePartial) localDate46, 31619, locale48);
        long long52 = dividedDateTimeField35.add(10L, (-3));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-146504) + "'", int39 == (-146504));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 251824464000000L + "'", long42 == 251824464000000L);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "31619" + "'", str49.equals("31619"));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-188868326821990L) + "'", long52 == (-188868326821990L));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
        java.util.Locale locale22 = null;
        try {
            int int23 = unsupportedDateTimeField20.getMaximumShortTextLength(locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(24);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, (int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(0);
        org.joda.time.DateTime.Property property13 = dateTime10.weekOfWeekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) (short) 100, locale5);
        int int7 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.clockhourOfHalfday();
        org.joda.time.Partial partial12 = new org.joda.time.Partial(dateTimeFieldType8, 0, (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.Partial partial14 = partial12.plus(readablePeriod13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = partial12.getFormatter();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(partial14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsText(0L);
        int int39 = dividedDateTimeField35.getMinimumValue((long) 31702879);
        long long42 = dividedDateTimeField35.addWrapField(0L, 4);
        org.joda.time.DurationField durationField43 = dividedDateTimeField35.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-146504) + "'", int39 == (-146504));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 251824464000000L + "'", long42 == 251824464000000L);
        org.junit.Assert.assertNull(durationField43);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        long long8 = dateTimeZone5.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.Chronology chronology11 = zonedChronology9.withZone(dateTimeZone10);
        boolean boolean13 = zonedChronology9.equals((java.lang.Object) 1969);
        org.joda.time.Chronology chronology14 = zonedChronology9.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology16.clockhourOfDay();
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = copticChronology21.years();
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField29 = iSOChronology28.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology30.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31);
        org.joda.time.DurationField durationField33 = delegatedDateTimeField32.getDurationField();
        java.util.Locale locale35 = null;
        java.lang.String str36 = delegatedDateTimeField32.getAsShortText((long) (short) 100, locale35);
        int int37 = delegatedDateTimeField32.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = delegatedDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, durationField29, dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = dateTimeFormatter40.withChronology((org.joda.time.Chronology) buddhistChronology41);
        org.joda.time.DurationField durationField43 = buddhistChronology41.minutes();
        org.joda.time.DurationField durationField44 = buddhistChronology41.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField44);
        int int46 = localDate24.get(dateTimeFieldType38);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField(dateTimeField20, durationField22, dateTimeFieldType38, (int) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField49 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) zonedChronology9, (org.joda.time.DateTimeField) dividedDateTimeField48);
        boolean boolean50 = dividedDateTimeField48.isLenient();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2513" + "'", str36.equals("2513"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-292268511) + "'", int37 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1970 + "'", int46 == 1970);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        long long23 = unsupportedDateTimeField20.add(0L, (long) 'a');
        org.joda.time.DurationField durationField24 = unsupportedDateTimeField20.getLeapDurationField();
        java.util.Locale locale27 = null;
        try {
            long long28 = unsupportedDateTimeField20.set((long) 1995, "2019-06-15T15:48:09.450-07:00", locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3061497600000L + "'", long23 == 3061497600000L);
        org.junit.Assert.assertNull(durationField24);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        long long7 = property6.remainder();
        boolean boolean9 = property6.equals((java.lang.Object) 19);
        int int10 = property6.getMinimumValueOverall();
        org.joda.time.DateTime dateTime11 = property6.getDateTime();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) (short) 100, locale5);
        int int7 = delegatedDateTimeField2.getMinimumValue();
        int int10 = delegatedDateTimeField2.getDifference((-35L), (long) (short) -1);
        long long13 = delegatedDateTimeField2.add(0L, (int) (byte) 1);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField2.getLeapDurationField();
        long long17 = delegatedDateTimeField2.getDifferenceAsLong((long) 99, (long) (-5));
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(dateTimeZone18);
        org.joda.time.LocalDate localDate21 = localDate19.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
        boolean boolean24 = localDate21.equals((java.lang.Object) localDate23);
        org.joda.time.LocalDate.Property property25 = localDate23.yearOfEra();
        java.util.Locale locale27 = null;
        java.lang.String str28 = delegatedDateTimeField2.getAsText((org.joda.time.ReadablePartial) localDate23, 2019, locale27);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32054400000L + "'", long13 == 32054400000L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) 947);
        java.lang.String str4 = iSOChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
        int int7 = localDate6.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = localDate6.toDateTimeAtCurrentTime(dateTimeZone8);
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime9.toYearMonthDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withDayOfMonth((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime9.toDateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds(10019);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
        org.joda.time.Chronology chronology19 = iSOChronology0.withZone(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology0.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        try {
            int[] intArray24 = iSOChronology0.get(readablePeriod21, 757814399993L, (long) 11172);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateMidnight dateMidnight2 = localDate1.toDateMidnight();
        int int3 = localDate1.getMonthOfYear();
        try {
            int int5 = localDate1.getValue(999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 999");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
//        org.joda.time.DateTime dateTime9 = property7.addToCopy((long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        int int12 = localDate11.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = localDate11.toDateTimeAtCurrentTime(dateTimeZone13);
//        int int15 = dateTime14.getYearOfCentury();
//        org.joda.time.DateTime dateTime17 = dateTime14.minusYears(24);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(readableDuration18, (int) (byte) -1);
//        long long21 = property7.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
//        try {
//            org.joda.time.DateTime dateTime23 = property7.setCopy("1969-12-31T16:00:00.001-08:00");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31T16:00:00.001-08:00\" for yearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 23L + "'", long21 == 23L);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        boolean boolean4 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) 10019);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
        int int9 = localDate8.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = localDate8.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = dateTime11.getYearOfCentury();
        org.joda.time.DateTime dateTime14 = dateTime11.minusYears(24);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(readableDuration15, (int) (byte) -1);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekyear(0);
        org.joda.time.DateTime dateTime21 = dateTime17.minusWeeks(19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField23 = iSOChronology22.halfdays();
        boolean boolean25 = iSOChronology22.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        org.joda.time.DurationField durationField29 = delegatedDateTimeField28.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology22, (org.joda.time.DateTimeField) delegatedDateTimeField28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone31);
        int int33 = localDate32.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = localDate32.toDateTimeAtCurrentTime(dateTimeZone34);
        org.joda.time.YearMonthDay yearMonthDay36 = dateTime35.toYearMonthDay();
        org.joda.time.DateTime.Property property37 = dateTime35.millisOfSecond();
        org.joda.time.DateTime dateTime39 = dateTime35.minusSeconds(100);
        org.joda.time.DateTime dateTime40 = dateTime35.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime42 = dateTime35.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
        org.joda.time.DurationField durationField46 = delegatedDateTimeField45.getDurationField();
        java.util.Locale locale48 = null;
        java.lang.String str49 = delegatedDateTimeField45.getAsShortText((long) (short) 100, locale48);
        int int50 = delegatedDateTimeField45.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = delegatedDateTimeField45.getType();
        org.joda.time.DateTime.Property property52 = dateTime35.property(dateTimeFieldType51);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField30, dateTimeFieldType51);
        org.joda.time.DateTime dateTime55 = dateTime17.withField(dateTimeFieldType51, (int) (short) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType51, (int) (short) 100);
        java.util.Locale locale60 = null;
        try {
            long long61 = offsetDateTimeField57.set((long) (-7), "", locale60);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 19 + "'", int33 == 19);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(yearMonthDay36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2513" + "'", str49.equals("2513"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-292268511) + "'", int50 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTime55);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.plusDays((int) (short) 1);
        org.joda.time.LocalDate localDate5 = localDate3.withYear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtStartOfDay();
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (int) ' ');
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getRangeDurationField();
        long long24 = unsupportedDateTimeField20.add((long) (-7), (long) 24);
        try {
            long long26 = unsupportedDateTimeField20.roundHalfEven((long) 11172);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 757814399993L + "'", long24 == 757814399993L);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
//        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
//        boolean boolean4 = delegatedDateTimeField2.isLenient();
//        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) 10019);
//        boolean boolean7 = delegatedDateTimeField2.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone8);
//        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate9, (java.lang.Object) (-1.0d));
//        int int12 = localDate9.getWeekOfWeekyear();
//        int int13 = localDate9.getDayOfWeek();
//        int[] intArray19 = new int[] { 365, (-2), (byte) 1, 10, (byte) 1 };
//        int int20 = delegatedDateTimeField2.getMinimumValue((org.joda.time.ReadablePartial) localDate9, intArray19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        int int23 = localDate22.getYearOfCentury();
//        org.joda.time.DurationFieldType durationFieldType24 = null;
//        boolean boolean25 = localDate22.isSupported(durationFieldType24);
//        int int26 = localDate22.getWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(dateTimeZone28);
//        int int30 = localDate29.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = localDate29.toDateTimeAtCurrentTime(dateTimeZone31);
//        org.joda.time.YearMonthDay yearMonthDay33 = dateTime32.toYearMonthDay();
//        boolean boolean34 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay33);
//        int[] intArray35 = yearMonthDay33.getValues();
//        int[] intArray37 = delegatedDateTimeField2.add((org.joda.time.ReadablePartial) localDate22, 56791, intArray35, 0);
//        org.joda.time.LocalDate.Property property38 = localDate22.dayOfWeek();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292268511) + "'", int20 == (-292268511));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 19 + "'", int30 == 19);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(yearMonthDay33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertNotNull(property38);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsShortText((long) (-25200000));
        int int40 = dividedDateTimeField35.getDifference((long) (byte) 100, 1L);
        org.joda.time.DurationField durationField41 = dividedDateTimeField35.getRangeDurationField();
        int int43 = dividedDateTimeField35.get((long) 948);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNull(durationField41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        long long8 = dateTimeZone5.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        java.lang.String str12 = copticChronology11.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str12.equals("CopticChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 0, locale3);
//        long long7 = dateTimeZone1.adjustOffset((-189302399948L), false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str10 = cachedDateTimeZone8.getNameKey(100L);
//        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone8.getUncachedZone();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-189302399948L) + "'", long7 == (-189302399948L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        int int9 = skipDateTimeField8.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate11, (java.lang.Object) (-1.0d));
        org.joda.time.LocalDate.Property property14 = localDate11.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField19 = iSOChronology18.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
        org.joda.time.DurationField durationField23 = delegatedDateTimeField22.getDurationField();
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField22.getAsShortText((long) (short) 100, locale25);
        int int27 = delegatedDateTimeField22.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField22.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, durationField19, dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter30.withChronology((org.joda.time.Chronology) buddhistChronology31);
        org.joda.time.DurationField durationField33 = buddhistChronology31.minutes();
        org.joda.time.DurationField durationField34 = buddhistChronology31.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField34);
        org.joda.time.LocalDate.Property property36 = localDate11.property(dateTimeFieldType28);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, dateTimeFieldType28);
        java.util.Locale locale38 = null;
        int int39 = skipDateTimeField8.getMaximumShortTextLength(locale38);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292268512) + "'", int9 == (-292268512));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2513" + "'", str26.equals("2513"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-292268511) + "'", int27 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField3 = buddhistChronology1.minutes();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = buddhistChronology1.withZone(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology1.days();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.weekyear();
        org.joda.time.DurationField durationField10 = buddhistChronology8.halfdays();
        org.joda.time.Chronology chronology11 = buddhistChronology8.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        long long16 = dateTimeZone13.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance(chronology11, dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.Chronology chronology19 = zonedChronology17.withZone(dateTimeZone18);
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) 1969);
        boolean boolean22 = buddhistChronology1.equals((java.lang.Object) 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField3 = buddhistChronology1.minutes();
        org.joda.time.DurationField durationField4 = buddhistChronology1.weekyears();
        long long7 = durationField4.subtract((long) (-146504), (long) 133);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-4196707346504L) + "'", long7 == (-4196707346504L));
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.plusDays((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
//        boolean boolean6 = localDate3.equals((java.lang.Object) localDate5);
//        org.joda.time.LocalDate.Property property7 = localDate5.yearOfEra();
//        int int8 = localDate5.getYear();
//        int int9 = localDate5.getDayOfYear();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 166 + "'", int9 == 166);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) (short) 100, locale5);
        int int7 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate9.plus(readablePeriod10);
        int int12 = localDate11.size();
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField2.getAsText((org.joda.time.ReadablePartial) localDate11, locale13);
        int int15 = localDate11.getMonthOfYear();
        int int16 = localDate11.getYear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        java.lang.String str7 = property6.toString();
//        org.joda.time.DateTime dateTime8 = property6.getDateTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        int int11 = localDate10.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = localDate10.toDateTimeAtCurrentTime(dateTimeZone12);
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime13.withCenturyOfEra((int) (byte) 100);
//        int int19 = property6.getDifference((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.MutableDateTime mutableDateTime20 = dateTime13.toMutableDateTime();
//        org.joda.time.DateTime dateTime22 = dateTime13.withWeekyear(100);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
//        org.joda.time.DateTime dateTime24 = property23.roundHalfCeilingCopy();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[millisOfSecond]" + "'", str7.equals("Property[millisOfSecond]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        int int4 = localDate3.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime(dateTimeZone5);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        boolean boolean8 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay7);
        int[] intArray9 = yearMonthDay7.getValues();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) yearMonthDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(intArray9);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = dateTime4.withCenturyOfEra((int) (byte) 100);
//        int int10 = dateTime4.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = dateTime4.withWeekyear(1969);
//        int int13 = dateTime12.getYear();
//        org.joda.time.DateTime dateTime15 = dateTime12.minusSeconds((int) '4');
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsText(0L);
        long long40 = dividedDateTimeField35.set((long) 6, 1970);
        boolean boolean41 = dividedDateTimeField35.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 124023554870400006L + "'", long40 == 124023554870400006L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = iSOChronology5.add(readablePeriod7, (long) 6, 10);
        org.joda.time.DurationField durationField11 = iSOChronology5.years();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology5.weekyear();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(12, 133, (int) '4', (-25200000), (-146504), (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 6L + "'", long10 == 6L);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.plusDays((int) (short) 1);
        org.joda.time.LocalDate localDate5 = localDate3.withYear((int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate3.minus(readablePeriod6);
        org.joda.time.Interval interval8 = localDate3.toInterval();
        java.util.Locale locale10 = null;
        java.lang.String str11 = localDate3.toString("0010-06-16", locale10);
        org.joda.time.DateTime dateTime12 = localDate3.toDateTimeAtCurrentTime();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0010-06-16" + "'", str11.equals("0010-06-16"));
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        int int23 = unsupportedDateTimeField20.getDifference((long) (byte) 0, 0L);
        long long26 = unsupportedDateTimeField20.add((long) 232, 31619);
        try {
            int int27 = unsupportedDateTimeField20.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 997799644800232L + "'", long26 == 997799644800232L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        int int5 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) 947);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTwoDigitYear(208, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendCenturyOfEra(0, 948);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField3 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfMonth();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField3 = buddhistChronology1.minutes();
        long long7 = buddhistChronology1.add(1560638889450L, (long) (-146504), (-292268512));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 44379144971498L + "'", long7 == 44379144971498L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.LocalDate localDate3 = localDate1.plus(readablePeriod2);
        org.joda.time.LocalTime localTime4 = null;
        org.joda.time.DateTime dateTime5 = localDate1.toDateTime(localTime4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) localTime4);
        org.joda.time.DateTime dateTime8 = dateTime6.plusDays(2019);
        org.joda.time.DateTime dateTime10 = dateTime6.minusMonths((int) (short) 100);
        org.joda.time.DateTime.Property property11 = dateTime10.weekyear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        java.lang.String str7 = property6.toString();
//        org.joda.time.DateTime dateTime8 = property6.getDateTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        int int11 = localDate10.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = localDate10.toDateTimeAtCurrentTime(dateTimeZone12);
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime13.withCenturyOfEra((int) (byte) 100);
//        int int19 = property6.getDifference((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.MutableDateTime mutableDateTime20 = dateTime13.toMutableDateTime();
//        org.joda.time.DateTime dateTime22 = dateTime13.withWeekyear(100);
//        org.joda.time.DateTime.Property property23 = dateTime22.secondOfMinute();
//        org.joda.time.DateTime dateTime24 = property23.getDateTime();
//        org.joda.time.DateTime dateTime26 = dateTime24.minus(0L);
//        org.joda.time.DateTime dateTime28 = dateTime24.plusMillis((-292268512));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[millisOfSecond]" + "'", str7.equals("Property[millisOfSecond]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        long long23 = unsupportedDateTimeField20.add(0L, (long) 'a');
        org.joda.time.DurationField durationField24 = unsupportedDateTimeField20.getLeapDurationField();
        boolean boolean25 = unsupportedDateTimeField20.isLenient();
        try {
            long long27 = unsupportedDateTimeField20.remainder(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3061497600000L + "'", long23 == 3061497600000L);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
//        org.joda.time.DateTime dateTime9 = property7.addToCopy((long) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        int int12 = localDate11.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = localDate11.toDateTimeAtCurrentTime(dateTimeZone13);
//        int int15 = dateTime14.getYearOfCentury();
//        org.joda.time.DateTime dateTime17 = dateTime14.minusYears(24);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(readableDuration18, (int) (byte) -1);
//        long long21 = property7.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
//        int int24 = localDate23.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = localDate23.toDateTimeAtCurrentTime(dateTimeZone25);
//        org.joda.time.YearMonthDay yearMonthDay27 = dateTime26.toYearMonthDay();
//        org.joda.time.DateTime.Property property28 = dateTime26.millisOfSecond();
//        org.joda.time.DateTime.Property property29 = dateTime26.yearOfCentury();
//        int int30 = dateTime26.getDayOfYear();
//        long long31 = property7.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTime.Property property32 = dateTime26.dayOfMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 23L + "'", long21 == 23L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 19 + "'", int24 == 19);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(yearMonthDay27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 166 + "'", int30 == 166);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(property32);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0843-06-13");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.DurationField durationField3 = buddhistChronology1.halfdays();
        org.joda.time.Chronology chronology4 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        long long9 = dateTimeZone6.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology12);
        java.lang.Appendable appendable14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
        int int17 = localDate16.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime(dateTimeZone18);
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime19.toYearMonthDay();
        org.joda.time.DateTime.Property property21 = dateTime19.millisOfSecond();
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        int int23 = dateTime19.getYear();
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.DateTime dateTime25 = dateTime19.minus(readableDuration24);
        try {
            dateTimeFormatter0.printTo(appendable14, (org.joda.time.ReadableInstant) dateTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(yearMonthDay20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(dateTime25);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
//        int int11 = dateTime10.getMonthOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField16 = iSOChronology15.months();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
//        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
//        int int24 = delegatedDateTimeField19.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
//        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
//        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
//        java.lang.String str37 = dividedDateTimeField35.getAsText(0L);
//        org.joda.time.ReadablePartial readablePartial38 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField41);
//        org.joda.time.DurationField durationField43 = delegatedDateTimeField42.getDurationField();
//        boolean boolean44 = delegatedDateTimeField42.isLenient();
//        java.lang.String str46 = delegatedDateTimeField42.getAsShortText((long) 10019);
//        boolean boolean47 = delegatedDateTimeField42.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate(dateTimeZone48);
//        boolean boolean51 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate49, (java.lang.Object) (-1.0d));
//        int int52 = localDate49.getWeekOfWeekyear();
//        int int53 = localDate49.getDayOfWeek();
//        int[] intArray59 = new int[] { 365, (-2), (byte) 1, 10, (byte) 1 };
//        int int60 = delegatedDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) localDate49, intArray59);
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.LocalDate localDate62 = new org.joda.time.LocalDate(dateTimeZone61);
//        int int63 = localDate62.getYearOfCentury();
//        org.joda.time.DurationFieldType durationFieldType64 = null;
//        boolean boolean65 = localDate62.isSupported(durationFieldType64);
//        int int66 = localDate62.getWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone68 = null;
//        org.joda.time.LocalDate localDate69 = new org.joda.time.LocalDate(dateTimeZone68);
//        int int70 = localDate69.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone71 = null;
//        org.joda.time.DateTime dateTime72 = localDate69.toDateTimeAtCurrentTime(dateTimeZone71);
//        org.joda.time.YearMonthDay yearMonthDay73 = dateTime72.toYearMonthDay();
//        boolean boolean74 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay73);
//        int[] intArray75 = yearMonthDay73.getValues();
//        int[] intArray77 = delegatedDateTimeField42.add((org.joda.time.ReadablePartial) localDate62, 56791, intArray75, 0);
//        try {
//            int[] intArray79 = dividedDateTimeField35.set(readablePartial38, 11172, intArray77, (-13));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11172");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
//        org.junit.Assert.assertNotNull(buddhistChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2513" + "'", str46.equals("2513"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 24 + "'", int52 == 24);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-292268511) + "'", int60 == (-292268511));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 19 + "'", int63 == 19);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 19 + "'", int70 == 19);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(yearMonthDay73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertNotNull(intArray75);
//        org.junit.Assert.assertNotNull(intArray77);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        try {
            org.joda.time.LocalDate localDate4 = localDate1.withMonthOfYear(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(1560638880305L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate1.withCenturyOfEra((int) (short) 1);
        org.joda.time.LocalDate.Property property7 = localDate6.year();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate1.withCenturyOfEra((int) (short) 1);
        org.joda.time.LocalDate.Property property7 = localDate1.weekyear();
        org.joda.time.LocalDate localDate8 = property7.roundHalfCeilingCopy();
        org.joda.time.LocalDate.Property property9 = localDate8.dayOfYear();
        org.joda.time.Chronology chronology10 = localDate8.getChronology();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.LocalDate localDate7 = localDate5.plusDays((int) (short) 1);
        int int8 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate7);
        long long10 = delegatedDateTimeField3.roundHalfFloor((long) (short) 10);
        int int11 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField3);
        int int14 = skipUndoDateTimeField12.get((long) 86399999);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292268511) + "'", int8 == (-292268511));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259200000L) + "'", long10 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-292268511) + "'", int11 == (-292268511));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2513 + "'", int14 == 2513);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("0010-06-16", (int) (short) 100);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder3.addCutover(86399999, 'a', 99, 4, 10019, true, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime4.toDateTime(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        long long15 = dateTimeZone12.adjustOffset(0L, false);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone17);
        java.lang.String str19 = dateTimeZone17.getID();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone8, dateTimeZone17);
        java.lang.String str22 = dateTime20.toString("[]");
        org.joda.time.DateTime.Property property23 = dateTime20.weekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "America/Los_Angeles" + "'", str19.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "[]" + "'", str22.equals("[]"));
        org.junit.Assert.assertNotNull(property23);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) 0, locale4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        java.lang.String str7 = property6.toString();
//        org.joda.time.DateTime dateTime8 = property6.getDateTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        int int11 = localDate10.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = localDate10.toDateTimeAtCurrentTime(dateTimeZone12);
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime13.withCenturyOfEra((int) (byte) 100);
//        int int19 = property6.getDifference((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
//        int int22 = localDate21.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = localDate21.toDateTimeAtCurrentTime(dateTimeZone23);
//        org.joda.time.YearMonthDay yearMonthDay25 = dateTime24.toYearMonthDay();
//        org.joda.time.DateTime.Property property26 = dateTime24.millisOfSecond();
//        org.joda.time.DateTime dateTime28 = dateTime24.minusSeconds(100);
//        org.joda.time.DateTime dateTime29 = dateTime24.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime31 = dateTime24.withMonthOfYear((int) (byte) 10);
//        int int32 = property6.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        java.util.Locale locale33 = null;
//        int int34 = property6.getMaximumTextLength(locale33);
//        org.joda.time.DateTime dateTime35 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime37 = dateTime35.plusWeeks((int) (byte) 100);
//        java.util.Locale locale38 = null;
//        java.util.Calendar calendar39 = dateTime35.toCalendar(locale38);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[millisOfSecond]" + "'", str7.equals("Property[millisOfSecond]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19 + "'", int22 == 19);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(yearMonthDay25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-3) + "'", int32 == (-3));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(calendar39);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        long long8 = dateTimeZone5.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology9.yearOfEra();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.halfdays();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField12.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology6, (org.joda.time.DateTimeField) delegatedDateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
        int int17 = localDate16.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime(dateTimeZone18);
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime19.toYearMonthDay();
        org.joda.time.DateTime.Property property21 = dateTime19.millisOfSecond();
        org.joda.time.DateTime dateTime23 = dateTime19.minusSeconds(100);
        org.joda.time.DateTime dateTime24 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime26 = dateTime19.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        org.joda.time.DurationField durationField30 = delegatedDateTimeField29.getDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField29.getAsShortText((long) (short) 100, locale32);
        int int34 = delegatedDateTimeField29.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = delegatedDateTimeField29.getType();
        org.joda.time.DateTime.Property property36 = dateTime19.property(dateTimeFieldType35);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType35, 99);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder3.appendMillisOfDay(1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder3.appendPattern("29");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(yearMonthDay20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2513" + "'", str33.equals("2513"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-292268511) + "'", int34 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        boolean boolean4 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) 10019);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
        int int9 = localDate8.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = localDate8.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = dateTime11.getYearOfCentury();
        org.joda.time.DateTime dateTime14 = dateTime11.minusYears(24);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(readableDuration15, (int) (byte) -1);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekyear(0);
        org.joda.time.DateTime dateTime21 = dateTime17.minusWeeks(19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField23 = iSOChronology22.halfdays();
        boolean boolean25 = iSOChronology22.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        org.joda.time.DurationField durationField29 = delegatedDateTimeField28.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology22, (org.joda.time.DateTimeField) delegatedDateTimeField28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone31);
        int int33 = localDate32.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = localDate32.toDateTimeAtCurrentTime(dateTimeZone34);
        org.joda.time.YearMonthDay yearMonthDay36 = dateTime35.toYearMonthDay();
        org.joda.time.DateTime.Property property37 = dateTime35.millisOfSecond();
        org.joda.time.DateTime dateTime39 = dateTime35.minusSeconds(100);
        org.joda.time.DateTime dateTime40 = dateTime35.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime42 = dateTime35.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
        org.joda.time.DurationField durationField46 = delegatedDateTimeField45.getDurationField();
        java.util.Locale locale48 = null;
        java.lang.String str49 = delegatedDateTimeField45.getAsShortText((long) (short) 100, locale48);
        int int50 = delegatedDateTimeField45.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = delegatedDateTimeField45.getType();
        org.joda.time.DateTime.Property property52 = dateTime35.property(dateTimeFieldType51);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField30, dateTimeFieldType51);
        org.joda.time.DateTime dateTime55 = dateTime17.withField(dateTimeFieldType51, (int) (short) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType51, (int) (short) 100);
        boolean boolean58 = offsetDateTimeField57.isLenient();
        long long61 = offsetDateTimeField57.set((long) (byte) 10, "2019");
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 19 + "'", int33 == 19);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(yearMonthDay36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2513" + "'", str49.equals("2513"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-292268511) + "'", int50 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-18743961599990L) + "'", long61 == (-18743961599990L));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = copticChronology6.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        long long12 = dateTimeZone9.adjustOffset(0L, false);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.Chronology chronology14 = copticChronology6.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = copticChronology6.getZone();
        java.lang.String str16 = dateTimeZone15.getID();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(19, (-292268512), 947, 0, (-28800000), 6, dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate1.withDayOfMonth(8);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
        int int9 = localDate8.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = localDate8.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = dateTime11.getYearOfCentury();
        org.joda.time.DateTime dateTime14 = dateTime11.minusYears(24);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(readableDuration15, (int) (byte) -1);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
        int int22 = localDate21.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = localDate21.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = dateTime24.getYearOfCentury();
        org.joda.time.DateTime dateTime27 = dateTime24.minusYears(24);
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded(readableDuration28, (int) (byte) -1);
        org.joda.time.DateTime dateTime32 = dateTime30.withWeekyear(0);
        org.joda.time.DateTime dateTime34 = dateTime30.minusWeeks(19);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField36 = iSOChronology35.halfdays();
        boolean boolean38 = iSOChronology35.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField40 = buddhistChronology39.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField40);
        org.joda.time.DurationField durationField42 = delegatedDateTimeField41.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology35, (org.joda.time.DateTimeField) delegatedDateTimeField41);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate(dateTimeZone44);
        int int46 = localDate45.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = localDate45.toDateTimeAtCurrentTime(dateTimeZone47);
        org.joda.time.YearMonthDay yearMonthDay49 = dateTime48.toYearMonthDay();
        org.joda.time.DateTime.Property property50 = dateTime48.millisOfSecond();
        org.joda.time.DateTime dateTime52 = dateTime48.minusSeconds(100);
        org.joda.time.DateTime dateTime53 = dateTime48.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime55 = dateTime48.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField57 = buddhistChronology56.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField58 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField57);
        org.joda.time.DurationField durationField59 = delegatedDateTimeField58.getDurationField();
        java.util.Locale locale61 = null;
        java.lang.String str62 = delegatedDateTimeField58.getAsShortText((long) (short) 100, locale61);
        int int63 = delegatedDateTimeField58.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = delegatedDateTimeField58.getType();
        org.joda.time.DateTime.Property property65 = dateTime48.property(dateTimeFieldType64);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField66 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField43, dateTimeFieldType64);
        org.joda.time.DateTime dateTime68 = dateTime30.withField(dateTimeFieldType64, (int) (short) 100);
        boolean boolean69 = dateTime19.isSupported(dateTimeFieldType64);
        org.joda.time.chrono.GJChronology gJChronology70 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField71 = gJChronology70.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField72 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField71);
        boolean boolean73 = localDate6.isSupported(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19 + "'", int22 == 19);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 19 + "'", int25 == 19);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(buddhistChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 19 + "'", int46 == 19);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(yearMonthDay49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(buddhistChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2513" + "'", str62.equals("2513"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-292268511) + "'", int63 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(gJChronology70);
        org.junit.Assert.assertNotNull(durationField71);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime4.toDateTime(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
//        java.lang.String str12 = dateTime10.toString(dateTimeFormatter11);
//        org.joda.time.Chronology chronology13 = dateTimeFormatter11.getChronology();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter11.withPivotYear((java.lang.Integer) 1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019W246" + "'", str12.equals("2019W246"));
//        org.junit.Assert.assertNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime4.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(10019);
        org.joda.time.DateTimeZone dateTimeZone13 = dateTime12.getZone();
        org.joda.time.DateTime dateTime15 = dateTime12.withHourOfDay(1);
        org.joda.time.DateTime dateTime17 = dateTime12.plusMillis((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsShortText((long) (-25200000));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField35);
        long long40 = remainderDateTimeField38.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28800000L + "'", long40 == 28800000L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DurationField durationField4 = delegatedDateTimeField3.getDurationField();
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField3.getAsShortText((long) (short) 100, locale6);
        int int8 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.clockhourOfHalfday();
        org.joda.time.Partial partial13 = new org.joda.time.Partial(dateTimeFieldType9, 0, (org.joda.time.Chronology) iSOChronology11);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType9, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2513" + "'", str7.equals("2513"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292268511) + "'", int8 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.year();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.millis();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        java.lang.String str2 = gJChronology0.toString();
        try {
            long long7 = gJChronology0.getDateTimeMillis((-7), (int) (byte) 1, (-13), (-96));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -96 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.halfdays();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField12.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology6, (org.joda.time.DateTimeField) delegatedDateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
        int int17 = localDate16.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime(dateTimeZone18);
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime19.toYearMonthDay();
        org.joda.time.DateTime.Property property21 = dateTime19.millisOfSecond();
        org.joda.time.DateTime dateTime23 = dateTime19.minusSeconds(100);
        org.joda.time.DateTime dateTime24 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime26 = dateTime19.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        org.joda.time.DurationField durationField30 = delegatedDateTimeField29.getDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField29.getAsShortText((long) (short) 100, locale32);
        int int34 = delegatedDateTimeField29.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = delegatedDateTimeField29.getType();
        org.joda.time.DateTime.Property property36 = dateTime19.property(dateTimeFieldType35);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType35, 99);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder3.appendMillisOfDay(1970);
        boolean boolean43 = dateTimeFormatterBuilder3.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(yearMonthDay20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2513" + "'", str33.equals("2513"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-292268511) + "'", int34 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
//        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
//        boolean boolean4 = delegatedDateTimeField2.isLenient();
//        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) 10019);
//        boolean boolean7 = delegatedDateTimeField2.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone8);
//        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate9, (java.lang.Object) (-1.0d));
//        int int12 = localDate9.getWeekOfWeekyear();
//        int int13 = localDate9.getDayOfWeek();
//        int[] intArray19 = new int[] { 365, (-2), (byte) 1, 10, (byte) 1 };
//        int int20 = delegatedDateTimeField2.getMinimumValue((org.joda.time.ReadablePartial) localDate9, intArray19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        int int23 = localDate22.getYearOfCentury();
//        org.joda.time.DurationFieldType durationFieldType24 = null;
//        boolean boolean25 = localDate22.isSupported(durationFieldType24);
//        int int26 = localDate22.getWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(dateTimeZone28);
//        int int30 = localDate29.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = localDate29.toDateTimeAtCurrentTime(dateTimeZone31);
//        org.joda.time.YearMonthDay yearMonthDay33 = dateTime32.toYearMonthDay();
//        boolean boolean34 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay33);
//        int[] intArray35 = yearMonthDay33.getValues();
//        int[] intArray37 = delegatedDateTimeField2.add((org.joda.time.ReadablePartial) localDate22, 56791, intArray35, 0);
//        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField2, 960, (int) (byte) 100, 1995);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.LocalDate localDate45 = localDate43.plus(readablePeriod44);
//        int int46 = localDate45.size();
//        org.joda.time.LocalDate localDate48 = localDate45.withWeekyear(843);
//        org.joda.time.LocalDate.Property property49 = localDate45.yearOfEra();
//        org.joda.time.LocalDate localDate51 = property49.addToCopy(2019);
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate51, 292279636, locale53);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292268511) + "'", int20 == (-292268511));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 19 + "'", int30 == 19);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(yearMonthDay33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(localDate51);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "292279636" + "'", str54.equals("292279636"));
//    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = dateTime4.withCenturyOfEra((int) (byte) 100);
//        int int10 = dateTime4.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = dateTime4.withWeekyear(1969);
//        org.joda.time.DateTime dateTime13 = dateTime12.toDateTimeISO();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone14);
//        int int16 = localDate15.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = localDate15.toDateTimeAtCurrentTime(dateTimeZone17);
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
//        org.joda.time.DateTime dateTime21 = dateTime18.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime.Property property22 = dateTime21.yearOfCentury();
//        org.joda.time.DateTime.Property property23 = dateTime21.yearOfCentury();
//        org.joda.time.DateTime dateTime24 = property23.roundHalfEvenCopy();
//        boolean boolean25 = dateTime13.isBefore((org.joda.time.ReadableInstant) dateTime24);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 19 + "'", int16 == 19);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) (short) 10, (java.lang.Number) (byte) 1, number3);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str9 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10" + "'", str8.equals("10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10 for Pacific Standard Time must not be smaller than 1" + "'", str9.equals("org.joda.time.IllegalFieldValueException: Value 10 for Pacific Standard Time must not be smaller than 1"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.era();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str1.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value null for weekyear is not supported: CopticChronology[America/Los_Angeles]");
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.plusDays((int) (short) 1);
//        org.joda.time.LocalDate localDate5 = localDate3.withYear((int) (byte) 10);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.LocalDate localDate7 = localDate3.minus(readablePeriod6);
//        org.joda.time.Interval interval8 = localDate3.toInterval();
//        int int9 = localDate3.getWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        int int12 = localDate11.getYearOfCentury();
//        int int13 = localDate11.getDayOfWeek();
//        boolean boolean14 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate11);
//        boolean boolean16 = localDate11.equals((java.lang.Object) (-2));
//        org.joda.time.DateTime dateTime17 = localDate11.toDateTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime19 = dateTime17.minusMonths((-292268510));
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(interval8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) (short) 10, (java.lang.Number) (byte) 1, number3);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = localDate1.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property6 = localDate1.dayOfMonth();
        java.util.Locale locale7 = null;
        int int8 = property6.getMaximumTextLength(locale7);
        org.joda.time.LocalDate localDate10 = property6.setCopy(24);
        org.joda.time.LocalDate localDate11 = property6.withMinimumValue();
        java.util.Locale locale12 = null;
        int int13 = property6.getMaximumTextLength(locale12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, ' ', 9, 0, (int) (byte) -1, true, 7);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("", 999);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder11.addRecurringSavings("", 0, (int) (byte) 10, (-7), '4', 0, (int) (short) -1, 947, true, 292279536);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder30 = dateTimeZoneBuilder11.addCutover(0, '#', 5, 48, (-292268510), false, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        int int23 = unsupportedDateTimeField20.getDifference((long) (byte) 0, 0L);
        long long26 = unsupportedDateTimeField20.add((long) 232, 31619);
        org.joda.time.DurationField durationField27 = unsupportedDateTimeField20.getDurationField();
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField20.getDurationField();
        try {
            int int30 = unsupportedDateTimeField20.getMaximumValue(1571154509319L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 997799644800232L + "'", long26 == 997799644800232L);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) (short) 100, locale5);
        int int7 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.clockhourOfHalfday();
        org.joda.time.Partial partial12 = new org.joda.time.Partial(dateTimeFieldType8, 0, (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.Partial partial14 = partial12.plus(readablePeriod13);
        org.joda.time.DateTimeField[] dateTimeFieldArray15 = partial12.getFields();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(partial14);
        org.junit.Assert.assertNotNull(dateTimeFieldArray15);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
        long long24 = unsupportedDateTimeField20.add((-292268536L), (int) (byte) 10);
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField20.getRangeDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 315413331464L + "'", long24 == 315413331464L);
        org.junit.Assert.assertNull(durationField25);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = dateTime4.minusSeconds(100);
//        int int9 = dateTime8.getSecondOfDay();
//        int int10 = dateTime8.getCenturyOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime8.millisOfDay();
//        org.joda.time.DateTime dateTime12 = property11.withMinimumValue();
//        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31652 + "'", int9 == 31652);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("weekyear", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"weekyear/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate4.plusDays((int) (short) 1);
        int int7 = delegatedDateTimeField2.getMinimumValue((org.joda.time.ReadablePartial) localDate6);
        long long9 = delegatedDateTimeField2.roundHalfFloor((long) (short) 10);
        int int10 = delegatedDateTimeField2.getMinimumValue();
        java.util.Locale locale11 = null;
        int int12 = delegatedDateTimeField2.getMaximumTextLength(locale11);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 1995);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField14.getAsText(0L, locale16);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292268511) + "'", int10 == (-292268511));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4508" + "'", str17.equals("4508"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
        int int9 = localDate8.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = localDate8.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = dateTime11.getYearOfCentury();
        org.joda.time.DateTime dateTime14 = dateTime11.minusYears(24);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(readableDuration15, (int) (byte) -1);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekyear(0);
        org.joda.time.DateTime dateTime21 = dateTime17.minusWeeks(19);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
        int int24 = localDate23.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = localDate23.toDateTimeAtCurrentTime(dateTimeZone25);
        org.joda.time.YearMonthDay yearMonthDay27 = dateTime26.toYearMonthDay();
        org.joda.time.DateTime.Property property28 = dateTime26.millisOfSecond();
        org.joda.time.DateTime dateTime30 = dateTime26.minusSeconds(100);
        org.joda.time.DateTime dateTime31 = dateTime26.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime33 = dateTime26.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology34.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        org.joda.time.DurationField durationField37 = delegatedDateTimeField36.getDurationField();
        java.util.Locale locale39 = null;
        java.lang.String str40 = delegatedDateTimeField36.getAsShortText((long) (short) 100, locale39);
        int int41 = delegatedDateTimeField36.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = delegatedDateTimeField36.getType();
        org.joda.time.DateTime.Property property43 = dateTime26.property(dateTimeFieldType42);
        int int44 = dateTime21.get(dateTimeFieldType42);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType42);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder45.appendMonthOfYear(365);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder45.appendLiteral("2019-06-15T15:47:57.033-07:00");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 19 + "'", int24 == 19);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(yearMonthDay27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2513" + "'", str40.equals("2513"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-292268511) + "'", int41 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1995 + "'", int44 == 1995);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, (long) 6, 10);
        org.joda.time.DurationField durationField6 = iSOChronology0.years();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 6L + "'", long5 == 6L);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        org.joda.time.DurationField durationField36 = dividedDateTimeField35.getDurationField();
        java.util.Locale locale39 = null;
        long long40 = dividedDateTimeField35.set((long) 31606, "69", locale39);
        java.lang.String str42 = dividedDateTimeField35.getAsText(757814399993L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 4343972284831606L + "'", long40 == 4343972284831606L);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 31740630);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("2513", dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsShortText((long) (-25200000));
        int int40 = dividedDateTimeField35.getDifference((long) (byte) 100, 1L);
        long long42 = dividedDateTimeField35.remainder(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate(dateTimeZone46);
        org.joda.time.LocalDate localDate49 = localDate47.plusDays((int) (short) 1);
        int int50 = delegatedDateTimeField45.getMinimumValue((org.joda.time.ReadablePartial) localDate49);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate(dateTimeZone51);
        org.joda.time.LocalDate localDate54 = localDate52.plusDays((int) (short) 1);
        org.joda.time.LocalDate localDate56 = localDate54.withYear((int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.LocalDate localDate58 = localDate54.minus(readablePeriod57);
        int int59 = localDate49.compareTo((org.joda.time.ReadablePartial) localDate58);
        org.joda.time.LocalDate.Property property60 = localDate58.dayOfMonth();
        java.util.Locale locale61 = null;
        java.lang.String str62 = dividedDateTimeField35.getAsText((org.joda.time.ReadablePartial) localDate58, locale61);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-292268511) + "'", int50 == (-292268511));
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2019" + "'", str62.equals("2019"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2489", "", 2000, 1970);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 4);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey(1814400000L);
        java.lang.String str12 = fixedDateTimeZone4.getNameKey((-2L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2000 + "'", int6 == 2000);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) (short) 10, (java.lang.Number) (byte) 1, number3);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.toString();
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10 for Pacific Standard Time must not be smaller than 1" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value 10 for Pacific Standard Time must not be smaller than 1"));
        org.junit.Assert.assertNull(durationFieldType8);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = localDate1.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property6 = localDate1.dayOfMonth();
        java.util.Locale locale7 = null;
        int int8 = property6.getMaximumTextLength(locale7);
        org.joda.time.LocalDate localDate10 = property6.setCopy(24);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) 9);
        org.joda.time.LocalDate localDate13 = localDate10.withFields((org.joda.time.ReadablePartial) localDate12);
        java.lang.String str14 = localDate12.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969-12-31" + "'", str14.equals("1969-12-31"));
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 0, locale3);
//        long long7 = dateTimeZone1.adjustOffset((-189302399948L), false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        int int10 = cachedDateTimeZone8.getOffset((long) 365);
//        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone8.getUncachedZone();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-189302399948L) + "'", long7 == (-189302399948L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
        org.joda.time.DurationField durationField3 = buddhistChronology1.halfdays();
        org.joda.time.Chronology chronology4 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        long long9 = dateTimeZone6.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withPivotYear((-292268510));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.weekyear();
//        org.joda.time.DurationField durationField3 = buddhistChronology1.halfdays();
//        org.joda.time.Chronology chronology4 = buddhistChronology1.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        long long9 = dateTimeZone6.adjustOffset(0L, false);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology12);
//        java.io.Writer writer14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
//        int int17 = localDate16.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime(dateTimeZone18);
//        org.joda.time.YearMonthDay yearMonthDay20 = dateTime19.toYearMonthDay();
//        org.joda.time.DateTime.Property property21 = dateTime19.millisOfSecond();
//        org.joda.time.DateTime dateTime23 = dateTime19.minusSeconds(100);
//        org.joda.time.DateTime dateTime24 = dateTime19.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime26 = dateTime19.withMonthOfYear((int) (byte) 10);
//        long long27 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTime dateTime29 = dateTime26.minusYears(31606);
//        try {
//            dateTimeFormatter0.printTo(writer14, (org.joda.time.ReadableInstant) dateTime29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(yearMonthDay20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1571154555171L + "'", long27 == 1571154555171L);
//        org.junit.Assert.assertNotNull(dateTime29);
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        java.lang.String str7 = property6.toString();
//        org.joda.time.DateTime dateTime8 = property6.getDateTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        int int11 = localDate10.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = localDate10.toDateTimeAtCurrentTime(dateTimeZone12);
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime13.withCenturyOfEra((int) (byte) 100);
//        int int19 = property6.getDifference((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
//        int int22 = localDate21.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = localDate21.toDateTimeAtCurrentTime(dateTimeZone23);
//        org.joda.time.YearMonthDay yearMonthDay25 = dateTime24.toYearMonthDay();
//        org.joda.time.DateTime.Property property26 = dateTime24.millisOfSecond();
//        org.joda.time.DateTime dateTime28 = dateTime24.minusSeconds(100);
//        org.joda.time.DateTime dateTime29 = dateTime24.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime31 = dateTime24.withMonthOfYear((int) (byte) 10);
//        int int32 = property6.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        java.util.Locale locale33 = null;
//        int int34 = property6.getMaximumTextLength(locale33);
//        org.joda.time.DateTime dateTime35 = property6.roundHalfEvenCopy();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendTwoDigitWeekyear(9, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendHourOfHalfday(2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder39.appendMonthOfYearShortText();
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(dateTimeZone43);
//        int int45 = localDate44.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.DateTime dateTime47 = localDate44.toDateTimeAtCurrentTime(dateTimeZone46);
//        int int48 = dateTime47.getYearOfCentury();
//        org.joda.time.DateTime dateTime50 = dateTime47.minusYears(24);
//        org.joda.time.ReadableDuration readableDuration51 = null;
//        org.joda.time.DateTime dateTime53 = dateTime50.withDurationAdded(readableDuration51, (int) (byte) -1);
//        org.joda.time.DateTime dateTime55 = dateTime53.withWeekyear(0);
//        org.joda.time.DateTime dateTime57 = dateTime53.minusWeeks(19);
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate(dateTimeZone58);
//        int int60 = localDate59.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.DateTime dateTime62 = localDate59.toDateTimeAtCurrentTime(dateTimeZone61);
//        org.joda.time.YearMonthDay yearMonthDay63 = dateTime62.toYearMonthDay();
//        org.joda.time.DateTime.Property property64 = dateTime62.millisOfSecond();
//        org.joda.time.DateTime dateTime66 = dateTime62.minusSeconds(100);
//        org.joda.time.DateTime dateTime67 = dateTime62.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime69 = dateTime62.withMonthOfYear((int) (byte) 10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology70 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField71 = buddhistChronology70.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField71);
//        org.joda.time.DurationField durationField73 = delegatedDateTimeField72.getDurationField();
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = delegatedDateTimeField72.getAsShortText((long) (short) 100, locale75);
//        int int77 = delegatedDateTimeField72.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType78 = delegatedDateTimeField72.getType();
//        org.joda.time.DateTime.Property property79 = dateTime62.property(dateTimeFieldType78);
//        int int80 = dateTime57.get(dateTimeFieldType78);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder39.appendText(dateTimeFieldType78);
//        int int82 = dateTime35.get(dateTimeFieldType78);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[millisOfSecond]" + "'", str7.equals("Property[millisOfSecond]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-2) + "'", int19 == (-2));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19 + "'", int22 == 19);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(yearMonthDay25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-3) + "'", int32 == (-3));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 19 + "'", int45 == 19);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 19 + "'", int48 == 19);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 19 + "'", int60 == 19);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(yearMonthDay63);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(buddhistChronology70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertNotNull(durationField73);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "2513" + "'", str76.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-292268511) + "'", int77 == (-292268511));
//        org.junit.Assert.assertNotNull(dateTimeFieldType78);
//        org.junit.Assert.assertNotNull(property79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1995 + "'", int80 == 1995);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 2019 + "'", int82 == 2019);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate12 = localDate10.plus(readablePeriod11);
        org.joda.time.LocalTime localTime13 = null;
        org.joda.time.DateTime dateTime14 = localDate10.toDateTime(localTime13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) localTime13);
        org.joda.time.DateTime dateTime17 = dateTime15.plusDays(2019);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate21 = localDate19.plus(readablePeriod20);
        org.joda.time.LocalTime localTime22 = null;
        org.joda.time.DateTime dateTime23 = localDate19.toDateTime(localTime22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone24);
        int int26 = localDate25.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = localDate25.toDateTimeAtCurrentTime(dateTimeZone27);
        org.joda.time.YearMonthDay yearMonthDay29 = dateTime28.toYearMonthDay();
        org.joda.time.DateTime.Property property30 = dateTime28.millisOfSecond();
        org.joda.time.DateTime dateTime32 = dateTime28.minusSeconds(100);
        org.joda.time.DateTime dateTime33 = dateTime28.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime35 = dateTime28.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
        org.joda.time.DurationField durationField39 = delegatedDateTimeField38.getDurationField();
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField38.getAsShortText((long) (short) 100, locale41);
        int int43 = delegatedDateTimeField38.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = delegatedDateTimeField38.getType();
        org.joda.time.DateTime.Property property45 = dateTime28.property(dateTimeFieldType44);
        int int46 = localDate19.get(dateTimeFieldType44);
        boolean boolean47 = dateTime17.isSupported(dateTimeFieldType44);
        org.joda.time.DateTime.Property property48 = dateTime7.property(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(yearMonthDay29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2513" + "'", str42.equals("2513"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-292268511) + "'", int43 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(property48);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        int int23 = unsupportedDateTimeField20.getDifference((long) (byte) 0, 0L);
        long long26 = unsupportedDateTimeField20.add((long) 232, 31619);
        org.joda.time.DurationField durationField27 = unsupportedDateTimeField20.getDurationField();
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField20.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate(dateTimeZone29);
        int int31 = localDate30.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = localDate30.toDateTimeAtCurrentTime(dateTimeZone32);
        org.joda.time.LocalDate localDate35 = localDate30.withCenturyOfEra((int) (short) 1);
        org.joda.time.LocalDate.Property property36 = localDate30.weekyear();
        org.joda.time.LocalDate localDate37 = property36.roundHalfCeilingCopy();
        org.joda.time.LocalDate.Property property38 = localDate37.dayOfYear();
        int[] intArray43 = new int[] { (byte) 1, (-13), (-8), 948 };
        try {
            int int44 = unsupportedDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDate37, intArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 997799644800232L + "'", long26 == 997799644800232L);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 19 + "'", int31 == 19);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(intArray43);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
        long long24 = unsupportedDateTimeField20.add((-292268536L), (int) (byte) 10);
        try {
            long long26 = unsupportedDateTimeField20.remainder((long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 315413331464L + "'", long24 == 315413331464L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
        int int8 = dateTime4.getYear();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.minus(readableDuration9);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfSecond(292279536);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279536 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsText(0L);
        int int39 = dividedDateTimeField35.getMinimumValue((long) 31702879);
        long long42 = dividedDateTimeField35.addWrapField(0L, 4);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(dateTimeZone43);
        org.joda.time.LocalDate localDate46 = localDate44.plusDays((int) (short) 1);
        java.util.Locale locale48 = null;
        java.lang.String str49 = dividedDateTimeField35.getAsShortText((org.joda.time.ReadablePartial) localDate46, 31619, locale48);
        org.joda.time.DurationField durationField50 = dividedDateTimeField35.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-146504) + "'", int39 == (-146504));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 251824464000000L + "'", long42 == 251824464000000L);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "31619" + "'", str49.equals("31619"));
        org.junit.Assert.assertNotNull(durationField50);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate1.withCenturyOfEra((int) (short) 1);
        org.joda.time.LocalDate.Property property7 = localDate1.weekyear();
        org.joda.time.LocalDate localDate8 = property7.roundHalfCeilingCopy();
        org.joda.time.Interval interval9 = property7.toInterval();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        org.joda.time.DurationField durationField36 = dividedDateTimeField35.getDurationField();
        org.joda.time.DurationField durationField37 = dividedDateTimeField35.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(durationField37);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        java.lang.String str7 = property6.toString();
//        org.joda.time.DateTime dateTime8 = property6.getDateTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        int int11 = localDate10.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = localDate10.toDateTimeAtCurrentTime(dateTimeZone12);
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime13.withCenturyOfEra((int) (byte) 100);
//        int int19 = property6.getDifference((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.MutableDateTime mutableDateTime20 = dateTime13.toMutableDateTime();
//        org.joda.time.DateTime dateTime22 = dateTime13.withWeekyear(100);
//        int int23 = dateTime22.getYearOfEra();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[millisOfSecond]" + "'", str7.equals("Property[millisOfSecond]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-30) + "'", int19 == (-30));
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, ' ', 9, 0, (int) (byte) -1, true, 7);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("UTC", 69);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = localDate1.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property6 = localDate1.dayOfMonth();
        java.util.Locale locale7 = null;
        int int8 = property6.getMaximumTextLength(locale7);
        org.joda.time.LocalDate localDate10 = property6.setCopy(24);
        int int11 = localDate10.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.plusDays((int) (short) 1);
//        org.joda.time.LocalDate localDate5 = localDate3.withYear((int) (byte) 10);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.LocalDate localDate7 = localDate3.minus(readablePeriod6);
//        org.joda.time.Interval interval8 = localDate3.toInterval();
//        int int9 = localDate3.getWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
//        int int12 = localDate11.getYearOfCentury();
//        int int13 = localDate11.getDayOfWeek();
//        boolean boolean14 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate11);
//        org.joda.time.LocalDate localDate16 = localDate3.minusYears((int) ' ');
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(interval8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(localDate16);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.plusDays((int) (short) 1);
        org.joda.time.LocalDate localDate5 = localDate3.withYear((int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate3.minus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate9 = localDate7.plus(readablePeriod8);
        org.joda.time.LocalDate localDate11 = localDate7.withCenturyOfEra((int) 'a');
        org.joda.time.LocalDate.Property property12 = localDate11.dayOfWeek();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsShortText((long) (-25200000));
        int int40 = dividedDateTimeField35.getDifference((long) (byte) 100, 1L);
        long long42 = dividedDateTimeField35.remainder(0L);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int int44 = dividedDateTimeField35.getMinimumValue(readablePartial43);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-146504) + "'", int44 == (-146504));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(31619, 292279536);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 292311155 + "'", int2 == 292311155);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsShortText((long) (-25200000));
        int int40 = dividedDateTimeField35.getDifference((long) (byte) 100, 1L);
        long long42 = dividedDateTimeField35.remainder(0L);
        int int44 = dividedDateTimeField35.get((-35999999L));
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) dividedDateTimeField35, 11172, 1970, 56791);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
        org.joda.time.DateTime.Property property8 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime.Property property9 = dateTime4.era();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
//        int int8 = dateTime4.getDayOfYear();
//        org.joda.time.DateTime dateTime10 = dateTime4.withHourOfDay(1);
//        org.joda.time.DateTime.Property property11 = dateTime4.millisOfDay();
//        java.util.Locale locale12 = null;
//        int int13 = property11.getMaximumShortTextLength(locale12);
//        int int14 = property11.getMaximumValue();
//        org.joda.time.DateTime dateTime15 = property11.roundHalfFloorCopy();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 166 + "'", int8 == 166);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86399999 + "'", int14 == 86399999);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate4 = localDate2.plusDays((int) (short) 1);
//        org.joda.time.LocalDate localDate6 = localDate4.withYear((int) (byte) 10);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.LocalDate localDate8 = localDate4.minus(readablePeriod7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.LocalDate localDate10 = localDate8.plus(readablePeriod9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate12, (java.lang.Object) (-1.0d));
//        int int15 = localDate12.getWeekOfWeekyear();
//        int int16 = localDate12.getDayOfWeek();
//        int int17 = localDate12.getYearOfCentury();
//        int int18 = localDate8.compareTo((org.joda.time.ReadablePartial) localDate12);
//        java.lang.String str19 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019W247" + "'", str19.equals("2019W247"));
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap1);
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfDay(0, 1995);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        long long7 = property6.remainder();
        boolean boolean9 = property6.equals((java.lang.Object) 19);
        int int10 = property6.getMinimumValueOverall();
        org.joda.time.DateTime dateTime12 = property6.setCopy((int) (short) 10);
        org.joda.time.DateTime dateTime13 = property6.withMaximumValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendSecondOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField8 = iSOChronology7.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField11.getDurationField();
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField11.getAsShortText((long) (short) 100, locale14);
        int int16 = delegatedDateTimeField11.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField11.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, durationField8, dateTimeFieldType17);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter19.withChronology((org.joda.time.Chronology) buddhistChronology20);
        org.joda.time.DurationField durationField22 = buddhistChronology20.minutes();
        org.joda.time.DurationField durationField23 = buddhistChronology20.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, durationField23);
        int int25 = localDate3.get(dateTimeFieldType17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder1.appendShortText(dateTimeFieldType17);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendWeekOfWeekyear((-8));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2513" + "'", str15.equals("2513"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-292268511) + "'", int16 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
//        int int8 = dateTime4.getDayOfYear();
//        org.joda.time.DateTime dateTime10 = dateTime4.withHourOfDay(1);
//        org.joda.time.DateTime.Property property11 = dateTime4.millisOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime4.era();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 166 + "'", int8 == 166);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate1, (java.lang.Object) (-1.0d));
//        int int4 = localDate1.getWeekOfWeekyear();
//        int int5 = localDate1.getDayOfWeek();
//        int int6 = localDate1.getYearOfCentury();
//        int int7 = localDate1.getWeekyear();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsText(0L);
        int int39 = dividedDateTimeField35.getMinimumValue((long) 31702879);
        long long42 = dividedDateTimeField35.addWrapField(0L, 4);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(dateTimeZone43);
        org.joda.time.DateMidnight dateMidnight45 = localDate44.toDateMidnight();
        int int46 = localDate44.getMonthOfYear();
        org.joda.time.LocalDate localDate48 = localDate44.withYearOfEra(10019);
        org.joda.time.LocalDate localDate50 = localDate48.minusYears((int) (byte) -1);
        int int51 = dividedDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) localDate50);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-146504) + "'", int39 == (-146504));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 251824464000000L + "'", long42 == 251824464000000L);
        org.junit.Assert.assertNotNull(dateMidnight45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 146505 + "'", int51 == 146505);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 0, locale3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone1.getShortName((long) 6, locale6);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) (short) 100, locale5);
        int int7 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField2.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField2.getType();
        java.lang.Number number10 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, number10, "CopticChronology[America/Los_Angeles]");
        java.lang.String str13 = illegalFieldValueException12.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "null" + "'", str13.equals("null"));
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField4 = iSOChronology3.months();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
//        int int12 = delegatedDateTimeField7.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
//        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
//        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
//        int int23 = unsupportedDateTimeField20.getDifference((long) (byte) 0, 0L);
//        long long26 = unsupportedDateTimeField20.add((long) 232, 31619);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.plusDays((int) (short) 1);
//        org.joda.time.LocalDate localDate32 = localDate30.withYear((int) (byte) 10);
//        org.joda.time.ReadablePeriod readablePeriod33 = null;
//        org.joda.time.LocalDate localDate34 = localDate30.minus(readablePeriod33);
//        org.joda.time.Interval interval35 = localDate30.toInterval();
//        int int36 = localDate30.getWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate(dateTimeZone37);
//        int int39 = localDate38.getYearOfCentury();
//        int int40 = localDate38.getDayOfWeek();
//        boolean boolean41 = localDate30.isAfter((org.joda.time.ReadablePartial) localDate38);
//        java.util.Locale locale42 = null;
//        try {
//            java.lang.String str43 = unsupportedDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate38, locale42);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 997799644800232L + "'", long26 == 997799644800232L);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(interval35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 19 + "'", int39 == 19);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) 947);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.clockhourOfDay();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) iSOChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField4.getAsShortText((long) (short) 100, locale7);
        int int9 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField4.getType();
        org.joda.time.DurationField durationField11 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) -1);
        long long16 = skipUndoDateTimeField13.set((-4196707346504L), 100);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2513" + "'", str8.equals("2513"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292268511) + "'", int9 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-76147344146504L) + "'", long16 == (-76147344146504L));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTwoDigitYear(208, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        boolean boolean10 = dateTimeFormatter9.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsText(0L);
        int int39 = dividedDateTimeField35.get((long) 960);
        java.util.Locale locale41 = null;
        java.lang.String str42 = dividedDateTimeField35.getAsShortText((long) (-8), locale41);
        try {
            long long45 = dividedDateTimeField35.set(0L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder1 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = dateTimeZoneBuilder1.addCutover(0, ' ', 9, 0, (int) (byte) -1, true, 7);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("2019", false);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 1995, dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) (short) 10, (java.lang.Number) (byte) 1, number3);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException4.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
        org.junit.Assert.assertNull(durationFieldType8);
        org.junit.Assert.assertNull(dateTimeFieldType9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear((int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendHourOfHalfday((-292268512));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("2019-06-15T15:47:57.033-07:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-15T15:47:57.033-07:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone8);
        int int10 = localDate9.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = localDate9.toDateTimeAtCurrentTime(dateTimeZone11);
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime12.toYearMonthDay();
        org.joda.time.DateTime.Property property14 = dateTime12.millisOfSecond();
        org.joda.time.DateTime dateTime16 = dateTime12.withYearOfEra((int) 'a');
        int int17 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime12);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(0, 0, 947, 0, 6, (-1), dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-25200000) + "'", int17 == (-25200000));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMinuteOfHour(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfSecond(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
//        int int8 = dateTime4.getDayOfYear();
//        org.joda.time.DateTime dateTime10 = dateTime4.withHourOfDay(1);
//        org.joda.time.DateTime.Property property11 = dateTime4.millisOfDay();
//        java.util.Locale locale12 = null;
//        int int13 = property11.getMaximumShortTextLength(locale12);
//        int int14 = property11.getMaximumValue();
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = property11.getAsShortText(locale15);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 166 + "'", int8 == 166);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86399999 + "'", int14 == 86399999);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31760450" + "'", str16.equals("31760450"));
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = dateTime4.withCenturyOfEra((int) (byte) 100);
//        int int10 = dateTime4.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = dateTime4.withWeekyear(1969);
//        int int13 = dateTime12.getYear();
//        org.joda.time.DateTime.Property property14 = dateTime12.secondOfMinute();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
//        org.junit.Assert.assertNotNull(property14);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test329");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(dateTimeZone3);
//        org.joda.time.LocalDate localDate6 = localDate4.plusDays((int) (short) 1);
//        int int7 = delegatedDateTimeField2.getMinimumValue((org.joda.time.ReadablePartial) localDate6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone8);
//        org.joda.time.LocalDate localDate11 = localDate9.plusDays((int) (short) 1);
//        org.joda.time.LocalDate localDate13 = localDate11.withYear((int) (byte) 10);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.LocalDate localDate15 = localDate11.minus(readablePeriod14);
//        int int16 = localDate6.compareTo((org.joda.time.ReadablePartial) localDate15);
//        org.joda.time.LocalDate.Property property17 = localDate15.dayOfMonth();
//        java.util.Locale locale18 = null;
//        int int19 = property17.getMaximumTextLength(locale18);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = property17.getAsText(locale20);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "16" + "'", str21.equals("16"));
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.Chronology chronology4 = buddhistChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.halfdayOfDay();
        boolean boolean6 = copticChronology0.equals((java.lang.Object) buddhistChronology2);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1, (java.lang.Number) (-1514419168394L), (java.lang.Number) 31607);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test333");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.DurationFieldType durationFieldType2 = null;
//        boolean boolean3 = localDate1.isSupported(durationFieldType2);
//        int int4 = localDate1.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        int int7 = localDate6.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = localDate6.toDateTimeAtCurrentTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = localDate6.toDateTimeAtMidnight();
//        org.joda.time.LocalDate localDate11 = localDate1.withFields((org.joda.time.ReadablePartial) localDate6);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        int int5 = dateTime4.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = dateTime4.withZone(dateTimeZone7);
//        java.lang.String str10 = dateTime4.toString();
//        org.joda.time.DateTime dateTime12 = dateTime4.minusDays(0);
//        org.joda.time.DateTime dateTime14 = dateTime4.withCenturyOfEra((int) '#');
//        org.joda.time.DateTime dateTime16 = dateTime4.withEra(0);
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime4.toMutableDateTimeISO();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(dateTimeZone18);
//        int int20 = localDate19.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = localDate19.toDateTimeAtCurrentTime(dateTimeZone21);
//        org.joda.time.YearMonthDay yearMonthDay23 = dateTime22.toYearMonthDay();
//        org.joda.time.DateTime.Property property24 = dateTime22.millisOfSecond();
//        org.joda.time.DateTime dateTime26 = dateTime22.minusSeconds(100);
//        org.joda.time.DateTime dateTime27 = dateTime22.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime29 = dateTime22.withMonthOfYear((int) (byte) 10);
//        long long30 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTime dateTime32 = dateTime29.minusYears(31606);
//        boolean boolean33 = mutableDateTime17.isBefore((org.joda.time.ReadableInstant) dateTime29);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15T08:49:20.723-07:00" + "'", str10.equals("2019-06-15T08:49:20.723-07:00"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(yearMonthDay23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1571154560725L + "'", long30 == 1571154560725L);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        long long8 = dateTimeZone5.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
        org.joda.time.Chronology chronology11 = zonedChronology9.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property7.addToCopy((long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
        int int12 = localDate11.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = localDate11.toDateTimeAtCurrentTime(dateTimeZone13);
        int int15 = dateTime14.getYearOfCentury();
        org.joda.time.DateTime dateTime17 = dateTime14.minusYears(24);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(readableDuration18, (int) (byte) -1);
        long long21 = property7.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime22 = property7.roundFloorCopy();
        org.joda.time.DateTimeField dateTimeField23 = property7.getField();
        java.util.Locale locale24 = null;
        int int25 = property7.getMaximumTextLength(locale24);
        org.joda.time.DateTime dateTime27 = property7.addToCopy((long) (-13));
        try {
            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) property7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 23L + "'", long21 == 23L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime4.withYearOfEra((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime((org.joda.time.Chronology) gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate1.withCenturyOfEra((int) (short) 1);
        org.joda.time.LocalDate.Property property7 = localDate1.weekyear();
        org.joda.time.LocalDate localDate8 = property7.roundCeilingCopy();
        org.joda.time.LocalDate localDate9 = property7.roundFloorCopy();
        org.joda.time.LocalDate localDate10 = property7.roundCeilingCopy();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(24);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, (int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone13);
        int int15 = localDate14.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = localDate14.toDateTimeAtCurrentTime(dateTimeZone16);
        int int18 = dateTime17.getYearOfCentury();
        org.joda.time.DateTime dateTime20 = dateTime17.minusYears(24);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) (byte) -1);
        org.joda.time.DateTime dateTime25 = dateTime23.withWeekyear(0);
        org.joda.time.DateTime dateTime27 = dateTime23.minusWeeks(19);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField29 = iSOChronology28.halfdays();
        boolean boolean31 = iSOChronology28.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DurationField durationField35 = delegatedDateTimeField34.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology28, (org.joda.time.DateTimeField) delegatedDateTimeField34);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate(dateTimeZone37);
        int int39 = localDate38.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = localDate38.toDateTimeAtCurrentTime(dateTimeZone40);
        org.joda.time.YearMonthDay yearMonthDay42 = dateTime41.toYearMonthDay();
        org.joda.time.DateTime.Property property43 = dateTime41.millisOfSecond();
        org.joda.time.DateTime dateTime45 = dateTime41.minusSeconds(100);
        org.joda.time.DateTime dateTime46 = dateTime41.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime48 = dateTime41.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology49.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField51 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField50);
        org.joda.time.DurationField durationField52 = delegatedDateTimeField51.getDurationField();
        java.util.Locale locale54 = null;
        java.lang.String str55 = delegatedDateTimeField51.getAsShortText((long) (short) 100, locale54);
        int int56 = delegatedDateTimeField51.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = delegatedDateTimeField51.getType();
        org.joda.time.DateTime.Property property58 = dateTime41.property(dateTimeFieldType57);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, dateTimeFieldType57);
        org.joda.time.DateTime dateTime61 = dateTime23.withField(dateTimeFieldType57, (int) (short) 100);
        boolean boolean62 = dateTime12.isSupported(dateTimeFieldType57);
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField64 = gJChronology63.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType57, durationField64);
        java.lang.String str66 = unsupportedDateTimeField65.getName();
        try {
            int int67 = unsupportedDateTimeField65.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 19 + "'", int39 == 19);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(yearMonthDay42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(buddhistChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2513" + "'", str55.equals("2513"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-292268511) + "'", int56 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "weekyear" + "'", str66.equals("weekyear"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        boolean boolean6 = localDate3.equals((java.lang.Object) localDate5);
        org.joda.time.LocalDate localDate8 = localDate3.minusYears(11172);
        org.joda.time.LocalDate localDate10 = localDate3.minusMonths(31740630);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(1995);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra(11172, 948);
        boolean boolean9 = dateTimeFormatterBuilder5.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime4.withCenturyOfEra((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("[]");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        long long8 = dateTimeZone5.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
        try {
            long long18 = zonedChronology9.getDateTimeMillis(24, (-4), (int) (short) 10, 0, (-1), (-6), (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -4 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = localDate1.toDateTimeAtMidnight();
//        org.joda.time.LocalDate.Property property6 = localDate1.dayOfMonth();
//        org.joda.time.LocalDate.Property property7 = localDate1.weekOfWeekyear();
//        org.joda.time.LocalDate localDate8 = property7.roundFloorCopy();
//        org.joda.time.LocalDate localDate9 = property7.roundCeilingCopy();
//        org.joda.time.LocalDate localDate11 = property7.setCopy((int) (short) 1);
//        java.lang.String str12 = property7.getAsString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "24" + "'", str12.equals("24"));
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime.Property property6 = dateTime4.weekyear();
        java.lang.String str7 = property6.getAsShortText();
        java.lang.String str8 = property6.toString();
        org.joda.time.DateTime dateTime10 = property6.setCopy((-30));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[weekyear]" + "'", str8.equals("Property[weekyear]"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(2513, (-4));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 2513");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) (short) 10, (java.lang.Number) (byte) 1, number3);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) (short) 100, locale5);
        int int7 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField2.getType();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.clockhourOfHalfday();
        org.joda.time.Partial partial12 = new org.joda.time.Partial(dateTimeFieldType8, 0, (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.weekyearOfCentury();
        try {
            long long21 = iSOChronology10.getDateTimeMillis(0, 99, (int) '#', 508, 292279536, 38, 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 508 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        long long8 = dateTimeZone5.adjustOffset(0L, false);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.Chronology chronology11 = zonedChronology9.withZone(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology9.weekyear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate1, (java.lang.Object) (-1.0d));
        org.joda.time.LocalDate.Property property4 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate6 = property4.addToCopy((-96));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
        int int9 = localDate8.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = localDate8.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = dateTime11.getYearOfCentury();
        org.joda.time.DateTime dateTime14 = dateTime11.minusYears(24);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(readableDuration15, (int) (byte) -1);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone20);
        int int22 = localDate21.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = localDate21.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = dateTime24.getYearOfCentury();
        org.joda.time.DateTime dateTime27 = dateTime24.minusYears(24);
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded(readableDuration28, (int) (byte) -1);
        org.joda.time.DateTime dateTime32 = dateTime30.withWeekyear(0);
        org.joda.time.DateTime dateTime34 = dateTime30.minusWeeks(19);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField36 = iSOChronology35.halfdays();
        boolean boolean38 = iSOChronology35.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField40 = buddhistChronology39.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField40);
        org.joda.time.DurationField durationField42 = delegatedDateTimeField41.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology35, (org.joda.time.DateTimeField) delegatedDateTimeField41);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate(dateTimeZone44);
        int int46 = localDate45.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = localDate45.toDateTimeAtCurrentTime(dateTimeZone47);
        org.joda.time.YearMonthDay yearMonthDay49 = dateTime48.toYearMonthDay();
        org.joda.time.DateTime.Property property50 = dateTime48.millisOfSecond();
        org.joda.time.DateTime dateTime52 = dateTime48.minusSeconds(100);
        org.joda.time.DateTime dateTime53 = dateTime48.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime55 = dateTime48.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField57 = buddhistChronology56.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField58 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField57);
        org.joda.time.DurationField durationField59 = delegatedDateTimeField58.getDurationField();
        java.util.Locale locale61 = null;
        java.lang.String str62 = delegatedDateTimeField58.getAsShortText((long) (short) 100, locale61);
        int int63 = delegatedDateTimeField58.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = delegatedDateTimeField58.getType();
        org.joda.time.DateTime.Property property65 = dateTime48.property(dateTimeFieldType64);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField66 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField43, dateTimeFieldType64);
        org.joda.time.DateTime dateTime68 = dateTime30.withField(dateTimeFieldType64, (int) (short) 100);
        boolean boolean69 = dateTime19.isSupported(dateTimeFieldType64);
        org.joda.time.chrono.GJChronology gJChronology70 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField71 = gJChronology70.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField72 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType64, durationField71);
        boolean boolean73 = localDate6.isSupported(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19 + "'", int22 == 19);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 19 + "'", int25 == 19);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(buddhistChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 19 + "'", int46 == 19);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(yearMonthDay49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(buddhistChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2513" + "'", str62.equals("2513"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-292268511) + "'", int63 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(gJChronology70);
        org.junit.Assert.assertNotNull(durationField71);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) (short) 10, (java.lang.Number) (byte) 1, number3);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 1 + "'", number7.equals((byte) 1));
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test357");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime.Property property8 = dateTime4.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.LocalDate localDate12 = localDate10.plus(readablePeriod11);
//        org.joda.time.LocalTime localTime13 = null;
//        org.joda.time.DateTime dateTime14 = localDate10.toDateTime(localTime13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) localTime13);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusDays(2019);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(dateTimeZone18);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.LocalDate localDate21 = localDate19.plus(readablePeriod20);
//        org.joda.time.LocalTime localTime22 = null;
//        org.joda.time.DateTime dateTime23 = localDate19.toDateTime(localTime22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone24);
//        int int26 = localDate25.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = localDate25.toDateTimeAtCurrentTime(dateTimeZone27);
//        org.joda.time.YearMonthDay yearMonthDay29 = dateTime28.toYearMonthDay();
//        org.joda.time.DateTime.Property property30 = dateTime28.millisOfSecond();
//        org.joda.time.DateTime dateTime32 = dateTime28.minusSeconds(100);
//        org.joda.time.DateTime dateTime33 = dateTime28.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime35 = dateTime28.withMonthOfYear((int) (byte) 10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
//        org.joda.time.DurationField durationField39 = delegatedDateTimeField38.getDurationField();
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = delegatedDateTimeField38.getAsShortText((long) (short) 100, locale41);
//        int int43 = delegatedDateTimeField38.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = delegatedDateTimeField38.getType();
//        org.joda.time.DateTime.Property property45 = dateTime28.property(dateTimeFieldType44);
//        int int46 = localDate19.get(dateTimeFieldType44);
//        boolean boolean47 = dateTime17.isSupported(dateTimeFieldType44);
//        boolean boolean48 = dateTime4.isSupported(dateTimeFieldType44);
//        int int49 = dateTime4.getSecondOfMinute();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(yearMonthDay29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2513" + "'", str42.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-292268511) + "'", int43 == (-292268511));
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 22 + "'", int49 == 22);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsShortText((long) (-25200000));
        int int40 = dividedDateTimeField35.getDifference((long) (byte) 100, 1L);
        long long42 = dividedDateTimeField35.remainder(0L);
        int int44 = dividedDateTimeField35.get((-35999999L));
        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology45.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        org.joda.time.DurationField durationField48 = delegatedDateTimeField47.getDurationField();
        java.util.Locale locale50 = null;
        java.lang.String str51 = delegatedDateTimeField47.getAsShortText((long) (short) 100, locale50);
        int int52 = delegatedDateTimeField47.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = delegatedDateTimeField47.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = delegatedDateTimeField47.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField55 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField35, dateTimeFieldType54);
        long long57 = remainderDateTimeField55.roundHalfFloor((-292268536L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2513" + "'", str51.equals("2513"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-292268511) + "'", int52 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 28800000L + "'", long57 == 28800000L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) '#', (-13));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.LocalDate localDate3 = localDate1.plus(readablePeriod2);
        int int4 = localDate3.size();
        org.joda.time.LocalDate localDate6 = localDate3.withWeekyear(843);
        int int7 = localDate6.getCenturyOfEra();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
//        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        int int9 = localDate8.getYearOfCentury();
//        org.joda.time.DurationFieldType durationFieldType10 = null;
//        boolean boolean11 = localDate8.isSupported(durationFieldType10);
//        int int12 = localDate8.getWeekyear();
//        org.joda.time.DateTime dateTime13 = localDate8.toDateTimeAtCurrentTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.withDayOfMonth(1);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone17);
//        int int19 = localDate18.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = localDate18.toDateTimeAtCurrentTime(dateTimeZone20);
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        org.joda.time.DateTime.Property property23 = dateTime21.millisOfSecond();
//        org.joda.time.DateTime dateTime25 = dateTime21.minusSeconds(100);
//        org.joda.time.DateTime dateTime26 = dateTime21.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime28 = dateTime21.withMonthOfYear((int) (byte) 10);
//        long long29 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.ReadableDateTime) dateTime16, (org.joda.time.ReadableDateTime) dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1571154563510L + "'", long29 == 1571154563510L);
//        org.junit.Assert.assertNotNull(limitChronology30);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.field.FieldUtils.verifyValueBounds("16", (-5), (-28800000), 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime.Property property6 = dateTime4.weekyear();
        java.lang.String str7 = property6.getAsShortText();
        org.joda.time.DurationField durationField8 = property6.getLeapDurationField();
        org.joda.time.DurationField durationField9 = property6.getDurationField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsShortText((long) (-25200000));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField35);
        org.joda.time.DurationField durationField39 = remainderDateTimeField38.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertNotNull(durationField39);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test366");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = dateTime4.withCenturyOfEra((int) (byte) 100);
//        int int10 = dateTime4.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = dateTime4.minusDays((int) (short) 100);
//        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        java.lang.String str6 = delegatedDateTimeField2.getAsShortText((long) (short) 100, locale5);
        int int7 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField2.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField2.getType();
        java.lang.Number number10 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, number10, "CopticChronology[America/Los_Angeles]");
        java.lang.String str13 = illegalFieldValueException12.toString();
        java.lang.String str14 = illegalFieldValueException12.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2513" + "'", str6.equals("2513"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292268511) + "'", int7 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.joda.time.IllegalFieldValueException: Value null for weekyear is not supported: CopticChronology[America/Los_Angeles]" + "'", str13.equals("org.joda.time.IllegalFieldValueException: Value null for weekyear is not supported: CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "null" + "'", str14.equals("null"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime4.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(10019);
        org.joda.time.DateTimeZone dateTimeZone13 = dateTime12.getZone();
        org.joda.time.LocalDateTime localDateTime14 = null;
        try {
            boolean boolean15 = dateTimeZone13.isLocalDateTimeGap(localDateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10019, (-1), (-8), 0, 24, 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test371");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        int int5 = dateTime4.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = dateTime4.withZone(dateTimeZone7);
//        java.lang.String str10 = dateTime4.toString();
//        org.joda.time.DateTime dateTime13 = dateTime4.withDurationAdded((long) (short) 10, (-7));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15T08:49:24.472-07:00" + "'", str10.equals("2019-06-15T08:49:24.472-07:00"));
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        boolean boolean4 = localDate1.isSupported(durationFieldType3);
        int int5 = localDate1.getWeekyear();
        org.joda.time.DateTime dateTime6 = localDate1.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfDay(0);
        int int9 = dateTime8.getCenturyOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfEra();
        org.joda.time.DateTime dateTime11 = dateTime8.withLaterOffsetAtOverlap();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getRangeDurationField();
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField20.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNull(durationField22);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test374");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getDurationField();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField4.getAsShortText((long) (short) 100, locale7);
//        int int9 = delegatedDateTimeField4.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField4.getType();
//        org.joda.time.DurationField durationField11 = delegatedDateTimeField4.getRangeDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) -1);
//        boolean boolean14 = delegatedDateTimeField4.isLenient();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.LocalDate localDate18 = localDate16.plus(readablePeriod17);
//        org.joda.time.LocalTime localTime19 = null;
//        org.joda.time.DateTime dateTime20 = localDate16.toDateTime(localTime19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
//        int int23 = localDate22.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = localDate22.toDateTimeAtCurrentTime(dateTimeZone24);
//        org.joda.time.YearMonthDay yearMonthDay26 = dateTime25.toYearMonthDay();
//        org.joda.time.DateTime.Property property27 = dateTime25.millisOfSecond();
//        org.joda.time.DateTime dateTime29 = dateTime25.minusSeconds(100);
//        org.joda.time.DateTime dateTime30 = dateTime25.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime32 = dateTime25.withMonthOfYear((int) (byte) 10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology33.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
//        org.joda.time.DurationField durationField36 = delegatedDateTimeField35.getDurationField();
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = delegatedDateTimeField35.getAsShortText((long) (short) 100, locale38);
//        int int40 = delegatedDateTimeField35.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField35.getType();
//        org.joda.time.DateTime.Property property42 = dateTime25.property(dateTimeFieldType41);
//        int int43 = localDate16.get(dateTimeFieldType41);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology45.weekyear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
//        org.joda.time.DurationField durationField48 = delegatedDateTimeField47.getDurationField();
//        boolean boolean49 = delegatedDateTimeField47.isLenient();
//        java.lang.String str51 = delegatedDateTimeField47.getAsShortText((long) 10019);
//        boolean boolean52 = delegatedDateTimeField47.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate(dateTimeZone53);
//        boolean boolean56 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate54, (java.lang.Object) (-1.0d));
//        int int57 = localDate54.getWeekOfWeekyear();
//        int int58 = localDate54.getDayOfWeek();
//        int[] intArray64 = new int[] { 365, (-2), (byte) 1, 10, (byte) 1 };
//        int int65 = delegatedDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) localDate54, intArray64);
//        org.joda.time.DateTimeZone dateTimeZone66 = null;
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate(dateTimeZone66);
//        int int68 = localDate67.getYearOfCentury();
//        org.joda.time.DurationFieldType durationFieldType69 = null;
//        boolean boolean70 = localDate67.isSupported(durationFieldType69);
//        int int71 = localDate67.getWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone73 = null;
//        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate(dateTimeZone73);
//        int int75 = localDate74.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone76 = null;
//        org.joda.time.DateTime dateTime77 = localDate74.toDateTimeAtCurrentTime(dateTimeZone76);
//        org.joda.time.YearMonthDay yearMonthDay78 = dateTime77.toYearMonthDay();
//        boolean boolean79 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay78);
//        int[] intArray80 = yearMonthDay78.getValues();
//        int[] intArray82 = delegatedDateTimeField47.add((org.joda.time.ReadablePartial) localDate67, 56791, intArray80, 0);
//        try {
//            int[] intArray84 = delegatedDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) localDate16, (int) '#', intArray82, (-13));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2513" + "'", str8.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292268511) + "'", int9 == (-292268511));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNull(durationField11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(yearMonthDay26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2513" + "'", str39.equals("2513"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-292268511) + "'", int40 == (-292268511));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertNotNull(buddhistChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2513" + "'", str51.equals("2513"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 24 + "'", int57 == 24);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-292268511) + "'", int65 == (-292268511));
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 19 + "'", int68 == 19);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2019 + "'", int71 == 2019);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 19 + "'", int75 == 19);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(yearMonthDay78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//        org.junit.Assert.assertNotNull(intArray80);
//        org.junit.Assert.assertNotNull(intArray82);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsText(0L);
        org.joda.time.DurationField durationField38 = dividedDateTimeField35.getLeapDurationField();
        int int39 = dividedDateTimeField35.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertNull(durationField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 146505 + "'", int39 == 146505);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.halfdays();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField12.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology6, (org.joda.time.DateTimeField) delegatedDateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
        int int17 = localDate16.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime(dateTimeZone18);
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime19.toYearMonthDay();
        org.joda.time.DateTime.Property property21 = dateTime19.millisOfSecond();
        org.joda.time.DateTime dateTime23 = dateTime19.minusSeconds(100);
        org.joda.time.DateTime dateTime24 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime26 = dateTime19.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        org.joda.time.DurationField durationField30 = delegatedDateTimeField29.getDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField29.getAsShortText((long) (short) 100, locale32);
        int int34 = delegatedDateTimeField29.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = delegatedDateTimeField29.getType();
        org.joda.time.DateTime.Property property36 = dateTime19.property(dateTimeFieldType35);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType35, 99);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder3.appendMillisOfDay(1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder42.appendFractionOfMinute(69, 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(yearMonthDay20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2513" + "'", str33.equals("2513"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-292268511) + "'", int34 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("0010-06-16", (int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("America/Los_Angeles", (-13));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(9, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2000);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.halfdays();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 947);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField12.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology6, (org.joda.time.DateTimeField) delegatedDateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
        int int17 = localDate16.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = localDate16.toDateTimeAtCurrentTime(dateTimeZone18);
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime19.toYearMonthDay();
        org.joda.time.DateTime.Property property21 = dateTime19.millisOfSecond();
        org.joda.time.DateTime dateTime23 = dateTime19.minusSeconds(100);
        org.joda.time.DateTime dateTime24 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime26 = dateTime19.withMonthOfYear((int) (byte) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        org.joda.time.DurationField durationField30 = delegatedDateTimeField29.getDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField29.getAsShortText((long) (short) 100, locale32);
        int int34 = delegatedDateTimeField29.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = delegatedDateTimeField29.getType();
        org.joda.time.DateTime.Property property36 = dateTime19.property(dateTimeFieldType35);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType35, 99);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder3.appendMillisOfDay(1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatterBuilder42.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(yearMonthDay20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2513" + "'", str33.equals("2513"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-292268511) + "'", int34 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test379");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = dateTime4.withCenturyOfEra((int) (byte) 100);
//        int int10 = dateTime4.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = dateTime4.minusDays((int) (short) 100);
//        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
//        org.joda.time.Chronology chronology14 = dateTime12.getChronology();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertNotNull(chronology14);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate5.plus(readablePeriod6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate5.toDateTime(localTime8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) localTime8);
        int int11 = dateTime10.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField16 = iSOChronology15.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText((long) (short) 100, locale22);
        int int24 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField19.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, durationField16, dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) buddhistChronology28);
        org.joda.time.DurationField durationField30 = buddhistChronology28.minutes();
        org.joda.time.DurationField durationField31 = buddhistChronology28.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField31);
        boolean boolean33 = dateTime10.isSupported(dateTimeFieldType25);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType25, 1995);
        java.lang.String str37 = dividedDateTimeField35.getAsShortText((long) (-25200000));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField35);
        org.joda.time.DurationField durationField39 = remainderDateTimeField38.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2513" + "'", str23.equals("2513"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-292268511) + "'", int24 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertNotNull(durationField39);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        int int23 = unsupportedDateTimeField20.getDifference((long) (byte) 0, 0L);
        try {
            java.lang.String str25 = unsupportedDateTimeField20.getAsShortText((-2L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        int int2 = localDate1.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime13 = dateTime4.withTime(843, 1945, 948, (-3));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 843 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DurationField durationField10 = buddhistChronology8.minutes();
        org.joda.time.DurationField durationField11 = buddhistChronology8.weekyears();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology8);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0, 999, 11172, 31702879, (-8), 232, 35, (org.joda.time.Chronology) buddhistChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test385");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        boolean boolean1 = instant0.isAfterNow();
//        org.joda.time.Chronology chronology2 = instant0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime3 = instant0.toMutableDateTime();
//        int int4 = mutableDateTime3.getWeekOfWeekyear();
//        boolean boolean6 = mutableDateTime3.isEqual((long) 292279636);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test386");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.append(dateTimePrinter7);
//        org.joda.time.format.DateTimePrinter dateTimePrinter10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
//        int int13 = localDate12.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = localDate12.toDateTimeAtCurrentTime(dateTimeZone14);
//        org.joda.time.YearMonthDay yearMonthDay16 = dateTime15.toYearMonthDay();
//        org.joda.time.DateTime dateTime18 = dateTime15.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = dateTime15.toDateTime(dateTimeZone19);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
//        java.lang.String str23 = dateTime21.toString(dateTimeFormatter22);
//        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatter22.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter10, dateTimeParser24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter7, dateTimeParser24);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone27);
//        org.joda.time.LocalDate localDate30 = localDate28.plusDays((int) (short) 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.weekyear();
//        org.joda.time.DurationField durationField33 = buddhistChronology31.halfdays();
//        org.joda.time.Chronology chronology34 = buddhistChronology31.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
//        long long39 = dateTimeZone36.adjustOffset(0L, false);
//        org.joda.time.chrono.ZonedChronology zonedChronology40 = org.joda.time.chrono.ZonedChronology.getInstance(chronology34, dateTimeZone36);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
//        org.joda.time.DateTime dateTime42 = localDate28.toDateTimeAtCurrentTime(dateTimeZone41);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter26.withZone(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimePrinter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(yearMonthDay16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019W246" + "'", str23.equals("2019W246"));
//        org.junit.Assert.assertNotNull(dateTimeParser24);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(zonedChronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test387");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(dateTimeZone1);
//        int int3 = localDate2.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTimeAtCurrentTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight();
//        org.joda.time.LocalDate.Property property7 = localDate2.dayOfMonth();
//        org.joda.time.LocalDate.Property property8 = localDate2.dayOfMonth();
//        long long10 = copticChronology0.set((org.joda.time.ReadablePartial) localDate2, (long) (-146504));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10513238253496L + "'", long10 == 10513238253496L);
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test388");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        int int2 = localDate1.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        java.lang.String str7 = property6.toString();
//        org.joda.time.DateTime dateTime8 = property6.getDateTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        int int11 = localDate10.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = localDate10.toDateTimeAtCurrentTime(dateTimeZone12);
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.withDayOfMonth((int) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime13.withCenturyOfEra((int) (byte) 100);
//        int int19 = property6.getDifference((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.MutableDateTime mutableDateTime20 = dateTime13.toMutableDateTime();
//        org.joda.time.DateTime dateTime22 = dateTime13.withWeekyear(100);
//        java.util.Locale locale23 = null;
//        java.util.Calendar calendar24 = dateTime22.toCalendar(locale23);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[millisOfSecond]" + "'", str7.equals("Property[millisOfSecond]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-33) + "'", int19 == (-33));
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(calendar24);
//    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test389");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.LocalDate localDate3 = localDate1.plus(readablePeriod2);
//        int int4 = localDate3.size();
//        org.joda.time.LocalDate localDate6 = localDate3.withWeekyear(843);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        int int9 = localDate8.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = localDate8.toDateTimeAtCurrentTime(dateTimeZone10);
//        int int12 = dateTime11.getYearOfCentury();
//        org.joda.time.DateTime dateTime14 = dateTime11.minusYears(24);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(readableDuration15, (int) (byte) -1);
//        int int18 = dateTime17.getMinuteOfDay();
//        org.joda.time.LocalDate localDate19 = dateTime17.toLocalDate();
//        boolean boolean20 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate19);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 529 + "'", int18 == 529);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.weekyear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsShortText((long) (short) 100, locale10);
        int int12 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField7.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, durationField4, dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DurationField durationField18 = buddhistChronology16.minutes();
        org.joda.time.DurationField durationField19 = buddhistChronology16.weekyears();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField19);
        long long23 = unsupportedDateTimeField20.add(0L, (long) 'a');
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone24);
        int int26 = localDate25.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = localDate25.toDateTimeAtCurrentTime(dateTimeZone27);
        org.joda.time.LocalDate localDate30 = localDate25.withCenturyOfEra((int) (short) 1);
        org.joda.time.LocalDate.Property property31 = localDate25.weekyear();
        org.joda.time.LocalDate localDate33 = localDate25.withYearOfCentury((int) '#');
        java.util.Locale locale35 = null;
        try {
            java.lang.String str36 = unsupportedDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate25, 2, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2513" + "'", str11.equals("2513"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268511) + "'", int12 == (-292268511));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3061497600000L + "'", long23 == 3061497600000L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate33);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str2 = julianChronology1.toString();
        int int3 = julianChronology1.getMinimumDaysInFirstWeek();
        long long7 = julianChronology1.add((long) 56789, (long) (-1), 0);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) 31607, (org.joda.time.Chronology) julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 56789L + "'", long7 == 56789L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.dayOfWeek();
        org.junit.Assert.assertNotNull(property1);
    }
}

