import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        java.lang.String str6 = offsetDateTimeField3.getAsShortText((long) (short) 10);
        java.lang.String str7 = offsetDateTimeField3.getName();
        int int8 = offsetDateTimeField3.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "weekyear" + "'", str7.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        long long5 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType8 = periodType7.withWeeksRemoved();
        org.joda.time.PeriodType periodType9 = periodType8.withDaysRemoved();
        org.joda.time.PeriodType periodType10 = periodType9.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = periodType10.indexOf(durationFieldType11);
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration4, readableInstant6, periodType10);
        org.joda.time.Period period15 = period13.withMinutes((int) '#');
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.Period period17 = period15.withPeriodType(periodType16);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.Period period4 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = gregorianChronology5.hours();
        int int7 = gregorianChronology5.getMinimumDaysInFirstWeek();
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) ' ', (java.lang.Object) gregorianChronology5);
        try {
            long long16 = gregorianChronology5.getDateTimeMillis((int) (short) 100, (int) (byte) 10, (int) '#', 35, 6528, 0, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        long long10 = unsupportedDateTimeField7.add(1560627933476L, 100);
        org.joda.time.DurationField durationField11 = unsupportedDateTimeField7.getLeapDurationField();
        org.joda.time.DurationField durationField12 = unsupportedDateTimeField7.getLeapDurationField();
        org.joda.time.DurationField durationField13 = unsupportedDateTimeField7.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560628033476L + "'", long10 == 1560628033476L);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = zonedChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = zonedChronology4.millisOfDay();
        org.joda.time.DurationField durationField7 = zonedChronology4.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.Period period4 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.Period period6 = period4.minusMillis(0);
        org.joda.time.Period period8 = period6.withHours(0);
        org.joda.time.Period period10 = period8.withMonths(0);
        org.joda.time.Period period12 = period10.withMillis(0);
        org.joda.time.Period period14 = period12.multipliedBy(0);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableDuration15, readableInstant16);
        org.joda.time.MutablePeriod mutablePeriod18 = period17.toMutablePeriod();
        org.joda.time.Period period20 = period17.plusSeconds((int) (short) -1);
        org.joda.time.Period period22 = period17.plusMillis((int) (byte) -1);
        org.joda.time.Period period23 = period14.withFields((org.joda.time.ReadablePeriod) period22);
        int int24 = period22.getDays();
        org.joda.time.Period period26 = period22.plusWeeks(0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(mutablePeriod18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(period26);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        java.lang.String str8 = unsupportedDateTimeField7.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = unsupportedDateTimeField7.getType();
        java.lang.String str10 = unsupportedDateTimeField7.getName();
        org.joda.time.DurationField durationField11 = unsupportedDateTimeField7.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "weekyear" + "'", str8.equals("weekyear"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "weekyear" + "'", str10.equals("weekyear"));
        org.junit.Assert.assertNull(durationField11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withMonthsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = gregorianChronology5.millis();
        org.joda.time.DurationField durationField7 = gregorianChronology5.millis();
        org.joda.time.Period period8 = new org.joda.time.Period(36001010L, 10L, periodType4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.weekyear();
        org.joda.time.DurationField durationField13 = gregorianChronology11.hours();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.secondOfDay();
        org.joda.time.DurationField durationField15 = gregorianChronology11.centuries();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology11.centuryOfEra();
        boolean boolean17 = org.joda.time.field.FieldUtils.equals((java.lang.Object) gregorianChronology5, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology5.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology5.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.weekyear();
        org.joda.time.DurationField durationField23 = gregorianChronology21.hours();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.secondOfDay();
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology21.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField30.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField26, dateTimeFieldType31);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType31);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType3, chronology4);
        java.lang.String str6 = period5.toString();
        org.joda.time.Hours hours7 = period5.toStandardHours();
        org.joda.time.Period period9 = period5.plusMonths((int) ' ');
        int int10 = period5.getMillis();
        org.joda.time.Period period12 = period5.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableInstant17);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period18.toDurationTo(readableInstant19);
        long long21 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration20);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType23 = periodType22.withHoursRemoved();
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant15, (org.joda.time.ReadableDuration) duration20, periodType23);
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant14, (org.joda.time.ReadableDuration) duration20);
        boolean boolean26 = periodType13.equals((java.lang.Object) duration20);
        org.joda.time.PeriodType periodType27 = periodType13.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType29 = periodType27.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(durationFieldType29, "PeriodType[YearWeekDay]");
        int int32 = period12.indexOf(durationFieldType29);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(durationFieldType29, (java.lang.Number) (-94608000000L), (java.lang.Number) 196919L, (java.lang.Number) 31455222L);
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField37 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0.002S" + "'", str6.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (short) -1);
        long long21 = offsetDateTimeField19.roundCeiling(0L);
        org.joda.time.PeriodType periodType24 = null;
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType24, chronology25);
        java.lang.String str27 = period26.toString();
        org.joda.time.Hours hours28 = period26.toStandardHours();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) offsetDateTimeField19, (java.lang.Object) period26);
        org.joda.time.ReadablePartial readablePartial30 = null;
        int[] intArray36 = new int[] { (short) 0, (-1), (byte) 100, 0, (byte) 10 };
        int int37 = offsetDateTimeField19.getMaximumValue(readablePartial30, intArray36);
        int int38 = zeroIsMaxDateTimeField12.getMinimumValue(readablePartial15, intArray36);
        long long41 = zeroIsMaxDateTimeField12.addWrapField(0L, 0);
        int int43 = zeroIsMaxDateTimeField12.get((-53L));
        int int46 = zeroIsMaxDateTimeField12.getDifference((long) (-4714), 37L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31795200000L + "'", long21 == 31795200000L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PT0.002S" + "'", str27.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 292278992 + "'", int37 == 292278992);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1439 + "'", int43 == 1439);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT-0.001S", "", 1, (int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((long) 9);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = fixedDateTimeZone4.getOffset(readableInstant6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int11 = cachedDateTimeZone9.getOffset(31741875055L);
        boolean boolean12 = cachedDateTimeZone9.isFixed();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 19");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long6 = gregorianChronology0.getDateTimeMillis((long) 100, (int) (short) 10, 0, 1, (int) (short) 10);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.minuteOfHour();
        org.joda.time.DurationField durationField8 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 36001010L + "'", long6 == 36001010L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = fixedDateTimeZone4.getOffset(readableInstant6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int11 = cachedDateTimeZone9.getOffset(31741875055L);
        boolean boolean12 = cachedDateTimeZone9.isFixed();
        int int14 = cachedDateTimeZone9.getOffset((long) (byte) -1);
        int int16 = cachedDateTimeZone9.getOffset((long) 5620749);
        int int18 = cachedDateTimeZone9.getOffset(3155846400000000L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PT0.002S", (java.lang.Number) 1.0f, (java.lang.Number) (-1.0d), (java.lang.Number) (byte) 10);
        illegalFieldValueException4.prependMessage("PT0.002S");
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException4.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0.002S" + "'", str7.equals("PT0.002S"));
        org.junit.Assert.assertNull(durationFieldType8);
        org.junit.Assert.assertNull(durationFieldType9);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        boolean boolean8 = unsupportedDateTimeField7.isSupported();
        long long11 = unsupportedDateTimeField7.getDifferenceAsLong((long) 64, 0L);
        org.joda.time.DurationField durationField12 = unsupportedDateTimeField7.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = unsupportedDateTimeField7.getType();
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = unsupportedDateTimeField7.getAsShortText(360000000L, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        java.lang.String str8 = unsupportedDateTimeField7.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = unsupportedDateTimeField7.getType();
        java.lang.String str10 = unsupportedDateTimeField7.getName();
        try {
            long long12 = unsupportedDateTimeField7.roundCeiling((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "weekyear" + "'", str8.equals("weekyear"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "weekyear" + "'", str10.equals("weekyear"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT-0.001S", "", 1, (int) (short) 100);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 'a', locale6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.ReadablePartial readablePartial9 = null;
        try {
            long long11 = gregorianChronology8.set(readablePartial9, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.001" + "'", str7.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.Period period2 = new org.joda.time.Period((-1641081600000L), (-1728292335055L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        int int15 = zeroIsMaxDateTimeField12.getMinimumValue();
        long long18 = zeroIsMaxDateTimeField12.set(3120000L, (int) (byte) 1);
        long long20 = zeroIsMaxDateTimeField12.roundHalfFloor(0L);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int int22 = zeroIsMaxDateTimeField12.getMinimumValue(readablePartial21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.weekyear();
        org.joda.time.DurationField durationField28 = gregorianChronology26.hours();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.secondOfDay();
        org.joda.time.Period period30 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology26.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField31, dateTimeFieldType36);
        int int39 = zeroIsMaxDateTimeField37.getMaximumValue(1560628033476L);
        org.joda.time.ReadablePartial readablePartial40 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (short) -1);
        long long46 = offsetDateTimeField44.roundCeiling(0L);
        org.joda.time.PeriodType periodType49 = null;
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.Period period51 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType49, chronology50);
        java.lang.String str52 = period51.toString();
        org.joda.time.Hours hours53 = period51.toStandardHours();
        boolean boolean54 = org.joda.time.field.FieldUtils.equals((java.lang.Object) offsetDateTimeField44, (java.lang.Object) period51);
        org.joda.time.ReadablePartial readablePartial55 = null;
        int[] intArray61 = new int[] { (short) 0, (-1), (byte) 100, 0, (byte) 10 };
        int int62 = offsetDateTimeField44.getMaximumValue(readablePartial55, intArray61);
        int int63 = zeroIsMaxDateTimeField37.getMinimumValue(readablePartial40, intArray61);
        try {
            int[] intArray65 = zeroIsMaxDateTimeField12.addWrapField(readablePartial23, 3, intArray61, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 60000L + "'", long18 == 60000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1440 + "'", int39 == 1440);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 31795200000L + "'", long46 == 31795200000L);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "PT0.002S" + "'", str52.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 292278992 + "'", int62 == 292278992);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
        org.joda.time.DurationField durationField6 = gregorianChronology4.hours();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.secondOfDay();
        org.joda.time.DurationField durationField8 = gregorianChronology4.hours();
        org.joda.time.Chronology chronology9 = gregorianChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology4.dayOfMonth();
        org.joda.time.Period period12 = new org.joda.time.Period(292260000L, (long) ' ', periodType3, (org.joda.time.Chronology) gregorianChronology4);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        long long10 = unsupportedDateTimeField7.add(1560627933476L, 100);
        int int13 = unsupportedDateTimeField7.getDifference((-1048319L), (long) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560628033476L + "'", long10 == 1560628033476L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1048) + "'", int13 == (-1048));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 5620749, (-2019427200001L), periodType4);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.weekyear();
        org.joda.time.DurationField durationField10 = gregorianChronology8.hours();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.secondOfDay();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology8.minuteOfDay();
        org.joda.time.Period period14 = new org.joda.time.Period((-1728292335055L), (-448320L), periodType4, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.PeriodType periodType15 = periodType4.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        int int15 = zeroIsMaxDateTimeField12.getMinimumValue();
        long long18 = zeroIsMaxDateTimeField12.set(3120000L, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial19 = null;
        java.util.Locale locale21 = null;
        java.lang.String str22 = zeroIsMaxDateTimeField12.getAsText(readablePartial19, 893638, locale21);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 60000L + "'", long18 == 60000L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "893638" + "'", str22.equals("893638"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PT0.002S", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT0.002S" + "'", str3.equals("PT0.002S"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.DurationField durationField5 = offsetDateTimeField3.getLeapDurationField();
        int int7 = offsetDateTimeField3.getMaximumValue((-9223309881273600000L));
        boolean boolean9 = offsetDateTimeField3.isLeap((-29537222399991L));
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsText(0L, locale11);
        org.joda.time.DurationField durationField13 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278992 + "'", int7 == 292278992);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.seconds();
        long long5 = iSOChronology0.add(0L, (-1L), (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.monthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("35", "10", 1440, (int) '#');
        boolean boolean12 = fixedDateTimeZone11.isFixed();
        org.joda.time.Chronology chronology13 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.Chronology chronology14 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        int int15 = zeroIsMaxDateTimeField12.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (short) -1);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray26 = new int[] { (byte) 0, (-2), (byte) 0, (short) 10 };
        int int27 = offsetDateTimeField20.getMinimumValue(readablePartial21, intArray26);
        org.joda.time.ReadablePartial readablePartial28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (short) -1);
        long long34 = offsetDateTimeField32.roundCeiling(0L);
        org.joda.time.PeriodType periodType37 = null;
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType37, chronology38);
        java.lang.String str40 = period39.toString();
        org.joda.time.Hours hours41 = period39.toStandardHours();
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) offsetDateTimeField32, (java.lang.Object) period39);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int[] intArray49 = new int[] { (short) 0, (-1), (byte) 100, 0, (byte) 10 };
        int int50 = offsetDateTimeField32.getMaximumValue(readablePartial43, intArray49);
        int int51 = offsetDateTimeField20.getMaximumValue(readablePartial28, intArray49);
        int int52 = zeroIsMaxDateTimeField12.getMinimumValue(readablePartial16, intArray49);
        int int54 = zeroIsMaxDateTimeField12.getMinimumValue((-62135369395200L));
        long long56 = zeroIsMaxDateTimeField12.roundCeiling((long) 35);
        int int57 = zeroIsMaxDateTimeField12.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-292275055) + "'", int27 == (-292275055));
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 31795200000L + "'", long34 == 31795200000L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PT0.002S" + "'", str40.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 292278992 + "'", int50 == 292278992);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 292278992 + "'", int51 == 292278992);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 60000L + "'", long56 == 60000L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler5 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file6 = null;
        java.io.File[] fileArray7 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = zoneInfoCompiler5.compile(file6, fileArray7);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = zoneInfoCompiler0.compile(file4, fileArray7);
        java.io.File file10 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler11 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file12 = null;
        java.io.File[] fileArray13 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap14 = zoneInfoCompiler11.compile(file12, fileArray13);
        java.io.File file15 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler16 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file17 = null;
        java.io.File[] fileArray18 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap19 = zoneInfoCompiler16.compile(file17, fileArray18);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap20 = zoneInfoCompiler11.compile(file15, fileArray18);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = zoneInfoCompiler0.compile(file10, fileArray18);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray7);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertNotNull(strMap9);
        org.junit.Assert.assertNotNull(fileArray13);
        org.junit.Assert.assertNotNull(strMap14);
        org.junit.Assert.assertNotNull(fileArray18);
        org.junit.Assert.assertNotNull(strMap19);
        org.junit.Assert.assertNotNull(strMap20);
        org.junit.Assert.assertNotNull(strMap21);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField15);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (int) '4');
        org.joda.time.DurationField durationField19 = dividedDateTimeField18.getDurationField();
        int int20 = dividedDateTimeField18.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField24.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "weekyear");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField18, dateTimeFieldType25);
        long long30 = remainderDateTimeField28.roundCeiling((-2L));
        int int31 = remainderDateTimeField28.getDivisor();
        long long33 = remainderDateTimeField28.remainder(100L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5620749 + "'", int20 == 5620749);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31795200000L + "'", long30 == 31795200000L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 259200100L + "'", long33 == 259200100L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        long long15 = zeroIsMaxDateTimeField12.add(0L, (int) '4');
        int int17 = zeroIsMaxDateTimeField12.getMinimumValue((long) (-292271120));
        long long19 = zeroIsMaxDateTimeField12.roundHalfFloor((long) 3);
        int int22 = zeroIsMaxDateTimeField12.getDifference((long) 35, 3840010L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3120000L + "'", long15 == 3120000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-63) + "'", int22 == (-63));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        long long17 = zeroIsMaxDateTimeField12.add((long) (-292275055), (-28800001L));
        long long19 = zeroIsMaxDateTimeField12.roundHalfEven((long) 292278992);
        long long21 = zeroIsMaxDateTimeField12.roundCeiling(31795200000L);
        boolean boolean23 = zeroIsMaxDateTimeField12.isLeap((long) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1728292335055L) + "'", long17 == (-1728292335055L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 292260000L + "'", long19 == 292260000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31795200000L + "'", long21 == 31795200000L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField15);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (int) '4');
        org.joda.time.DurationField durationField19 = dividedDateTimeField18.getDurationField();
        int int20 = dividedDateTimeField18.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField24.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "weekyear");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField18, dateTimeFieldType25);
        long long30 = remainderDateTimeField28.roundFloor((-80194466524L));
        org.joda.time.DateTimeField dateTimeField31 = remainderDateTimeField28.getWrappedField();
        long long33 = remainderDateTimeField28.roundHalfCeiling((long) (short) 10);
        int int34 = remainderDateTimeField28.getMaximumValue();
        long long36 = remainderDateTimeField28.roundFloor((-259260000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5620749 + "'", int20 == 5620749);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-94608000000L) + "'", long30 == (-94608000000L));
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-259200000L) + "'", long33 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 51 + "'", int34 == 51);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-31708800000L) + "'", long36 == (-31708800000L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = zonedChronology4.monthOfYear();
        org.joda.time.DurationField durationField6 = zonedChronology4.years();
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology4.millisOfDay();
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology4.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) -1, chronology3);
        org.joda.time.Period period6 = period4.multipliedBy(2);
        long long9 = gregorianChronology1.add((org.joda.time.ReadablePeriod) period6, (-1048319L), 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1048319L) + "'", long9 == (-1048319L));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType2, chronology3);
        java.lang.String str5 = period4.toString();
        org.joda.time.Hours hours6 = period4.toStandardHours();
        org.joda.time.Period period8 = period4.plusMonths((int) ' ');
        int int9 = period4.getMillis();
        org.joda.time.Period period11 = period4.plusMonths((int) (short) -1);
        org.joda.time.Period period13 = period11.minusWeeks((int) '4');
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType15 = periodType14.withWeeksRemoved();
        org.joda.time.PeriodType periodType16 = periodType15.withDaysRemoved();
        try {
            org.joda.time.Period period17 = period13.withPeriodType(periodType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0.002S" + "'", str5.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField15);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (int) '4');
        org.joda.time.DurationField durationField19 = dividedDateTimeField18.getDurationField();
        long long22 = dividedDateTimeField18.getDifferenceAsLong((-80194466524L), 1560628033476L);
        long long25 = dividedDateTimeField18.set((-524253L), 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-60715267724253L) + "'", long25 == (-60715267724253L));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.Period period1 = org.joda.time.Period.parse("P4DT240M");
        org.joda.time.Period period3 = period1.withSeconds((-292275055));
        org.joda.time.Period period5 = period1.minusMillis(0);
        org.joda.time.Weeks weeks6 = period5.toStandardWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(weeks6);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler5 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file6 = null;
        java.io.File[] fileArray7 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = zoneInfoCompiler5.compile(file6, fileArray7);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = zoneInfoCompiler0.compile(file4, fileArray7);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap9);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray7);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertNotNull(strMap9);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(15L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000001737d + "'", double1 == 2440587.5000001737d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.MutablePeriod mutablePeriod3 = period2.toMutablePeriod();
        org.joda.time.Period period5 = period2.plusSeconds((int) (short) -1);
        org.joda.time.Period period7 = period2.withMonths(2);
        org.joda.time.Period period9 = period7.withYears((int) (byte) 10);
        org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) period9);
        org.junit.Assert.assertNotNull(mutablePeriod3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (-33052872));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.weekyear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.minutes();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology5.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.eras();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00:00.001", "P4DT240M");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationTo(readableInstant11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType15 = periodType14.withHoursRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant7, (org.joda.time.ReadableDuration) duration12, periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant6, (org.joda.time.ReadableDuration) duration12);
        boolean boolean18 = periodType5.equals((java.lang.Object) duration12);
        org.joda.time.PeriodType periodType19 = periodType5.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType21, "PeriodType[YearWeekDay]");
        boolean boolean24 = period2.isSupported(durationFieldType21);
        org.joda.time.field.PreciseDurationField preciseDurationField26 = new org.joda.time.field.PreciseDurationField(durationFieldType21, 60000L);
        long long29 = preciseDurationField26.getDifferenceAsLong(551478992L, 292260000L);
        long long32 = preciseDurationField26.getDifferenceAsLong((-31455220675L), (long) 102);
        boolean boolean33 = preciseDurationField26.isPrecise();
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4320L + "'", long29 == 4320L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-524253L) + "'", long32 == (-524253L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationTo(readableInstant11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType15 = periodType14.withHoursRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant7, (org.joda.time.ReadableDuration) duration12, periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant6, (org.joda.time.ReadableDuration) duration12);
        boolean boolean18 = periodType5.equals((java.lang.Object) duration12);
        org.joda.time.PeriodType periodType19 = periodType5.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType21, "PeriodType[YearWeekDay]");
        boolean boolean24 = period2.isSupported(durationFieldType21);
        org.joda.time.field.PreciseDurationField preciseDurationField26 = new org.joda.time.field.PreciseDurationField(durationFieldType21, 60000L);
        long long29 = preciseDurationField26.getDifferenceAsLong(551478992L, 292260000L);
        long long32 = preciseDurationField26.getDifferenceAsLong((-31455220675L), (long) 102);
        long long35 = preciseDurationField26.add(2440587999L, 64L);
        boolean boolean36 = preciseDurationField26.isPrecise();
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4320L + "'", long29 == 4320L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-524253L) + "'", long32 == (-524253L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2444427999L + "'", long35 == 2444427999L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        org.joda.time.DurationField durationField4 = gregorianChronology2.millis();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.Period period6 = new org.joda.time.Period(0L, periodType1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant7, readableInstant8);
        org.joda.time.Period period11 = period9.withDays((int) '4');
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType15 = periodType14.withSecondsRemoved();
        java.lang.String str16 = periodType14.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekyear();
        org.joda.time.DurationField durationField19 = gregorianChronology17.hours();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.secondOfDay();
        org.joda.time.DurationField durationField21 = gregorianChronology17.centuries();
        org.joda.time.Period period22 = new org.joda.time.Period((long) 4, (long) 1440, periodType14, (org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.Period period23 = period11.normalizedStandard(periodType14);
        int[] intArray25 = gregorianChronology2.get((org.joda.time.ReadablePeriod) period11, 0L);
        org.joda.time.DurationFieldType durationFieldType26 = null;
        try {
            org.joda.time.Period period28 = period11.withField(durationFieldType26, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PeriodType[YearWeekDay]" + "'", str16.equals("PeriodType[YearWeekDay]"));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PT0.002S", "");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.Period period4 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.Period period6 = period4.minusMillis(0);
        org.joda.time.Period period8 = period6.withHours(0);
        org.joda.time.Period period10 = period8.withMonths(0);
        org.joda.time.Period period12 = period10.withMillis(0);
        org.joda.time.Period period14 = period12.multipliedBy(0);
        org.joda.time.Period period16 = period14.minusMonths((int) (byte) 100);
        org.joda.time.DurationFieldType[] durationFieldTypeArray17 = period16.getFieldTypes();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldTypeArray17);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        long long17 = zeroIsMaxDateTimeField12.add((long) (-292275055), (-28800001L));
        int int19 = zeroIsMaxDateTimeField12.get((long) 4);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = zeroIsMaxDateTimeField12.getAsShortText(readablePartial20, 4, locale22);
        long long26 = zeroIsMaxDateTimeField12.addWrapField(3155846400000000L, 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1728292335055L) + "'", long17 == (-1728292335055L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1440 + "'", int19 == 1440);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "4" + "'", str23.equals("4"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3155846400000000L + "'", long26 == 3155846400000000L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = fixedDateTimeZone4.getOffset(readableInstant6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str11 = cachedDateTimeZone9.getNameKey(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.millis();
        org.joda.time.DurationField durationField14 = gregorianChronology12.millis();
        long long17 = durationField14.subtract((long) 0, (int) (short) -1);
        boolean boolean18 = cachedDateTimeZone9.equals((java.lang.Object) long17);
        java.lang.String str20 = cachedDateTimeZone9.getNameKey((long) (-292271120));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str6 = jodaTimePermission5.toString();
        java.lang.String str7 = jodaTimePermission5.getActions();
        boolean boolean8 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        java.lang.String str9 = jodaTimePermission5.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str6.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        long long17 = zeroIsMaxDateTimeField12.add((long) (-292275055), (-28800001L));
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = gregorianChronology21.millis();
        org.joda.time.DurationField durationField23 = gregorianChronology21.millis();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.minuteOfHour();
        org.joda.time.Period period25 = new org.joda.time.Period(0L, periodType20, (org.joda.time.Chronology) gregorianChronology21);
        int[] intArray26 = period25.getValues();
        int int27 = zeroIsMaxDateTimeField12.getMaximumValue(readablePartial18, intArray26);
        long long29 = zeroIsMaxDateTimeField12.roundHalfEven(0L);
        int int31 = zeroIsMaxDateTimeField12.getLeapAmount((long) (byte) -1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1728292335055L) + "'", long17 == (-1728292335055L));
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1440 + "'", int27 == 1440);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsText(readablePartial9, 0, locale11);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField3.getAsText(0, locale7);
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField3.getWrappedField();
        long long11 = offsetDateTimeField3.roundHalfEven(24192000018L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31795200000L + "'", long11 == 31795200000L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        java.lang.String str6 = fixedDateTimeZone4.getName((-1420329600000L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField15);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (int) '4');
        org.joda.time.DurationField durationField19 = dividedDateTimeField18.getDurationField();
        int int20 = dividedDateTimeField18.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField24.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "weekyear");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField18, dateTimeFieldType25);
        long long30 = remainderDateTimeField28.roundFloor((-80194466524L));
        org.joda.time.DateTimeField dateTimeField31 = remainderDateTimeField28.getWrappedField();
        int int33 = remainderDateTimeField28.get((-62135369395200L));
        long long36 = remainderDateTimeField28.set(0L, 32);
        int int38 = remainderDateTimeField28.get(3120000L);
        long long40 = remainderDateTimeField28.roundHalfCeiling((long) 15);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5620749 + "'", int20 == 5620749);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-94608000000L) + "'", long30 == (-94608000000L));
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-410054400000L) + "'", long36 == (-410054400000L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 45 + "'", int38 == 45);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-259200000L) + "'", long40 == (-259200000L));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (byte) -1, chronology1);
        org.joda.time.Period period4 = period2.multipliedBy(2);
        org.joda.time.Seconds seconds5 = period4.toStandardSeconds();
        org.joda.time.Period period7 = period4.plusDays(0);
        org.joda.time.Period period9 = period7.minusSeconds(2);
        org.joda.time.Period period11 = period9.withDays((int) '#');
        org.joda.time.Period period13 = org.joda.time.Period.seconds(100);
        org.joda.time.Period period14 = period13.normalizedStandard();
        org.joda.time.Period period15 = period9.withFields((org.joda.time.ReadablePeriod) period14);
        int int16 = period9.getHours();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(seconds5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str6 = fixedDateTimeZone4.toString();
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone4.getShortName(2440588L, locale10);
        long long14 = fixedDateTimeZone4.convertLocalToUTC(183600000L, false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 183600001L + "'", long14 == 183600001L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = fixedDateTimeZone4.getOffset(readableInstant6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.Period period14 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.Period period16 = period14.minusMillis(0);
        int int17 = period16.getMonths();
        boolean boolean18 = cachedDateTimeZone9.equals((java.lang.Object) period16);
        long long20 = cachedDateTimeZone9.previousTransition(164096150400001L);
        long long22 = cachedDateTimeZone9.nextTransition((-27346961293L));
        int int24 = cachedDateTimeZone9.getOffset(0L);
        long long26 = cachedDateTimeZone9.previousTransition(2440588L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 164096150400001L + "'", long20 == 164096150400001L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-27346961293L) + "'", long22 == (-27346961293L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2440588L + "'", long26 == 2440588L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField6 = gregorianChronology0.hours();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.time();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 1439, 164127892275055L, periodType9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType15, chronology16);
        java.lang.String str18 = period17.toString();
        org.joda.time.Hours hours19 = period17.toStandardHours();
        org.joda.time.Period period21 = period17.plusMonths((int) ' ');
        int int22 = period17.getMillis();
        org.joda.time.Period period24 = period17.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period30.toDurationTo(readableInstant31);
        long long33 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType35 = periodType34.withHoursRemoved();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant27, (org.joda.time.ReadableDuration) duration32, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant26, (org.joda.time.ReadableDuration) duration32);
        boolean boolean38 = periodType25.equals((java.lang.Object) duration32);
        org.joda.time.PeriodType periodType39 = periodType25.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType41, "PeriodType[YearWeekDay]");
        int int44 = period24.indexOf(durationFieldType41);
        boolean boolean45 = periodType12.isSupported(durationFieldType41);
        int int46 = periodType9.indexOf(durationFieldType41);
        org.joda.time.field.ScaledDurationField scaledDurationField48 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType41, 51);
        long long51 = scaledDurationField48.getValueAsLong((long) (byte) 1, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.002S" + "'", str18.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        int int9 = offsetDateTimeField3.get(292260000L);
        org.joda.time.DurationField durationField10 = offsetDateTimeField3.getLeapDurationField();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField3, (-1048320), 0, (-436));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1048320 for weekyear must be in the range [0,-436]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withDaysRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withMonthsRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType5);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 1.0 for PT0.002S must be in the range [-1.0,10]", (java.lang.Number) 100L, (java.lang.Number) 10.0d, number3);
        java.lang.String str5 = illegalFieldValueException4.toString();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("-00:00:00.001");
        java.lang.String str9 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for org.joda.time.IllegalFieldValueException: Value 1.0 for PT0.002S must be in the range [-1.0,10] must not be smaller than 10.0" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 100 for org.joda.time.IllegalFieldValueException: Value 1.0 for PT0.002S must be in the range [-1.0,10] must not be smaller than 10.0"));
        org.junit.Assert.assertNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.MutablePeriod mutablePeriod3 = period2.toMutablePeriod();
        org.joda.time.Period period5 = period2.plusSeconds((int) (short) -1);
        org.joda.time.Period period7 = period2.plusMillis((int) (byte) -1);
        org.joda.time.Period period8 = period7.toPeriod();
        org.joda.time.Period period9 = period8.negated();
        org.junit.Assert.assertNotNull(mutablePeriod3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (byte) -1, chronology1);
        org.joda.time.Period period4 = period2.multipliedBy(2);
        org.joda.time.Period period6 = period4.withHours(0);
        org.joda.time.Period period8 = period6.withMillis((-63));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationFrom(readableInstant6);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.weeks();
        int int9 = periodType8.size();
        org.joda.time.Period period10 = period5.normalizedStandard(periodType8);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "910");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        boolean boolean5 = offsetDateTimeField3.isLeap(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getLeapDurationField();
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField3.getMaximumShortTextLength(locale7);
        int int10 = offsetDateTimeField3.get(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField3.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.DurationField durationField5 = offsetDateTimeField3.getLeapDurationField();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        java.lang.String str12 = fixedDateTimeZone10.toString();
        int int14 = fixedDateTimeZone10.getStandardOffset((long) 10);
        boolean boolean15 = fixedDateTimeZone10.isFixed();
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) offsetDateTimeField3, (java.lang.Object) fixedDateTimeZone10);
        java.lang.String str18 = fixedDateTimeZone10.getShortName((long) 0);
        long long20 = fixedDateTimeZone10.previousTransition(2440587999L);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-00:00:00.001" + "'", str18.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2440587999L + "'", long20 == 2440587999L);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(iSOChronology22);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField6 = gregorianChronology0.hours();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.time();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 1439, 164127892275055L, periodType9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType15, chronology16);
        java.lang.String str18 = period17.toString();
        org.joda.time.Hours hours19 = period17.toStandardHours();
        org.joda.time.Period period21 = period17.plusMonths((int) ' ');
        int int22 = period17.getMillis();
        org.joda.time.Period period24 = period17.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period30.toDurationTo(readableInstant31);
        long long33 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType35 = periodType34.withHoursRemoved();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant27, (org.joda.time.ReadableDuration) duration32, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant26, (org.joda.time.ReadableDuration) duration32);
        boolean boolean38 = periodType25.equals((java.lang.Object) duration32);
        org.joda.time.PeriodType periodType39 = periodType25.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType41, "PeriodType[YearWeekDay]");
        int int44 = period24.indexOf(durationFieldType41);
        boolean boolean45 = periodType12.isSupported(durationFieldType41);
        int int46 = periodType9.indexOf(durationFieldType41);
        org.joda.time.field.ScaledDurationField scaledDurationField48 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType41, 51);
        long long51 = scaledDurationField48.add((-1420070400000L), (long) (-292271120));
        boolean boolean52 = scaledDurationField48.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.002S" + "'", str18.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-53662397702400000L) + "'", long51 == (-53662397702400000L));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        long long10 = unsupportedDateTimeField7.getDifferenceAsLong((long) 1439, (-31455220675L));
        try {
            long long13 = unsupportedDateTimeField7.addWrapField((long) (byte) 1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 31455222L + "'", long10 == 31455222L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        long long15 = zeroIsMaxDateTimeField12.add(0L, (int) '4');
        int int17 = zeroIsMaxDateTimeField12.getMinimumValue((long) (-292271120));
        int int19 = zeroIsMaxDateTimeField12.getMinimumValue((long) (-2));
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.weekyear();
        org.joda.time.DurationField durationField25 = gregorianChronology23.hours();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.secondOfDay();
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology23);
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology23.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType33);
        int int36 = zeroIsMaxDateTimeField34.getMaximumValue(1560628033476L);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = zeroIsMaxDateTimeField34.getMaximumValue(readablePartial37);
        org.joda.time.ReadablePartial readablePartial39 = null;
        org.joda.time.PeriodType periodType42 = null;
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.Period period44 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType42, chronology43);
        java.lang.String str45 = period44.toString();
        org.joda.time.Hours hours46 = period44.toStandardHours();
        int int47 = period44.getSeconds();
        int[] intArray48 = period44.getValues();
        int int49 = zeroIsMaxDateTimeField34.getMinimumValue(readablePartial39, intArray48);
        try {
            int[] intArray51 = zeroIsMaxDateTimeField12.addWrapField(readablePartial20, 0, intArray48, 6400);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3120000L + "'", long15 == 3120000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1440 + "'", int36 == 1440);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1440 + "'", int38 == 1440);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "PT0.002S" + "'", str45.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        long long10 = unsupportedDateTimeField7.add(1560627933476L, 100);
        java.lang.String str11 = unsupportedDateTimeField7.toString();
        java.lang.String str12 = unsupportedDateTimeField7.getName();
        org.joda.time.DurationField durationField13 = unsupportedDateTimeField7.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560628033476L + "'", long10 == 1560628033476L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnsupportedDateTimeField" + "'", str11.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "weekyear" + "'", str12.equals("weekyear"));
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        long long15 = zeroIsMaxDateTimeField12.add(0L, (int) '4');
        long long17 = zeroIsMaxDateTimeField12.roundHalfFloor((-2L));
        long long19 = zeroIsMaxDateTimeField12.roundFloor((-29537222399991L));
        int int21 = zeroIsMaxDateTimeField12.getMaximumValue(31795200000L);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = zeroIsMaxDateTimeField12.getMinimumValue(readablePartial22);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3120000L + "'", long15 == 3120000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-29537222400000L) + "'", long19 == (-29537222400000L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1440 + "'", int21 == 1440);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.year();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        int int15 = zeroIsMaxDateTimeField12.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (short) -1);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray26 = new int[] { (byte) 0, (-2), (byte) 0, (short) 10 };
        int int27 = offsetDateTimeField20.getMinimumValue(readablePartial21, intArray26);
        org.joda.time.ReadablePartial readablePartial28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (short) -1);
        long long34 = offsetDateTimeField32.roundCeiling(0L);
        org.joda.time.PeriodType periodType37 = null;
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType37, chronology38);
        java.lang.String str40 = period39.toString();
        org.joda.time.Hours hours41 = period39.toStandardHours();
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) offsetDateTimeField32, (java.lang.Object) period39);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int[] intArray49 = new int[] { (short) 0, (-1), (byte) 100, 0, (byte) 10 };
        int int50 = offsetDateTimeField32.getMaximumValue(readablePartial43, intArray49);
        int int51 = offsetDateTimeField20.getMaximumValue(readablePartial28, intArray49);
        int int52 = zeroIsMaxDateTimeField12.getMinimumValue(readablePartial16, intArray49);
        int int54 = zeroIsMaxDateTimeField12.getMinimumValue((-62135369395200L));
        long long56 = zeroIsMaxDateTimeField12.roundCeiling((long) 35);
        java.util.Locale locale57 = null;
        int int58 = zeroIsMaxDateTimeField12.getMaximumShortTextLength(locale57);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-292275055) + "'", int27 == (-292275055));
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 31795200000L + "'", long34 == 31795200000L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PT0.002S" + "'", str40.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 292278992 + "'", int50 == 292278992);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 292278992 + "'", int51 == 292278992);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 60000L + "'", long56 == 60000L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 4 + "'", int58 == 4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        boolean boolean4 = periodType2.isSupported(durationFieldType3);
        org.joda.time.Period period9 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.Period period11 = period9.minusMillis(0);
        org.joda.time.Period period13 = period11.plusDays((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType14 = null;
        boolean boolean15 = period13.isSupported(durationFieldType14);
        int int16 = period13.getHours();
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant20, readableInstant21);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Duration duration24 = period22.toDurationTo(readableInstant23);
        long long25 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration24);
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType27 = periodType26.withHoursRemoved();
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant19, (org.joda.time.ReadableDuration) duration24, periodType27);
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant18, (org.joda.time.ReadableDuration) duration24);
        boolean boolean30 = periodType17.equals((java.lang.Object) duration24);
        org.joda.time.PeriodType periodType31 = periodType17.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(durationFieldType33, "PeriodType[YearWeekDay]");
        org.joda.time.Period period37 = period13.withField(durationFieldType33, 102);
        int int38 = periodType2.indexOf(durationFieldType33);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32 + "'", int16 == 32);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(duration24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType2, chronology3);
        java.lang.String str5 = period4.toString();
        org.joda.time.Hours hours6 = period4.toStandardHours();
        org.joda.time.Period period8 = period4.plusMonths((int) ' ');
        org.joda.time.Period period10 = period8.minusMinutes(1969);
        org.joda.time.Period period12 = period10.plusSeconds(15);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0.002S" + "'", str5.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value 1.0 for PT0.002S must be in the range [-1.0,10]", (java.lang.Number) 100L, (java.lang.Number) 10.0d, number3);
        java.lang.String str5 = illegalFieldValueException4.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number7 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for org.joda.time.IllegalFieldValueException: Value 1.0 for PT0.002S must be in the range [-1.0,10] must not be smaller than 10.0" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 100 for org.joda.time.IllegalFieldValueException: Value 1.0 for PT0.002S must be in the range [-1.0,10] must not be smaller than 10.0"));
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100L + "'", number7.equals(100L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        java.lang.String str6 = periodType4.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.DurationField durationField9 = gregorianChronology7.hours();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.secondOfDay();
        org.joda.time.DurationField durationField11 = gregorianChronology7.centuries();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 4, (long) 1440, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period13 = new org.joda.time.Period(60000L, (long) '#', periodType4);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = gregorianChronology17.millis();
        org.joda.time.DurationField durationField19 = gregorianChronology17.millis();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.minuteOfHour();
        org.joda.time.Period period21 = new org.joda.time.Period(0L, periodType16, (org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period(1560628033476L, periodType16, chronology22);
        org.joda.time.PeriodType periodType24 = periodType16.withMinutesRemoved();
        org.joda.time.PeriodType periodType25 = periodType24.withDaysRemoved();
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant29, readableInstant30);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.Duration duration33 = period31.toDurationTo(readableInstant32);
        long long34 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration33);
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType36 = periodType35.withHoursRemoved();
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant28, (org.joda.time.ReadableDuration) duration33, periodType36);
        org.joda.time.Period period38 = new org.joda.time.Period(readableInstant27, (org.joda.time.ReadableDuration) duration33);
        boolean boolean39 = periodType26.equals((java.lang.Object) duration33);
        org.joda.time.PeriodType periodType40 = periodType26.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType42 = periodType40.getFieldType(0);
        int int43 = periodType24.indexOf(durationFieldType42);
        boolean boolean44 = period13.isSupported(durationFieldType42);
        java.lang.Number number47 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(durationFieldType42, (java.lang.Number) 1560628033476L, (java.lang.Number) 1641201672990L, number47);
        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(durationFieldType42, (java.lang.Number) 1440, (java.lang.Number) (-63158400000L), (java.lang.Number) 10.0f);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[YearWeekDay]" + "'", str6.equals("PeriodType[YearWeekDay]"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(duration33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(durationFieldType42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = iSOChronology2.seconds();
        long long7 = iSOChronology2.add(0L, (-1L), (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.monthOfYear();
        boolean boolean9 = jodaTimePermission1.equals((java.lang.Object) iSOChronology2);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        java.lang.String str16 = fixedDateTimeZone14.toString();
        int int18 = fixedDateTimeZone14.getStandardOffset((long) 10);
        java.lang.Object obj19 = null;
        boolean boolean20 = fixedDateTimeZone14.equals(obj19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DurationField durationField22 = gregorianChronology21.years();
        jodaTimePermission1.checkGuard((java.lang.Object) gregorianChronology21);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.Period period4 = new org.joda.time.Period(19, (int) (byte) 100, (int) (short) 10, (int) (byte) 10);
        org.joda.time.Period period6 = period4.plusHours(15);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        long long17 = zeroIsMaxDateTimeField12.add((long) (-292275055), (-28800001L));
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = gregorianChronology21.millis();
        org.joda.time.DurationField durationField23 = gregorianChronology21.millis();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.minuteOfHour();
        org.joda.time.Period period25 = new org.joda.time.Period(0L, periodType20, (org.joda.time.Chronology) gregorianChronology21);
        int[] intArray26 = period25.getValues();
        int int27 = zeroIsMaxDateTimeField12.getMaximumValue(readablePartial18, intArray26);
        long long29 = zeroIsMaxDateTimeField12.roundHalfEven(0L);
        long long32 = zeroIsMaxDateTimeField12.getDifferenceAsLong((-80194466524L), (-29537222399990L));
        long long34 = zeroIsMaxDateTimeField12.roundHalfEven(1560628033476L);
        int int36 = zeroIsMaxDateTimeField12.getLeapAmount(0L);
        long long39 = zeroIsMaxDateTimeField12.addWrapField(0L, 5620749);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1728292335055L) + "'", long17 == (-1728292335055L));
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1440 + "'", int27 == 1440);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 490950465L + "'", long32 == 490950465L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560628020000L + "'", long34 == 1560628020000L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 25740000L + "'", long39 == 25740000L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        long long15 = zeroIsMaxDateTimeField12.add(0L, (int) '4');
        int int17 = zeroIsMaxDateTimeField12.getMinimumValue((long) (-292271120));
        long long19 = zeroIsMaxDateTimeField12.roundHalfFloor(1546214400000L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3120000L + "'", long15 == 3120000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546214400000L + "'", long19 == 1546214400000L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DurationField durationField5 = zonedChronology4.years();
        org.joda.time.Chronology chronology6 = zonedChronology4.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology4.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.MutablePeriod mutablePeriod3 = period2.toMutablePeriod();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.Period period8 = period6.plusMonths((int) (short) 10);
        org.joda.time.Period period10 = period8.plusMinutes((int) '#');
        boolean boolean11 = period2.equals((java.lang.Object) period10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Period period13 = period2.withFields(readablePeriod12);
        org.junit.Assert.assertNotNull(mutablePeriod3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableInstant2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationTo(readableInstant4);
        long long6 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType8 = periodType7.withHoursRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType8);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableInstant14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period15.toDurationTo(readableInstant16);
        long long18 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration17);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant12, (org.joda.time.ReadableDuration) duration17, periodType20);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant11, (org.joda.time.ReadableDuration) duration17);
        boolean boolean23 = periodType10.equals((java.lang.Object) duration17);
        org.joda.time.PeriodType periodType24 = periodType10.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType26 = periodType24.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType26, "PeriodType[YearWeekDay]");
        org.joda.time.Period period30 = period9.withFieldAdded(durationFieldType26, 15);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period30);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT-0.001S", "", 1, (int) (short) 100);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 'a', locale6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        java.util.TimeZone timeZone15 = fixedDateTimeZone14.toTimeZone();
        org.joda.time.ReadableInstant readableInstant16 = null;
        int int17 = fixedDateTimeZone14.getOffset(readableInstant16);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        org.joda.time.Period period24 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.Period period26 = period24.minusMillis(0);
        int int27 = period26.getMonths();
        boolean boolean28 = cachedDateTimeZone19.equals((java.lang.Object) period26);
        long long30 = cachedDateTimeZone19.previousTransition(164096150400001L);
        long long32 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone19, 0L);
        org.joda.time.DateTimeZone dateTimeZone33 = cachedDateTimeZone19.getUncachedZone();
        java.lang.String str35 = cachedDateTimeZone19.getNameKey((long) 5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.001" + "'", str7.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 164096150400001L + "'", long30 == 164096150400001L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2L + "'", long32 == 2L);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField6 = gregorianChronology0.hours();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.time();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 1439, 164127892275055L, periodType9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType15, chronology16);
        java.lang.String str18 = period17.toString();
        org.joda.time.Hours hours19 = period17.toStandardHours();
        org.joda.time.Period period21 = period17.plusMonths((int) ' ');
        int int22 = period17.getMillis();
        org.joda.time.Period period24 = period17.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period30.toDurationTo(readableInstant31);
        long long33 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType35 = periodType34.withHoursRemoved();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant27, (org.joda.time.ReadableDuration) duration32, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant26, (org.joda.time.ReadableDuration) duration32);
        boolean boolean38 = periodType25.equals((java.lang.Object) duration32);
        org.joda.time.PeriodType periodType39 = periodType25.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType41, "PeriodType[YearWeekDay]");
        int int44 = period24.indexOf(durationFieldType41);
        boolean boolean45 = periodType12.isSupported(durationFieldType41);
        int int46 = periodType9.indexOf(durationFieldType41);
        org.joda.time.field.ScaledDurationField scaledDurationField48 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType41, 51);
        long long51 = scaledDurationField48.add((-1420070400000L), (long) (-292271120));
        long long53 = scaledDurationField48.getMillis((-4714));
        long long54 = scaledDurationField48.getUnitMillis();
        int int57 = scaledDurationField48.getDifference(2440587999L, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.002S" + "'", str18.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-53662397702400000L) + "'", long51 == (-53662397702400000L));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-865490400000L) + "'", long53 == (-865490400000L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 183600000L + "'", long54 == 183600000L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 13 + "'", int57 == 13);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(100, (-1048));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1048");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        long long17 = zeroIsMaxDateTimeField12.add((long) (-292275055), (-28800001L));
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = gregorianChronology21.millis();
        org.joda.time.DurationField durationField23 = gregorianChronology21.millis();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.minuteOfHour();
        org.joda.time.Period period25 = new org.joda.time.Period(0L, periodType20, (org.joda.time.Chronology) gregorianChronology21);
        int[] intArray26 = period25.getValues();
        int int27 = zeroIsMaxDateTimeField12.getMaximumValue(readablePartial18, intArray26);
        boolean boolean29 = zeroIsMaxDateTimeField12.isLeap((-53662397702400000L));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1728292335055L) + "'", long17 == (-1728292335055L));
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1440 + "'", int27 == 1440);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = fixedDateTimeZone4.getOffset(readableInstant6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int11 = cachedDateTimeZone9.getOffset(31741875055L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField15.getType();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = iSOChronology17.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField18);
        long long22 = unsupportedDateTimeField19.add(1560627933476L, 100);
        java.lang.String str23 = unsupportedDateTimeField19.toString();
        boolean boolean24 = cachedDateTimeZone9.equals((java.lang.Object) str23);
        long long26 = cachedDateTimeZone9.previousTransition(33L);
        java.lang.String str28 = cachedDateTimeZone9.getNameKey((long) 888);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560628033476L + "'", long22 == 1560628033476L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnsupportedDateTimeField" + "'", str23.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 33L + "'", long26 == 33L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.Period period8 = new org.joda.time.Period(0, (-1595218380), (-33052872), 5, 0, 0, 5620749, (-1048));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        int int10 = offsetDateTimeField3.getLeapAmount(3155846400000000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = offsetDateTimeField3.getAsShortText((long) (short) 100, locale5);
        int int7 = offsetDateTimeField3.getOffset();
        long long10 = offsetDateTimeField3.set(0L, 102);
        org.joda.time.DurationField durationField11 = offsetDateTimeField3.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58916592000000L) + "'", long10 == (-58916592000000L));
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField15);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (int) '4');
        long long21 = dividedDateTimeField18.add(64L, 1440);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField25.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "weekyear");
        java.lang.Number number29 = illegalFieldValueException28.getIllegalNumberValue();
        java.lang.String str30 = illegalFieldValueException28.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = illegalFieldValueException28.getDateTimeFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField18, dateTimeFieldType31, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2362985049600064L + "'", long21 == 2362985049600064L);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "weekyear" + "'", str30.equals("weekyear"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (byte) 10, "UnsupportedDateTimeField");
        java.lang.String str3 = illegalInstantException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.010 (UnsupportedDateTimeField)" + "'", str3.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.010 (UnsupportedDateTimeField)"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField6 = gregorianChronology0.hours();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.time();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 1439, 164127892275055L, periodType9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType15, chronology16);
        java.lang.String str18 = period17.toString();
        org.joda.time.Hours hours19 = period17.toStandardHours();
        org.joda.time.Period period21 = period17.plusMonths((int) ' ');
        int int22 = period17.getMillis();
        org.joda.time.Period period24 = period17.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period30.toDurationTo(readableInstant31);
        long long33 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType35 = periodType34.withHoursRemoved();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant27, (org.joda.time.ReadableDuration) duration32, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant26, (org.joda.time.ReadableDuration) duration32);
        boolean boolean38 = periodType25.equals((java.lang.Object) duration32);
        org.joda.time.PeriodType periodType39 = periodType25.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType41, "PeriodType[YearWeekDay]");
        int int44 = period24.indexOf(durationFieldType41);
        boolean boolean45 = periodType12.isSupported(durationFieldType41);
        int int46 = periodType9.indexOf(durationFieldType41);
        org.joda.time.field.ScaledDurationField scaledDurationField48 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType41, 51);
        int int51 = scaledDurationField48.getDifference(384001000L, (long) 45);
        java.lang.String str52 = scaledDurationField48.getName();
        int int55 = scaledDurationField48.getDifference(584542255L, (long) (byte) -1);
        int int58 = scaledDurationField48.getDifference(0L, 2362985049600064L);
        java.lang.String str59 = scaledDurationField48.getName();
        long long61 = scaledDurationField48.getValueAsLong(64L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.002S" + "'", str18.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "years" + "'", str52.equals("years"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-12870288) + "'", int58 == (-12870288));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "years" + "'", str59.equals("years"));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.Period period4 = new org.joda.time.Period((-33052872), 0, 35, 1439);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Period period6 = period4.plus(readablePeriod5);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) 0);
        org.joda.time.Period period3 = period1.withSeconds((int) (short) 0);
        org.joda.time.Period period5 = period3.minusYears((int) (byte) -1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        int int15 = zeroIsMaxDateTimeField12.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (short) -1);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray26 = new int[] { (byte) 0, (-2), (byte) 0, (short) 10 };
        int int27 = offsetDateTimeField20.getMinimumValue(readablePartial21, intArray26);
        org.joda.time.ReadablePartial readablePartial28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (short) -1);
        long long34 = offsetDateTimeField32.roundCeiling(0L);
        org.joda.time.PeriodType periodType37 = null;
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType37, chronology38);
        java.lang.String str40 = period39.toString();
        org.joda.time.Hours hours41 = period39.toStandardHours();
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) offsetDateTimeField32, (java.lang.Object) period39);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int[] intArray49 = new int[] { (short) 0, (-1), (byte) 100, 0, (byte) 10 };
        int int50 = offsetDateTimeField32.getMaximumValue(readablePartial43, intArray49);
        int int51 = offsetDateTimeField20.getMaximumValue(readablePartial28, intArray49);
        int int52 = zeroIsMaxDateTimeField12.getMinimumValue(readablePartial16, intArray49);
        long long54 = zeroIsMaxDateTimeField12.remainder((long) (byte) 0);
        long long57 = zeroIsMaxDateTimeField12.set(3120000L, 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-292275055) + "'", int27 == (-292275055));
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 31795200000L + "'", long34 == 31795200000L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PT0.002S" + "'", str40.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 292278992 + "'", int50 == 292278992);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 292278992 + "'", int51 == 292278992);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 600000L + "'", long57 == 600000L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PT0S", (int) '4');
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("P4DT240M", true);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        java.lang.String str14 = fixedDateTimeZone12.toString();
        int int16 = fixedDateTimeZone12.getStandardOffset((long) 10);
        java.lang.Object obj17 = null;
        boolean boolean18 = fixedDateTimeZone12.equals(obj17);
        org.joda.time.Chronology chronology19 = iSOChronology7.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        try {
            long long24 = iSOChronology7.getDateTimeMillis((int) (short) 10, 37, (-292275055), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 37 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 888, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 888L + "'", long2 == 888L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        int int8 = fixedDateTimeZone4.getStandardOffset(490950465L);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = offsetDateTimeField3.getAsShortText((long) (short) 100, locale5);
        int int7 = offsetDateTimeField3.getOffset();
        long long10 = offsetDateTimeField3.add(1L, 0);
        boolean boolean11 = offsetDateTimeField3.isLenient();
        long long13 = offsetDateTimeField3.roundFloor((-1728292335055L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1735430400000L) + "'", long13 == (-1735430400000L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        long long17 = zeroIsMaxDateTimeField12.add((long) (-292275055), (-28800001L));
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = gregorianChronology21.millis();
        org.joda.time.DurationField durationField23 = gregorianChronology21.millis();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.minuteOfHour();
        org.joda.time.Period period25 = new org.joda.time.Period(0L, periodType20, (org.joda.time.Chronology) gregorianChronology21);
        int[] intArray26 = period25.getValues();
        int int27 = zeroIsMaxDateTimeField12.getMaximumValue(readablePartial18, intArray26);
        long long29 = zeroIsMaxDateTimeField12.roundHalfEven(0L);
        long long32 = zeroIsMaxDateTimeField12.getDifferenceAsLong((-80194466524L), (-29537222399990L));
        long long34 = zeroIsMaxDateTimeField12.roundHalfEven((-1640817677610637L));
        org.joda.time.DurationField durationField35 = zeroIsMaxDateTimeField12.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1728292335055L) + "'", long17 == (-1728292335055L));
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1440 + "'", int27 == 1440);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 490950465L + "'", long32 == 490950465L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1640817677640000L) + "'", long34 == (-1640817677640000L));
        org.junit.Assert.assertNull(durationField35);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.Period period7 = new org.joda.time.Period(31795200000L, (long) (byte) 0, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.year();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000000116d + "'", double1 == 2440587.5000000116d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        java.lang.String str6 = periodType4.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.DurationField durationField9 = gregorianChronology7.hours();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.secondOfDay();
        org.joda.time.DurationField durationField11 = gregorianChronology7.centuries();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 4, (long) 1440, periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period13 = new org.joda.time.Period(60000L, (long) '#', periodType4);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableInstant18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period19.toDurationTo(readableInstant20);
        long long22 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration21);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withHoursRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant16, (org.joda.time.ReadableDuration) duration21, periodType24);
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant15, (org.joda.time.ReadableDuration) duration21);
        boolean boolean27 = periodType14.equals((java.lang.Object) duration21);
        org.joda.time.PeriodType periodType28 = periodType14.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType30 = periodType28.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(durationFieldType30, "PeriodType[YearWeekDay]");
        int int33 = periodType4.indexOf(durationFieldType30);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[YearWeekDay]" + "'", str6.equals("PeriodType[YearWeekDay]"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.hours();
        java.lang.String str5 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PT0S", (int) '4');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder3.setStandardOffset(0);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder3.toDateTimeZone("", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder3.setFixedSavings("10", (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("4", 32);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder14.setStandardOffset(45);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        boolean boolean5 = offsetDateTimeField3.isLeap(0L);
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText(readablePartial6, 0, locale8);
        long long11 = offsetDateTimeField3.roundCeiling((-44305833600000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-44274643200000L) + "'", long11 == (-44274643200000L));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        long long15 = zeroIsMaxDateTimeField12.add(0L, (int) '4');
        int int17 = zeroIsMaxDateTimeField12.getMinimumValue((long) (-292271120));
        int int19 = zeroIsMaxDateTimeField12.getMinimumValue((long) (-2));
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (short) -1);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int[] intArray30 = new int[] { (byte) 0, (-2), (byte) 0, (short) 10 };
        int int31 = offsetDateTimeField24.getMinimumValue(readablePartial25, intArray30);
        int int32 = zeroIsMaxDateTimeField12.getMinimumValue(readablePartial20, intArray30);
        long long35 = zeroIsMaxDateTimeField12.add((long) (-1048320), 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3120000L + "'", long15 == 3120000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-292275055) + "'", int31 == (-292275055));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-1048320L) + "'", long35 == (-1048320L));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = fixedDateTimeZone4.getOffset(readableInstant6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str11 = cachedDateTimeZone9.getNameKey(0L);
        boolean boolean12 = cachedDateTimeZone9.isFixed();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableInstant14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period15.toDurationTo(readableInstant16);
        int int18 = period15.getDays();
        boolean boolean19 = cachedDateTimeZone9.equals((java.lang.Object) period15);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (byte) -1, chronology1);
        org.joda.time.Period period4 = period2.multipliedBy(2);
        org.joda.time.Period period9 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.Period period11 = period9.minusMillis(0);
        org.joda.time.Period period13 = period11.withHours(0);
        org.joda.time.Period period15 = period13.withMonths(0);
        org.joda.time.Period period17 = period15.withMillis(0);
        org.joda.time.Period period19 = period15.withWeeks((-1));
        org.joda.time.Period period20 = period2.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period22 = period20.plusMillis((int) (byte) 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        org.joda.time.DurationField durationField8 = unsupportedDateTimeField7.getLeapDurationField();
        long long11 = unsupportedDateTimeField7.add((long) (-5620637), (-1640817671990L));
        org.joda.time.DurationField durationField12 = unsupportedDateTimeField7.getLeapDurationField();
        try {
            int int14 = unsupportedDateTimeField7.getMinimumValue((-31741875055L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1640817677610637L) + "'", long11 == (-1640817677610637L));
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.hours();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(0, (int) 'a', 0, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.Period period1 = org.joda.time.Period.parse("P4DT240M");
        org.joda.time.Period period3 = period1.withSeconds((-292275055));
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period7.toDurationTo(readableInstant8);
        org.joda.time.Period period11 = period7.plusHours((int) (short) 100);
        org.joda.time.Period period13 = period11.plusHours(0);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType15 = periodType14.withWeeksRemoved();
        org.joda.time.Period period16 = period13.normalizedStandard(periodType14);
        org.joda.time.Duration duration17 = period16.toStandardDuration();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant4, (org.joda.time.ReadableDuration) duration17);
        org.joda.time.Period period19 = period18.negated();
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.time();
        org.joda.time.Period period23 = new org.joda.time.Period((long) 1439, 164127892275055L, periodType22);
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType25 = periodType24.withHoursRemoved();
        org.joda.time.PeriodType periodType28 = null;
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType28, chronology29);
        java.lang.String str31 = period30.toString();
        org.joda.time.Hours hours32 = period30.toStandardHours();
        org.joda.time.Period period34 = period30.plusMonths((int) ' ');
        int int35 = period30.getMillis();
        org.joda.time.Period period37 = period30.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period(readableInstant41, readableInstant42);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.Duration duration45 = period43.toDurationTo(readableInstant44);
        long long46 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration45);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType48 = periodType47.withHoursRemoved();
        org.joda.time.Period period49 = new org.joda.time.Period(readableInstant40, (org.joda.time.ReadableDuration) duration45, periodType48);
        org.joda.time.Period period50 = new org.joda.time.Period(readableInstant39, (org.joda.time.ReadableDuration) duration45);
        boolean boolean51 = periodType38.equals((java.lang.Object) duration45);
        org.joda.time.PeriodType periodType52 = periodType38.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType54 = periodType52.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(durationFieldType54, "PeriodType[YearWeekDay]");
        int int57 = period37.indexOf(durationFieldType54);
        boolean boolean58 = periodType25.isSupported(durationFieldType54);
        int int59 = periodType22.indexOf(durationFieldType54);
        boolean boolean60 = period18.isSupported(durationFieldType54);
        int int61 = period3.get(durationFieldType54);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PT0.002S" + "'", str31.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(duration45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(durationFieldType54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.year();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (short) -1);
        long long10 = offsetDateTimeField8.roundCeiling(0L);
        org.joda.time.DurationField durationField11 = offsetDateTimeField8.getDurationField();
        org.joda.time.DurationField durationField12 = offsetDateTimeField8.getDurationField();
        org.joda.time.DurationField durationField13 = offsetDateTimeField8.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField17.getType();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = iSOChronology19.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField20);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType18, (int) '4');
        org.joda.time.DurationField durationField24 = dividedDateTimeField23.getDurationField();
        int int25 = dividedDateTimeField23.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField29.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, "weekyear");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23, dateTimeFieldType30);
        boolean boolean34 = iSOChronology1.equals((java.lang.Object) dividedDateTimeField23);
        long long36 = dividedDateTimeField23.roundFloor((long) (-1048));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 31795200000L + "'", long10 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5620749 + "'", int25 == 5620749);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1420329600000L) + "'", long36 == (-1420329600000L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.Period period1 = org.joda.time.Period.millis((-5620637));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-12870288), (long) 893638);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-11501378427744L) + "'", long2 == (-11501378427744L));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(52);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        java.lang.String str8 = offsetDateTimeField3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DateTimeField[weekyear]" + "'", str8.equals("DateTimeField[weekyear]"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField15);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (int) '4');
        org.joda.time.DurationField durationField19 = dividedDateTimeField18.getDurationField();
        int int20 = dividedDateTimeField18.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField24.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "weekyear");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField18, dateTimeFieldType25);
        int int29 = dividedDateTimeField18.getMaximumValue();
        long long32 = dividedDateTimeField18.set((-31455220675L), 3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5620749 + "'", int20 == 5620749);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 5620749 + "'", int29 == 5620749);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-55824255220675L) + "'", long32 == (-55824255220675L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.010 (UnsupportedDateTimeField)", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.010 (UnsupportedDateTimeField)/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("weekyear");
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType2, chronology3);
        java.lang.String str5 = period4.toString();
        org.joda.time.Hours hours6 = period4.toStandardHours();
        org.joda.time.Period period8 = period4.plusMonths((int) ' ');
        int int9 = period8.getMinutes();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0.002S" + "'", str5.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str6 = fixedDateTimeZone4.toString();
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 10);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey((long) 9);
        int int12 = fixedDateTimeZone4.getStandardOffset((long) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        int int15 = zeroIsMaxDateTimeField12.getMinimumValue();
        org.joda.time.DurationField durationField16 = zeroIsMaxDateTimeField12.getLeapDurationField();
        long long19 = zeroIsMaxDateTimeField12.add((-259200000L), (int) (short) -1);
        int int21 = zeroIsMaxDateTimeField12.getMinimumValue(292260000L);
        long long23 = zeroIsMaxDateTimeField12.roundHalfEven((-31741875055L));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259260000L) + "'", long19 == (-259260000L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-31741860000L) + "'", long23 == (-31741860000L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        int int16 = zeroIsMaxDateTimeField12.get(64L);
        org.joda.time.DurationField durationField17 = zeroIsMaxDateTimeField12.getLeapDurationField();
        java.util.Locale locale18 = null;
        int int19 = zeroIsMaxDateTimeField12.getMaximumShortTextLength(locale18);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.Period period23 = new org.joda.time.Period((long) 32, periodType21);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField25 = iSOChronology24.seconds();
        long long29 = iSOChronology24.add(0L, (-1L), (int) (short) -1);
        org.joda.time.Period period31 = org.joda.time.Period.parse("P4DT240M");
        org.joda.time.Period period33 = period31.withMillis((int) (byte) 100);
        org.joda.time.PeriodType periodType36 = null;
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType36, chronology37);
        java.lang.String str39 = period38.toString();
        org.joda.time.Period period41 = period38.withWeeks((int) (byte) 10);
        org.joda.time.Period period42 = period33.minus((org.joda.time.ReadablePeriod) period38);
        boolean boolean43 = iSOChronology24.equals((java.lang.Object) period33);
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology24.clockhourOfHalfday();
        try {
            org.joda.time.Period period45 = new org.joda.time.Period((java.lang.Object) zeroIsMaxDateTimeField12, periodType21, (org.joda.time.Chronology) iSOChronology24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.ZeroIsMaxDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1440 + "'", int16 == 1440);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PT0.002S" + "'", str39.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dateTimeField44);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.util.Set<java.lang.String> strSet5 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean6 = zonedChronology4.equals((java.lang.Object) strSet5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.Chronology chronology9 = zonedChronology4.withZone(dateTimeZone8);
        org.joda.time.Period period14 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.Period period16 = period14.minusMillis(0);
        org.joda.time.Period period18 = period16.withHours(0);
        org.joda.time.Period period20 = period18.minusHours(0);
        org.joda.time.Period period22 = period20.plusMonths((int) (byte) 1);
        boolean boolean23 = zonedChronology4.equals((java.lang.Object) (byte) 1);
        org.joda.time.DurationField durationField24 = zonedChronology4.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        boolean boolean5 = offsetDateTimeField3.isLeap(0L);
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText(readablePartial6, 0, locale8);
        int int12 = offsetDateTimeField3.getDifference((-9223309881273600000L), 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292275055) + "'", int12 == (-292275055));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        int int15 = zeroIsMaxDateTimeField12.getMinimumValue();
        long long18 = zeroIsMaxDateTimeField12.set(3120000L, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = zeroIsMaxDateTimeField12.getType();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 60000L + "'", long18 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField15);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (int) '4');
        org.joda.time.DurationField durationField19 = dividedDateTimeField18.getDurationField();
        int int20 = dividedDateTimeField18.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField24.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "weekyear");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField18, dateTimeFieldType25);
        long long30 = remainderDateTimeField28.roundFloor((-80194466524L));
        int int31 = remainderDateTimeField28.getMaximumValue();
        long long34 = remainderDateTimeField28.add((long) (byte) 0, (long) (byte) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5620749 + "'", int20 == 5620749);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-94608000000L) + "'", long30 == (-94608000000L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 51 + "'", int31 == 51);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.centuryOfEra();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(31795200000L, 5, 0, (-1), 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.withDays((int) '4');
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType8 = periodType7.withSecondsRemoved();
        java.lang.String str9 = periodType7.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.weekyear();
        org.joda.time.DurationField durationField12 = gregorianChronology10.hours();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.secondOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology10.centuries();
        org.joda.time.Period period15 = new org.joda.time.Period((long) 4, (long) 1440, periodType7, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.Period period16 = period4.normalizedStandard(periodType7);
        org.joda.time.PeriodType periodType17 = periodType7.withMonthsRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType19 = periodType17.getFieldType(4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PeriodType[YearWeekDay]" + "'", str9.equals("PeriodType[YearWeekDay]"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.hours();
        org.joda.time.Chronology chronology5 = gregorianChronology0.withUTC();
        long long9 = gregorianChronology0.add(153721833456959L, 0L, 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 153721833456959L + "'", long9 == 153721833456959L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant6, readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        long long11 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType13 = periodType12.withHoursRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant5, (org.joda.time.ReadableDuration) duration10, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant4, (org.joda.time.ReadableDuration) duration10);
        boolean boolean16 = periodType3.equals((java.lang.Object) duration10);
        org.joda.time.PeriodType periodType17 = periodType3.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType19 = periodType17.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField20 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long27 = gregorianChronology21.getDateTimeMillis((long) 100, (int) (short) 10, 0, 1, (int) (short) 10);
        org.joda.time.DurationField durationField28 = gregorianChronology21.eras();
        int int29 = decoratedDurationField20.compareTo(durationField28);
        try {
            int int32 = decoratedDurationField20.getDifference(164127892275055L, 292278991L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 164127599996064");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 36001010L + "'", long27 == 36001010L);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        org.joda.time.DurationField durationField8 = unsupportedDateTimeField7.getLeapDurationField();
        long long11 = unsupportedDateTimeField7.add((long) 'a', 0L);
        try {
            long long13 = unsupportedDateTimeField7.roundHalfEven(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        org.joda.time.DurationField durationField8 = unsupportedDateTimeField7.getLeapDurationField();
        long long11 = unsupportedDateTimeField7.add((long) (-5620637), (-1640817671990L));
        org.joda.time.DurationField durationField12 = unsupportedDateTimeField7.getLeapDurationField();
        boolean boolean13 = unsupportedDateTimeField7.isLenient();
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField19 = gregorianChronology18.millis();
        org.joda.time.DurationField durationField20 = gregorianChronology18.millis();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.minuteOfHour();
        org.joda.time.Period period22 = new org.joda.time.Period(0L, periodType17, (org.joda.time.Chronology) gregorianChronology18);
        int[] intArray23 = period22.getValues();
        try {
            int[] intArray25 = unsupportedDateTimeField7.addWrapField(readablePartial14, (int) (short) 10, intArray23, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1640817677610637L) + "'", long11 == (-1640817677610637L));
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = gregorianChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) gregorianChronology1);
        org.joda.time.DurationField durationField5 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.seconds();
        long long5 = iSOChronology0.add(0L, (-1L), (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.ReadablePartial readablePartial4 = null;
        int[] intArray9 = new int[] { (byte) 0, (-2), (byte) 0, (short) 10 };
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial4, intArray9);
        long long13 = offsetDateTimeField3.add(1009723728880L, (-4714));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292275055) + "'", int10 == (-292275055));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-147749908271120L) + "'", long13 == (-147749908271120L));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        org.joda.time.DurationField durationField8 = unsupportedDateTimeField7.getLeapDurationField();
        java.util.Locale locale11 = null;
        try {
            long long12 = unsupportedDateTimeField7.set(64L, "910", locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertNull(durationField8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationTo(readableInstant11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType15 = periodType14.withHoursRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant7, (org.joda.time.ReadableDuration) duration12, periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant6, (org.joda.time.ReadableDuration) duration12);
        boolean boolean18 = periodType5.equals((java.lang.Object) duration12);
        org.joda.time.PeriodType periodType19 = periodType5.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType21, "PeriodType[YearWeekDay]");
        boolean boolean24 = period2.isSupported(durationFieldType21);
        org.joda.time.field.PreciseDurationField preciseDurationField26 = new org.joda.time.field.PreciseDurationField(durationFieldType21, 60000L);
        long long29 = preciseDurationField26.getDifferenceAsLong(551478992L, 292260000L);
        long long30 = preciseDurationField26.getUnitMillis();
        long long33 = preciseDurationField26.getValueAsLong((-55824255220675L), 259200100L);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4320L + "'", long29 == 4320L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 60000L + "'", long30 == 60000L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-930404253L) + "'", long33 == (-930404253L));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = zeroIsMaxDateTimeField12.getMaximumValue(readablePartial15);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = zeroIsMaxDateTimeField12.getMinimumValue(readablePartial17);
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = zeroIsMaxDateTimeField12.getMaximumValue(readablePartial19);
        long long23 = zeroIsMaxDateTimeField12.add(3264L, (-5620675));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1440 + "'", int16 == 1440);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1440 + "'", int20 == 1440);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-337240496736L) + "'", long23 == (-337240496736L));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        int int10 = unsupportedDateTimeField7.getDifference((long) 292278992, (long) (-292275055));
        try {
            int int12 = unsupportedDateTimeField7.getMinimumValue((-29537222399990L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 584554 + "'", int10 == 584554);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        int int15 = zeroIsMaxDateTimeField12.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = zeroIsMaxDateTimeField12.getMinimumValue(readablePartial16);
        long long20 = zeroIsMaxDateTimeField12.add((-27346961293L), 9);
        int int21 = zeroIsMaxDateTimeField12.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-27346421293L) + "'", long20 == (-27346421293L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1440 + "'", int21 == 1440);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.year();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.weekyear();
        org.joda.time.DurationField durationField6 = iSOChronology1.centuries();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Period period6 = period2.plusHours((int) (short) 100);
        org.joda.time.Period period8 = period6.plusHours(0);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType10 = periodType9.withWeeksRemoved();
        org.joda.time.Period period11 = period8.normalizedStandard(periodType9);
        org.joda.time.Duration duration12 = period11.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant13, periodType14);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField6 = gregorianChronology0.hours();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.time();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 1439, 164127892275055L, periodType9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType15, chronology16);
        java.lang.String str18 = period17.toString();
        org.joda.time.Hours hours19 = period17.toStandardHours();
        org.joda.time.Period period21 = period17.plusMonths((int) ' ');
        int int22 = period17.getMillis();
        org.joda.time.Period period24 = period17.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period30.toDurationTo(readableInstant31);
        long long33 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType35 = periodType34.withHoursRemoved();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant27, (org.joda.time.ReadableDuration) duration32, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant26, (org.joda.time.ReadableDuration) duration32);
        boolean boolean38 = periodType25.equals((java.lang.Object) duration32);
        org.joda.time.PeriodType periodType39 = periodType25.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType41, "PeriodType[YearWeekDay]");
        int int44 = period24.indexOf(durationFieldType41);
        boolean boolean45 = periodType12.isSupported(durationFieldType41);
        int int46 = periodType9.indexOf(durationFieldType41);
        org.joda.time.field.ScaledDurationField scaledDurationField48 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType41, 51);
        long long51 = scaledDurationField48.add((-1420070400000L), (long) (-292271120));
        int int53 = scaledDurationField48.getValue((long) 0);
        long long56 = scaledDurationField48.getValueAsLong(3155846400000L, 12L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.002S" + "'", str18.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-53662397702400000L) + "'", long51 == (-53662397702400000L));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 17188L + "'", long56 == 17188L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getName();
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(permissionCollection4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.Period period4 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.Period period6 = period4.minusMillis(0);
        org.joda.time.Period period8 = period6.withHours(0);
        org.joda.time.Period period10 = period8.withMonths(0);
        org.joda.time.Period period12 = period10.withMillis(0);
        org.joda.time.Period period14 = period12.multipliedBy(0);
        org.joda.time.Period period16 = period14.minusMonths((int) (byte) 100);
        org.joda.time.Period period17 = period14.negated();
        org.joda.time.Period period19 = period14.plusHours((-292275055));
        org.joda.time.Period period21 = period14.minusHours(1439);
        org.joda.time.Period period23 = period14.plusYears(893638);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        boolean boolean8 = unsupportedDateTimeField7.isSupported();
        long long11 = unsupportedDateTimeField7.getDifferenceAsLong((long) 64, 0L);
        org.joda.time.DurationField durationField12 = unsupportedDateTimeField7.getRangeDurationField();
        try {
            int int13 = unsupportedDateTimeField7.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        org.joda.time.DurationField durationField13 = zeroIsMaxDateTimeField12.getLeapDurationField();
        boolean boolean14 = zeroIsMaxDateTimeField12.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.Period period4 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.Period period6 = period4.minusMillis(0);
        org.joda.time.Period period8 = period6.withHours(0);
        org.joda.time.Period period10 = period8.withMonths(0);
        org.joda.time.Period period12 = period10.withMillis(0);
        org.joda.time.Period period14 = period12.multipliedBy(0);
        org.joda.time.Period period16 = period14.minusMonths((int) (byte) 100);
        org.joda.time.Period period18 = period16.minusMillis(2);
        org.joda.time.PeriodType periodType21 = null;
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType21, chronology22);
        java.lang.String str24 = period23.toString();
        org.joda.time.Hours hours25 = period23.toStandardHours();
        org.joda.time.Period period27 = period23.plusMonths((int) ' ');
        int int28 = period23.getMillis();
        org.joda.time.Period period30 = period23.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant34, readableInstant35);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Duration duration38 = period36.toDurationTo(readableInstant37);
        long long39 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration38);
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType41 = periodType40.withHoursRemoved();
        org.joda.time.Period period42 = new org.joda.time.Period(readableInstant33, (org.joda.time.ReadableDuration) duration38, periodType41);
        org.joda.time.Period period43 = new org.joda.time.Period(readableInstant32, (org.joda.time.ReadableDuration) duration38);
        boolean boolean44 = periodType31.equals((java.lang.Object) duration38);
        org.joda.time.PeriodType periodType45 = periodType31.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType47 = periodType45.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(durationFieldType47, "PeriodType[YearWeekDay]");
        int int50 = period30.indexOf(durationFieldType47);
        int int51 = period16.get(durationFieldType47);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PT0.002S" + "'", str24.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(duration38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(durationFieldType47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField6 = gregorianChronology0.hours();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.time();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 1439, 164127892275055L, periodType9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType15, chronology16);
        java.lang.String str18 = period17.toString();
        org.joda.time.Hours hours19 = period17.toStandardHours();
        org.joda.time.Period period21 = period17.plusMonths((int) ' ');
        int int22 = period17.getMillis();
        org.joda.time.Period period24 = period17.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period30.toDurationTo(readableInstant31);
        long long33 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType35 = periodType34.withHoursRemoved();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant27, (org.joda.time.ReadableDuration) duration32, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant26, (org.joda.time.ReadableDuration) duration32);
        boolean boolean38 = periodType25.equals((java.lang.Object) duration32);
        org.joda.time.PeriodType periodType39 = periodType25.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType41, "PeriodType[YearWeekDay]");
        int int44 = period24.indexOf(durationFieldType41);
        boolean boolean45 = periodType12.isSupported(durationFieldType41);
        int int46 = periodType9.indexOf(durationFieldType41);
        org.joda.time.field.ScaledDurationField scaledDurationField48 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType41, 51);
        int int51 = scaledDurationField48.getDifference(384001000L, (long) 45);
        java.lang.String str52 = scaledDurationField48.getName();
        int int55 = scaledDurationField48.getDifference(584542255L, (long) (byte) -1);
        int int58 = scaledDurationField48.getDifference(0L, 2362985049600064L);
        java.lang.String str59 = scaledDurationField48.getName();
        long long62 = scaledDurationField48.getDifferenceAsLong((long) (-259199997), (long) (-12870288));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.002S" + "'", str18.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "years" + "'", str52.equals("years"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-12870288) + "'", int58 == (-12870288));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "years" + "'", str59.equals("years"));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-1L) + "'", long62 == (-1L));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.util.Set<java.lang.String> strSet5 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean6 = zonedChronology4.equals((java.lang.Object) strSet5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.Chronology chronology9 = zonedChronology4.withZone(dateTimeZone8);
        org.joda.time.Period period14 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.Period period16 = period14.minusMillis(0);
        org.joda.time.Period period18 = period16.withHours(0);
        org.joda.time.Period period20 = period18.minusHours(0);
        org.joda.time.Period period22 = period20.plusMonths((int) (byte) 1);
        boolean boolean23 = zonedChronology4.equals((java.lang.Object) (byte) 1);
        org.joda.time.DurationField durationField24 = zonedChronology4.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "64");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        long long17 = zeroIsMaxDateTimeField12.add((long) (-292275055), (-28800001L));
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = gregorianChronology21.millis();
        org.joda.time.DurationField durationField23 = gregorianChronology21.millis();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.minuteOfHour();
        org.joda.time.Period period25 = new org.joda.time.Period(0L, periodType20, (org.joda.time.Chronology) gregorianChronology21);
        int[] intArray26 = period25.getValues();
        int int27 = zeroIsMaxDateTimeField12.getMaximumValue(readablePartial18, intArray26);
        long long29 = zeroIsMaxDateTimeField12.roundHalfEven(0L);
        long long32 = zeroIsMaxDateTimeField12.getDifferenceAsLong((-80194466524L), (-29537222399990L));
        long long35 = zeroIsMaxDateTimeField12.add((-29537222399991L), 0L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (short) -1);
        long long43 = offsetDateTimeField41.roundCeiling(0L);
        org.joda.time.PeriodType periodType46 = null;
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.Period period48 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType46, chronology47);
        java.lang.String str49 = period48.toString();
        org.joda.time.Hours hours50 = period48.toStandardHours();
        boolean boolean51 = org.joda.time.field.FieldUtils.equals((java.lang.Object) offsetDateTimeField41, (java.lang.Object) period48);
        org.joda.time.ReadablePartial readablePartial52 = null;
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField56 = gregorianChronology55.millis();
        org.joda.time.DurationField durationField57 = gregorianChronology55.millis();
        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology55.minuteOfHour();
        org.joda.time.Period period59 = new org.joda.time.Period(0L, periodType54, (org.joda.time.Chronology) gregorianChronology55);
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.Period period62 = new org.joda.time.Period(readableInstant60, readableInstant61);
        org.joda.time.Period period64 = period62.withDays((int) '4');
        org.joda.time.PeriodType periodType67 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType68 = periodType67.withSecondsRemoved();
        java.lang.String str69 = periodType67.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology70.weekyear();
        org.joda.time.DurationField durationField72 = gregorianChronology70.hours();
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology70.secondOfDay();
        org.joda.time.DurationField durationField74 = gregorianChronology70.centuries();
        org.joda.time.Period period75 = new org.joda.time.Period((long) 4, (long) 1440, periodType67, (org.joda.time.Chronology) gregorianChronology70);
        org.joda.time.Period period76 = period64.normalizedStandard(periodType67);
        int[] intArray78 = gregorianChronology55.get((org.joda.time.ReadablePeriod) period64, 0L);
        int int79 = offsetDateTimeField41.getMaximumValue(readablePartial52, intArray78);
        try {
            int[] intArray81 = zeroIsMaxDateTimeField12.add(readablePartial36, (int) (short) 10, intArray78, (-63));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1728292335055L) + "'", long17 == (-1728292335055L));
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1440 + "'", int27 == 1440);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 490950465L + "'", long32 == 490950465L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-29537222399991L) + "'", long35 == (-29537222399991L));
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 31795200000L + "'", long43 == 31795200000L);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "PT0.002S" + "'", str49.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertNotNull(periodType67);
        org.junit.Assert.assertNotNull(periodType68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "PeriodType[YearWeekDay]" + "'", str69.equals("PeriodType[YearWeekDay]"));
        org.junit.Assert.assertNotNull(gregorianChronology70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(durationField74);
        org.junit.Assert.assertNotNull(period76);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 292278992 + "'", int79 == 292278992);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = fixedDateTimeZone4.getOffset(readableInstant6);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        long long11 = fixedDateTimeZone4.previousTransition((-9223309975622399998L));
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime12);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9223309975622399998L) + "'", long11 == (-9223309975622399998L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 1);
        org.joda.time.Period period3 = period1.plusMonths(64);
        try {
            org.joda.time.Duration duration4 = period3.toStandardDuration();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Duration as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        java.util.Locale locale5 = null;
        java.lang.String str6 = offsetDateTimeField3.getAsShortText((long) (short) 100, locale5);
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNull(durationField7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType2, chronology3);
        org.joda.time.Period period6 = period4.withSeconds((int) (short) 10);
        org.joda.time.Period period8 = period4.plusMinutes(8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType3 = periodType0.withWeeksRemoved();
        java.lang.String str4 = periodType3.toString();
        java.lang.String str5 = periodType3.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PeriodType[YearWeekDayTimeNoWeeks]" + "'", str4.equals("PeriodType[YearWeekDayTimeNoWeeks]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PeriodType[YearWeekDayTimeNoWeeks]" + "'", str5.equals("PeriodType[YearWeekDayTimeNoWeeks]"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        long long10 = unsupportedDateTimeField7.getDifferenceAsLong((long) 1439, (-31455220675L));
        java.lang.String str11 = unsupportedDateTimeField7.getName();
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = unsupportedDateTimeField7.getAsText(32L, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 31455222L + "'", long10 == 31455222L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "weekyear" + "'", str11.equals("weekyear"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField15);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (int) '4');
        org.joda.time.DurationField durationField19 = dividedDateTimeField18.getDurationField();
        int int20 = dividedDateTimeField18.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField24.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "weekyear");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField18, dateTimeFieldType25);
        long long30 = dividedDateTimeField18.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5620749 + "'", int20 == 5620749);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 221097600000L + "'", long30 == 221097600000L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        java.lang.String str6 = offsetDateTimeField3.getAsShortText((long) (short) 10);
        long long8 = offsetDateTimeField3.roundFloor((long) 'a');
        long long11 = offsetDateTimeField3.addWrapField(0L, (-292275055));
        long long13 = offsetDateTimeField3.roundHalfCeiling(384000990L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-259200000L) + "'", long8 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9223309881273600000L) + "'", long11 == (-9223309881273600000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = zonedChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = zonedChronology4.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology4.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT-0.001S", "", 1, (int) (short) 100);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 'a', locale6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str11 = dateTimeZone9.getName((-865490400000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.001" + "'", str7.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) 'a');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationTo(readableInstant11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType15 = periodType14.withHoursRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant7, (org.joda.time.ReadableDuration) duration12, periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant6, (org.joda.time.ReadableDuration) duration12);
        boolean boolean18 = periodType5.equals((java.lang.Object) duration12);
        org.joda.time.PeriodType periodType19 = periodType5.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType21, "PeriodType[YearWeekDay]");
        boolean boolean24 = period2.isSupported(durationFieldType21);
        org.joda.time.field.PreciseDurationField preciseDurationField26 = new org.joda.time.field.PreciseDurationField(durationFieldType21, 60000L);
        long long29 = preciseDurationField26.getDifferenceAsLong(551478992L, 292260000L);
        long long32 = preciseDurationField26.getDifferenceAsLong((-31455220675L), (long) 102);
        long long35 = preciseDurationField26.add(2440587999L, 64L);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField37 = gregorianChronology36.millis();
        org.joda.time.DurationField durationField38 = gregorianChronology36.millis();
        int int39 = preciseDurationField26.compareTo(durationField38);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.centuryOfEra();
        org.joda.time.DurationField durationField42 = iSOChronology40.weeks();
        int int43 = preciseDurationField26.compareTo(durationField42);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4320L + "'", long29 == 4320L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-524253L) + "'", long32 == (-524253L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2444427999L + "'", long35 == 2444427999L);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.joda.time.Period period1 = org.joda.time.Period.months((-292271120));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.util.Set<java.lang.String> strSet5 = org.joda.time.DateTimeZone.getAvailableIDs();
        boolean boolean6 = zonedChronology4.equals((java.lang.Object) strSet5);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology4.millisOfSecond();
        org.joda.time.DurationField durationField8 = zonedChronology4.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        int int10 = unsupportedDateTimeField7.getDifference((long) 292278992, (long) (-292275055));
        try {
            int int12 = unsupportedDateTimeField7.getMaximumValue((long) (-4714));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 584554 + "'", int10 == 584554);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = offsetDateTimeField3.getAsText(readablePartial8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getName(locale2, "Pacific Standard Time", "P4DT240M");
        java.lang.Class<?> wildcardClass6 = defaultNameProvider0.getClass();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = fixedDateTimeZone4.getOffset(readableInstant6);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        long long11 = fixedDateTimeZone4.nextTransition(1641201672990L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1641201672990L + "'", long11 == 1641201672990L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField15);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (int) '4');
        try {
            long long21 = dividedDateTimeField18.set((-28800001L), 597649218);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 597649218 for weekyear must be in the range [-5620675,5620749]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField6 = gregorianChronology0.hours();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.time();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 1439, 164127892275055L, periodType9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType15, chronology16);
        java.lang.String str18 = period17.toString();
        org.joda.time.Hours hours19 = period17.toStandardHours();
        org.joda.time.Period period21 = period17.plusMonths((int) ' ');
        int int22 = period17.getMillis();
        org.joda.time.Period period24 = period17.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period30.toDurationTo(readableInstant31);
        long long33 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType35 = periodType34.withHoursRemoved();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant27, (org.joda.time.ReadableDuration) duration32, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant26, (org.joda.time.ReadableDuration) duration32);
        boolean boolean38 = periodType25.equals((java.lang.Object) duration32);
        org.joda.time.PeriodType periodType39 = periodType25.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType41, "PeriodType[YearWeekDay]");
        int int44 = period24.indexOf(durationFieldType41);
        boolean boolean45 = periodType12.isSupported(durationFieldType41);
        int int46 = periodType9.indexOf(durationFieldType41);
        org.joda.time.field.ScaledDurationField scaledDurationField48 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType41, 51);
        long long49 = scaledDurationField48.getUnitMillis();
        long long52 = scaledDurationField48.getDifferenceAsLong(3840010L, (long) 45);
        long long55 = scaledDurationField48.getValueAsLong((long) 19, (-315997875055L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.002S" + "'", str18.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 183600000L + "'", long49 == 183600000L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.joda.time.Period period4 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.Period period6 = period4.minusMillis(0);
        org.joda.time.Period period8 = period6.withHours(0);
        org.joda.time.Period period10 = period8.minusHours(0);
        org.joda.time.Period period12 = period10.plusMonths((int) (byte) 1);
        int int13 = period10.getMonths();
        org.joda.time.Period period15 = period10.withMillis(19);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period10.isSupported(durationFieldType16);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Period period6 = period2.plusHours((int) (short) 100);
        org.joda.time.Period period8 = period2.plusMillis((int) 'a');
        int int9 = period2.getMonths();
        org.joda.time.Period period11 = period2.plusMinutes(35);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField6 = gregorianChronology0.hours();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.time();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 1439, 164127892275055L, periodType9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType15, chronology16);
        java.lang.String str18 = period17.toString();
        org.joda.time.Hours hours19 = period17.toStandardHours();
        org.joda.time.Period period21 = period17.plusMonths((int) ' ');
        int int22 = period17.getMillis();
        org.joda.time.Period period24 = period17.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period30.toDurationTo(readableInstant31);
        long long33 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType35 = periodType34.withHoursRemoved();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant27, (org.joda.time.ReadableDuration) duration32, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant26, (org.joda.time.ReadableDuration) duration32);
        boolean boolean38 = periodType25.equals((java.lang.Object) duration32);
        org.joda.time.PeriodType periodType39 = periodType25.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType41, "PeriodType[YearWeekDay]");
        int int44 = period24.indexOf(durationFieldType41);
        boolean boolean45 = periodType12.isSupported(durationFieldType41);
        int int46 = periodType9.indexOf(durationFieldType41);
        org.joda.time.field.ScaledDurationField scaledDurationField48 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType41, 51);
        int int51 = scaledDurationField48.getDifference(384001000L, (long) 45);
        int int53 = scaledDurationField48.getValue(584542254L);
        long long54 = scaledDurationField48.getUnitMillis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.002S" + "'", str18.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 3 + "'", int53 == 3);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 183600000L + "'", long54 == 183600000L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply((-60715267724253L), 292278992);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -60715267724253 * 292278992");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-259200000L), (-2019427200001L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -259200000 * -2019427200001");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 37, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        int int16 = zeroIsMaxDateTimeField12.get(64L);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "org.joda.time.IllegalFieldValueException: Value 1.0 for PT0.002S must be in the range [-1.0,10]");
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField25 = gregorianChronology24.millis();
        long long28 = durationField25.subtract((long) 100, (long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (short) -1);
        long long34 = offsetDateTimeField32.roundCeiling(0L);
        org.joda.time.DurationField durationField35 = offsetDateTimeField32.getDurationField();
        org.joda.time.DurationField durationField36 = offsetDateTimeField32.getDurationField();
        org.joda.time.DurationField durationField37 = offsetDateTimeField32.getRangeDurationField();
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField32.getAsShortText(64, locale39);
        org.joda.time.DurationField durationField41 = offsetDateTimeField32.getLeapDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField42 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType21, durationField25, durationField41);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField12, dateTimeFieldType21, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1440 + "'", int16 == 1440);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 99L + "'", long28 == 99L);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 31795200000L + "'", long34 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "64" + "'", str40.equals("64"));
        org.junit.Assert.assertNotNull(durationField41);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = zeroIsMaxDateTimeField12.getMaximumValue(1560628033476L);
        int int15 = zeroIsMaxDateTimeField12.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (short) -1);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray26 = new int[] { (byte) 0, (-2), (byte) 0, (short) 10 };
        int int27 = offsetDateTimeField20.getMinimumValue(readablePartial21, intArray26);
        org.joda.time.ReadablePartial readablePartial28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (short) -1);
        long long34 = offsetDateTimeField32.roundCeiling(0L);
        org.joda.time.PeriodType periodType37 = null;
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType37, chronology38);
        java.lang.String str40 = period39.toString();
        org.joda.time.Hours hours41 = period39.toStandardHours();
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) offsetDateTimeField32, (java.lang.Object) period39);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int[] intArray49 = new int[] { (short) 0, (-1), (byte) 100, 0, (byte) 10 };
        int int50 = offsetDateTimeField32.getMaximumValue(readablePartial43, intArray49);
        int int51 = offsetDateTimeField20.getMaximumValue(readablePartial28, intArray49);
        int int52 = zeroIsMaxDateTimeField12.getMinimumValue(readablePartial16, intArray49);
        int int54 = zeroIsMaxDateTimeField12.getMinimumValue((-62135369395200L));
        long long56 = zeroIsMaxDateTimeField12.roundFloor(97L);
        long long58 = zeroIsMaxDateTimeField12.roundHalfCeiling((long) 3);
        org.joda.time.ReadablePartial readablePartial59 = null;
        int int60 = zeroIsMaxDateTimeField12.getMinimumValue(readablePartial59);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1440 + "'", int14 == 1440);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-292275055) + "'", int27 == (-292275055));
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 31795200000L + "'", long34 == 31795200000L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PT0.002S" + "'", str40.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 292278992 + "'", int50 == 292278992);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 292278992 + "'", int51 == 292278992);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = fixedDateTimeZone4.getOffset(readableInstant6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.Period period14 = new org.joda.time.Period((int) ' ', (int) '#', 0, 0);
        org.joda.time.Period period16 = period14.minusMillis(0);
        int int17 = period16.getMonths();
        boolean boolean18 = cachedDateTimeZone9.equals((java.lang.Object) period16);
        long long20 = cachedDateTimeZone9.previousTransition(164096150400001L);
        long long22 = cachedDateTimeZone9.nextTransition((-27346961293L));
        int int24 = cachedDateTimeZone9.getOffset(0L);
        int int26 = cachedDateTimeZone9.getStandardOffset(0L);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant27, readableInstant28);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Duration duration31 = period29.toDurationTo(readableInstant30);
        org.joda.time.Period period33 = period29.plusHours((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant35, readableInstant36);
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.Duration duration39 = period37.toDurationTo(readableInstant38);
        org.joda.time.Period period40 = new org.joda.time.Period(readableInstant34, (org.joda.time.ReadableDuration) duration39);
        org.joda.time.Period period41 = period33.withFields((org.joda.time.ReadablePeriod) period40);
        int int42 = period41.getWeeks();
        boolean boolean43 = cachedDateTimeZone9.equals((java.lang.Object) int42);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 164096150400001L + "'", long20 == 164096150400001L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-27346961293L) + "'", long22 == (-27346961293L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertNotNull(duration31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(duration39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationTo(readableInstant11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType15 = periodType14.withHoursRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant7, (org.joda.time.ReadableDuration) duration12, periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant6, (org.joda.time.ReadableDuration) duration12);
        boolean boolean18 = periodType5.equals((java.lang.Object) duration12);
        org.joda.time.PeriodType periodType19 = periodType5.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType21 = periodType19.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType21, "PeriodType[YearWeekDay]");
        boolean boolean24 = period2.isSupported(durationFieldType21);
        org.joda.time.field.PreciseDurationField preciseDurationField26 = new org.joda.time.field.PreciseDurationField(durationFieldType21, 60000L);
        long long29 = preciseDurationField26.getDifferenceAsLong(551478992L, 292260000L);
        boolean boolean30 = preciseDurationField26.isPrecise();
        long long33 = preciseDurationField26.getValueAsLong((-62899199998L), (long) 1969);
        long long34 = preciseDurationField26.getUnitMillis();
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4320L + "'", long29 == 4320L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1048319L) + "'", long33 == (-1048319L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 60000L + "'", long34 == 60000L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        try {
            org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.withDays((int) '4');
        org.joda.time.Period period6 = period4.plusWeeks(292278992);
        org.joda.time.Period period8 = period6.minusDays(13);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField6);
        long long10 = unsupportedDateTimeField7.getDifferenceAsLong((long) 1439, (-31455220675L));
        java.lang.String str11 = unsupportedDateTimeField7.getName();
        org.joda.time.DurationField durationField12 = unsupportedDateTimeField7.getLeapDurationField();
        long long15 = unsupportedDateTimeField7.add(0L, (-2));
        try {
            long long18 = unsupportedDateTimeField7.set((long) (-292275055), "");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 31455222L + "'", long10 == 31455222L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "weekyear" + "'", str11.equals("weekyear"));
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2000L) + "'", long15 == (-2000L));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = fixedDateTimeZone4.getOffset(readableInstant6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str11 = cachedDateTimeZone9.getNameKey(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.millis();
        org.joda.time.DurationField durationField14 = gregorianChronology12.millis();
        long long17 = durationField14.subtract((long) 0, (int) (short) -1);
        boolean boolean18 = cachedDateTimeZone9.equals((java.lang.Object) long17);
        java.lang.String str20 = cachedDateTimeZone9.getNameKey((-31741875055L));
        boolean boolean21 = cachedDateTimeZone9.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (byte) -1, chronology1);
        org.joda.time.Period period4 = period2.multipliedBy(2);
        org.joda.time.Period period6 = period4.withHours(0);
        org.joda.time.Period period8 = period6.minusMonths((int) (byte) 100);
        org.joda.time.Period period10 = period8.minusYears((-63));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PT0.002S", (java.lang.Number) 1.0f, (java.lang.Number) (-1.0d), (java.lang.Number) (byte) 10);
        java.lang.String str5 = illegalFieldValueException4.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1.0 for PT0.002S must be in the range [-1.0,10]" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 1.0 for PT0.002S must be in the range [-1.0,10]"));
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField3.getAsText(0, locale7);
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField3.getWrappedField();
        long long12 = offsetDateTimeField3.getDifferenceAsLong(3264L, (-930404253L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        try {
            org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) dateTimeField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.PreciseDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField15);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (int) '4');
        long long21 = dividedDateTimeField18.add(64L, 1440);
        int int22 = dividedDateTimeField18.getDivisor();
        int int24 = dividedDateTimeField18.get((long) (-1));
        long long27 = dividedDateTimeField18.addWrapField((-62899199998L), 292278992);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField18, 888);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2362985049600064L + "'", long21 == 2362985049600064L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 37 + "'", int24 == 37);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3186684547200002L + "'", long27 == 3186684547200002L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField15);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (int) '4');
        org.joda.time.DurationField durationField19 = dividedDateTimeField18.getDurationField();
        int int20 = dividedDateTimeField18.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField24.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "weekyear");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField18, dateTimeFieldType25);
        long long30 = remainderDateTimeField28.roundFloor((-80194466524L));
        org.joda.time.DateTimeField dateTimeField31 = remainderDateTimeField28.getWrappedField();
        int int33 = remainderDateTimeField28.get((-62135369395200L));
        long long35 = remainderDateTimeField28.roundCeiling((long) 1969);
        long long38 = remainderDateTimeField28.addWrapField(0L, (-5620675));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5620749 + "'", int20 == 5620749);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-94608000000L) + "'", long30 == (-94608000000L));
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 31795200000L + "'", long35 == 31795200000L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 157852800000L + "'", long38 == 157852800000L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.PeriodType periodType5 = periodType2.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 15);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = offsetDateTimeField3.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType4, "org.joda.time.IllegalFieldValueException: Value 1.0 for PT0.002S must be in the range [-1.0,10]");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.millis();
        long long11 = durationField8.subtract((long) 100, (long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (short) -1);
        long long17 = offsetDateTimeField15.roundCeiling(0L);
        org.joda.time.DurationField durationField18 = offsetDateTimeField15.getDurationField();
        org.joda.time.DurationField durationField19 = offsetDateTimeField15.getDurationField();
        org.joda.time.DurationField durationField20 = offsetDateTimeField15.getRangeDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField15.getAsShortText(64, locale22);
        org.joda.time.DurationField durationField24 = offsetDateTimeField15.getLeapDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField25 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType4, durationField8, durationField24);
        long long28 = preciseDateTimeField25.addWrapField(1L, 1969);
        long long30 = preciseDateTimeField25.roundFloor(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 99L + "'", long11 == 99L);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31795200000L + "'", long17 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "64" + "'", str23.equals("64"));
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1970L + "'", long28 == 1970L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.secondOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.weekyear();
        org.joda.time.DurationField durationField15 = gregorianChronology13.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField15);
        java.lang.Class<?> wildcardClass17 = unsupportedDateTimeField16.getClass();
        boolean boolean18 = unsupportedDateTimeField16.isSupported();
        try {
            int int20 = unsupportedDateTimeField16.get(183600001L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (int) (short) -1, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str6 = fixedDateTimeZone4.toString();
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 10);
        java.lang.Object obj9 = null;
        boolean boolean10 = fixedDateTimeZone4.equals(obj9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.secondOfDay();
        org.joda.time.DurationField durationField13 = gregorianChronology11.millis();
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundCeiling(0L);
        org.joda.time.DurationField durationField6 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = iSOChronology14.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField15);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType13, (int) '4');
        long long21 = dividedDateTimeField18.add(64L, 1440);
        int int22 = dividedDateTimeField18.getDivisor();
        long long25 = dividedDateTimeField18.set((long) (byte) 10, 19);
        long long27 = dividedDateTimeField18.remainder(1560627933476L);
        long long30 = dividedDateTimeField18.add(4728010L, (int) (byte) -1);
        long long32 = dividedDateTimeField18.remainder((long) (-292271120));
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = offsetDateTimeField36.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "org.joda.time.IllegalFieldValueException: Value 1.0 for PT0.002S must be in the range [-1.0,10]");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField40 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField18, dateTimeFieldType37);
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, "64");
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField44 = gregorianChronology43.millis();
        org.joda.time.DurationField durationField45 = gregorianChronology43.millis();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology43.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology43.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology43.millisOfSecond();
        org.joda.time.DurationField durationField49 = gregorianChronology43.hours();
        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.time();
        org.joda.time.Period period53 = new org.joda.time.Period((long) 1439, 164127892275055L, periodType52);
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType55 = periodType54.withHoursRemoved();
        org.joda.time.PeriodType periodType58 = null;
        org.joda.time.Chronology chronology59 = null;
        org.joda.time.Period period60 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType58, chronology59);
        java.lang.String str61 = period60.toString();
        org.joda.time.Hours hours62 = period60.toStandardHours();
        org.joda.time.Period period64 = period60.plusMonths((int) ' ');
        int int65 = period60.getMillis();
        org.joda.time.Period period67 = period60.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType68 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.ReadableInstant readableInstant71 = null;
        org.joda.time.ReadableInstant readableInstant72 = null;
        org.joda.time.Period period73 = new org.joda.time.Period(readableInstant71, readableInstant72);
        org.joda.time.ReadableInstant readableInstant74 = null;
        org.joda.time.Duration duration75 = period73.toDurationTo(readableInstant74);
        long long76 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration75);
        org.joda.time.PeriodType periodType77 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType78 = periodType77.withHoursRemoved();
        org.joda.time.Period period79 = new org.joda.time.Period(readableInstant70, (org.joda.time.ReadableDuration) duration75, periodType78);
        org.joda.time.Period period80 = new org.joda.time.Period(readableInstant69, (org.joda.time.ReadableDuration) duration75);
        boolean boolean81 = periodType68.equals((java.lang.Object) duration75);
        org.joda.time.PeriodType periodType82 = periodType68.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType84 = periodType82.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(durationFieldType84, "PeriodType[YearWeekDay]");
        int int87 = period67.indexOf(durationFieldType84);
        boolean boolean88 = periodType55.isSupported(durationFieldType84);
        int int89 = periodType52.indexOf(durationFieldType84);
        org.joda.time.field.ScaledDurationField scaledDurationField91 = new org.joda.time.field.ScaledDurationField(durationField49, durationFieldType84, 51);
        org.joda.time.DurationField durationField92 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField93 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType37, durationField49, durationField92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31795200000L + "'", long5 == 31795200000L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2362985049600064L + "'", long21 == 2362985049600064L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-29537222399990L) + "'", long25 == (-29537222399990L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-80194466524L) + "'", long27 == (-80194466524L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1640817671990L) + "'", long30 == (-1640817671990L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-292271120L) + "'", long32 == (-292271120L));
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "PT0.002S" + "'", str61.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours62);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2 + "'", int65 == 2);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(periodType68);
        org.junit.Assert.assertNotNull(duration75);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 0L + "'", long76 == 0L);
        org.junit.Assert.assertNotNull(periodType77);
        org.junit.Assert.assertNotNull(periodType78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(periodType82);
        org.junit.Assert.assertNotNull(durationFieldType84);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField6 = gregorianChronology0.hours();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.time();
        org.joda.time.Period period10 = new org.joda.time.Period((long) 1439, 164127892275055L, periodType9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType12 = periodType11.withHoursRemoved();
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, (long) 1, periodType15, chronology16);
        java.lang.String str18 = period17.toString();
        org.joda.time.Hours hours19 = period17.toStandardHours();
        org.joda.time.Period period21 = period17.plusMonths((int) ' ');
        int int22 = period17.getMillis();
        org.joda.time.Period period24 = period17.plusMonths((int) (short) -1);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.years();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant28, readableInstant29);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period30.toDurationTo(readableInstant31);
        long long33 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration32);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType35 = periodType34.withHoursRemoved();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant27, (org.joda.time.ReadableDuration) duration32, periodType35);
        org.joda.time.Period period37 = new org.joda.time.Period(readableInstant26, (org.joda.time.ReadableDuration) duration32);
        boolean boolean38 = periodType25.equals((java.lang.Object) duration32);
        org.joda.time.PeriodType periodType39 = periodType25.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType41 = periodType39.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType41, "PeriodType[YearWeekDay]");
        int int44 = period24.indexOf(durationFieldType41);
        boolean boolean45 = periodType12.isSupported(durationFieldType41);
        int int46 = periodType9.indexOf(durationFieldType41);
        org.joda.time.field.ScaledDurationField scaledDurationField48 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType41, 51);
        int int51 = scaledDurationField48.getDifference(384001000L, (long) 45);
        java.lang.String str52 = scaledDurationField48.getName();
        int int55 = scaledDurationField48.getDifference(584542255L, (long) (byte) -1);
        int int58 = scaledDurationField48.getDifference(0L, 2362985049600064L);
        java.lang.String str59 = scaledDurationField48.getName();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder60 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder63 = dateTimeZoneBuilder60.setFixedSavings("PT0S", (int) '4');
        org.joda.time.DateTimeZone dateTimeZone66 = dateTimeZoneBuilder60.toDateTimeZone("P4DT240M", true);
        boolean boolean67 = scaledDurationField48.equals((java.lang.Object) true);
        long long68 = scaledDurationField48.getUnitMillis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT0.002S" + "'", str18.equals("PT0.002S"));
        org.junit.Assert.assertNotNull(hours19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "years" + "'", str52.equals("years"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-12870288) + "'", int58 == (-12870288));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "years" + "'", str59.equals("years"));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder63);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 183600000L + "'", long68 == 183600000L);
    }
}

