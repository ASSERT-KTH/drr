import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 1, (int) (byte) 100, (-1), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-1L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField1 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.Chronology chronology2 = null;
        try {
            org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((int) (short) -1, (int) (short) -1, chronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        try {
            org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 100, 100, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) -1, (int) '#', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            int int3 = dateTime0.get(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeField dateTimeField1 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField2 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        try {
            org.joda.time.DateTime dateTime2 = dateTime0.withDayOfWeek((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            int int4 = property2.compareTo(readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) -1, (int) (short) 100, (int) (byte) -1, (int) ' ', (int) 'a', (int) '#', dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(10, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            int int6 = dateTime0.get(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime dateTime2 = dateTime0.withEarlierOffsetAtOverlap();
        boolean boolean4 = dateTime0.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        try {
            org.joda.time.DateTime dateTime5 = dateTime0.withDayOfWeek((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            long long5 = copticChronology0.getDateTimeMillis((int) (short) 100, (int) (short) 100, (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.weekyear();
//        org.joda.time.DateTime.Property property5 = dateTime2.monthOfYear();
//        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
//        int int7 = dateTime2.getDayOfWeek();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        java.util.Locale locale2 = null;
        java.lang.String str3 = property1.getAsText(locale2);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(271, 0, (int) (short) 1, 0, (int) 'a', (int) '4', (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        try {
            long long6 = copticChronology0.getDateTimeMillis(0, 0, (-1), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("2019");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) -1, (int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField3 = copticChronology2.days();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.halfdayOfDay();
        try {
            org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((int) (short) 0, (int) (short) 10, (org.joda.time.Chronology) copticChronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        org.joda.time.DateTime.Property property7 = dateTime5.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        boolean boolean9 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime10.weekyear();
//        org.joda.time.DateTime.Property property13 = dateTime10.monthOfYear();
//        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(0);
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime5, (org.joda.time.ReadableDateTime) dateTime15);
//        org.joda.time.DateTime.Property property17 = dateTime5.millisOfDay();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertNotNull(property17);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        long long5 = durationField2.subtract((long) 100, (int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField7 = copticChronology6.days();
        long long10 = durationField7.subtract((long) 100, (int) (byte) 100);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField11 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-8643599900L) + "'", long5 == (-8643599900L));
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-8643599900L) + "'", long10 == (-8643599900L));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longDate();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withDate((int) (byte) -1, (int) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        org.joda.time.DateTime.Property property7 = dateTime5.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        boolean boolean9 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime10.weekyear();
//        org.joda.time.DateTime.Property property13 = dateTime10.monthOfYear();
//        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(0);
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime5, (org.joda.time.ReadableDateTime) dateTime15);
//        try {
//            long long21 = limitChronology16.getDateTimeMillis(12, (int) (byte) -1, 0, 12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,13]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(limitChronology16);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        java.lang.String str4 = property3.getAsText();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June" + "'", str4.equals("June"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime7 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            java.lang.String str2 = dateTimeFormatter0.print(readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime.Property property4 = dateTime0.weekyear();
        java.lang.String str5 = property4.getAsText();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.DateTime dateTime8 = property4.setCopy("hi!", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.lang.Object obj3 = null;
        boolean boolean4 = gregorianChronology2.equals(obj3);
        int int5 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (byte) -1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = gregorianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1L), 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField3 = copticChronology2.days();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology2.getZone();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
        org.joda.time.LocalDateTime localDateTime7 = dateTime5.toLocalDateTime();
        boolean boolean8 = dateTimeZone4.isLocalDateTimeGap(localDateTime7);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField7 = copticChronology6.days();
        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology6.getZone();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) '4', (int) (byte) 100, 0, 49591, 999, 1, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49591 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        try {
            long long2 = dateTimeFormatter0.parseMillis("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTime.Property property4 = dateTime1.monthOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
        int int6 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime8 = dateTime1.plusMinutes(0);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15:59:59-08:00" + "'", str9.equals("15:59:59-08:00"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime.Property property4 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime6 = dateTime0.minusWeeks((int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillis((long) (short) 1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", (java.lang.Number) 100, number2, (java.lang.Number) 100L);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100 + "'", number5.equals(100));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        boolean boolean5 = dateTime0.isBefore((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime0.toDateTime(dateTimeZone7);
        try {
            org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (long) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 1, 271, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime0.plus(readableDuration8);
        int int10 = dateTime0.getDayOfYear();
        org.joda.time.DateTime.Property property11 = dateTime0.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        boolean boolean5 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime3);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10, number2, (java.lang.Number) 365);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
        int int5 = dateTime0.getMillisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            int int7 = dateTime0.get(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 999 + "'", int5 == 999);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime7 = dateTime1.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime8 = dateTime0.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
        boolean boolean12 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime9);
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withYearOfEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
        int int5 = dateTime0.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime6.getZone();
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime6.toMutableDateTimeISO();
        java.lang.String str11 = mutableDateTime10.toString();
        boolean boolean12 = dateTime0.isAfter((org.joda.time.ReadableInstant) mutableDateTime10);
        java.lang.Class<?> wildcardClass13 = mutableDateTime10.getClass();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 999 + "'", int5 == 999);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969-12-31T15:59:59.999-08:00" + "'", str11.equals("1969-12-31T15:59:59.999-08:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        java.lang.String str3 = property2.getAsString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        int int7 = property2.compareTo((org.joda.time.ReadablePartial) localDateTime6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        org.joda.time.DateTime.Property property11 = dateTime8.monthOfYear();
        org.joda.time.DateTime dateTime13 = dateTime8.minusMinutes(0);
        org.joda.time.DateTime dateTime15 = dateTime8.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
        org.joda.time.DateTime dateTime18 = localDateTime6.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970" + "'", str3.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
        int int3 = dateTime0.getDayOfMonth();
        int int4 = dateTime0.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 100, 57599);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57699 + "'", int2 == 57699);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        try {
            org.joda.time.DateTime dateTime11 = dateTime0.withTime(365, 271, (int) ' ', 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
        int int5 = dateTime0.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = dateTime0.plusMinutes(0);
        org.joda.time.DateTime dateTime9 = dateTime0.plusSeconds((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundHalfCeilingCopy();
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 'a', 271);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 26287L + "'", long2 == 26287L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(12, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("15:59:59-08:00");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime6.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str15 = dateTime6.toString(dateTimeFormatter14);
        org.joda.time.DateTime dateTime17 = dateTime6.withEra(0);
        org.joda.time.DateTime dateTime19 = dateTime17.minus((-8643599900L));
        long long20 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
        java.util.Locale locale22 = null;
        try {
            org.joda.time.DateTime dateTime23 = property5.setCopy("hi!", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T15:59:59-08:00" + "'", str15.equals("T15:59:59-08:00"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 124271280422L + "'", long20 == 124271280422L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMonthOfYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1969-365");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1969-365' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatter0, (java.lang.Object) 100);
        org.joda.time.ReadableInstant readableInstant3 = null;
        java.lang.String str4 = dateTimeFormatter0.print(readableInstant3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31" + "'", str4.equals("1969-12-31"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(31, 365, 0, 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime0.plus(readableDuration8);
        boolean boolean10 = dateTime0.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        int int4 = property3.get();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        java.util.Locale locale12 = null;
        try {
            long long13 = skipUndoDateTimeField9.set((long) 31, "Property[secondOfDay]", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[secondOfDay]\" for halfdayOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("15:59:59-08:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"15:59:59-08:00\" is malformed at \":59:59-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1.0d), (java.lang.Number) 100.0f, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime dateTime2 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime4 = dateTime0.plusSeconds(0);
        java.util.Date date5 = dateTime0.toDate();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            long long10 = gregorianChronology2.getDateTimeMillis(999, 57699, 10, 57599, (int) ' ', (int) (byte) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            int[] intArray5 = copticChronology0.get(readablePartial3, (long) 49591);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.io.Writer writer1 = null;
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        java.lang.String str4 = dateTimeZone3.getID();
        long long6 = dateTimeZone3.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone3);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) monthDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-28799968L) + "'", long6 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime8 = dateTime0.withMonthOfYear((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
        org.joda.time.LocalDateTime localDateTime4 = dateTime2.toLocalDateTime();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDateTime4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField4 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.era();
        org.joda.time.DurationField durationField5 = copticChronology1.years();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField6 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField9.getAsShortText((int) (short) 10, locale11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray20 = new int[] { (short) -1, (-1), 999, 49591, 57599 };
        java.util.Locale locale22 = null;
        try {
            int[] intArray23 = skipUndoDateTimeField9.set(readablePartial13, 57599, intArray20, "10", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for halfdayOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.fullDate();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("T15:59:59-08:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"T15:59:59-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 1);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 0, locale3);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 12, "2019");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        boolean boolean5 = dateTime0.isBefore((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime0.toDateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime.Property property4 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime6 = dateTime0.minusWeeks((int) (short) 10);
        try {
            org.joda.time.DateTime dateTime11 = dateTime0.withTime((int) '#', 11, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
        int int5 = property4.getMinimumValueOverall();
        org.joda.time.DateTime dateTime7 = property4.setCopy((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.withEra((int) (short) 0);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime9.toMutableDateTimeISO();
        java.lang.String str12 = dateTime9.toString("10");
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(57599, 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
        int int5 = property4.getMinimumValueOverall();
        org.joda.time.DateTime dateTime7 = property4.setCopy((int) (short) 1);
        java.lang.String str8 = property4.getName();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "monthOfYear" + "'", str8.equals("monthOfYear"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        boolean boolean7 = dateTimeZone3.isLocalDateTimeGap(localDateTime6);
        org.joda.time.Chronology chronology8 = julianChronology0.withZone(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime0.plus(readableDuration8);
//        int int10 = dateTime0.getDayOfYear();
//        org.joda.time.TimeOfDay timeOfDay11 = dateTime0.toTimeOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 166 + "'", int10 == 166);
//        org.junit.Assert.assertNotNull(timeOfDay11);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
//        int int6 = dateTime0.getSecondOfDay();
//        java.lang.String str7 = dateTime0.toString();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 49600 + "'", int6 == 49600);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15T13:46:40.771-07:00" + "'", str7.equals("2019-06-15T13:46:40.771-07:00"));
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime7 = dateTime1.withEarlierOffsetAtOverlap();
        boolean boolean9 = dateTime7.isEqual((long) 12);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime.Property property4 = dateTime0.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(julianChronology4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) -1, 100, 0, 6, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime7 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property8 = dateTime1.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime10 = property8.setCopy(166);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.minuteOfHour();
        org.joda.time.DurationField durationField3 = gregorianChronology1.weeks();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        int int3 = monthDay1.size();
        java.util.Locale locale5 = null;
        try {
            java.lang.String str6 = monthDay1.toString("T15:59:59-08:00", locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("T13:46:40-07:00", 10, (int) '4', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for T13:46:40-07:00 must be in the range [52,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        org.joda.time.DateTime.Property property7 = dateTime5.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        boolean boolean9 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime10.weekyear();
//        org.joda.time.DateTime.Property property13 = dateTime10.monthOfYear();
//        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(0);
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime5, (org.joda.time.ReadableDateTime) dateTime15);
//        try {
//            long long21 = limitChronology16.getDateTimeMillis(0, 19, (int) (short) 100, 2);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,13]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(limitChronology16);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        java.lang.String str2 = dateTimeZone1.getID();
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, 10L, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+97:00" + "'", str2.equals("+97:00"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        boolean boolean7 = dateTimeZone1.isLocalDateTimeGap(localDateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.weekyear();
        org.joda.time.DateTime.Property property5 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime7 = dateTime2.minusMinutes(0);
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks(6);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField11 = copticChronology10.days();
        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology10.getZone();
        org.joda.time.DateTime dateTime13 = dateTime7.withChronology((org.joda.time.Chronology) copticChronology10);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) ' ', 15);
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
        try {
            org.joda.time.DateTime dateTime6 = property4.setCopy("15:59:59-08:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"15:59:59-08:00\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property8 = dateTime0.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.weekyear();
//        org.joda.time.DateTime.Property property5 = dateTime2.monthOfYear();
//        org.joda.time.DateTime dateTime7 = dateTime2.minusMinutes(0);
//        org.joda.time.DateTime dateTime9 = dateTime2.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str11 = dateTime2.toString(dateTimeFormatter10);
//        org.joda.time.DateTime dateTime13 = dateTime2.withEra(0);
//        org.joda.time.DateTime dateTime15 = dateTime13.minus((-8643599900L));
//        org.joda.time.DateTime dateTime17 = dateTime13.plus(1758642998400011L);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "T13:46:45-07:00" + "'", str11.equals("T13:46:45-07:00"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray12 = new int[] {};
        try {
            int[] intArray14 = skipUndoDateTimeField9.addWrapPartial(readablePartial10, 999, intArray12, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        int int4 = property3.get();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1735 + "'", int4 == 1735);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", (java.lang.Number) 100, number2, (java.lang.Number) 100L);
        java.lang.String str5 = illegalFieldValueException4.toString();
        java.lang.Number number8 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", (java.lang.Number) 100, number8, (java.lang.Number) 100L);
        java.lang.String str11 = illegalFieldValueException10.getFieldName();
        java.lang.String str12 = illegalFieldValueException10.toString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100" + "'", str12.equals("org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100"));
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField2 = copticChronology1.days();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
//        long long8 = skipDateTimeField6.roundHalfEven(0L);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.minuteOfHour();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
//        java.lang.String str18 = localDateTime15.toString(dateTimeFormatter17);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
//        int int20 = localDateTime15.indexOf(dateTimeFieldType19);
//        int[] intArray22 = gregorianChronology11.get((org.joda.time.ReadablePartial) localDateTime15, (long) 12);
//        try {
//            int int23 = skipDateTimeField6.getMaximumValue(readablePartial9, intArray22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-230400000L) + "'", long8 == (-230400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019-166" + "'", str18.equals("2019-166"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(intArray22);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1104537599969L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        java.lang.Object obj10 = null;
        boolean boolean11 = gregorianChronology2.equals(obj10);
        try {
            long long16 = gregorianChronology2.getDateTimeMillis(12, 3, 365, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField6 = copticChronology5.days();
//        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology4, dateTimeField9);
//        java.lang.String str12 = skipDateTimeField10.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
//        java.lang.String str16 = property15.getAsString();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime19 = dateTime17.toLocalDateTime();
//        int int20 = property15.compareTo((org.joda.time.ReadablePartial) localDateTime19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property22 = dateTime21.yearOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.weekyear();
//        org.joda.time.DateTime.Property property24 = dateTime21.monthOfYear();
//        org.joda.time.DateTime dateTime26 = dateTime21.minusMinutes(0);
//        org.joda.time.DateTime dateTime28 = dateTime21.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readablePeriod29);
//        org.joda.time.DateTime dateTime31 = localDateTime19.toDateTime((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTimeField[] dateTimeFieldArray32 = localDateTime19.getFields();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDateTime19, locale33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipDateTimeField10.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType35);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType35, 59, 49591, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for weekOfWeekyear must be in the range [49591,100]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "24" + "'", str34.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
//        int int4 = dateTime2.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime6 = dateTime2.withMillisOfDay(3);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField2 = copticChronology1.days();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.halfdayOfDay();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField7 = copticChronology6.days();
//        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology6.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField(chronology5, dateTimeField10);
//        java.lang.String str13 = skipDateTimeField11.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
//        org.joda.time.DateTime.Property property16 = dateTime14.weekyear();
//        java.lang.String str17 = property16.getAsString();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime20 = dateTime18.toLocalDateTime();
//        int int21 = property16.compareTo((org.joda.time.ReadablePartial) localDateTime20);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property23 = dateTime22.yearOfEra();
//        org.joda.time.DateTime.Property property24 = dateTime22.weekyear();
//        org.joda.time.DateTime.Property property25 = dateTime22.monthOfYear();
//        org.joda.time.DateTime dateTime27 = dateTime22.minusMinutes(0);
//        org.joda.time.DateTime dateTime29 = dateTime22.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime29.minus(readablePeriod30);
//        org.joda.time.DateTime dateTime32 = localDateTime20.toDateTime((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTimeField[] dateTimeFieldArray33 = localDateTime20.getFields();
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime20, locale34);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipDateTimeField11.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType36);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(localDateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "24" + "'", str35.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        java.lang.Integer int6 = dateTimeFormatter4.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNull(int6);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 10);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((long) ' ');
//        org.joda.time.MonthDay.Property property10 = monthDay9.monthOfYear();
//        org.joda.time.MonthDay monthDay12 = property10.addToCopy(86399);
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField16 = copticChronology15.days();
//        org.joda.time.DateTimeZone dateTimeZone17 = copticChronology15.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField(chronology14, dateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.DateTime.Property property25 = dateTime23.weekyear();
//        java.lang.String str26 = property25.getAsString();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime29 = dateTime27.toLocalDateTime();
//        int int30 = property25.compareTo((org.joda.time.ReadablePartial) localDateTime29);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property32 = dateTime31.yearOfEra();
//        org.joda.time.DateTime.Property property33 = dateTime31.weekyear();
//        org.joda.time.DateTime.Property property34 = dateTime31.monthOfYear();
//        org.joda.time.DateTime dateTime36 = dateTime31.minusMinutes(0);
//        org.joda.time.DateTime dateTime38 = dateTime31.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.DateTime dateTime40 = dateTime38.minus(readablePeriod39);
//        org.joda.time.DateTime dateTime41 = localDateTime29.toDateTime((org.joda.time.ReadableInstant) dateTime38);
//        org.joda.time.DateTimeField[] dateTimeFieldArray42 = localDateTime29.getFields();
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = skipDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDateTime29, locale43);
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = skipDateTimeField20.getType();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone46);
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.minuteOfHour();
//        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property50 = dateTime49.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime51 = dateTime49.toLocalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter52.withZoneUTC();
//        java.lang.String str54 = localDateTime51.toString(dateTimeFormatter53);
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = null;
//        int int56 = localDateTime51.indexOf(dateTimeFieldType55);
//        int[] intArray58 = gregorianChronology47.get((org.joda.time.ReadablePartial) localDateTime51, (long) 12);
//        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone59);
//        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology60.minuteOfHour();
//        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property63 = dateTime62.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime64 = dateTime62.toLocalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter65 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter66 = dateTimeFormatter65.withZoneUTC();
//        java.lang.String str67 = localDateTime64.toString(dateTimeFormatter66);
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = null;
//        int int69 = localDateTime64.indexOf(dateTimeFieldType68);
//        int[] intArray71 = gregorianChronology60.get((org.joda.time.ReadablePartial) localDateTime64, (long) 12);
//        int int72 = skipDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDateTime51, intArray71);
//        try {
//            int[] intArray74 = offsetDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) monthDay12, 0, intArray71, 271);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(copticChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(localDateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(localDateTime51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2019-166" + "'", str54.equals("2019-166"));
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertNotNull(gregorianChronology60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(localDateTime64);
//        org.junit.Assert.assertNotNull(dateTimeFormatter65);
//        org.junit.Assert.assertNotNull(dateTimeFormatter66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2019-166" + "'", str67.equals("2019-166"));
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
//        org.junit.Assert.assertNotNull(intArray71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 53 + "'", int72 == 53);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField2 = copticChronology1.days();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
//        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
//        java.lang.String str12 = property11.getAsString();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
//        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
//        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
//        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
//        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
//        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
//        org.joda.time.DurationField durationField31 = skipDateTimeField6.getLeapDurationField();
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "24" + "'", str30.equals("24"));
//        org.junit.Assert.assertNull(durationField31);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        java.lang.Appendable appendable1 = null;
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        java.lang.String str4 = dateTimeZone3.getID();
        long long6 = dateTimeZone3.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone3);
        org.joda.time.MonthDay monthDay9 = monthDay7.plusMonths((int) (byte) 0);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) monthDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-28799968L) + "'", long6 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
//        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime7.toMutableDateTimeISO();
//        java.lang.String str12 = mutableDateTime11.toString();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime0, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019-06-15T13:46:51.570-07:00" + "'", str12.equals("2019-06-15T13:46:51.570-07:00"));
//        org.junit.Assert.assertNotNull(chronology13);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 1, 57599, 4, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime4 = dateTime0.minusSeconds(6);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"2019\")"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime.Property property4 = dateTime0.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime0.toMutableDateTime();
        int int6 = dateTime0.getEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", (java.lang.Number) 100, number2, (java.lang.Number) 100L);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertNull(durationFieldType6);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfDay(86399);
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.dayOfMonth();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.weekyear();
//        org.joda.time.DateTime.Property property5 = dateTime2.monthOfYear();
//        org.joda.time.DateTime dateTime7 = dateTime2.minusMinutes(0);
//        org.joda.time.DateTime dateTime9 = dateTime2.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str11 = dateTime2.toString(dateTimeFormatter10);
//        org.joda.time.DateTime dateTime13 = dateTime2.withEra(0);
//        org.joda.time.DateTime dateTime15 = dateTime13.minus((-8643599900L));
//        long long16 = property1.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "T13:46:54-07:00" + "'", str11.equals("T13:46:54-07:00"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1474748L + "'", long16 == 1474748L);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("(\"org.joda.time.JodaTimePermission\" \"2019\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"(\"org.joda.time.JodaTimePermissi...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("June");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"June\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundHalfCeilingCopy();
        boolean boolean3 = property1.isLeap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        try {
            long long10 = gregorianChronology1.getDateTimeMillis(100, (int) (byte) -1, 53, 271, (int) (byte) -1, 0, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 271 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("+97:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+97:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        try {
            long long12 = gregorianChronology2.getDateTimeMillis((int) (short) -1, 11, (int) (short) 0, 0, (int) (byte) 0, 53, 11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTimeISO();
//        org.joda.time.DateTime.Property property5 = dateTime0.secondOfDay();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(0);
//        org.joda.time.DateTime dateTime13 = dateTime6.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str15 = dateTime6.toString(dateTimeFormatter14);
//        org.joda.time.DateTime dateTime17 = dateTime6.withEra(0);
//        org.joda.time.DateTime dateTime19 = dateTime17.minus((-8643599900L));
//        long long20 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
//        java.lang.String str21 = property5.toString();
//        org.joda.time.Interval interval22 = property5.toInterval();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T13:46:55-07:00" + "'", str15.equals("T13:46:55-07:00"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 127426950421L + "'", long20 == 127426950421L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Property[secondOfDay]" + "'", str21.equals("Property[secondOfDay]"));
//        org.junit.Assert.assertNotNull(interval22);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(57599, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendClockhourOfDay(15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfMinute(15, 271);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.era();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfYear();
        try {
            long long9 = copticChronology0.getDateTimeMillis(0L, 31, 0, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
//        int int3 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime0.secondOfMinute();
//        int int5 = property4.getMaximumValueOverall();
//        int int6 = property4.getLeapAmount();
//        long long7 = property4.remainder();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(localDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 838L + "'", long7 == 838L);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay monthDay3 = monthDay1.plusDays(365);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        try {
            boolean boolean7 = monthDay1.isEqual((org.joda.time.ReadablePartial) localDateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay monthDay3 = monthDay1.plusDays(365);
        try {
            org.joda.time.MonthDay monthDay5 = monthDay1.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay3);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
//        org.joda.time.DateTime.Property property7 = dateTime5.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        boolean boolean9 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime10.weekyear();
//        org.joda.time.DateTime.Property property13 = dateTime10.monthOfYear();
//        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(0);
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime5, (org.joda.time.ReadableDateTime) dateTime15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        boolean boolean18 = limitChronology16.equals((java.lang.Object) dateTimeFormatter17);
//        java.lang.String str19 = limitChronology16.toString();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LimitChronology[CopticChronology[America/Los_Angeles], 2019-06-15T13:46:56.712-07:00, 2019-06-15T13:46:56.713-07:00]" + "'", str19.equals("LimitChronology[CopticChronology[America/Los_Angeles], 2019-06-15T13:46:56.712-07:00, 2019-06-15T13:46:56.713-07:00]"));
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 57699, (java.lang.Number) (short) 10, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
//        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
//        org.joda.time.DateTime.Property property12 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime13 = property12.roundCeilingCopy();
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime13.withDayOfMonth((int) '4');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T13:46:57-07:00" + "'", str9.equals("T13:46:57-07:00"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(100, 1, 826, 1735, (int) '4', 1735, (int) (short) 0, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1735 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        int int46 = remainderDateTimeField44.getMinimumValue();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "24" + "'", str40.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.era();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.hourOfDay();
        java.lang.String str5 = copticChronology0.toString();
        try {
            long long13 = copticChronology0.getDateTimeMillis(19, 49591, 52, 100, 15, 0, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str5.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100", (int) (byte) 10, 57699, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100 must be in the range [57699,3]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime8 = dateTime0.withMonthOfYear((int) (short) 1);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        int int12 = gregorianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology11.getZone();
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime0.toMutableDateTime(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) -1, 2, 166, 6, 6, 166);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "T15:59:59-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        boolean boolean5 = dateTime0.isBefore((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        org.joda.time.DateTime dateTime8 = dateTime0.toDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime0.plusSeconds((int) '4');
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfCentury((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder0.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
//        int int3 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime0.secondOfMinute();
//        int int5 = dateTime0.getYearOfCentury();
//        org.joda.time.DateTime dateTime7 = dateTime0.minusWeeks(15);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(localDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(1L, locale3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundHalfCeilingCopy();
        int int3 = dateTime2.getEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(57599, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumTextLength(locale3);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "-00:00:00.001");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
//        java.lang.String str5 = dateTimeZone2.getName((long) (short) 10);
//        org.joda.time.Chronology chronology6 = copticChronology0.withZone(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.year();
//        try {
//            long long12 = copticChronology0.getDateTimeMillis((int) (byte) -1, 0, 57699, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "monthOfYear");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
//        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
//        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
//        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime14 = dateTime6.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
//        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
//        boolean boolean18 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime20 = dateTime15.withCenturyOfEra(100);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone3.getName(1L, locale23);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pacific Standard Time" + "'", str24.equals("Pacific Standard Time"));
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime.Property property4 = dateTime0.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime0.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone6 = mutableDateTime5.getZone();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(124271280422L);
        org.joda.time.DateTime dateTime3 = dateTime1.minus((long) 2000);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendCenturyOfEra(0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
//        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
//        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T13:47:02-07:00" + "'", str9.equals("T13:47:02-07:00"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(chronology12);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = remainderDateTimeField44.getAsText(1758642998400011L, locale47);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "24" + "'", str40.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
//    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
//        int int5 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property6 = dateTime0.weekyear();
//        try {
//            org.joda.time.DateTime dateTime8 = property6.addToCopy(1560631603338L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560631603338");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(property6);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) -1);
        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        boolean boolean2 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        java.lang.String str3 = property2.getAsString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        int int7 = property2.compareTo((org.joda.time.ReadablePartial) localDateTime6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        int int11 = property2.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfEra();
        org.joda.time.DateTime.Property property14 = dateTime12.weekyear();
        org.joda.time.DateTime.Property property15 = dateTime12.monthOfYear();
        org.joda.time.DateTime dateTime17 = dateTime12.minusMinutes(0);
        org.joda.time.DateTime dateTime19 = dateTime12.minusDays((int) (short) 100);
        org.joda.time.DateTime dateTime21 = dateTime19.minusSeconds((int) (short) 10);
        int int22 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology23.dayOfYear();
        org.joda.time.DateTimeField dateTimeField25 = copticChronology23.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
        int int28 = dateTime19.get(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        boolean boolean2 = dateTime0.isAfterNow();
        org.joda.time.DateTime.Property property3 = dateTime0.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(property3);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property47 = dateTime46.yearOfEra();
//        org.joda.time.DateTime.Property property48 = dateTime46.weekyear();
//        java.lang.String str49 = property48.getAsString();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property51 = dateTime50.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime52 = dateTime50.toLocalDateTime();
//        int int53 = property48.compareTo((org.joda.time.ReadablePartial) localDateTime52);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property55 = dateTime54.yearOfEra();
//        org.joda.time.DateTime.Property property56 = dateTime54.weekyear();
//        org.joda.time.DateTime.Property property57 = dateTime54.monthOfYear();
//        org.joda.time.DateTime dateTime59 = dateTime54.minusMinutes(0);
//        org.joda.time.DateTime dateTime61 = dateTime54.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod62 = null;
//        org.joda.time.DateTime dateTime63 = dateTime61.minus(readablePeriod62);
//        org.joda.time.DateTime dateTime64 = localDateTime52.toDateTime((org.joda.time.ReadableInstant) dateTime61);
//        java.util.Locale locale65 = null;
//        java.lang.String str66 = remainderDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) localDateTime52, locale65);
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField69 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField44, dateTimeFieldType67, 31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "24" + "'", str40.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019" + "'", str49.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(localDateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "24" + "'", str66.equals("24"));
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) ' ', 15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfYear(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        java.lang.String str2 = copticChronology0.toString();
        org.joda.time.DurationField durationField3 = copticChronology0.months();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str2.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        java.lang.String str3 = property2.getAsString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        int int7 = property2.compareTo((org.joda.time.ReadablePartial) localDateTime6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        org.joda.time.DateTime.Property property11 = dateTime8.monthOfYear();
        org.joda.time.DateTime dateTime13 = dateTime8.minusMinutes(0);
        org.joda.time.DateTime dateTime15 = dateTime8.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
        org.joda.time.DateTime dateTime18 = localDateTime6.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime19 = dateTime15.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        java.util.Locale locale3 = null;
        try {
            org.joda.time.DateTime dateTime4 = property1.setCopy("monthOfYear", locale3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"monthOfYear\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusWeeks((int) 'a');
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfEra(2000, (int) (byte) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendYear(57699, (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHourOfHalfday(24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property5 = monthDay4.monthOfYear();
        org.joda.time.MonthDay monthDay7 = property5.addToCopy(999);
        try {
            boolean boolean8 = localDateTime2.isAfter((org.joda.time.ReadablePartial) monthDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter1.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
//        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
//        org.joda.time.DateTime.Property property12 = dateTime0.centuryOfEra();
//        java.util.Locale locale13 = null;
//        int int14 = property12.getMaximumTextLength(locale13);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T13:47:06-07:00" + "'", str9.equals("T13:47:06-07:00"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property2.addToCopy(999);
        org.joda.time.MonthDay monthDay6 = property2.addWrapFieldToCopy(86399);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", (java.lang.Number) 100, number2, (java.lang.Number) 100L);
        java.lang.String str5 = illegalFieldValueException4.toString();
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100L + "'", number7.equals(100L));
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
//        int int5 = dateTime0.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime6.getZone();
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime6.toMutableDateTimeISO();
//        java.lang.String str11 = mutableDateTime10.toString();
//        boolean boolean12 = dateTime0.isAfter((org.joda.time.ReadableInstant) mutableDateTime10);
//        int int13 = mutableDateTime10.getMonthOfYear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 131 + "'", int5 == 131);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15T13:47:07.132-07:00" + "'", str11.equals("2019-06-15T13:47:07.132-07:00"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(57599, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendWeekOfWeekyear((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
//        int int5 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property6 = dateTime0.weekyear();
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology11 = gregorianChronology9.withZone(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfDay();
//        boolean boolean13 = dateTime0.equals((java.lang.Object) dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"America/Los_Angeles/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        org.joda.time.DateTime.Property property4 = dateTime0.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime0.toMutableDateTime();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime0);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime0);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getName((long) (short) 10);
//        org.joda.time.DateTime dateTime12 = dateTime0.toDateTime(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560631627679L + "'", long7 == 1560631627679L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pacific Standard Time" + "'", str11.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 100, 11, 0, (int) (byte) 1, (int) (byte) 0, (int) (short) 100, (int) (byte) 0, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        try {
            org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.tz.CachedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        java.lang.String str3 = property2.getAsString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        int int7 = property2.compareTo((org.joda.time.ReadablePartial) localDateTime6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        org.joda.time.DateTime.Property property11 = dateTime8.monthOfYear();
        org.joda.time.DateTime dateTime13 = dateTime8.minusMinutes(0);
        org.joda.time.DateTime dateTime15 = dateTime8.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
        org.joda.time.DateTime dateTime18 = localDateTime6.toDateTime((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime21 = dateTime15.withDurationAdded(0L, 0);
        org.joda.time.DateTime.Property property22 = dateTime15.era();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(57599, 31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendClockhourOfDay(15);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField11 = copticChronology10.days();
//        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology10.getZone();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology10.halfdayOfDay();
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField16 = copticChronology15.days();
//        org.joda.time.DateTimeZone dateTimeZone17 = copticChronology15.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField(chronology14, dateTimeField19);
//        java.lang.String str22 = skipDateTimeField20.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.DateTime.Property property25 = dateTime23.weekyear();
//        java.lang.String str26 = property25.getAsString();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime29 = dateTime27.toLocalDateTime();
//        int int30 = property25.compareTo((org.joda.time.ReadablePartial) localDateTime29);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property32 = dateTime31.yearOfEra();
//        org.joda.time.DateTime.Property property33 = dateTime31.weekyear();
//        org.joda.time.DateTime.Property property34 = dateTime31.monthOfYear();
//        org.joda.time.DateTime dateTime36 = dateTime31.minusMinutes(0);
//        org.joda.time.DateTime dateTime38 = dateTime31.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.DateTime dateTime40 = dateTime38.minus(readablePeriod39);
//        org.joda.time.DateTime dateTime41 = localDateTime29.toDateTime((org.joda.time.ReadableInstant) dateTime38);
//        org.joda.time.DateTimeField[] dateTimeFieldArray42 = localDateTime29.getFields();
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = skipDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDateTime29, locale43);
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = skipDateTimeField20.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, dateTimeFieldType45);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, "(\"org.joda.time.JodaTimePermission\" \"2019\")");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType45, 53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(copticChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(localDateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "24" + "'", str44.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
//        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime8 = dateTime0.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
//        boolean boolean12 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime9);
//        java.lang.String str13 = dateTime0.toString();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-06-15T13:47:09.249-07:00" + "'", str13.equals("2019-06-15T13:47:09.249-07:00"));
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Pacific Standard Time' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        boolean boolean2 = dateTime0.isAfterNow();
//        int int3 = dateTime0.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.weeks();
        long long5 = durationField2.subtract((-100L), (long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-6051600100L) + "'", long5 == (-6051600100L));
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
//        int int3 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime0.secondOfMinute();
//        int int5 = property4.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime6 = property4.getDateTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(localDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        boolean boolean3 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime5 = dateTime0.minusYears(31);
        org.joda.time.DateTime dateTime7 = dateTime0.minusMillis((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        long long4 = dateTimeZone1.convertLocalToUTC((long) (byte) 10, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28800010L + "'", long4 == 28800010L);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField2 = copticChronology1.days();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
//        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
//        java.lang.String str12 = property11.getAsString();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
//        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
//        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
//        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
//        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
//        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField6.getType();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.minuteOfHour();
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property36 = dateTime35.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime37 = dateTime35.toLocalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = dateTimeFormatter38.withZoneUTC();
//        java.lang.String str40 = localDateTime37.toString(dateTimeFormatter39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = null;
//        int int42 = localDateTime37.indexOf(dateTimeFieldType41);
//        int[] intArray44 = gregorianChronology33.get((org.joda.time.ReadablePartial) localDateTime37, (long) 12);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone45);
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology46.minuteOfHour();
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property49 = dateTime48.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime50 = dateTime48.toLocalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = dateTimeFormatter51.withZoneUTC();
//        java.lang.String str53 = localDateTime50.toString(dateTimeFormatter52);
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
//        int int55 = localDateTime50.indexOf(dateTimeFieldType54);
//        int[] intArray57 = gregorianChronology46.get((org.joda.time.ReadablePartial) localDateTime50, (long) 12);
//        int int58 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDateTime37, intArray57);
//        int int60 = skipDateTimeField6.get(0L);
//        try {
//            long long63 = skipDateTimeField6.set((long) 86399, "PM");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PM\" for weekOfWeekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "24" + "'", str30.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(localDateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019-166" + "'", str40.equals("2019-166"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(localDateTime50);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019-166" + "'", str53.equals("2019-166"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 53 + "'", int58 == 53);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        java.util.Locale locale6 = null;
        try {
            org.joda.time.DateTime dateTime7 = property3.setCopy("PST", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PST\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField6 = copticChronology5.days();
//        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology4, dateTimeField9);
//        java.lang.String str12 = skipDateTimeField10.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
//        java.lang.String str16 = property15.getAsString();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime19 = dateTime17.toLocalDateTime();
//        int int20 = property15.compareTo((org.joda.time.ReadablePartial) localDateTime19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property22 = dateTime21.yearOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.weekyear();
//        org.joda.time.DateTime.Property property24 = dateTime21.monthOfYear();
//        org.joda.time.DateTime dateTime26 = dateTime21.minusMinutes(0);
//        org.joda.time.DateTime dateTime28 = dateTime21.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readablePeriod29);
//        org.joda.time.DateTime dateTime31 = localDateTime19.toDateTime((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTimeField[] dateTimeFieldArray32 = localDateTime19.getFields();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDateTime19, locale33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipDateTimeField10.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType35);
//        int int37 = delegatedDateTimeField36.getMinimumValue();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "24" + "'", str34.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.era();
        org.joda.time.DurationField durationField4 = copticChronology0.hours();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("2019-166");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-166\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField6, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        int int3 = monthDay1.getMonthOfYear();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay6 = monthDay1.withPeriodAdded(readablePeriod4, (int) ' ');
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.weekOfWeekyear();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField6 = copticChronology5.days();
        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology5.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology9 = iSOChronology8.withUTC();
        boolean boolean10 = iSOChronology3.equals((java.lang.Object) iSOChronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.Chronology chronology12 = iSOChronology8.withZone(dateTimeZone11);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(chronology12);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField2 = copticChronology1.days();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
//        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
//        java.lang.String str12 = property11.getAsString();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
//        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
//        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
//        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
//        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
//        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
//        try {
//            long long33 = skipDateTimeField6.set((long) 86399, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [1,53]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "24" + "'", str30.equals("24"));
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        boolean boolean3 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.Chronology chronology4 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property5 = dateTime0.secondOfDay();
        java.lang.String str6 = property5.getName();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "secondOfDay" + "'", str6.equals("secondOfDay"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField13);
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        org.joda.time.Chronology chronology17 = gregorianChronology2.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Chronology chronology4 = copticChronology3.withUTC();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology(chronology4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology4);
        try {
            org.joda.time.MonthDay monthDay7 = monthDay1.withChronologyRetainFields(chronology4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for dayOfMonth must not be larger than 30");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField2 = copticChronology1.days();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
//        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
//        java.lang.String str12 = property11.getAsString();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
//        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
//        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
//        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
//        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
//        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField6.getType();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.minuteOfHour();
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property36 = dateTime35.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime37 = dateTime35.toLocalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = dateTimeFormatter38.withZoneUTC();
//        java.lang.String str40 = localDateTime37.toString(dateTimeFormatter39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = null;
//        int int42 = localDateTime37.indexOf(dateTimeFieldType41);
//        int[] intArray44 = gregorianChronology33.get((org.joda.time.ReadablePartial) localDateTime37, (long) 12);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone45);
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology46.minuteOfHour();
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property49 = dateTime48.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime50 = dateTime48.toLocalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = dateTimeFormatter51.withZoneUTC();
//        java.lang.String str53 = localDateTime50.toString(dateTimeFormatter52);
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
//        int int55 = localDateTime50.indexOf(dateTimeFieldType54);
//        int[] intArray57 = gregorianChronology46.get((org.joda.time.ReadablePartial) localDateTime50, (long) 12);
//        int int58 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDateTime37, intArray57);
//        int int60 = skipDateTimeField6.get(0L);
//        long long62 = skipDateTimeField6.roundHalfFloor(0L);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "24" + "'", str30.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(localDateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019-166" + "'", str40.equals("2019-166"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(localDateTime50);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019-166" + "'", str53.equals("2019-166"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 53 + "'", int58 == 53);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-230400000L) + "'", long62 == (-230400000L));
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = gregorianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime8.getZone();
        org.joda.time.DateTime.Property property12 = dateTime8.minuteOfDay();
        boolean boolean13 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime15 = dateTime7.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        org.joda.time.DateTime.Property property18 = dateTime16.weekyear();
        boolean boolean19 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime21 = dateTime16.withCenturyOfEra(100);
        org.joda.time.DateTime dateTime23 = dateTime16.withMonthOfYear(1);
        int int24 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime7 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property8 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime10 = property8.addToCopy((long) (short) 10);
        org.joda.time.DateTime.Property property11 = dateTime10.year();
        org.joda.time.DurationField durationField12 = property11.getDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(10, 24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property47 = dateTime46.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime48 = dateTime46.toLocalDateTime();
//        int[] intArray51 = new int[] { 24 };
//        try {
//            int[] intArray53 = remainderDateTimeField44.add((org.joda.time.ReadablePartial) localDateTime48, (int) (byte) 100, intArray51, 46);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "24" + "'", str40.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(localDateTime48);
//        org.junit.Assert.assertNotNull(intArray51);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.weekyear();
        org.joda.time.DateTime.Property property5 = dateTime2.monthOfYear();
        java.util.Date date6 = dateTime2.toDate();
        org.joda.time.DateTime.Property property7 = dateTime2.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField9 = copticChronology8.days();
        org.joda.time.DateTimeZone dateTimeZone10 = copticChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology8.era();
        org.joda.time.DateTime dateTime12 = dateTime2.withChronology((org.joda.time.Chronology) copticChronology8);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime dateTime2 = dateTime0.withEarlierOffsetAtOverlap();
        int int3 = dateTime0.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str2 = dateTimeZone1.getID();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        org.joda.time.DateTime.Property property5 = dateTime3.weekyear();
//        java.lang.String str6 = property5.getAsString();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime9 = dateTime7.toLocalDateTime();
//        int int10 = property5.compareTo((org.joda.time.ReadablePartial) localDateTime9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property12 = dateTime11.yearOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime11.weekyear();
//        org.joda.time.DateTime.Property property14 = dateTime11.monthOfYear();
//        org.joda.time.DateTime dateTime16 = dateTime11.minusMinutes(0);
//        org.joda.time.DateTime dateTime18 = dateTime11.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.minus(readablePeriod19);
//        org.joda.time.DateTime dateTime21 = localDateTime9.toDateTime((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime24 = dateTime18.withDurationAdded(0L, 0);
//        int int25 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-28800000) + "'", int25 == (-28800000));
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.withYear(100);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology9 = gregorianChronology7.withZone(dateTimeZone8);
        java.util.TimeZone timeZone10 = dateTimeZone8.toTimeZone();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfEra();
        org.joda.time.DateTime.Property property14 = dateTime12.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime12.getZone();
        org.joda.time.DateTime.Property property16 = dateTime12.minuteOfDay();
        boolean boolean17 = dateTime11.isAfter((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime19 = dateTime11.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property21 = dateTime20.yearOfEra();
        org.joda.time.DateTime.Property property22 = dateTime20.weekyear();
        boolean boolean23 = dateTime11.isAfter((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime25 = dateTime20.withCenturyOfEra(100);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime25);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        java.lang.String str29 = dateTimeZone28.getID();
        long long31 = dateTimeZone28.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now(dateTimeZone28);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology26, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone34 = zonedChronology33.getZone();
        org.joda.time.DateTime dateTime35 = dateTime4.withZoneRetainFields(dateTimeZone34);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "America/Los_Angeles" + "'", str29.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-28799968L) + "'", long31 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTime35);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property47 = dateTime46.yearOfEra();
//        org.joda.time.DateTime.Property property48 = dateTime46.weekyear();
//        java.lang.String str49 = property48.getAsString();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property51 = dateTime50.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime52 = dateTime50.toLocalDateTime();
//        int int53 = property48.compareTo((org.joda.time.ReadablePartial) localDateTime52);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property55 = dateTime54.yearOfEra();
//        org.joda.time.DateTime.Property property56 = dateTime54.weekyear();
//        org.joda.time.DateTime.Property property57 = dateTime54.monthOfYear();
//        org.joda.time.DateTime dateTime59 = dateTime54.minusMinutes(0);
//        org.joda.time.DateTime dateTime61 = dateTime54.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod62 = null;
//        org.joda.time.DateTime dateTime63 = dateTime61.minus(readablePeriod62);
//        org.joda.time.DateTime dateTime64 = localDateTime52.toDateTime((org.joda.time.ReadableInstant) dateTime61);
//        java.util.Locale locale65 = null;
//        java.lang.String str66 = remainderDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) localDateTime52, locale65);
//        org.joda.time.DateTimeField dateTimeField67 = remainderDateTimeField44.getWrappedField();
//        long long69 = remainderDateTimeField44.roundHalfFloor((long) 1735);
//        long long71 = remainderDateTimeField44.roundCeiling((long) 9);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "24" + "'", str40.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019" + "'", str49.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(localDateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "24" + "'", str66.equals("24"));
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-14400000L) + "'", long69 == (-14400000L));
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 28800000L + "'", long71 == 28800000L);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime14 = dateTime6.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
        boolean boolean18 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.withCenturyOfEra(100);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime20);
        int int22 = gJChronology21.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.era();
        org.joda.time.DurationField durationField4 = copticChronology0.days();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        java.util.Locale locale3 = null;
        try {
            java.lang.String str4 = dateTime0.toString("2019-06-15T13:46:29.596-07:00", locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
//        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
//        org.joda.time.DateTime dateTime13 = dateTime11.minus((-8643599900L));
//        org.joda.time.LocalDate localDate14 = dateTime11.toLocalDate();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T13:47:18-07:00" + "'", str9.equals("T13:47:18-07:00"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDate14);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-28799968L));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", (java.lang.Number) 100, number2, (java.lang.Number) 100L);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "America/Los_Angeles" + "'", str6.equals("America/Los_Angeles"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime.Property property4 = dateTime0.minuteOfDay();
        java.lang.String str5 = property4.toString();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[minuteOfDay]" + "'", str5.equals("Property[minuteOfDay]"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime8 = dateTime0.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime10 = dateTime0.minusDays(0);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths(53);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField8 = copticChronology7.days();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology7.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField(chronology6, dateTimeField11);
        java.lang.String str14 = skipDateTimeField12.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
        java.lang.String str18 = property17.getAsString();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        org.joda.time.LocalDateTime localDateTime21 = dateTime19.toLocalDateTime();
        int int22 = property17.compareTo((org.joda.time.ReadablePartial) localDateTime21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
        org.joda.time.DateTime.Property property25 = dateTime23.weekyear();
        org.joda.time.DateTime.Property property26 = dateTime23.monthOfYear();
        org.joda.time.DateTime dateTime28 = dateTime23.minusMinutes(0);
        org.joda.time.DateTime dateTime30 = dateTime23.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime30.minus(readablePeriod31);
        org.joda.time.DateTime dateTime33 = localDateTime21.toDateTime((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTimeField[] dateTimeFieldArray34 = localDateTime21.getFields();
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipDateTimeField12.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType37);
        boolean boolean39 = dateTimeFormatterBuilder38.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder38.appendTwoDigitWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970" + "'", str18.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeFieldArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1" + "'", str36.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = gregorianChronology2.withZone(dateTimeZone5);
        boolean boolean8 = dateTimeZone5.isStandardOffset(127426950421L);
        int int10 = dateTimeZone5.getOffsetFromLocal((long) 1735);
        java.lang.String str11 = dateTimeZone5.getID();
        long long13 = dateTimeZone5.convertUTCToLocal((-1L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-28800001L) + "'", long13 == (-28800001L));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime.Property property4 = dateTime0.weekyear();
        java.lang.String str5 = property4.getAsText();
        java.lang.String str6 = property4.getName();
        boolean boolean7 = property4.isLeap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970" + "'", str5.equals("1970"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "weekyear" + "'", str6.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        long long4 = dateTimeZone1.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now(dateTimeZone1);
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-28799968L) + "'", long4 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.append(dateTimeFormatter9);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField13 = copticChronology12.days();
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology12.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology11, dateTimeField16);
        java.lang.String str19 = skipDateTimeField17.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property21 = dateTime20.yearOfEra();
        org.joda.time.DateTime.Property property22 = dateTime20.weekyear();
        java.lang.String str23 = property22.getAsString();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property25 = dateTime24.yearOfEra();
        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
        int int27 = property22.compareTo((org.joda.time.ReadablePartial) localDateTime26);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property29 = dateTime28.yearOfEra();
        org.joda.time.DateTime.Property property30 = dateTime28.weekyear();
        org.joda.time.DateTime.Property property31 = dateTime28.monthOfYear();
        org.joda.time.DateTime dateTime33 = dateTime28.minusMinutes(0);
        org.joda.time.DateTime dateTime35 = dateTime28.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime37 = dateTime35.minus(readablePeriod36);
        org.joda.time.DateTime dateTime38 = localDateTime26.toDateTime((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTimeField[] dateTimeFieldArray39 = localDateTime26.getFields();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDateTime26, locale40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField17.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType42);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType42, (int) 'a');
        org.joda.time.DurationField durationField46 = remainderDateTimeField45.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = remainderDateTimeField45.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField48 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970" + "'", str23.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTimeFieldArray39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNull(durationField46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime8 = dateTime0.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
        boolean boolean12 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateMidnight dateMidnight13 = dateTime0.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateMidnight13);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        boolean boolean4 = property2.equals((java.lang.Object) "T13:46:53-07:00");
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.weekyear();
        java.lang.String str6 = property5.getAsString();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.LocalDateTime localDateTime9 = dateTime7.toLocalDateTime();
        int int10 = property5.compareTo((org.joda.time.ReadablePartial) localDateTime9);
        int int11 = property1.compareTo((org.joda.time.ReadablePartial) localDateTime9);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: America/Los_Angeles");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
        org.joda.time.DateTime dateTime13 = dateTime11.minus((-8643599900L));
        int int14 = dateTime11.getMillisOfDay();
        org.joda.time.DateTime dateTime15 = dateTime11.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T08:00:00-08:00" + "'", str9.equals("T08:00:00-08:00"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 28800032 + "'", int14 == 28800032);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 10);
        int int8 = offsetDateTimeField7.getOffset();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
        java.lang.String str12 = property11.getAsString();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
        int[] intArray23 = new int[] { 53, (short) 0, 49591, 7, 4 };
        try {
            int[] intArray25 = offsetDateTimeField7.set((org.joda.time.ReadablePartial) localDateTime15, 131, intArray23, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3 for minuteOfHour must be in the range [10,69]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.era();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfCentury((int) '#', 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfHalfday(7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendYearOfCentury((int) ' ', 24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        boolean boolean3 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        java.lang.String str9 = localDateTime6.toString(dateTimeFormatter8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDateTime6.indexOf(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = dateTime0.withFields((org.joda.time.ReadablePartial) localDateTime6);
        org.joda.time.DateTime.Property property13 = dateTime12.era();
        java.lang.String str14 = property13.getName();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-365" + "'", str9.equals("1969-365"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "era" + "'", str14.equals("era"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
        java.lang.String str12 = property11.getAsString();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField6.getType();
        org.joda.time.DurationField durationField32 = skipDateTimeField6.getLeapDurationField();
        int int33 = skipDateTimeField6.getMinimumValue();
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField36 = copticChronology35.days();
        org.joda.time.DateTimeZone dateTimeZone37 = copticChronology35.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField(chronology34, dateTimeField39);
        java.lang.String str42 = skipDateTimeField40.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property44 = dateTime43.yearOfEra();
        org.joda.time.DateTime.Property property45 = dateTime43.weekyear();
        java.lang.String str46 = property45.getAsString();
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property48 = dateTime47.yearOfEra();
        org.joda.time.LocalDateTime localDateTime49 = dateTime47.toLocalDateTime();
        int int50 = property45.compareTo((org.joda.time.ReadablePartial) localDateTime49);
        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property52 = dateTime51.yearOfEra();
        org.joda.time.DateTime.Property property53 = dateTime51.weekyear();
        org.joda.time.DateTime.Property property54 = dateTime51.monthOfYear();
        org.joda.time.DateTime dateTime56 = dateTime51.minusMinutes(0);
        org.joda.time.DateTime dateTime58 = dateTime51.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod59 = null;
        org.joda.time.DateTime dateTime60 = dateTime58.minus(readablePeriod59);
        org.joda.time.DateTime dateTime61 = localDateTime49.toDateTime((org.joda.time.ReadableInstant) dateTime58);
        org.joda.time.DateTimeField[] dateTimeFieldArray62 = localDateTime49.getFields();
        java.util.Locale locale63 = null;
        java.lang.String str64 = skipDateTimeField40.getAsShortText((org.joda.time.ReadablePartial) localDateTime49, locale63);
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = skipDateTimeField40.getType();
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = gregorianChronology67.minuteOfHour();
        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property70 = dateTime69.yearOfEra();
        org.joda.time.LocalDateTime localDateTime71 = dateTime69.toLocalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = dateTimeFormatter72.withZoneUTC();
        java.lang.String str74 = localDateTime71.toString(dateTimeFormatter73);
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = null;
        int int76 = localDateTime71.indexOf(dateTimeFieldType75);
        int[] intArray78 = gregorianChronology67.get((org.joda.time.ReadablePartial) localDateTime71, (long) 12);
        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology80 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone79);
        org.joda.time.DateTimeField dateTimeField81 = gregorianChronology80.minuteOfHour();
        org.joda.time.DateTime dateTime82 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property83 = dateTime82.yearOfEra();
        org.joda.time.LocalDateTime localDateTime84 = dateTime82.toLocalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter85 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter86 = dateTimeFormatter85.withZoneUTC();
        java.lang.String str87 = localDateTime84.toString(dateTimeFormatter86);
        org.joda.time.DateTimeFieldType dateTimeFieldType88 = null;
        int int89 = localDateTime84.indexOf(dateTimeFieldType88);
        int[] intArray91 = gregorianChronology80.get((org.joda.time.ReadablePartial) localDateTime84, (long) 12);
        int int92 = skipDateTimeField40.getMaximumValue((org.joda.time.ReadablePartial) localDateTime71, intArray91);
        int int93 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDateTime71);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1" + "'", str30.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1" + "'", str42.equals("1"));
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1970" + "'", str46.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(localDateTime49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTimeFieldArray62);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "1" + "'", str64.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(localDateTime71);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertNotNull(dateTimeFormatter73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1969-365" + "'", str74.equals("1969-365"));
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertNotNull(gregorianChronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(dateTime82);
        org.junit.Assert.assertNotNull(property83);
        org.junit.Assert.assertNotNull(localDateTime84);
        org.junit.Assert.assertNotNull(dateTimeFormatter85);
        org.junit.Assert.assertNotNull(dateTimeFormatter86);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "1969-365" + "'", str87.equals("1969-365"));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 53 + "'", int92 == 53);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 53 + "'", int93 == 53);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        java.lang.String str3 = property2.getAsString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        int int7 = property2.compareTo((org.joda.time.ReadablePartial) localDateTime6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        int int11 = property2.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.append(dateTimeFormatter16);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField20 = copticChronology19.days();
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology19.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField(chronology18, dateTimeField23);
        java.lang.String str26 = skipDateTimeField24.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
        java.lang.String str30 = property29.getAsString();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property32 = dateTime31.yearOfEra();
        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
        int int34 = property29.compareTo((org.joda.time.ReadablePartial) localDateTime33);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property36 = dateTime35.yearOfEra();
        org.joda.time.DateTime.Property property37 = dateTime35.weekyear();
        org.joda.time.DateTime.Property property38 = dateTime35.monthOfYear();
        org.joda.time.DateTime dateTime40 = dateTime35.minusMinutes(0);
        org.joda.time.DateTime dateTime42 = dateTime35.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.DateTime dateTime44 = dateTime42.minus(readablePeriod43);
        org.joda.time.DateTime dateTime45 = localDateTime33.toDateTime((org.joda.time.ReadableInstant) dateTime42);
        org.joda.time.DateTimeField[] dateTimeFieldArray46 = localDateTime33.getFields();
        java.util.Locale locale47 = null;
        java.lang.String str48 = skipDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) localDateTime33, locale47);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = skipDateTimeField24.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType49);
        int int51 = dateTime10.get(dateTimeFieldType49);
        org.joda.time.MutableDateTime mutableDateTime52 = dateTime10.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970" + "'", str3.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970" + "'", str30.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeFieldArray46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 52 + "'", int51 == 52);
        org.junit.Assert.assertNotNull(mutableDateTime52);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = property2.addToCopy(57599);
        boolean boolean6 = buddhistChronology0.equals((java.lang.Object) 57599);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.Chronology chronology11 = buddhistChronology0.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("24", false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        try {
            org.joda.time.MonthDay monthDay4 = property2.setCopy(59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        java.util.Date date4 = dateTime0.toDate();
        try {
            org.joda.time.DateTime dateTime6 = dateTime0.withEra(24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.withYear(100);
        java.util.Date date5 = dateTime2.toDate();
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.fromDateFields(date5);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField9.getAsShortText((int) (short) 10, locale11);
        java.lang.String str14 = skipUndoDateTimeField9.getAsShortText((long) (byte) 100);
        org.joda.time.DurationField durationField15 = skipUndoDateTimeField9.getRangeDurationField();
        int int17 = skipUndoDateTimeField9.getMinimumValue((long) 52);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PM" + "'", str14.equals("PM"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.era();
        org.joda.time.DurationField durationField5 = copticChronology1.years();
        org.joda.time.DurationField durationField6 = copticChronology1.months();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = gregorianChronology8.weekyears();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField10 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField6, durationField9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfEra();
        org.joda.time.DateTime.Property property13 = dateTime11.weekyear();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime11.getZone();
        org.joda.time.DateTime.Property property15 = dateTime11.minuteOfDay();
        boolean boolean16 = dateTime10.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime17 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.LocalTime localTime18 = dateTime11.toLocalTime();
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) localTime18, locale19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField4 = julianChronology1.eras();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = gregorianChronology4.withZone(dateTimeZone5);
        long long11 = gregorianChronology4.getDateTimeMillis(57699, 3, 6, 11);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.monthOfYear();
        try {
            org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((int) ' ', 9, (org.joda.time.Chronology) gregorianChronology4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1758642998400011L + "'", long11 == 1758642998400011L);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
        java.lang.String str12 = property11.getAsString();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipDateTimeField6.getAsShortText((long) (short) 0, locale32);
        java.util.Locale locale34 = null;
        int int35 = skipDateTimeField6.getMaximumTextLength(locale34);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1" + "'", str30.equals("1"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.clockhourOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = copticChronology0.add(readablePeriod2, (long) 49600, (int) (short) 1);
        org.joda.time.DurationField durationField6 = copticChronology0.weekyears();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 49600L + "'", long5 == 49600L);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        int int5 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        java.lang.String str3 = property2.getAsString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        int int7 = property2.compareTo((org.joda.time.ReadablePartial) localDateTime6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        int int11 = property2.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.append(dateTimeFormatter16);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField20 = copticChronology19.days();
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology19.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField(chronology18, dateTimeField23);
        java.lang.String str26 = skipDateTimeField24.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
        java.lang.String str30 = property29.getAsString();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property32 = dateTime31.yearOfEra();
        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
        int int34 = property29.compareTo((org.joda.time.ReadablePartial) localDateTime33);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property36 = dateTime35.yearOfEra();
        org.joda.time.DateTime.Property property37 = dateTime35.weekyear();
        org.joda.time.DateTime.Property property38 = dateTime35.monthOfYear();
        org.joda.time.DateTime dateTime40 = dateTime35.minusMinutes(0);
        org.joda.time.DateTime dateTime42 = dateTime35.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.DateTime dateTime44 = dateTime42.minus(readablePeriod43);
        org.joda.time.DateTime dateTime45 = localDateTime33.toDateTime((org.joda.time.ReadableInstant) dateTime42);
        org.joda.time.DateTimeField[] dateTimeFieldArray46 = localDateTime33.getFields();
        java.util.Locale locale47 = null;
        java.lang.String str48 = skipDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) localDateTime33, locale47);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = skipDateTimeField24.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType49);
        int int51 = dateTime10.get(dateTimeFieldType49);
        int int52 = dateTime10.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970" + "'", str3.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970" + "'", str30.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeFieldArray46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 52 + "'", int51 == 52);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 6 + "'", int52 == 6);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime13 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property14 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime16 = property14.addToCopy((long) (short) 10);
        boolean boolean17 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime16);
        java.util.GregorianCalendar gregorianCalendar18 = dateTime5.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar18);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(28800032);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        boolean boolean3 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime5 = dateTime0.minusYears(31);
        int int6 = dateTime5.getMinuteOfDay();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        org.joda.time.DateTime.Property property10 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime12 = dateTime7.minusMinutes(0);
        org.joda.time.DateTime dateTime14 = dateTime7.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str16 = dateTime7.toString(dateTimeFormatter15);
        org.joda.time.DateTime dateTime18 = dateTime7.withEra(0);
        org.joda.time.DateTime dateTime20 = dateTime18.minus((-8643599900L));
        org.joda.time.DateTime dateTime22 = dateTime18.plus(1758642998400011L);
        boolean boolean23 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime25 = dateTime5.minusMonths((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 480 + "'", int6 == 480);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "T08:00:00-08:00" + "'", str16.equals("T08:00:00-08:00"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', 34, 24, 0, 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 57699, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 57647L + "'", long2 == 57647L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField12 = copticChronology11.days();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
        java.lang.String str22 = property21.getAsString();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property47 = dateTime46.yearOfEra();
        org.joda.time.DateTime.Property property48 = dateTime46.weekyear();
        java.lang.String str49 = property48.getAsString();
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property51 = dateTime50.yearOfEra();
        org.joda.time.LocalDateTime localDateTime52 = dateTime50.toLocalDateTime();
        int int53 = property48.compareTo((org.joda.time.ReadablePartial) localDateTime52);
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property55 = dateTime54.yearOfEra();
        org.joda.time.DateTime.Property property56 = dateTime54.weekyear();
        org.joda.time.DateTime.Property property57 = dateTime54.monthOfYear();
        org.joda.time.DateTime dateTime59 = dateTime54.minusMinutes(0);
        org.joda.time.DateTime dateTime61 = dateTime54.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.DateTime dateTime63 = dateTime61.minus(readablePeriod62);
        org.joda.time.DateTime dateTime64 = localDateTime52.toDateTime((org.joda.time.ReadableInstant) dateTime61);
        java.util.Locale locale65 = null;
        java.lang.String str66 = remainderDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) localDateTime52, locale65);
        org.joda.time.DateTimeField dateTimeField67 = remainderDateTimeField44.getWrappedField();
        java.util.Locale locale69 = null;
        java.lang.String str70 = remainderDateTimeField44.getAsShortText((long) (short) 1, locale69);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1970" + "'", str49.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(localDateTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1" + "'", str66.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1" + "'", str70.equals("1"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime.Property property4 = dateTime0.weekyear();
        java.lang.String str5 = property4.getAsText();
        int int6 = property4.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970" + "'", str5.equals("1970"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
        java.lang.String str12 = property11.getAsString();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField6.getType();
        int int34 = skipDateTimeField6.getDifference((long) 15, (long) 6);
        java.lang.String str36 = skipDateTimeField6.getAsShortText((long) 2);
        boolean boolean37 = skipDateTimeField6.isSupported();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1" + "'", str30.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1" + "'", str36.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
        java.lang.String str12 = property11.getAsString();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField6.getType();
        java.util.TimeZone timeZone32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
        java.lang.String str34 = dateTimeZone33.getID();
        long long36 = dateTimeZone33.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now(dateTimeZone33);
        org.joda.time.MonthDay monthDay38 = org.joda.time.MonthDay.now(dateTimeZone33);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.MonthDay monthDay40 = monthDay38.minus(readablePeriod39);
        org.joda.time.MonthDay monthDay42 = monthDay38.withMonthOfYear((int) (byte) 10);
        int[] intArray44 = null;
        try {
            int[] intArray46 = skipDateTimeField6.addWrapField((org.joda.time.ReadablePartial) monthDay38, 34, intArray44, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1" + "'", str30.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "America/Los_Angeles" + "'", str34.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-28799968L) + "'", long36 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(monthDay42);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 10);
        long long9 = offsetDateTimeField7.roundHalfFloor((long) 59);
        long long11 = offsetDateTimeField7.roundHalfFloor((long) 57699);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 60000L + "'", long11 == 60000L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
        java.lang.String str12 = property11.getAsString();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipDateTimeField6.getAsShortText((long) (short) 0, locale32);
        org.joda.time.ReadablePartial readablePartial34 = null;
        java.util.Locale locale35 = null;
        try {
            java.lang.String str36 = skipDateTimeField6.getAsShortText(readablePartial34, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1" + "'", str30.equals("1"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
        java.lang.String str12 = property11.getAsString();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField6.getType();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.minuteOfHour();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property36 = dateTime35.yearOfEra();
        org.joda.time.LocalDateTime localDateTime37 = dateTime35.toLocalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = dateTimeFormatter38.withZoneUTC();
        java.lang.String str40 = localDateTime37.toString(dateTimeFormatter39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = null;
        int int42 = localDateTime37.indexOf(dateTimeFieldType41);
        int[] intArray44 = gregorianChronology33.get((org.joda.time.ReadablePartial) localDateTime37, (long) 12);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone45);
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology46.minuteOfHour();
        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property49 = dateTime48.yearOfEra();
        org.joda.time.LocalDateTime localDateTime50 = dateTime48.toLocalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = dateTimeFormatter51.withZoneUTC();
        java.lang.String str53 = localDateTime50.toString(dateTimeFormatter52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
        int int55 = localDateTime50.indexOf(dateTimeFieldType54);
        int[] intArray57 = gregorianChronology46.get((org.joda.time.ReadablePartial) localDateTime50, (long) 12);
        int int58 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDateTime37, intArray57);
        int int60 = skipDateTimeField6.get(0L);
        java.lang.String str61 = skipDateTimeField6.getName();
        java.util.Locale locale64 = null;
        try {
            long long65 = skipDateTimeField6.set(0L, "15:59:59-08:00", locale64);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"15:59:59-08:00\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1" + "'", str30.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(localDateTime37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1969-365" + "'", str40.equals("1969-365"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(localDateTime50);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1969-365" + "'", str53.equals("1969-365"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 53 + "'", int58 == 53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "weekOfWeekyear" + "'", str61.equals("weekOfWeekyear"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder5.toPrinter();
        boolean boolean7 = dateTimeFormatterBuilder5.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
        int int5 = property4.getMinimumValueOverall();
        org.joda.time.DateTime dateTime7 = property4.setCopy((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.withEra((int) (short) 0);
        org.joda.time.DateTime dateTime11 = dateTime7.minus(0L);
        org.joda.time.DateTime dateTime13 = dateTime7.plusHours(11);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.halfdayOfDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField7 = copticChronology6.days();
        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology6.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField(chronology5, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        org.joda.time.DateTime.Property property16 = dateTime14.weekyear();
        java.lang.String str17 = property16.getAsString();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
        org.joda.time.LocalDateTime localDateTime20 = dateTime18.toLocalDateTime();
        int int21 = property16.compareTo((org.joda.time.ReadablePartial) localDateTime20);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfEra();
        org.joda.time.DateTime.Property property24 = dateTime22.weekyear();
        org.joda.time.DateTime.Property property25 = dateTime22.monthOfYear();
        org.joda.time.DateTime dateTime27 = dateTime22.minusMinutes(0);
        org.joda.time.DateTime dateTime29 = dateTime22.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.minus(readablePeriod30);
        org.joda.time.DateTime dateTime32 = localDateTime20.toDateTime((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTimeField[] dateTimeFieldArray33 = localDateTime20.getFields();
        java.util.Locale locale34 = null;
        java.lang.String str35 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime20, locale34);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipDateTimeField11.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType36);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, "(\"org.joda.time.JodaTimePermission\" \"2019\")");
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField40 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970" + "'", str17.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeFieldArray33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1" + "'", str35.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime8 = dateTime0.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = dateTime0.toDateTime(dateTimeZone9);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long5 = julianChronology0.getDateTimeMillis((int) (short) 100, 49627, 15, 49600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49627 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("15:59:59-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"15:59:59-08:00\" is malformed at \":59:59-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology6 = buddhistChronology5.withUTC();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10, 12, 10, (int) (short) 100, 52, (org.joda.time.Chronology) buddhistChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField12 = copticChronology11.days();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
        java.lang.String str22 = property21.getAsString();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property47 = dateTime46.yearOfEra();
        org.joda.time.DateTime.Property property48 = dateTime46.weekyear();
        java.lang.String str49 = property48.getAsString();
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property51 = dateTime50.yearOfEra();
        org.joda.time.LocalDateTime localDateTime52 = dateTime50.toLocalDateTime();
        int int53 = property48.compareTo((org.joda.time.ReadablePartial) localDateTime52);
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property55 = dateTime54.yearOfEra();
        org.joda.time.DateTime.Property property56 = dateTime54.weekyear();
        org.joda.time.DateTime.Property property57 = dateTime54.monthOfYear();
        org.joda.time.DateTime dateTime59 = dateTime54.minusMinutes(0);
        org.joda.time.DateTime dateTime61 = dateTime54.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.DateTime dateTime63 = dateTime61.minus(readablePeriod62);
        org.joda.time.DateTime dateTime64 = localDateTime52.toDateTime((org.joda.time.ReadableInstant) dateTime61);
        java.util.Locale locale65 = null;
        java.lang.String str66 = remainderDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) localDateTime52, locale65);
        java.lang.String str67 = remainderDateTimeField44.toString();
        long long69 = remainderDateTimeField44.roundCeiling(49600L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1970" + "'", str49.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(localDateTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1" + "'", str66.equals("1"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str67.equals("DateTimeField[weekOfWeekyear]"));
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 28800000L + "'", long69 == 28800000L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime8 = dateTime0.withMonthOfYear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readablePeriod9);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(49591);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(57599, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.append(dateTimeFormatter12);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatterBuilder13.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder2.append(dateTimePrinter14, dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(166);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 100.0d, (java.lang.Number) 6, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.field.FieldUtils.verifyValueBounds("PST", (int) (byte) 1, 0, 57699);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 86399);
        org.joda.time.DateTime dateTime2 = instant1.toDateTimeISO();
        org.joda.time.DateTime dateTime4 = dateTime2.plusDays(7);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField13 = copticChronology12.days();
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology12.halfdayOfDay();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField18 = copticChronology17.days();
        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology17.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField21);
        java.lang.String str24 = skipDateTimeField22.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
        org.joda.time.DateTime.Property property27 = dateTime25.weekyear();
        java.lang.String str28 = property27.getAsString();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
        int int32 = property27.compareTo((org.joda.time.ReadablePartial) localDateTime31);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property34 = dateTime33.yearOfEra();
        org.joda.time.DateTime.Property property35 = dateTime33.weekyear();
        org.joda.time.DateTime.Property property36 = dateTime33.monthOfYear();
        org.joda.time.DateTime dateTime38 = dateTime33.minusMinutes(0);
        org.joda.time.DateTime dateTime40 = dateTime33.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.minus(readablePeriod41);
        org.joda.time.DateTime dateTime43 = localDateTime31.toDateTime((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTimeField[] dateTimeFieldArray44 = localDateTime31.getFields();
        java.util.Locale locale45 = null;
        java.lang.String str46 = skipDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDateTime31, locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField22.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType47, 0, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType47, 11, 49591);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField56 = copticChronology55.days();
        org.joda.time.DateTimeZone dateTimeZone57 = copticChronology55.getZone();
        org.joda.time.DateTimeField dateTimeField58 = copticChronology55.era();
        org.joda.time.DurationField durationField59 = copticChronology55.years();
        long long62 = durationField59.subtract((long) 31, (long) '#');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField59);
        try {
            int int65 = unsupportedDateTimeField63.getLeapAmount((long) 49632681);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeFieldArray44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-1104537599969L) + "'", long62 == (-1104537599969L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("monthOfYear", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
        java.lang.String str2 = monthDay1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "--12-31" + "'", str2.equals("--12-31"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone13.getName((long) 34, locale15);
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime0.toMutableDateTime(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T08:00:00-08:00" + "'", str9.equals("T08:00:00-08:00"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+97:00" + "'", str16.equals("+97:00"));
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        boolean boolean3 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.Chronology chronology4 = dateTime0.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime0.minusYears((int) (byte) 0);
        boolean boolean7 = dateTime0.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField12 = copticChronology11.days();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
        java.lang.String str22 = property21.getAsString();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
        long long46 = remainderDateTimeField44.roundHalfCeiling(0L);
        java.util.Locale locale48 = null;
        java.lang.String str49 = remainderDateTimeField44.getAsText((int) (byte) 100, locale48);
        int int50 = remainderDateTimeField44.getMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-14400000L) + "'", long46 == (-14400000L));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "100" + "'", str49.equals("100"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 96 + "'", int50 == 96);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now(dateTimeZone1);
        java.lang.String str5 = monthDay4.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "--12-31" + "'", str5.equals("--12-31"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
        int int5 = property4.getMinimumValueOverall();
        int int6 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime9 = dateTime7.withEarlierOffsetAtOverlap();
        int int10 = property4.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime12 = dateTime9.plusYears(1);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
        boolean boolean17 = dateTime9.equals((java.lang.Object) dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks(6);
        org.joda.time.DateTime.Property property8 = dateTime5.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.weekOfWeekyear();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField6 = copticChronology5.days();
        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology5.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology9 = iSOChronology8.withUTC();
        boolean boolean10 = iSOChronology3.equals((java.lang.Object) iSOChronology8);
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField16 = copticChronology15.days();
        org.joda.time.DateTimeZone dateTimeZone17 = copticChronology15.getZone();
        org.joda.time.DateTimeField dateTimeField18 = copticChronology15.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology13, dateTimeField18, (int) (byte) 100);
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.hourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology13, dateTimeField24);
        java.util.TimeZone timeZone26 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
        org.joda.time.Chronology chronology28 = gregorianChronology13.withZone(dateTimeZone27);
        org.joda.time.Chronology chronology29 = iSOChronology3.withZone(dateTimeZone27);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.era();
        org.joda.time.DurationField durationField4 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.minuteOfHour();
        java.lang.String str6 = copticChronology0.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str6.equals("CopticChronology[America/Los_Angeles]"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        int int8 = dateTime0.getEra();
        org.joda.time.LocalTime localTime9 = dateTime0.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(localTime9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property2.addToCopy(86399);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay6 = monthDay4.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField8 = copticChronology7.days();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology7.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.append(dateTimeFormatter15);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField19 = copticChronology18.days();
        org.joda.time.DateTimeZone dateTimeZone20 = copticChronology18.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField(chronology17, dateTimeField22);
        java.lang.String str25 = skipDateTimeField23.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property27 = dateTime26.yearOfEra();
        org.joda.time.DateTime.Property property28 = dateTime26.weekyear();
        java.lang.String str29 = property28.getAsString();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property31 = dateTime30.yearOfEra();
        org.joda.time.LocalDateTime localDateTime32 = dateTime30.toLocalDateTime();
        int int33 = property28.compareTo((org.joda.time.ReadablePartial) localDateTime32);
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property35 = dateTime34.yearOfEra();
        org.joda.time.DateTime.Property property36 = dateTime34.weekyear();
        org.joda.time.DateTime.Property property37 = dateTime34.monthOfYear();
        org.joda.time.DateTime dateTime39 = dateTime34.minusMinutes(0);
        org.joda.time.DateTime dateTime41 = dateTime34.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.DateTime dateTime43 = dateTime41.minus(readablePeriod42);
        org.joda.time.DateTime dateTime44 = localDateTime32.toDateTime((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTimeField[] dateTimeFieldArray45 = localDateTime32.getFields();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) localDateTime32, locale46);
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = skipDateTimeField23.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType48);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField51 = new org.joda.time.field.RemainderDateTimeField(dateTimeField10, dateTimeFieldType48, (int) 'a');
        org.joda.time.DurationField durationField52 = remainderDateTimeField51.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = remainderDateTimeField51.getType();
        try {
            org.joda.time.MonthDay monthDay55 = monthDay4.withField(dateTimeFieldType53, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1" + "'", str25.equals("1"));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970" + "'", str29.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTimeFieldArray45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1" + "'", str47.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
        org.joda.time.DateTime.Property property12 = dateTime0.centuryOfEra();
        java.util.GregorianCalendar gregorianCalendar13 = dateTime0.toGregorianCalendar();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology18 = gregorianChronology16.withZone(dateTimeZone17);
        long long23 = gregorianChronology16.getDateTimeMillis(57699, 3, 6, 11);
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        java.lang.String str26 = dateTimeZone25.getID();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
        java.lang.String str30 = property29.getAsString();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property32 = dateTime31.yearOfEra();
        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
        int int34 = property29.compareTo((org.joda.time.ReadablePartial) localDateTime33);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property36 = dateTime35.yearOfEra();
        org.joda.time.DateTime.Property property37 = dateTime35.weekyear();
        org.joda.time.DateTime.Property property38 = dateTime35.monthOfYear();
        org.joda.time.DateTime dateTime40 = dateTime35.minusMinutes(0);
        org.joda.time.DateTime dateTime42 = dateTime35.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.DateTime dateTime44 = dateTime42.minus(readablePeriod43);
        org.joda.time.DateTime dateTime45 = localDateTime33.toDateTime((org.joda.time.ReadableInstant) dateTime42);
        org.joda.time.DateTime dateTime48 = dateTime42.withDurationAdded(0L, 0);
        int int49 = dateTimeZone25.getOffset((org.joda.time.ReadableInstant) dateTime48);
        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology16, dateTimeZone25);
        org.joda.time.DateTime dateTime51 = dateTime0.withZoneRetainFields(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T08:00:00-08:00" + "'", str9.equals("T08:00:00-08:00"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gregorianCalendar13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1758642998400011L + "'", long23 == 1758642998400011L);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "America/Los_Angeles" + "'", str26.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970" + "'", str30.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-25200000) + "'", int49 == (-25200000));
        org.junit.Assert.assertNotNull(zonedChronology50);
        org.junit.Assert.assertNotNull(dateTime51);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("15:59:59-08:00", dateTimeFormatter1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendWeekyear(57599, 31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatterBuilder3.toFormatter();
        try {
            org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.parse("2019-06-15T13:46:40.771-07:00", dateTimeFormatter7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15T13:46:40.771-07:00\" is malformed at \"-15T13:46:40.771-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay3 = monthDay1.minus(readablePeriod2);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime6.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str15 = dateTime6.toString(dateTimeFormatter14);
        org.joda.time.DateTime dateTime17 = dateTime6.withEra(0);
        org.joda.time.DateTime dateTime19 = dateTime17.minus((-8643599900L));
        long long20 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
        try {
            org.joda.time.DateTime dateTime25 = dateTime17.withTime(166, 131, 31, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T08:00:00-08:00" + "'", str15.equals("T08:00:00-08:00"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 124271280422L + "'", long20 == 124271280422L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
        org.joda.time.DateTime dateTime12 = dateTime11.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T08:00:00-08:00" + "'", str9.equals("T08:00:00-08:00"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.append(dateTimePrinter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendWeekyear(57599, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.append(dateTimeFormatter18);
        org.joda.time.format.DateTimePrinter dateTimePrinter20 = dateTimeFormatterBuilder19.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder8.append(dateTimePrinter20, dateTimeParser22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendYear(4, 15);
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField29 = copticChronology28.days();
        org.joda.time.DateTimeZone dateTimeZone30 = copticChronology28.getZone();
        org.joda.time.DateTimeField dateTimeField31 = copticChronology28.halfdayOfDay();
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField34 = copticChronology33.days();
        org.joda.time.DateTimeZone dateTimeZone35 = copticChronology33.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField(chronology32, dateTimeField37);
        java.lang.String str40 = skipDateTimeField38.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property42 = dateTime41.yearOfEra();
        org.joda.time.DateTime.Property property43 = dateTime41.weekyear();
        java.lang.String str44 = property43.getAsString();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property46 = dateTime45.yearOfEra();
        org.joda.time.LocalDateTime localDateTime47 = dateTime45.toLocalDateTime();
        int int48 = property43.compareTo((org.joda.time.ReadablePartial) localDateTime47);
        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property50 = dateTime49.yearOfEra();
        org.joda.time.DateTime.Property property51 = dateTime49.weekyear();
        org.joda.time.DateTime.Property property52 = dateTime49.monthOfYear();
        org.joda.time.DateTime dateTime54 = dateTime49.minusMinutes(0);
        org.joda.time.DateTime dateTime56 = dateTime49.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.DateTime dateTime58 = dateTime56.minus(readablePeriod57);
        org.joda.time.DateTime dateTime59 = localDateTime47.toDateTime((org.joda.time.ReadableInstant) dateTime56);
        org.joda.time.DateTimeField[] dateTimeFieldArray60 = localDateTime47.getFields();
        java.util.Locale locale61 = null;
        java.lang.String str62 = skipDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) localDateTime47, locale61);
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = skipDateTimeField38.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField64 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31, dateTimeFieldType63);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder27.appendFraction(dateTimeFieldType63, 0, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder27.appendYear(166, (int) (short) 1);
        org.joda.time.format.DateTimeParser dateTimeParser71 = dateTimeFormatterBuilder70.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder5.append(dateTimePrinter20, dateTimeParser71);
        org.joda.time.format.DateTimePrinter dateTimePrinter73 = dateTimeFormatterBuilder5.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimePrinter20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1970" + "'", str44.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(localDateTime47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTimeFieldArray60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1" + "'", str62.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
        org.junit.Assert.assertNotNull(dateTimeParser71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
        org.junit.Assert.assertNotNull(dateTimePrinter73);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField13 = copticChronology12.days();
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology12.halfdayOfDay();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField18 = copticChronology17.days();
        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology17.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField21);
        java.lang.String str24 = skipDateTimeField22.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
        org.joda.time.DateTime.Property property27 = dateTime25.weekyear();
        java.lang.String str28 = property27.getAsString();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
        int int32 = property27.compareTo((org.joda.time.ReadablePartial) localDateTime31);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property34 = dateTime33.yearOfEra();
        org.joda.time.DateTime.Property property35 = dateTime33.weekyear();
        org.joda.time.DateTime.Property property36 = dateTime33.monthOfYear();
        org.joda.time.DateTime dateTime38 = dateTime33.minusMinutes(0);
        org.joda.time.DateTime dateTime40 = dateTime33.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.minus(readablePeriod41);
        org.joda.time.DateTime dateTime43 = localDateTime31.toDateTime((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTimeField[] dateTimeFieldArray44 = localDateTime31.getFields();
        java.util.Locale locale45 = null;
        java.lang.String str46 = skipDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDateTime31, locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField22.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType47, 0, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType47, 11, 49591);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField56 = copticChronology55.days();
        org.joda.time.DateTimeZone dateTimeZone57 = copticChronology55.getZone();
        org.joda.time.DateTimeField dateTimeField58 = copticChronology55.era();
        org.joda.time.DurationField durationField59 = copticChronology55.years();
        long long62 = durationField59.subtract((long) 31, (long) '#');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField59);
        try {
            long long65 = unsupportedDateTimeField63.roundHalfEven((long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeFieldArray44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-1104537599969L) + "'", long62 == (-1104537599969L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField12 = copticChronology11.days();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
        java.lang.String str22 = property21.getAsString();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property47 = dateTime46.yearOfEra();
        org.joda.time.DateTime.Property property48 = dateTime46.weekyear();
        java.lang.String str49 = property48.getAsString();
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property51 = dateTime50.yearOfEra();
        org.joda.time.LocalDateTime localDateTime52 = dateTime50.toLocalDateTime();
        int int53 = property48.compareTo((org.joda.time.ReadablePartial) localDateTime52);
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property55 = dateTime54.yearOfEra();
        org.joda.time.DateTime.Property property56 = dateTime54.weekyear();
        org.joda.time.DateTime.Property property57 = dateTime54.monthOfYear();
        org.joda.time.DateTime dateTime59 = dateTime54.minusMinutes(0);
        org.joda.time.DateTime dateTime61 = dateTime54.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.DateTime dateTime63 = dateTime61.minus(readablePeriod62);
        org.joda.time.DateTime dateTime64 = localDateTime52.toDateTime((org.joda.time.ReadableInstant) dateTime61);
        java.util.Locale locale65 = null;
        java.lang.String str66 = remainderDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) localDateTime52, locale65);
        org.joda.time.DateTimeField dateTimeField67 = remainderDateTimeField44.getWrappedField();
        java.lang.String str69 = remainderDateTimeField44.getAsText((long) 6);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1970" + "'", str49.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(localDateTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1" + "'", str66.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "1" + "'", str69.equals("1"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property2.addToCopy(999);
        int int5 = property2.getMinimumValueOverall();
        java.util.Locale locale6 = null;
        int int7 = property2.getMaximumTextLength(locale6);
        int int8 = property2.getMaximumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        java.lang.String str8 = dateTimeZone7.getID();
        long long10 = dateTimeZone7.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(57699, (int) (byte) -1, 24, (int) (byte) 1, (int) (byte) 100, 31, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28799968L) + "'", long10 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay11);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
        org.joda.time.DateTime dateTime13 = dateTime11.minus((-8643599900L));
        org.joda.time.DateTime dateTime15 = dateTime11.plus(1758642998400011L);
        int int16 = dateTime15.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T08:00:00-08:00" + "'", str9.equals("T08:00:00-08:00"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 952 + "'", int16 == 952);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
        org.joda.time.DateTime.Property property12 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime13 = property12.roundCeilingCopy();
        org.joda.time.DateTime.Property property14 = dateTime13.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T08:00:00-08:00" + "'", str9.equals("T08:00:00-08:00"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(2, 57599);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 115198 + "'", int2 == 115198);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        int int5 = monthDay3.size();
        boolean boolean6 = julianChronology0.equals((java.lang.Object) int5);
        org.joda.time.Chronology chronology7 = julianChronology0.withUTC();
        org.joda.time.DurationField durationField8 = julianChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = julianChronology0.withZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime1.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property6 = dateTime1.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfFloorCopy();
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "080000-0800" + "'", str8.equals("080000-0800"));
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
//        java.lang.String str5 = dateTimeZone2.getName((long) (short) 10);
//        org.joda.time.Chronology chronology6 = copticChronology0.withZone(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField7 = null;
//        try {
//            org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology6, dateTimeField7, 28800032);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology6);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 10);
        long long9 = offsetDateTimeField7.roundHalfFloor((long) 59);
        long long12 = offsetDateTimeField7.add(1758642998400011L, 100);
        long long14 = offsetDateTimeField7.roundFloor(10L);
        try {
            long long17 = offsetDateTimeField7.set(2876L, 115198);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 115198 for minuteOfHour must be in the range [10,69]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1758643004400011L + "'", long12 == 1758643004400011L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField12 = copticChronology11.days();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
        java.lang.String str22 = property21.getAsString();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
        long long46 = remainderDateTimeField44.roundHalfCeiling(0L);
        long long49 = remainderDateTimeField44.add((long) 6, 28800000L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-14400000L) + "'", long46 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1244160000000006L + "'", long49 == 1244160000000006L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 3, (long) 86399);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 259197L + "'", long2 == 259197L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        boolean boolean3 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.Chronology chronology4 = dateTime0.getChronology();
        org.joda.time.DateTime dateTime6 = dateTime0.minusYears((int) (byte) 0);
        org.joda.time.DateTime dateTime7 = dateTime6.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime.Property property4 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField12 = copticChronology11.days();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
        java.lang.String str22 = property21.getAsString();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
        int int45 = remainderDateTimeField44.getMinimumValue();
        long long48 = remainderDateTimeField44.add((long) 57599, (long) 0);
        long long50 = remainderDateTimeField44.remainder((-28799968L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 57599L + "'", long48 == 57599L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 28800032L + "'", long50 == 28800032L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        int int8 = property5.getMaximumValueOverall();
        int int9 = property5.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86399 + "'", int8 == 86399);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399 + "'", int9 == 86399);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(0, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendCenturyOfEra(0, 49600);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.appendSecondOfDay(49627);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.era();
        org.joda.time.DurationField durationField4 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.year();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
        org.joda.time.DateTime.Property property12 = dateTime0.centuryOfEra();
        java.util.GregorianCalendar gregorianCalendar13 = dateTime0.toGregorianCalendar();
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar13);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T08:00:00-08:00" + "'", str9.equals("T08:00:00-08:00"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gregorianCalendar13);
        org.junit.Assert.assertNotNull(monthDay14);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
        org.joda.time.DateTime.Property property12 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime13 = property12.roundCeilingCopy();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay monthDay17 = monthDay15.plusDays(365);
        org.joda.time.DateTime dateTime18 = dateTime13.withFields((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.DateTime dateTime21 = dateTime18.withDurationAdded(26287L, 57599);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T08:00:00-08:00" + "'", str9.equals("T08:00:00-08:00"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 10);
        long long9 = offsetDateTimeField7.roundHalfFloor((long) 59);
        long long12 = offsetDateTimeField7.add(1758642998400011L, 100);
        long long14 = offsetDateTimeField7.roundFloor(10L);
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getLeapDurationField();
        long long17 = offsetDateTimeField7.roundCeiling((long) (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1758643004400011L + "'", long12 == 1758643004400011L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800000L) + "'", long17 == (-28800000L));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime6.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str15 = dateTime6.toString(dateTimeFormatter14);
        org.joda.time.DateTime dateTime17 = dateTime6.withEra(0);
        org.joda.time.DateTime dateTime19 = dateTime17.minus((-8643599900L));
        long long20 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
        java.lang.String str21 = property5.toString();
        org.joda.time.DateTime dateTime22 = property5.withMinimumValue();
        org.joda.time.Interval interval23 = property5.toInterval();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T08:00:00-08:00" + "'", str15.equals("T08:00:00-08:00"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 124271280422L + "'", long20 == 124271280422L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Property[secondOfDay]" + "'", str21.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(interval23);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
        int int5 = dateTime0.getDayOfWeek();
        org.joda.time.DateTime.Property property6 = dateTime0.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        java.lang.String str3 = property2.getAsString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        int int7 = property2.compareTo((org.joda.time.ReadablePartial) localDateTime6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        int int11 = property2.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.append(dateTimeFormatter16);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField20 = copticChronology19.days();
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology19.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField(chronology18, dateTimeField23);
        java.lang.String str26 = skipDateTimeField24.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
        java.lang.String str30 = property29.getAsString();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property32 = dateTime31.yearOfEra();
        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
        int int34 = property29.compareTo((org.joda.time.ReadablePartial) localDateTime33);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property36 = dateTime35.yearOfEra();
        org.joda.time.DateTime.Property property37 = dateTime35.weekyear();
        org.joda.time.DateTime.Property property38 = dateTime35.monthOfYear();
        org.joda.time.DateTime dateTime40 = dateTime35.minusMinutes(0);
        org.joda.time.DateTime dateTime42 = dateTime35.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.DateTime dateTime44 = dateTime42.minus(readablePeriod43);
        org.joda.time.DateTime dateTime45 = localDateTime33.toDateTime((org.joda.time.ReadableInstant) dateTime42);
        org.joda.time.DateTimeField[] dateTimeFieldArray46 = localDateTime33.getFields();
        java.util.Locale locale47 = null;
        java.lang.String str48 = skipDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) localDateTime33, locale47);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = skipDateTimeField24.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType49);
        int int51 = dateTime10.get(dateTimeFieldType49);
        java.util.TimeZone timeZone52 = null;
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forTimeZone(timeZone52);
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone53);
        int int55 = gregorianChronology54.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology56 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField57 = copticChronology56.days();
        org.joda.time.DateTimeZone dateTimeZone58 = copticChronology56.getZone();
        org.joda.time.DateTimeField dateTimeField59 = copticChronology56.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology54, dateTimeField59, (int) (byte) 100);
        java.util.Locale locale63 = null;
        java.lang.String str64 = skipUndoDateTimeField61.getAsShortText((int) (short) 10, locale63);
        java.lang.String str66 = skipUndoDateTimeField61.getAsShortText((long) (byte) 100);
        org.joda.time.DurationField durationField67 = skipUndoDateTimeField61.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType49, durationField67);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970" + "'", str3.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970" + "'", str30.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeFieldArray46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 52 + "'", int51 == 52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertNotNull(copticChronology56);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "PM" + "'", str66.equals("PM"));
        org.junit.Assert.assertNotNull(durationField67);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
//        java.lang.String str5 = dateTimeZone2.getName((long) (short) 10);
//        org.joda.time.Chronology chronology6 = copticChronology0.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime7.toMutableDateTimeISO();
//        java.lang.String str12 = mutableDateTime11.toString();
//        int int13 = mutableDateTime11.getMonthOfYear();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
//        org.joda.time.DateTime.Property property16 = dateTime14.weekyear();
//        org.joda.time.DateTime.Property property17 = dateTime14.monthOfYear();
//        org.joda.time.DateTime.Property property18 = dateTime14.monthOfYear();
//        int int19 = property18.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime21 = property18.setCopy((int) (short) 1);
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) mutableDateTime11, (org.joda.time.ReadableDateTime) dateTime21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31T08:00:00.032-08:00" + "'", str12.equals("1969-12-31T08:00:00.032-08:00"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology9 = gregorianChronology7.withZone(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology11 = gregorianChronology7.withZone(dateTimeZone10);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10, 6);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(480, 2, 24, 7, 57599, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(julianChronology13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField9.getAsShortText((int) (short) 10, locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipUndoDateTimeField9.getType();
        long long16 = skipUndoDateTimeField9.getDifferenceAsLong((long) 131, (-230400000L));
        int int17 = skipUndoDateTimeField9.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 5L + "'", long16 == 5L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (short) 1);
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        boolean boolean5 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay4);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime14 = dateTime6.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
        boolean boolean18 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.withCenturyOfEra(100);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay monthDay25 = monthDay23.plusDays(365);
        boolean boolean26 = gJChronology21.equals((java.lang.Object) monthDay23);
        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology21.getZone();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder28.append(dateTimeFormatter32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder28.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder28.appendTimeZoneId();
        boolean boolean36 = gJChronology21.equals((java.lang.Object) dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 52);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+97:00" + "'", str2.equals("+97:00"));
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone1);
        int int4 = dateTime3.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 86399);
        org.joda.time.Instant instant3 = instant1.minus((long) ' ');
        org.joda.time.Instant instant6 = instant3.withDurationAdded(124271280422L, 2);
        org.joda.time.MutableDateTime mutableDateTime7 = instant3.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) ' ', 15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral("2019-06-15T13:47:03.291-07:00");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime.Property property4 = dateTime0.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime0.toMutableDateTime();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime0);
        org.joda.time.DateTime.Property property7 = dateTime0.secondOfMinute();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        java.lang.String str3 = property2.getAsString();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        int int7 = property2.compareTo((org.joda.time.ReadablePartial) localDateTime6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        int int11 = property2.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfEra();
        org.joda.time.DateTime.Property property14 = dateTime12.weekyear();
        org.joda.time.DateTime.Property property15 = dateTime12.monthOfYear();
        org.joda.time.DateTime dateTime17 = dateTime12.minusMinutes(0);
        org.joda.time.DateTime dateTime19 = dateTime12.minusDays((int) (short) 100);
        org.joda.time.DateTime dateTime21 = dateTime19.minusSeconds((int) (short) 10);
        int int22 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime19);
        try {
            org.joda.time.DateTime dateTime24 = dateTime19.withEra(1735);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1735 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970" + "'", str3.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = property1.roundHalfCeilingCopy();
        int int3 = property1.getMinimumValue();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property1.getAsText(locale4);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19" + "'", str5.equals("19"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfCentury((int) (short) 0, 31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime13 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property14 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime16 = property14.addToCopy((long) (short) 10);
        boolean boolean17 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime16.withMinuteOfHour((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundHalfFloorCopy();
        long long7 = property5.remainder();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (short) 1);
        org.joda.time.MonthDay monthDay3 = monthDay1.plusDays(53);
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 6);
        try {
            long long4 = dateTimeFormatter0.parseMillis("T08:00:00-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"T08:00:00-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField13 = copticChronology12.days();
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology12.halfdayOfDay();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField18 = copticChronology17.days();
        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology17.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField21);
        java.lang.String str24 = skipDateTimeField22.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
        org.joda.time.DateTime.Property property27 = dateTime25.weekyear();
        java.lang.String str28 = property27.getAsString();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
        int int32 = property27.compareTo((org.joda.time.ReadablePartial) localDateTime31);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property34 = dateTime33.yearOfEra();
        org.joda.time.DateTime.Property property35 = dateTime33.weekyear();
        org.joda.time.DateTime.Property property36 = dateTime33.monthOfYear();
        org.joda.time.DateTime dateTime38 = dateTime33.minusMinutes(0);
        org.joda.time.DateTime dateTime40 = dateTime33.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.minus(readablePeriod41);
        org.joda.time.DateTime dateTime43 = localDateTime31.toDateTime((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTimeField[] dateTimeFieldArray44 = localDateTime31.getFields();
        java.util.Locale locale45 = null;
        java.lang.String str46 = skipDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDateTime31, locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField22.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType47, 0, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType47, 11, 49591);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField56 = copticChronology55.days();
        org.joda.time.DateTimeZone dateTimeZone57 = copticChronology55.getZone();
        org.joda.time.DateTimeField dateTimeField58 = copticChronology55.era();
        org.joda.time.DurationField durationField59 = copticChronology55.years();
        long long62 = durationField59.subtract((long) 31, (long) '#');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField59);
        java.lang.String str64 = unsupportedDateTimeField63.toString();
        try {
            long long67 = unsupportedDateTimeField63.addWrapField((long) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeFieldArray44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-1104537599969L) + "'", long62 == (-1104537599969L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "UnsupportedDateTimeField" + "'", str64.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        boolean boolean3 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        java.lang.String str9 = localDateTime6.toString(dateTimeFormatter8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDateTime6.indexOf(dateTimeFieldType10);
        org.joda.time.DateTime dateTime12 = dateTime0.withFields((org.joda.time.ReadablePartial) localDateTime6);
        org.joda.time.DateTime.Property property13 = dateTime12.era();
        org.joda.time.Chronology chronology14 = dateTime12.getChronology();
        int int15 = dateTime12.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-365" + "'", str9.equals("1969-365"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 32 + "'", int15 == 32);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime14 = dateTime6.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
        boolean boolean18 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.withCenturyOfEra(100);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        java.lang.String str24 = dateTimeZone23.getID();
        long long26 = dateTimeZone23.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now(dateTimeZone23);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology21, dateTimeZone23);
        int int29 = gJChronology21.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "America/Los_Angeles" + "'", str24.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799968L) + "'", long26 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(57599, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.append(dateTimeFormatter12);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatterBuilder13.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder2.append(dateTimePrinter14, dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime6.minusDays((int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.String str15 = dateTime6.toString(dateTimeFormatter14);
        org.joda.time.DateTime dateTime17 = dateTime6.withEra(0);
        org.joda.time.DateTime dateTime19 = dateTime17.minus((-8643599900L));
        long long20 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
        java.lang.String str21 = property5.toString();
        org.joda.time.DateTime dateTime22 = property5.roundHalfCeilingCopy();
        java.lang.String str23 = property5.getName();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T08:00:00-08:00" + "'", str15.equals("T08:00:00-08:00"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 124271280422L + "'", long20 == 124271280422L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Property[secondOfDay]" + "'", str21.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "secondOfDay" + "'", str23.equals("secondOfDay"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
        int int3 = dateTime0.getDayOfMonth();
        org.joda.time.DateTime.Property property4 = dateTime0.secondOfMinute();
        int int5 = dateTime0.getYearOfCentury();
        org.joda.time.DateTime.Property property6 = dateTime0.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField9.getAsShortText((int) (short) 10, locale11);
        java.lang.String str14 = skipUndoDateTimeField9.getAsShortText((long) (byte) 100);
        int int16 = skipUndoDateTimeField9.get((long) 11);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField9.getAsShortText(0, locale18);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PM" + "'", str14.equals("PM"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 86399);
        org.joda.time.Instant instant3 = instant1.minus((long) ' ');
        org.joda.time.Instant instant6 = instant3.withDurationAdded(124271280422L, 2);
        org.joda.time.Instant instant8 = instant3.withMillis((-8643599900L));
        org.joda.time.Instant instant10 = instant8.plus((long) 12);
        org.joda.time.Instant instant12 = instant10.withMillis(28800000L);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant12);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.era();
        org.joda.time.DurationField durationField4 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.year();
        long long9 = copticChronology0.add((long) 0, 1L, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.millisOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField11);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        boolean boolean10 = skipUndoDateTimeField9.isLenient();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime.Property property4 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime6 = dateTime0.withCenturyOfEra((int) '#');
        int int7 = dateTime6.getWeekOfWeekyear();
        int int8 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime dateTime10 = dateTime6.minusDays(3);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        boolean boolean8 = dateTime1.isBefore((long) '4');
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime8 = dateTime0.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime10 = dateTime0.minusDays(0);
        org.joda.time.DateTime dateTime12 = dateTime0.minusMillis(59);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        java.util.Date date4 = dateTime0.toDate();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.fromDateFields(date4);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) '#', true);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertNotNull(gJChronology4);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str2 = dateTimeZone1.getID();
//        long long4 = dateTimeZone1.convertUTCToLocal((long) ' ');
//        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now(dateTimeZone1);
//        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now(dateTimeZone1);
//        java.lang.String str8 = dateTimeZone1.getShortName((-28799968L));
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-28799968L) + "'", long4 == (-28799968L));
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay1.withPeriodAdded(readablePeriod3, 271);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(0);
        int int12 = dateTime6.getMinuteOfHour();
        org.joda.time.DateTime dateTime13 = monthDay5.toDateTime((org.joda.time.ReadableInstant) dateTime6);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
        try {
            long long8 = gregorianChronology1.getDateTimeMillis(1, 131, (-25200000), 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 131 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime0.withMillis((-100L));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.append(dateTimeFormatter14);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField18 = copticChronology17.days();
        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology17.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField21);
        java.lang.String str24 = skipDateTimeField22.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
        org.joda.time.DateTime.Property property27 = dateTime25.weekyear();
        java.lang.String str28 = property27.getAsString();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
        int int32 = property27.compareTo((org.joda.time.ReadablePartial) localDateTime31);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property34 = dateTime33.yearOfEra();
        org.joda.time.DateTime.Property property35 = dateTime33.weekyear();
        org.joda.time.DateTime.Property property36 = dateTime33.monthOfYear();
        org.joda.time.DateTime dateTime38 = dateTime33.minusMinutes(0);
        org.joda.time.DateTime dateTime40 = dateTime33.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.minus(readablePeriod41);
        org.joda.time.DateTime dateTime43 = localDateTime31.toDateTime((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTimeField[] dateTimeFieldArray44 = localDateTime31.getFields();
        java.util.Locale locale45 = null;
        java.lang.String str46 = skipDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDateTime31, locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType47);
        int int49 = dateTime9.get(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeFieldArray44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology6 = gregorianChronology2.withZone(dateTimeZone5);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5, 6);
        java.util.TimeZone timeZone9 = dateTimeZone5.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.Chronology chronology3 = copticChronology0.withZone(dateTimeZone2);
        org.joda.time.Chronology chronology4 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        java.lang.Object obj4 = null;
        boolean boolean5 = gregorianChronology3.equals(obj4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("Property[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[monthOfYear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime14 = dateTime6.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
        boolean boolean18 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.withCenturyOfEra(100);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        java.lang.String str24 = dateTimeZone23.getID();
        long long26 = dateTimeZone23.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now(dateTimeZone23);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology21, dateTimeZone23);
        org.joda.time.Chronology chronology29 = gJChronology21.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "America/Los_Angeles" + "'", str24.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799968L) + "'", long26 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime.Property property4 = dateTime0.monthOfYear();
        int int5 = property4.getMinimumValueOverall();
        org.joda.time.DateTime dateTime7 = property4.setCopy((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.withEra((int) (short) 0);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime9.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime12 = dateTime9.withMillisOfSecond(166);
        org.joda.time.LocalDateTime localDateTime13 = dateTime9.toLocalDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDateTime13);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime dateTime2 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.minus(readablePeriod3);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) 1L);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        java.lang.String str10 = dateTimeZone7.getShortName((long) (byte) 0);
//        try {
//            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(131, (int) (short) 10, 2, 35, (-1), 59, 2, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        boolean boolean11 = skipUndoDateTimeField9.isLeap((long) (-1));
        int int13 = skipUndoDateTimeField9.get((long) 2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField13 = copticChronology12.days();
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology12.halfdayOfDay();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField18 = copticChronology17.days();
        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology17.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField21);
        java.lang.String str24 = skipDateTimeField22.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
        org.joda.time.DateTime.Property property27 = dateTime25.weekyear();
        java.lang.String str28 = property27.getAsString();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
        int int32 = property27.compareTo((org.joda.time.ReadablePartial) localDateTime31);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property34 = dateTime33.yearOfEra();
        org.joda.time.DateTime.Property property35 = dateTime33.weekyear();
        org.joda.time.DateTime.Property property36 = dateTime33.monthOfYear();
        org.joda.time.DateTime dateTime38 = dateTime33.minusMinutes(0);
        org.joda.time.DateTime dateTime40 = dateTime33.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.minus(readablePeriod41);
        org.joda.time.DateTime dateTime43 = localDateTime31.toDateTime((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTimeField[] dateTimeFieldArray44 = localDateTime31.getFields();
        java.util.Locale locale45 = null;
        java.lang.String str46 = skipDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDateTime31, locale45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField22.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType47, 0, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType47, 11, 49591);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField56 = copticChronology55.days();
        org.joda.time.DateTimeZone dateTimeZone57 = copticChronology55.getZone();
        org.joda.time.DateTimeField dateTimeField58 = copticChronology55.era();
        org.joda.time.DurationField durationField59 = copticChronology55.years();
        long long62 = durationField59.subtract((long) 31, (long) '#');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField59);
        java.lang.String str64 = unsupportedDateTimeField63.toString();
        java.lang.String str65 = unsupportedDateTimeField63.getName();
        java.util.Locale locale67 = null;
        try {
            java.lang.String str68 = unsupportedDateTimeField63.getAsShortText((long) 52, locale67);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeFieldArray44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-1104537599969L) + "'", long62 == (-1104537599969L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "UnsupportedDateTimeField" + "'", str64.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "weekOfWeekyear" + "'", str65.equals("weekOfWeekyear"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 10);
        long long9 = offsetDateTimeField7.roundHalfFloor((long) 59);
        long long12 = offsetDateTimeField7.add(1758642998400011L, 100);
        long long15 = offsetDateTimeField7.add(10L, 28800032);
        int int17 = offsetDateTimeField7.get((long) 0);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = offsetDateTimeField7.getMaximumValue(readablePartial18);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1758643004400011L + "'", long12 == 1758643004400011L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1728001920010L + "'", long15 == 1728001920010L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 69 + "'", int19 == 69);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property2.addToCopy(999);
        int int5 = property2.getMinimumValueOverall();
        java.lang.String str6 = property2.toString();
        java.lang.String str7 = property2.getName();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[monthOfYear]" + "'", str6.equals("Property[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "monthOfYear" + "'", str7.equals("monthOfYear"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        java.lang.String str3 = property2.toString();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Property[weekyear]" + "'", str3.equals("Property[weekyear]"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.weeks();
        java.lang.String str3 = buddhistChronology1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        int int5 = monthDay3.size();
        boolean boolean6 = julianChronology0.equals((java.lang.Object) int5);
        org.joda.time.Chronology chronology7 = julianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        int int8 = dateTime0.getEra();
        try {
            org.joda.time.DateTime dateTime10 = dateTime0.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-1L), (long) 115198);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-115199L) + "'", long2 == (-115199L));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long6 = julianChronology0.getDateTimeMillis((long) 57699, (int) '4', 49632681, (int) (short) 10, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.lang.String str3 = dateTimeFormatter0.print(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "16:00:00.000" + "'", str3.equals("16:00:00.000"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime dateTime2 = dateTime0.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.withChronology(chronology3);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(10L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime14 = dateTime6.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
        boolean boolean18 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.withCenturyOfEra(100);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        java.lang.String str24 = dateTimeZone23.getID();
        long long26 = dateTimeZone23.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now(dateTimeZone23);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology21, dateTimeZone23);
        java.lang.String str29 = zonedChronology28.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "America/Los_Angeles" + "'", str24.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799968L) + "'", long26 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ZonedChronology[GJChronology[UTC,cutover=10069-12-31T16:00:00.032Z], America/Los_Angeles]" + "'", str29.equals("ZonedChronology[GJChronology[UTC,cutover=10069-12-31T16:00:00.032Z], America/Los_Angeles]"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 10);
        long long9 = offsetDateTimeField7.roundHalfFloor((long) 59);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
        org.joda.time.DateTime.Property property12 = dateTime10.weekyear();
        org.joda.time.DateTime.Property property13 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(0);
        org.joda.time.DateTime dateTime17 = dateTime15.minusWeeks(6);
        org.joda.time.LocalTime localTime18 = dateTime15.toLocalTime();
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) localTime18, locale19);
        long long23 = offsetDateTimeField7.addWrapField((long) 46, (int) ' ');
        int int24 = offsetDateTimeField7.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1920046L + "'", long23 == 1920046L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("Property[secondOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[secondOfDay]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField12 = copticChronology11.days();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
        java.lang.String str22 = property21.getAsString();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = remainderDateTimeField44.getType();
        try {
            long long49 = remainderDateTimeField44.addWrapField((-1L), 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for halfdayOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
    }
}

