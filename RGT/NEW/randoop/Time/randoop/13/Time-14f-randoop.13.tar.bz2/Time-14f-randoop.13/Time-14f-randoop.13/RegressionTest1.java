import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property2.addToCopy(86399);
        java.lang.String str5 = property2.getAsString();
        int int6 = property2.getMaximumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12" + "'", str5.equals("12"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        org.joda.time.DateTime.Property property4 = dateTime0.weekyear();
//        org.joda.time.DateTime dateTime6 = dateTime0.withCenturyOfEra((int) '#');
//        int int7 = dateTime6.getWeekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime6.toMutableDateTime(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 86399);
        org.joda.time.Instant instant3 = instant1.minus((long) ' ');
        boolean boolean5 = instant3.isAfter(5L);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.era();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfCentury((int) '#', 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfHalfday(7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendFractionOfHour(0, 115198);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfEra(2000, (int) (byte) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder5.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        boolean boolean11 = skipUndoDateTimeField9.isLeap((long) (-1));
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.Chronology chronology3 = copticChronology0.withZone(dateTimeZone2);
        java.lang.String str4 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str4.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1758643004400011L, (long) 53);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 93208079233200583L + "'", long2 == 93208079233200583L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.lang.String str2 = dateTimeFormatter0.print((-1104537599969L));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00" + "'", str2.equals("00"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", (java.lang.Number) 100, number2, (java.lang.Number) 100L);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.Number number7 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 100 for America/Los_Angeles must not be larger than 100"));
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology5 = gregorianChronology3.withZone(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology(chronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.minuteOfHour();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime5 = dateTime3.toLocalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter6.withZoneUTC();
//        java.lang.String str8 = localDateTime5.toString(dateTimeFormatter7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        int int10 = localDateTime5.indexOf(dateTimeFieldType9);
//        int[] intArray12 = gregorianChronology1.get((org.joda.time.ReadablePartial) localDateTime5, (long) 12);
//        org.joda.time.Chronology chronology13 = gregorianChronology1.withUTC();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology1.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-365" + "'", str8.equals("1969-365"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
//        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
//        org.joda.time.DateTime.Property property12 = dateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime13 = property12.roundCeilingCopy();
//        int int14 = property12.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T08:00:00-08:00" + "'", str9.equals("T08:00:00-08:00"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2922789 + "'", int14 == 2922789);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = remainderDateTimeField44.getType();
//        boolean boolean47 = remainderDateTimeField44.isLenient();
//        org.joda.time.DurationField durationField48 = remainderDateTimeField44.getRangeDurationField();
//        org.joda.time.DurationField durationField49 = remainderDateTimeField44.getRangeDurationField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(durationField49);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property12 = monthDay11.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay11.withPeriodAdded(readablePeriod13, 271);
        java.util.TimeZone timeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology20 = gregorianChronology18.withZone(dateTimeZone19);
        java.util.TimeZone timeZone21 = dateTimeZone19.toTimeZone();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
        org.joda.time.DateTime.Property property25 = dateTime23.weekyear();
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime23.getZone();
        org.joda.time.DateTime.Property property27 = dateTime23.minuteOfDay();
        boolean boolean28 = dateTime22.isAfter((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime30 = dateTime22.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property32 = dateTime31.yearOfEra();
        org.joda.time.DateTime.Property property33 = dateTime31.weekyear();
        boolean boolean34 = dateTime22.isAfter((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime36 = dateTime31.withCenturyOfEra(100);
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, (org.joda.time.ReadableInstant) dateTime36);
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        java.lang.String str40 = dateTimeZone39.getID();
        long long42 = dateTimeZone39.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay43 = org.joda.time.MonthDay.now(dateTimeZone39);
        org.joda.time.chrono.ZonedChronology zonedChronology44 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology37, dateTimeZone39);
        java.util.TimeZone timeZone45 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forTimeZone(timeZone45);
        java.lang.String str47 = dateTimeZone46.getID();
        long long49 = dateTimeZone46.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay50 = org.joda.time.MonthDay.now(dateTimeZone46);
        org.joda.time.MonthDay monthDay51 = org.joda.time.MonthDay.now(dateTimeZone46);
        org.joda.time.Chronology chronology52 = zonedChronology44.withZone(dateTimeZone46);
        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay((org.joda.time.Chronology) zonedChronology44);
        boolean boolean54 = monthDay15.isEqual((org.joda.time.ReadablePartial) monthDay53);
        int[] intArray55 = monthDay15.getValues();
        try {
            int[] intArray57 = skipDateTimeField6.addWrapPartial((org.joda.time.ReadablePartial) monthDay8, 1735, intArray55, 49591);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1735");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "America/Los_Angeles" + "'", str40.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-28799968L) + "'", long42 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(zonedChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "America/Los_Angeles" + "'", str47.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-28799968L) + "'", long49 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(intArray55);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
//        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
//        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
//        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime14 = dateTime6.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
//        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
//        boolean boolean18 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime20 = dateTime15.withCenturyOfEra(100);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime20);
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        java.lang.String str24 = dateTimeZone23.getID();
//        long long26 = dateTimeZone23.convertUTCToLocal((long) ' ');
//        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now(dateTimeZone23);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology21, dateTimeZone23);
//        java.util.TimeZone timeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forTimeZone(timeZone29);
//        java.lang.String str31 = dateTimeZone30.getID();
//        long long33 = dateTimeZone30.convertUTCToLocal((long) ' ');
//        org.joda.time.MonthDay monthDay34 = org.joda.time.MonthDay.now(dateTimeZone30);
//        org.joda.time.MonthDay monthDay35 = org.joda.time.MonthDay.now(dateTimeZone30);
//        org.joda.time.Chronology chronology36 = zonedChronology28.withZone(dateTimeZone30);
//        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay((org.joda.time.Chronology) zonedChronology28);
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property39 = dateTime38.yearOfEra();
//        org.joda.time.DateTime.Property property40 = dateTime38.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone41 = dateTime38.getZone();
//        org.joda.time.Chronology chronology42 = zonedChronology28.withZone(dateTimeZone41);
//        java.lang.String str44 = dateTimeZone41.getName((long) 49600);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "America/Los_Angeles" + "'", str24.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799968L) + "'", long26 == (-28799968L));
//        org.junit.Assert.assertNotNull(monthDay27);
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "America/Los_Angeles" + "'", str31.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-28799968L) + "'", long33 == (-28799968L));
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(monthDay35);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Pacific Standard Time" + "'", str44.equals("Pacific Standard Time"));
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField13 = copticChronology12.days();
//        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology12.getZone();
//        org.joda.time.DateTimeField dateTimeField15 = copticChronology12.halfdayOfDay();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField18 = copticChronology17.days();
//        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField21);
//        java.lang.String str24 = skipDateTimeField22.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
//        org.joda.time.DateTime.Property property27 = dateTime25.weekyear();
//        java.lang.String str28 = property27.getAsString();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
//        int int32 = property27.compareTo((org.joda.time.ReadablePartial) localDateTime31);
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfEra();
//        org.joda.time.DateTime.Property property35 = dateTime33.weekyear();
//        org.joda.time.DateTime.Property property36 = dateTime33.monthOfYear();
//        org.joda.time.DateTime dateTime38 = dateTime33.minusMinutes(0);
//        org.joda.time.DateTime dateTime40 = dateTime33.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime40.minus(readablePeriod41);
//        org.joda.time.DateTime dateTime43 = localDateTime31.toDateTime((org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTimeField[] dateTimeFieldArray44 = localDateTime31.getFields();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = skipDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDateTime31, locale45);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField22.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType47, 0, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType47, 11, 49591);
//        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField56 = copticChronology55.days();
//        org.joda.time.DateTimeZone dateTimeZone57 = copticChronology55.getZone();
//        org.joda.time.DateTimeField dateTimeField58 = copticChronology55.era();
//        org.joda.time.DurationField durationField59 = copticChronology55.years();
//        long long62 = durationField59.subtract((long) 31, (long) '#');
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField59);
//        java.lang.String str64 = unsupportedDateTimeField63.toString();
//        java.lang.String str65 = unsupportedDateTimeField63.getName();
//        org.joda.time.MonthDay monthDay67 = new org.joda.time.MonthDay((long) ' ');
//        org.joda.time.MonthDay.Property property68 = monthDay67.monthOfYear();
//        int int69 = monthDay67.getMonthOfYear();
//        org.joda.time.Chronology chronology70 = monthDay67.getChronology();
//        org.joda.time.DateTime dateTime71 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property72 = dateTime71.yearOfEra();
//        org.joda.time.DateTime.Property property73 = dateTime71.weekyear();
//        org.joda.time.DateTime.Property property74 = dateTime71.monthOfYear();
//        org.joda.time.DateTime dateTime76 = dateTime71.minusMinutes(0);
//        org.joda.time.DateTime dateTime78 = dateTime71.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter79 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str80 = dateTime71.toString(dateTimeFormatter79);
//        org.joda.time.DateTime dateTime82 = dateTime71.withEra(0);
//        org.joda.time.DateTime.Property property83 = dateTime71.centuryOfEra();
//        org.joda.time.DateTime dateTime84 = property83.roundCeilingCopy();
//        org.joda.time.MonthDay monthDay86 = new org.joda.time.MonthDay((long) ' ');
//        org.joda.time.MonthDay monthDay88 = monthDay86.plusDays(365);
//        org.joda.time.DateTime dateTime89 = dateTime84.withFields((org.joda.time.ReadablePartial) monthDay88);
//        int[] intArray90 = monthDay88.getValues();
//        try {
//            int int91 = unsupportedDateTimeField63.getMinimumValue((org.joda.time.ReadablePartial) monthDay67, intArray90);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(localDateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(copticChronology55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-1104537599969L) + "'", long62 == (-1104537599969L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "UnsupportedDateTimeField" + "'", str64.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "weekOfWeekyear" + "'", str65.equals("weekOfWeekyear"));
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 12 + "'", int69 == 12);
//        org.junit.Assert.assertNotNull(chronology70);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(dateTimeFormatter79);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "T08:00:00-08:00" + "'", str80.equals("T08:00:00-08:00"));
//        org.junit.Assert.assertNotNull(dateTime82);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertNotNull(monthDay88);
//        org.junit.Assert.assertNotNull(dateTime89);
//        org.junit.Assert.assertNotNull(intArray90);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        long long46 = remainderDateTimeField44.roundHalfCeiling(0L);
//        long long48 = remainderDateTimeField44.roundFloor(0L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-14400000L) + "'", long46 == (-14400000L));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-14400000L) + "'", long48 == (-14400000L));
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.era();
        org.joda.time.DurationField durationField4 = copticChronology0.hours();
        try {
            long long9 = copticChronology0.getDateTimeMillis((-25200000), 86399, 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 10);
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime9.toYearMonthDay();
        java.util.GregorianCalendar gregorianCalendar11 = dateTime9.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime7 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property8 = dateTime1.yearOfCentury();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.append(dateTimeFormatter13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.appendClockhourOfHalfday(53);
        boolean boolean18 = property8.equals((java.lang.Object) 53);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 86399);
        org.joda.time.Instant instant3 = instant1.minus((long) ' ');
        org.joda.time.Instant instant6 = instant3.withDurationAdded(124271280422L, 2);
        org.joda.time.Instant instant8 = instant3.withMillis((-8643599900L));
        org.joda.time.Instant instant10 = instant8.minus((long) 2922789);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property2.addToCopy(0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(57599, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.append(dateTimeFormatter12);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatterBuilder13.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder2.append(dateTimePrinter14, dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendFractionOfDay(0, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendHourOfHalfday(2000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay1.withPeriodAdded(readablePeriod3, 271);
        org.joda.time.MonthDay monthDay7 = monthDay1.minusDays(52);
        org.joda.time.Chronology chronology8 = monthDay1.getChronology();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(57599, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.append(dateTimeFormatter12);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatterBuilder13.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder2.append(dateTimePrinter14, dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendFractionOfMinute((int) '4', 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField2 = copticChronology1.days();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
//        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
//        java.lang.String str12 = property11.getAsString();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
//        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
//        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
//        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
//        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
//        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField6.getType();
//        long long33 = skipDateTimeField6.roundHalfCeiling((long) 11);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = skipDateTimeField6.getAsText((long) 1735, locale35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = skipDateTimeField6.getAsShortText((int) (byte) 10, locale38);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1" + "'", str30.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-230400000L) + "'", long33 == (-230400000L));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1" + "'", str36.equals("1"));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10" + "'", str39.equals("10"));
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        int int45 = remainderDateTimeField44.getMinimumValue();
//        long long47 = remainderDateTimeField44.roundHalfFloor((long) 7);
//        long long49 = remainderDateTimeField44.roundHalfCeiling((long) 15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField44, 1);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-14400000L) + "'", long47 == (-14400000L));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-14400000L) + "'", long49 == (-14400000L));
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology6.weekyears();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(49591, 3, 1735, 0, 28800032, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28800032 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 1);
        try {
            org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime8 = dateTime0.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
        boolean boolean12 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime14 = dateTime9.withCenturyOfEra(100);
        try {
            org.joda.time.DateTime dateTime16 = dateTime14.withDayOfWeek(10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = remainderDateTimeField44.getType();
//        org.joda.time.Chronology chronology48 = null;
//        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(0L, chronology48);
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology52.minuteOfHour();
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property55 = dateTime54.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime56 = dateTime54.toLocalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = dateTimeFormatter57.withZoneUTC();
//        java.lang.String str59 = localDateTime56.toString(dateTimeFormatter58);
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = null;
//        int int61 = localDateTime56.indexOf(dateTimeFieldType60);
//        int[] intArray63 = gregorianChronology52.get((org.joda.time.ReadablePartial) localDateTime56, (long) 12);
//        try {
//            int[] intArray65 = remainderDateTimeField44.add((org.joda.time.ReadablePartial) monthDay49, 365, intArray63, 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 365");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(localDateTime56);
//        org.junit.Assert.assertNotNull(dateTimeFormatter57);
//        org.junit.Assert.assertNotNull(dateTimeFormatter58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "1969-365" + "'", str59.equals("1969-365"));
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
//        org.junit.Assert.assertNotNull(intArray63);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
//        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime7 = dateTime1.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime.Property property8 = dateTime1.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        java.lang.String str12 = dateTimeZone9.getShortName((long) (byte) 0);
//        org.joda.time.DateTime dateTime13 = dateTime1.withZoneRetainFields(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField2 = copticChronology1.days();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
//        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
//        java.lang.String str12 = property11.getAsString();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
//        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
//        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
//        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
//        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
//        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
//        boolean boolean31 = skipDateTimeField6.isSupported();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipDateTimeField6.getAsShortText(1, locale33);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1" + "'", str30.equals("1"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear(49600);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField2 = copticChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
        boolean boolean9 = skipDateTimeField6.isLenient();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 49591);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField13 = copticChronology12.days();
//        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology12.getZone();
//        org.joda.time.DateTimeField dateTimeField15 = copticChronology12.halfdayOfDay();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField18 = copticChronology17.days();
//        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField21);
//        java.lang.String str24 = skipDateTimeField22.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
//        org.joda.time.DateTime.Property property27 = dateTime25.weekyear();
//        java.lang.String str28 = property27.getAsString();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
//        int int32 = property27.compareTo((org.joda.time.ReadablePartial) localDateTime31);
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfEra();
//        org.joda.time.DateTime.Property property35 = dateTime33.weekyear();
//        org.joda.time.DateTime.Property property36 = dateTime33.monthOfYear();
//        org.joda.time.DateTime dateTime38 = dateTime33.minusMinutes(0);
//        org.joda.time.DateTime dateTime40 = dateTime33.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime40.minus(readablePeriod41);
//        org.joda.time.DateTime dateTime43 = localDateTime31.toDateTime((org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTimeField[] dateTimeFieldArray44 = localDateTime31.getFields();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = skipDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDateTime31, locale45);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField22.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType47, 0, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType47, 11, 49591);
//        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField56 = copticChronology55.days();
//        org.joda.time.DateTimeZone dateTimeZone57 = copticChronology55.getZone();
//        org.joda.time.DateTimeField dateTimeField58 = copticChronology55.era();
//        org.joda.time.DurationField durationField59 = copticChronology55.years();
//        long long62 = durationField59.subtract((long) 31, (long) '#');
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField59);
//        java.lang.String str64 = unsupportedDateTimeField63.toString();
//        java.lang.String str65 = unsupportedDateTimeField63.getName();
//        boolean boolean66 = unsupportedDateTimeField63.isLenient();
//        java.util.Locale locale67 = null;
//        try {
//            int int68 = unsupportedDateTimeField63.getMaximumShortTextLength(locale67);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(localDateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(copticChronology55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-1104537599969L) + "'", long62 == (-1104537599969L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "UnsupportedDateTimeField" + "'", str64.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "weekOfWeekyear" + "'", str65.equals("weekOfWeekyear"));
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property5 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        int int8 = property5.getMaximumValueOverall();
        org.joda.time.Interval interval9 = property5.toInterval();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86399 + "'", int8 == 86399);
        org.junit.Assert.assertNotNull(interval9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime7 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property8 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime10 = property8.addToCopy((long) (short) 10);
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTime dateTime12 = property8.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "yearOfCentury" + "'", str11.equals("yearOfCentury"));
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.dayOfMonth();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
//        org.joda.time.DateTime.Property property4 = dateTime2.weekyear();
//        org.joda.time.DateTime.Property property5 = dateTime2.monthOfYear();
//        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
//        int int7 = dateTime2.getMillisOfSecond();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
//        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone11 = dateTime8.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime8.toMutableDateTimeISO();
//        java.lang.String str13 = mutableDateTime12.toString();
//        boolean boolean14 = dateTime2.isAfter((org.joda.time.ReadableInstant) mutableDateTime12);
//        boolean boolean15 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime2);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969-12-31T08:00:00.032-08:00" + "'", str13.equals("1969-12-31T08:00:00.032-08:00"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 10);
        long long9 = offsetDateTimeField7.roundHalfFloor((long) 59);
        long long12 = offsetDateTimeField7.add(1758642998400011L, 100);
        long long15 = offsetDateTimeField7.add(10L, 28800032);
        int int17 = offsetDateTimeField7.get((long) 0);
        long long19 = offsetDateTimeField7.roundHalfEven(26287L);
        java.lang.String str21 = offsetDateTimeField7.getAsText((long) 365);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1758643004400011L + "'", long12 == 1758643004400011L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1728001920010L + "'", long15 == 1728001920010L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
        int int8 = dateTime0.getEra();
        org.joda.time.DateTime dateTime10 = dateTime0.minusMonths(2019);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.withPeriodAdded(readablePeriod3, 10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime0.minus(readablePeriod6);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property2.addToCopy(999);
        int int5 = property2.getMinimumValueOverall();
        java.util.Locale locale6 = null;
        int int7 = property2.getMaximumTextLength(locale6);
        java.util.Locale locale8 = null;
        int int9 = property2.getMaximumTextLength(locale8);
        java.lang.String str10 = property2.getAsString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "12" + "'", str10.equals("12"));
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
//        long long9 = gregorianChronology2.getDateTimeMillis(57699, 3, 6, 11);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str12 = dateTimeZone11.getID();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
//        java.lang.String str16 = property15.getAsString();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime19 = dateTime17.toLocalDateTime();
//        int int20 = property15.compareTo((org.joda.time.ReadablePartial) localDateTime19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property22 = dateTime21.yearOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.weekyear();
//        org.joda.time.DateTime.Property property24 = dateTime21.monthOfYear();
//        org.joda.time.DateTime dateTime26 = dateTime21.minusMinutes(0);
//        org.joda.time.DateTime dateTime28 = dateTime21.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readablePeriod29);
//        org.joda.time.DateTime dateTime31 = localDateTime19.toDateTime((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime dateTime34 = dateTime28.withDurationAdded(0L, 0);
//        int int35 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone11);
//        org.joda.time.DurationField durationField37 = gregorianChronology2.millis();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology2.yearOfCentury();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1758642998400011L + "'", long9 == 1758642998400011L);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970" + "'", str16.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-25200000) + "'", int35 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField2 = copticChronology1.days();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField5);
//        java.lang.String str8 = skipDateTimeField6.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
//        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
//        java.lang.String str12 = property11.getAsString();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime15 = dateTime13.toLocalDateTime();
//        int int16 = property11.compareTo((org.joda.time.ReadablePartial) localDateTime15);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.DateTime.Property property19 = dateTime17.weekyear();
//        org.joda.time.DateTime.Property property20 = dateTime17.monthOfYear();
//        org.joda.time.DateTime dateTime22 = dateTime17.minusMinutes(0);
//        org.joda.time.DateTime dateTime24 = dateTime17.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.minus(readablePeriod25);
//        org.joda.time.DateTime dateTime27 = localDateTime15.toDateTime((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTimeField[] dateTimeFieldArray28 = localDateTime15.getFields();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = skipDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime15, locale29);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipDateTimeField6.getType();
//        org.joda.time.DurationField durationField32 = skipDateTimeField6.getLeapDurationField();
//        int int33 = skipDateTimeField6.getMinimumValue();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, 2);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1" + "'", str30.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField6 = copticChronology5.days();
//        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology4, dateTimeField9);
//        java.lang.String str12 = skipDateTimeField10.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
//        java.lang.String str16 = property15.getAsString();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime19 = dateTime17.toLocalDateTime();
//        int int20 = property15.compareTo((org.joda.time.ReadablePartial) localDateTime19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property22 = dateTime21.yearOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.weekyear();
//        org.joda.time.DateTime.Property property24 = dateTime21.monthOfYear();
//        org.joda.time.DateTime dateTime26 = dateTime21.minusMinutes(0);
//        org.joda.time.DateTime dateTime28 = dateTime21.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readablePeriod29);
//        org.joda.time.DateTime dateTime31 = localDateTime19.toDateTime((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTimeField[] dateTimeFieldArray32 = localDateTime19.getFields();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDateTime19, locale33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipDateTimeField10.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType35);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
//        int int40 = offsetDateTimeField38.getLeapAmount((long) 7);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970" + "'", str16.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField13 = copticChronology12.days();
//        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology12.getZone();
//        org.joda.time.DateTimeField dateTimeField15 = copticChronology12.halfdayOfDay();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField18 = copticChronology17.days();
//        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField21);
//        java.lang.String str24 = skipDateTimeField22.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
//        org.joda.time.DateTime.Property property27 = dateTime25.weekyear();
//        java.lang.String str28 = property27.getAsString();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
//        int int32 = property27.compareTo((org.joda.time.ReadablePartial) localDateTime31);
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfEra();
//        org.joda.time.DateTime.Property property35 = dateTime33.weekyear();
//        org.joda.time.DateTime.Property property36 = dateTime33.monthOfYear();
//        org.joda.time.DateTime dateTime38 = dateTime33.minusMinutes(0);
//        org.joda.time.DateTime dateTime40 = dateTime33.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime40.minus(readablePeriod41);
//        org.joda.time.DateTime dateTime43 = localDateTime31.toDateTime((org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTimeField[] dateTimeFieldArray44 = localDateTime31.getFields();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = skipDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDateTime31, locale45);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField22.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType47, 0, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType47, 11, 49591);
//        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField56 = copticChronology55.days();
//        org.joda.time.DateTimeZone dateTimeZone57 = copticChronology55.getZone();
//        org.joda.time.DateTimeField dateTimeField58 = copticChronology55.era();
//        org.joda.time.DurationField durationField59 = copticChronology55.years();
//        long long62 = durationField59.subtract((long) 31, (long) '#');
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField59);
//        java.lang.String str64 = unsupportedDateTimeField63.toString();
//        java.lang.String str65 = unsupportedDateTimeField63.getName();
//        try {
//            java.lang.String str67 = unsupportedDateTimeField63.getAsText((long) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(localDateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(copticChronology55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-1104537599969L) + "'", long62 == (-1104537599969L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "UnsupportedDateTimeField" + "'", str64.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "weekOfWeekyear" + "'", str65.equals("weekOfWeekyear"));
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1970");
        java.lang.Object obj2 = null;
        boolean boolean3 = jodaTimePermission1.equals(obj2);
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("1970");
        java.lang.Object obj6 = null;
        boolean boolean7 = jodaTimePermission5.equals(obj6);
        boolean boolean8 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        java.lang.String str9 = jodaTimePermission5.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1970\")" + "'", str9.equals("(\"org.joda.time.JodaTimePermission\" \"1970\")"));
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        long long46 = remainderDateTimeField44.roundHalfCeiling(0L);
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = remainderDateTimeField44.getAsText((int) (byte) 100, locale48);
//        try {
//            long long52 = remainderDateTimeField44.addWrapField((long) (-25200000), (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for halfdayOfDay must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-14400000L) + "'", long46 == (-14400000L));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "100" + "'", str49.equals("100"));
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        int int3 = dateTime0.getEra();
//        org.joda.time.TimeOfDay timeOfDay4 = dateTime0.toTimeOfDay();
//        boolean boolean5 = dateTime0.isBeforeNow();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(timeOfDay4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField13);
        java.lang.String str15 = gregorianChronology2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str15.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("1");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localTime2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime14 = dateTime6.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
        boolean boolean18 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.withCenturyOfEra(100);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        java.lang.String str24 = dateTimeZone23.getID();
        long long26 = dateTimeZone23.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now(dateTimeZone23);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology21, dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone29 = zonedChronology28.getZone();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone30);
        org.joda.time.Chronology chronology32 = zonedChronology28.withZone(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "America/Los_Angeles" + "'", str24.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799968L) + "'", long26 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property2.addToCopy(999);
        int int5 = property2.getMinimumValueOverall();
        java.util.Locale locale6 = null;
        int int7 = property2.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property2.getFieldType();
        java.lang.String str9 = property2.getName();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1970");
        java.lang.Object obj2 = null;
        boolean boolean3 = jodaTimePermission1.equals(obj2);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField9 = copticChronology8.days();
        org.joda.time.DateTimeZone dateTimeZone10 = copticChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology8.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField11, (int) (byte) 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField13.getAsShortText((int) (short) 10, locale15);
        java.lang.String str18 = skipUndoDateTimeField13.getAsShortText((long) (byte) 100);
        int int20 = skipUndoDateTimeField13.getMaximumValue((long) 999);
        jodaTimePermission1.checkGuard((java.lang.Object) int20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PM" + "'", str18.equals("PM"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone3);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        java.util.TimeZone timeZone11 = dateTimeZone9.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+97:00" + "'", str4.equals("+97:00"));
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 10);
//        long long9 = offsetDateTimeField7.roundHalfFloor((long) 59);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime10.weekyear();
//        org.joda.time.DateTime.Property property13 = dateTime10.monthOfYear();
//        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(0);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusWeeks(6);
//        org.joda.time.LocalTime localTime18 = dateTime15.toLocalTime();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) localTime18, locale19);
//        long long23 = offsetDateTimeField7.add(1474748L, (long) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1534748L + "'", long23 == 1534748L);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks(6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime8.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property13 = dateTime8.secondOfDay();
        org.joda.time.DateTime dateTime14 = property13.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField15 = property13.getField();
        int int16 = property13.getMaximumValueOverall();
        boolean boolean17 = dateTime5.equals((java.lang.Object) property13);
        org.joda.time.DateTime dateTime19 = dateTime5.minusMonths((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86399 + "'", int16 == 86399);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime14 = dateTime6.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
        boolean boolean18 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.withCenturyOfEra(100);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        java.lang.String str24 = dateTimeZone23.getID();
        long long26 = dateTimeZone23.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now(dateTimeZone23);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology21, dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone29 = zonedChronology28.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone30 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "America/Los_Angeles" + "'", str24.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799968L) + "'", long26 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(cachedDateTimeZone30);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 10);
//        long long9 = offsetDateTimeField7.roundHalfFloor((long) 59);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime10.weekyear();
//        org.joda.time.DateTime.Property property13 = dateTime10.monthOfYear();
//        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(0);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusWeeks(6);
//        org.joda.time.LocalTime localTime18 = dateTime15.toLocalTime();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) localTime18, locale19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property22 = dateTime21.yearOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.weekyear();
//        int int24 = dateTime21.getEra();
//        org.joda.time.TimeOfDay timeOfDay25 = dateTime21.toTimeOfDay();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) timeOfDay25, 11, locale27);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(timeOfDay25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
//        int int8 = dateTime0.getEra();
//        long long9 = dateTime0.getMillis();
//        org.joda.time.DateTime dateTime11 = dateTime0.withMillis((long) 11);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-28799968L) + "'", long9 == (-28799968L));
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property2.addToCopy(86399);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay6 = monthDay4.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.MonthDay.Property property7 = monthDay4.monthOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.minuteOfHour();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField5 = copticChronology4.days();
//        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField(chronology3, dateTimeField8);
//        java.lang.String str11 = skipDateTimeField9.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property13 = dateTime12.yearOfEra();
//        org.joda.time.DateTime.Property property14 = dateTime12.weekyear();
//        java.lang.String str15 = property14.getAsString();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime18 = dateTime16.toLocalDateTime();
//        int int19 = property14.compareTo((org.joda.time.ReadablePartial) localDateTime18);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfEra();
//        org.joda.time.DateTime.Property property22 = dateTime20.weekyear();
//        org.joda.time.DateTime.Property property23 = dateTime20.monthOfYear();
//        org.joda.time.DateTime dateTime25 = dateTime20.minusMinutes(0);
//        org.joda.time.DateTime dateTime27 = dateTime20.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.minus(readablePeriod28);
//        org.joda.time.DateTime dateTime30 = localDateTime18.toDateTime((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeField[] dateTimeFieldArray31 = localDateTime18.getFields();
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDateTime18, locale32);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipDateTimeField9.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType34, 32, 31, 57699);
//        long long40 = offsetDateTimeField38.remainder(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970" + "'", str15.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        long long4 = dateTimeZone1.convertUTCToLocal((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-28799968L) + "'", long4 == (-28799968L));
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField5 = copticChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology4.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField7, (int) (byte) 100);
        java.lang.String str11 = skipUndoDateTimeField9.getAsText((long) (byte) 100);
        long long13 = skipUndoDateTimeField9.remainder((long) 49600);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PM" + "'", str11.equals("PM"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 14449600L + "'", long13 == 14449600L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        java.util.Date date4 = dateTime0.toDate();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.fromDateFields(date4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = monthDay5.toString("-00:00:00.001", locale7);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-00:00:00.001" + "'", str8.equals("-00:00:00.001"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYear(4, 15);
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField7 = copticChronology6.days();
//        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology6.getZone();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology6.halfdayOfDay();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType41);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder5.appendFraction(dateTimeFieldType41, 0, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder5.appendYear(166, (int) (short) 1);
//        org.joda.time.format.DateTimeParser dateTimeParser49 = dateTimeFormatterBuilder48.toParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimePrinter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeParser49);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        long long47 = remainderDateTimeField44.getDifferenceAsLong(124271280422L, 0L);
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property49 = dateTime48.yearOfEra();
//        org.joda.time.DateTime.Property property50 = dateTime48.weekyear();
//        org.joda.time.DateTime.Property property51 = dateTime48.monthOfYear();
//        java.util.Date date52 = dateTime48.toDate();
//        org.joda.time.MonthDay monthDay53 = org.joda.time.MonthDay.fromDateFields(date52);
//        org.joda.time.ReadablePeriod readablePeriod54 = null;
//        org.joda.time.MonthDay monthDay56 = monthDay53.withPeriodAdded(readablePeriod54, 952);
//        java.util.Locale locale57 = null;
//        try {
//            java.lang.String str58 = remainderDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) monthDay53, locale57);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2876L + "'", long47 == 2876L);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(monthDay53);
//        org.junit.Assert.assertNotNull(monthDay56);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("10");
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField6 = copticChronology5.days();
//        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField(chronology4, dateTimeField9);
//        java.lang.String str12 = skipDateTimeField10.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
//        java.lang.String str16 = property15.getAsString();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime19 = dateTime17.toLocalDateTime();
//        int int20 = property15.compareTo((org.joda.time.ReadablePartial) localDateTime19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property22 = dateTime21.yearOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.weekyear();
//        org.joda.time.DateTime.Property property24 = dateTime21.monthOfYear();
//        org.joda.time.DateTime dateTime26 = dateTime21.minusMinutes(0);
//        org.joda.time.DateTime dateTime28 = dateTime21.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readablePeriod29);
//        org.joda.time.DateTime dateTime31 = localDateTime19.toDateTime((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTimeField[] dateTimeFieldArray32 = localDateTime19.getFields();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDateTime19, locale33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipDateTimeField10.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType35);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
//        boolean boolean40 = offsetDateTimeField38.isLeap((long) 34);
//        long long43 = offsetDateTimeField38.add(14449600L, (long) 1735);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970" + "'", str16.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 74962849600L + "'", long43 == 74962849600L);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(0, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendFractionOfMinute(49625, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime1.getZone();
//        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
//        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime7 = dateTime1.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime.Property property8 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime10 = property8.addToCopy((long) (short) 10);
//        org.joda.time.DateTime.Property property11 = dateTime10.year();
//        int int12 = property11.get();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1979 + "'", int12 == 1979);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField13 = copticChronology12.days();
//        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology12.getZone();
//        org.joda.time.DateTimeField dateTimeField15 = copticChronology12.halfdayOfDay();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField18 = copticChronology17.days();
//        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField21);
//        java.lang.String str24 = skipDateTimeField22.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
//        org.joda.time.DateTime.Property property27 = dateTime25.weekyear();
//        java.lang.String str28 = property27.getAsString();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
//        int int32 = property27.compareTo((org.joda.time.ReadablePartial) localDateTime31);
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfEra();
//        org.joda.time.DateTime.Property property35 = dateTime33.weekyear();
//        org.joda.time.DateTime.Property property36 = dateTime33.monthOfYear();
//        org.joda.time.DateTime dateTime38 = dateTime33.minusMinutes(0);
//        org.joda.time.DateTime dateTime40 = dateTime33.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime40.minus(readablePeriod41);
//        org.joda.time.DateTime dateTime43 = localDateTime31.toDateTime((org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTimeField[] dateTimeFieldArray44 = localDateTime31.getFields();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = skipDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDateTime31, locale45);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField22.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType47, 0, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType47, 11, 49591);
//        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField56 = copticChronology55.days();
//        org.joda.time.DateTimeZone dateTimeZone57 = copticChronology55.getZone();
//        org.joda.time.DateTimeField dateTimeField58 = copticChronology55.era();
//        org.joda.time.DurationField durationField59 = copticChronology55.years();
//        long long62 = durationField59.subtract((long) 31, (long) '#');
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField59);
//        java.lang.String str64 = unsupportedDateTimeField63.toString();
//        org.joda.time.DurationField durationField65 = unsupportedDateTimeField63.getRangeDurationField();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(localDateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(copticChronology55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-1104537599969L) + "'", long62 == (-1104537599969L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "UnsupportedDateTimeField" + "'", str64.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNull(durationField65);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTimeISO();
//        org.joda.time.DateTime.Property property5 = dateTime0.secondOfDay();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(0);
//        org.joda.time.DateTime dateTime13 = dateTime6.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str15 = dateTime6.toString(dateTimeFormatter14);
//        org.joda.time.DateTime dateTime17 = dateTime6.withEra(0);
//        org.joda.time.DateTime dateTime19 = dateTime17.minus((-8643599900L));
//        long long20 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
//        java.lang.String str21 = property5.toString();
//        org.joda.time.DateTime dateTime22 = property5.roundCeilingCopy();
//        java.util.Locale locale23 = null;
//        int int24 = property5.getMaximumShortTextLength(locale23);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T08:00:00-08:00" + "'", str15.equals("T08:00:00-08:00"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 124271280422L + "'", long20 == 124271280422L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Property[secondOfDay]" + "'", str21.equals("Property[secondOfDay]"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.append(dateTimePrinter4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
//        org.joda.time.DateTime.Property property8 = dateTime6.weekyear();
//        java.lang.String str9 = property8.getAsString();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime12 = dateTime10.toLocalDateTime();
//        int int13 = property8.compareTo((org.joda.time.ReadablePartial) localDateTime12);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfCeilingCopy();
//        int int17 = property8.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder18.append(dateTimeFormatter22);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField26 = copticChronology25.days();
//        org.joda.time.DateTimeZone dateTimeZone27 = copticChronology25.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField(chronology24, dateTimeField29);
//        java.lang.String str32 = skipDateTimeField30.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfEra();
//        org.joda.time.DateTime.Property property35 = dateTime33.weekyear();
//        java.lang.String str36 = property35.getAsString();
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property38 = dateTime37.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime39 = dateTime37.toLocalDateTime();
//        int int40 = property35.compareTo((org.joda.time.ReadablePartial) localDateTime39);
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property42 = dateTime41.yearOfEra();
//        org.joda.time.DateTime.Property property43 = dateTime41.weekyear();
//        org.joda.time.DateTime.Property property44 = dateTime41.monthOfYear();
//        org.joda.time.DateTime dateTime46 = dateTime41.minusMinutes(0);
//        org.joda.time.DateTime dateTime48 = dateTime41.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.minus(readablePeriod49);
//        org.joda.time.DateTime dateTime51 = localDateTime39.toDateTime((org.joda.time.ReadableInstant) dateTime48);
//        org.joda.time.DateTimeField[] dateTimeFieldArray52 = localDateTime39.getFields();
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = skipDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDateTime39, locale53);
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = skipDateTimeField30.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder18.appendShortText(dateTimeFieldType55);
//        int int57 = dateTime16.get(dateTimeFieldType55);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimePrinter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970" + "'", str9.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(copticChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1" + "'", str32.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1970" + "'", str36.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(localDateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray52);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "1" + "'", str54.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 52 + "'", int57 == 52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(57599, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.append(dateTimeFormatter12);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatterBuilder13.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder2.append(dateTimePrinter14, dateTimeParser16);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap18 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendTimeZoneName(strMap18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 10);
        try {
            long long10 = offsetDateTimeField7.set((long) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfHour must be in the range [10,69]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readableDuration1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfEra(2000, (int) (byte) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray7 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.append(dateTimePrinter6, dateTimeParserArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeParserArray7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(32, 166, 271, 69, 24, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        long long47 = remainderDateTimeField44.remainder(60000L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 14460000L + "'", long47 == 14460000L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        long long9 = gregorianChronology2.getDateTimeMillis(57699, 3, 6, 11);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1758642998400011L + "'", long9 == 1758642998400011L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.era();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime4.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
//        org.joda.time.DateTime.Property property8 = dateTime4.minuteOfDay();
//        boolean boolean9 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime11 = dateTime3.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = dateTime3.toDateTime(dateTimeZone12);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
//        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
//        org.joda.time.DateTime.Property property18 = dateTime15.monthOfYear();
//        org.joda.time.DateTime dateTime20 = dateTime15.minusMinutes(0);
//        org.joda.time.DateTime dateTime22 = dateTime15.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str24 = dateTime15.toString(dateTimeFormatter23);
//        org.joda.time.DateTime dateTime26 = dateTime15.withEra(0);
//        boolean boolean28 = dateTime15.isAfter((long) 57699);
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T08:00:00-08:00" + "'", str24.equals("T08:00:00-08:00"));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(124271280422L);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField1 = copticChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.append(dateTimeFormatter8);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField12 = copticChronology11.days();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology10, dateTimeField15);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        java.lang.String str22 = property21.getAsString();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime25 = dateTime23.toLocalDateTime();
//        int int26 = property21.compareTo((org.joda.time.ReadablePartial) localDateTime25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
//        org.joda.time.DateTime.Property property29 = dateTime27.weekyear();
//        org.joda.time.DateTime.Property property30 = dateTime27.monthOfYear();
//        org.joda.time.DateTime dateTime32 = dateTime27.minusMinutes(0);
//        org.joda.time.DateTime dateTime34 = dateTime27.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = localDateTime25.toDateTime((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeField[] dateTimeFieldArray38 = localDateTime25.getFields();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDateTime25, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField16.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType41);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType41, (int) 'a');
//        org.joda.time.DurationField durationField45 = remainderDateTimeField44.getLeapDurationField();
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property47 = dateTime46.yearOfEra();
//        org.joda.time.DateTime.Property property48 = dateTime46.weekyear();
//        java.lang.String str49 = property48.getAsString();
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property51 = dateTime50.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime52 = dateTime50.toLocalDateTime();
//        int int53 = property48.compareTo((org.joda.time.ReadablePartial) localDateTime52);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property55 = dateTime54.yearOfEra();
//        org.joda.time.DateTime.Property property56 = dateTime54.weekyear();
//        org.joda.time.DateTime.Property property57 = dateTime54.monthOfYear();
//        org.joda.time.DateTime dateTime59 = dateTime54.minusMinutes(0);
//        org.joda.time.DateTime dateTime61 = dateTime54.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod62 = null;
//        org.joda.time.DateTime dateTime63 = dateTime61.minus(readablePeriod62);
//        org.joda.time.DateTime dateTime64 = localDateTime52.toDateTime((org.joda.time.ReadableInstant) dateTime61);
//        java.util.Locale locale65 = null;
//        java.lang.String str66 = remainderDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) localDateTime52, locale65);
//        java.lang.String str67 = remainderDateTimeField44.toString();
//        org.joda.time.DurationField durationField68 = remainderDateTimeField44.getRangeDurationField();
//        long long70 = remainderDateTimeField44.roundFloor((long) (short) 100);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970" + "'", str22.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNull(durationField45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1970" + "'", str49.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(localDateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1" + "'", str66.equals("1"));
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str67.equals("DateTimeField[weekOfWeekyear]"));
//        org.junit.Assert.assertNotNull(durationField68);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-14400000L) + "'", long70 == (-14400000L));
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(4, 15);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField13 = copticChronology12.days();
//        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology12.getZone();
//        org.joda.time.DateTimeField dateTimeField15 = copticChronology12.halfdayOfDay();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField18 = copticChronology17.days();
//        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField(chronology16, dateTimeField21);
//        java.lang.String str24 = skipDateTimeField22.getAsShortText((long) ' ');
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
//        org.joda.time.DateTime.Property property27 = dateTime25.weekyear();
//        java.lang.String str28 = property27.getAsString();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
//        int int32 = property27.compareTo((org.joda.time.ReadablePartial) localDateTime31);
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfEra();
//        org.joda.time.DateTime.Property property35 = dateTime33.weekyear();
//        org.joda.time.DateTime.Property property36 = dateTime33.monthOfYear();
//        org.joda.time.DateTime dateTime38 = dateTime33.minusMinutes(0);
//        org.joda.time.DateTime dateTime40 = dateTime33.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime40.minus(readablePeriod41);
//        org.joda.time.DateTime dateTime43 = localDateTime31.toDateTime((org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTimeField[] dateTimeFieldArray44 = localDateTime31.getFields();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = skipDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDateTime31, locale45);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = skipDateTimeField22.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType47, 0, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType47, 11, 49591);
//        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DurationField durationField56 = copticChronology55.days();
//        org.joda.time.DateTimeZone dateTimeZone57 = copticChronology55.getZone();
//        org.joda.time.DateTimeField dateTimeField58 = copticChronology55.era();
//        org.joda.time.DurationField durationField59 = copticChronology55.years();
//        long long62 = durationField59.subtract((long) 31, (long) '#');
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType47, durationField59);
//        java.lang.String str64 = unsupportedDateTimeField63.toString();
//        java.lang.String str65 = unsupportedDateTimeField63.getName();
//        long long68 = unsupportedDateTimeField63.add(838L, 34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(localDateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(copticChronology55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-1104537599969L) + "'", long62 == (-1104537599969L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "UnsupportedDateTimeField" + "'", str64.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "weekOfWeekyear" + "'", str65.equals("weekOfWeekyear"));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1073001600838L + "'", long68 == 1073001600838L);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
        java.util.TimeZone timeZone5 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfDay();
        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime14 = dateTime6.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
        boolean boolean18 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.withCenturyOfEra(100);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        java.lang.String str24 = dateTimeZone23.getID();
        long long26 = dateTimeZone23.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now(dateTimeZone23);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology21, dateTimeZone23);
        java.util.TimeZone timeZone29 = null;
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forTimeZone(timeZone29);
        java.lang.String str31 = dateTimeZone30.getID();
        long long33 = dateTimeZone30.convertUTCToLocal((long) ' ');
        org.joda.time.MonthDay monthDay34 = org.joda.time.MonthDay.now(dateTimeZone30);
        org.joda.time.MonthDay monthDay35 = org.joda.time.MonthDay.now(dateTimeZone30);
        org.joda.time.Chronology chronology36 = zonedChronology28.withZone(dateTimeZone30);
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay((org.joda.time.Chronology) zonedChronology28);
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property39 = dateTime38.yearOfEra();
        org.joda.time.DateTime.Property property40 = dateTime38.weekyear();
        org.joda.time.DateTimeZone dateTimeZone41 = dateTime38.getZone();
        org.joda.time.Chronology chronology42 = zonedChronology28.withZone(dateTimeZone41);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "America/Los_Angeles" + "'", str24.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799968L) + "'", long26 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "America/Los_Angeles" + "'", str31.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-28799968L) + "'", long33 == (-28799968L));
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 9, (org.joda.time.Chronology) julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(4, 15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(0, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendCenturyOfEra(0, 49600);
        dateTimeFormatterBuilder15.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.junit.Assert.assertNotNull(monthDay0);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
//        int int6 = dateTime0.getSecondOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime0.minus((long) 2);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, 2);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 28800 + "'", int6 == 28800);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundCeiling(1560631627679L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036829575809L) + "'", long6 == (-9223372036829575809L));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property2.addToCopy(999);
        try {
            org.joda.time.MonthDay monthDay6 = property2.setCopy(1979);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1979 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("era", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"era\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
//        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
//        org.joda.time.DateTime.Property property12 = dateTime0.centuryOfEra();
//        java.util.GregorianCalendar gregorianCalendar13 = dateTime0.toGregorianCalendar();
//        org.joda.time.DateTime dateTime14 = dateTime0.toDateTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T08:00:00-08:00" + "'", str9.equals("T08:00:00-08:00"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(gregorianCalendar13);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) ' ');
//        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.lang.String str5 = dateTimeZone4.getID();
//        long long7 = dateTimeZone4.convertUTCToLocal((long) ' ');
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone4);
//        org.joda.time.MonthDay monthDay10 = monthDay8.plusMonths((int) (byte) 0);
//        boolean boolean11 = monthDay1.isAfter((org.joda.time.ReadablePartial) monthDay10);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28799968L) + "'", long7 == (-28799968L));
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology4 = gregorianChronology2.withZone(dateTimeZone3);
//        long long9 = gregorianChronology2.getDateTimeMillis(57699, 3, 6, 11);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str12 = dateTimeZone11.getID();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
//        java.lang.String str16 = property15.getAsString();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
//        org.joda.time.LocalDateTime localDateTime19 = dateTime17.toLocalDateTime();
//        int int20 = property15.compareTo((org.joda.time.ReadablePartial) localDateTime19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property22 = dateTime21.yearOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime21.weekyear();
//        org.joda.time.DateTime.Property property24 = dateTime21.monthOfYear();
//        org.joda.time.DateTime dateTime26 = dateTime21.minusMinutes(0);
//        org.joda.time.DateTime dateTime28 = dateTime21.minusDays((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readablePeriod29);
//        org.joda.time.DateTime dateTime31 = localDateTime19.toDateTime((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime dateTime34 = dateTime28.withDurationAdded(0L, 0);
//        int int35 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone37 = zonedChronology36.getZone();
//        try {
//            long long45 = zonedChronology36.getDateTimeMillis(96, (int) (short) 100, 2000, (-25200000), 12, 1, 46);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1758642998400011L + "'", long9 == 1758642998400011L);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970" + "'", str16.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-25200000) + "'", int35 == (-25200000));
//        org.junit.Assert.assertNotNull(zonedChronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime3.withEarlierOffsetAtOverlap();
        org.joda.time.TimeOfDay timeOfDay5 = dateTime3.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(timeOfDay5);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property1 = dateTime0.yearOfEra();
//        org.joda.time.DateTime.Property property2 = dateTime0.weekyear();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime5 = dateTime0.minusMinutes(0);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str9 = dateTime0.toString(dateTimeFormatter8);
//        org.joda.time.DateTime dateTime11 = dateTime0.withEra(0);
//        org.joda.time.DateTime.Property property12 = dateTime0.centuryOfEra();
//        int int13 = property12.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T08:00:00-08:00" + "'", str9.equals("T08:00:00-08:00"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }
//}

