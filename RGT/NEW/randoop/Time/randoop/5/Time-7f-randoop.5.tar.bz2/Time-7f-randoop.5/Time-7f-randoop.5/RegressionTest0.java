import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(100, (int) (byte) -1, (int) (short) 1, (int) (short) 1, (int) ' ', 100, (int) 'a', dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) "", dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime5 = dateTime2.withTimeAtStartOfDay();
        try {
            java.lang.String str7 = dateTime2.toString("2019-06-12T05:23:49.972-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) (short) -1, dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            mutableDateTime2.set(dateTimeFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.DateTime.Property property16 = dateTime11.property(dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-1), 100, 6, (int) (short) -1, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1L, (long) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10.0f, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 'a');
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1L), (java.lang.Number) 0.0f, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        mutableDateTime2.addYears((int) '4');
        java.lang.Object obj6 = mutableDateTime2.clone();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 19431);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500224896d + "'", double1 == 2440587.500224896d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        try {
//            org.joda.time.MutableDateTime.Property property13 = mutableDateTime2.property(dateTimeFieldType12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19432 + "'", int10 == 19432);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 97, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) 97, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField1 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        mutableDateTime2.addYears((int) '4');
        mutableDateTime2.setMillisOfSecond((int) ' ');
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology8.getZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((java.lang.Object) ' ', dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            int int8 = mutableDateTime2.get(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 100L, (java.lang.Number) 97, (java.lang.Number) 20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        java.lang.String str5 = mutableDateTime3.toString();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
//        org.joda.time.ReadablePartial readablePartial7 = null;
//        int[] intArray8 = new int[] {};
//        try {
//            gJChronology6.validate(readablePartial7, intArray8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-12T05:23:53.576-07:00" + "'", str5.equals("2019-06-12T05:23:53.576-07:00"));
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(intArray8);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(1L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withSecondOfMinute((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, 20, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (short) 10, locale17);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15, 20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 20");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) 'a', 0, 23, (-1), 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 23);
        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = instant14.toMutableDateTime(chronology15);
        int int17 = mutableDateTime16.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
        mutableDateTime16.setDate((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime25 = dateTime20.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime31 = dateTime28.withPeriodAdded(readablePeriod29, 0);
        org.joda.time.LocalDateTime localDateTime32 = dateTime31.toLocalDateTime();
        int[] intArray38 = new int[] { 0, 19431, 323, 19434 };
        try {
            int[] intArray40 = offsetDateTimeField3.addWrapField((org.joda.time.ReadablePartial) localDateTime32, (int) '4', intArray38, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDateTime32);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        java.lang.String str4 = mutableDateTime2.toString();
//        try {
//            mutableDateTime2.setTime((int) (short) 0, 6, (int) (short) -1, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-12T05:23:55.661-07:00" + "'", str4.equals("2019-06-12T05:23:55.661-07:00"));
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("2019-06-12T05:23:49.972-07:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T05:23:49.972-07:00\" is malformed at \":49.972-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = instant5.toMutableDateTime(chronology6);
        int int8 = mutableDateTime7.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withYearOfCentury(0);
        mutableDateTime7.setDate((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime11.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone20 = dateTime19.getZone();
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((int) (byte) 0, (int) ' ', 19431, 0, 19, dateTimeZone20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (byte) 10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime11.withDayOfMonth((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime17 = dateTime11.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        java.lang.String str5 = mutableDateTime3.toString();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
//        org.joda.time.Instant instant7 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = instant7.toMutableDateTime(chronology8);
//        int int10 = mutableDateTime9.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone12);
//        org.joda.time.DateTime dateTime15 = dateTime13.withYearOfCentury(0);
//        mutableDateTime9.setDate((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime18 = dateTime13.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime21 = dateTime18.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime24 = dateTime21.withPeriodAdded(readablePeriod22, 0);
//        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
//        int[] intArray29 = new int[] { 0, 23, 97 };
//        try {
//            gJChronology6.validate((org.joda.time.ReadablePartial) localDateTime25, intArray29);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 23 for monthOfYear must not be larger than 12");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-12T05:23:56.136-07:00" + "'", str5.equals("2019-06-12T05:23:56.136-07:00"));
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertNotNull(intArray29);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("2019-06-12T05:23:49.972-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T05:23:49.972-07:00\" is malformed at \":23:49.972-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        int int11 = property9.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property9.getFieldType();
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.year();
//        org.joda.time.DurationField durationField15 = julianChronology13.hours();
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField17 = julianChronology16.hours();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField18 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType12, durationField15, durationField17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19436 + "'", int11 == 19436);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(dateTimeZone12);
        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = instant14.toMutableDateTime(chronology15);
        int int17 = mutableDateTime16.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
        mutableDateTime16.setDate((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime25 = dateTime20.minusWeeks((int) (short) 100);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime27 = dateTime11.withChronology(chronology26);
        try {
            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(5, 19431, 0, (int) (byte) 100, (int) ' ', 6, (int) (short) 100, chronology26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        java.util.Locale locale6 = null;
        try {
            long long7 = offsetDateTimeField3.set(0L, "2019-06-12T05:23:52.525-07:00", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:23:52.525-07:00\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        java.util.Locale locale6 = null;
        try {
            long long7 = offsetDateTimeField3.set((long) 100, "Pacific Standard Time", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) 'a', (int) (short) 100, 0, 20, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("2019-06-12T05:23:49.972-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T05:23:49.972-07:00\" is malformed at \"-06-12T05:23:49.972-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 19434, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 19402L + "'", long2 == 19402L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, 0);
        org.joda.time.LocalDateTime localDateTime18 = dateTime17.toLocalDateTime();
        org.joda.time.DateTime dateTime20 = dateTime17.withYearOfEra((int) ' ');
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        int int12 = property11.getMinimumValue();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19438 + "'", int10 == 19438);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour(19);
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withDayOfMonth(323);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 323 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = julianChronology0.equals(obj2);
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.era();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0L);
//        org.joda.time.Instant instant7 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = instant7.toMutableDateTime(chronology8);
//        int int10 = mutableDateTime9.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone12);
//        org.joda.time.DateTime dateTime15 = dateTime13.withYearOfCentury(0);
//        mutableDateTime9.setDate((org.joda.time.ReadableInstant) dateTime13);
//        int int17 = mutableDateTime9.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime9.toMutableDateTime();
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology0, (org.joda.time.ReadableDateTime) dateTime6, (org.joda.time.ReadableDateTime) mutableDateTime9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19439 + "'", int17 == 19439);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        try {
            long long9 = julianChronology0.getDateTimeMillis(1, 19431, 0, (-292269045), 323, 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269045 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        java.util.Date date12 = dateTime9.toDate();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        long long19 = offsetDateTimeField16.add((long) 1, (long) (short) -1);
        long long21 = offsetDateTimeField16.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField16.getType();
        org.joda.time.DateTime dateTime24 = dateTime9.withField(dateTimeFieldType22, (int) (short) 0);
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField26 = julianChronology25.hours();
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField28 = julianChronology27.minutes();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField29 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType22, durationField26, durationField28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31535999999L) + "'", long19 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-30412800000L) + "'", long21 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
        java.lang.String str18 = delegatedDateTimeField14.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[year]" + "'", str18.equals("DateTimeField[year]"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setHourOfDay(5);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("2019-06-12T05:23:52.261-07:00");
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(19439435, 1, 19439, 97, 4, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 10, (int) (short) 0, 19437, 4, (int) (short) -1, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.append(dateTimePrinter3);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray5 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParserArray5);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.ReadableDuration readableDuration7 = null;
        mutableDateTime2.add(readableDuration7);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
//        int int12 = mutableDateTime11.getMillisOfDay();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19440 + "'", int10 == 19440);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19440521 + "'", int12 == 19440521);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        try {
            long long4 = dateTimeFormatter0.parseMillis("19438");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19438\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime5 = dateTime2.withTimeAtStartOfDay();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime2.withFieldAdded(durationFieldType6, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        java.util.Date date12 = dateTime9.toDate();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        long long19 = offsetDateTimeField16.add((long) 1, (long) (short) -1);
        long long21 = offsetDateTimeField16.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField16.getType();
        org.joda.time.DateTime dateTime24 = dateTime9.withField(dateTimeFieldType22, (int) (short) 0);
        org.joda.time.DateTime dateTime26 = dateTime9.minusWeeks(19438);
        boolean boolean28 = dateTime9.isBefore((long) (byte) 10);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31535999999L) + "'", long19 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-30412800000L) + "'", long21 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) -1, 5, 0, 10, 324, (int) '#', chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 324 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1968");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("2019-06-12T05:23:52.525-07:00");
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        long long7 = offsetDateTimeField4.add((long) 1, (long) (short) -1);
        long long9 = offsetDateTimeField4.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField4.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField11 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31535999999L) + "'", long7 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-30412800000L) + "'", long9 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.Class<?> wildcardClass2 = dateTimeZone1.getClass();
        java.util.TimeZone timeZone3 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        java.util.Date date12 = dateTime9.toDate();
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withSecondOfMinute(19441661);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19441661 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
        try {
            org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfSecond(19431);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19431 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.setCopy(10);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 10);
        long long11 = offsetDateTimeField8.add((long) 1, (long) (short) -1);
        long long13 = offsetDateTimeField8.roundFloor((long) 3);
        long long16 = offsetDateTimeField8.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, (int) (short) 100);
        long long21 = offsetDateTimeField8.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant22 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MutableDateTime mutableDateTime24 = instant22.toMutableDateTime(chronology23);
        int int25 = mutableDateTime24.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime28.withYearOfCentury(0);
        mutableDateTime24.setDate((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.DateTime dateTime33 = dateTime28.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.DateTime dateTime39 = dateTime36.withPeriodAdded(readablePeriod37, 0);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDateTime40, locale41);
        int int43 = property2.compareTo((org.joda.time.ReadablePartial) localDateTime40);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-31535999999L) + "'", long11 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-30412800000L) + "'", long13 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 599616000001L + "'", long16 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3155760000003L + "'", long21 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1968" + "'", str42.equals("1968"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
        long long26 = offsetDateTimeField21.roundFloor((long) 3);
        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21);
        java.util.Locale locale34 = null;
        java.lang.String str35 = delegatedDateTimeField32.getAsText(19438, locale34);
        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = julianChronology36.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 10);
        long long42 = offsetDateTimeField39.add((long) 1, (long) (short) -1);
        long long44 = offsetDateTimeField39.roundFloor((long) 3);
        long long47 = offsetDateTimeField39.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField39, (int) (short) 100);
        long long52 = offsetDateTimeField39.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant53 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.MutableDateTime mutableDateTime55 = instant53.toMutableDateTime(chronology54);
        int int56 = mutableDateTime55.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone58);
        org.joda.time.DateTime dateTime61 = dateTime59.withYearOfCentury(0);
        mutableDateTime55.setDate((org.joda.time.ReadableInstant) dateTime59);
        org.joda.time.DateTime dateTime64 = dateTime59.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime67 = dateTime64.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        org.joda.time.DateTime dateTime70 = dateTime67.withPeriodAdded(readablePeriod68, 0);
        org.joda.time.LocalDateTime localDateTime71 = dateTime70.toLocalDateTime();
        java.util.Locale locale72 = null;
        java.lang.String str73 = offsetDateTimeField39.getAsText((org.joda.time.ReadablePartial) localDateTime71, locale72);
        int int74 = delegatedDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDateTime71);
        int[] intArray77 = new int[] { (short) 1 };
        try {
            int[] intArray79 = delegatedDateTimeField14.addWrapPartial((org.joda.time.ReadablePartial) localDateTime71, 323, intArray77, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 323");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "19438" + "'", str35.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-31535999999L) + "'", long42 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-30412800000L) + "'", long44 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 599616000001L + "'", long47 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 3155760000003L + "'", long52 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant53);
        org.junit.Assert.assertNotNull(mutableDateTime55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(localDateTime71);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "1968" + "'", str73.equals("1968"));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 292273002 + "'", int74 == 292273002);
        org.junit.Assert.assertNotNull(intArray77);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime4.plus((long) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.withSecondOfMinute(3);
        org.joda.time.DateTime dateTime13 = dateTime9.plusHours(31);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 23);
        long long16 = offsetDateTimeField3.add(3061065600020L, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime(dateTimeZone22);
        org.joda.time.Instant instant24 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MutableDateTime mutableDateTime26 = instant24.toMutableDateTime(chronology25);
        int int27 = mutableDateTime26.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withYearOfCentury(0);
        mutableDateTime26.setDate((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime35 = dateTime30.minusWeeks((int) (short) 100);
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime dateTime37 = dateTime21.withChronology(chronology36);
        org.joda.time.TimeOfDay timeOfDay38 = dateTime21.toTimeOfDay();
        int int39 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay38);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { 3, (byte) 100 };
        try {
            int[] intArray46 = offsetDateTimeField3.addWrapPartial(readablePartial40, 292273002, intArray44, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 292273002");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 6216825600020L + "'", long16 == 6216825600020L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(instant24);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(timeOfDay38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 292273002 + "'", int39 == 292273002);
        org.junit.Assert.assertNotNull(intArray44);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 19440);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 19440");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        java.lang.String str5 = mutableDateTime3.toString();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
//        try {
//            long long14 = gJChronology6.getDateTimeMillis((-1), 19440521, 19435, 19434, 1979, 2000, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19434 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-12T05:24:06.120-07:00" + "'", str5.equals("2019-06-12T05:24:06.120-07:00"));
//        org.junit.Assert.assertNotNull(gJChronology6);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("1968", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1968/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
//        mutableDateTime2.setMinuteOfDay((int) (short) 0);
//        long long14 = mutableDateTime2.getMillis();
//        try {
//            mutableDateTime2.setDate(19441, (int) 'a', (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19446 + "'", int10 == 19446);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-57593277L) + "'", long14 == (-57593277L));
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, 0);
        int int18 = dateTime14.getHourOfDay();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundHalfFloor((long) 0);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1123200000L + "'", long8 == 1123200000L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.hours();
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DurationField durationField3 = julianChronology0.seconds();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        try {
            mutableDateTime7.setMinuteOfHour(19441);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19441 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("BuddhistChronology[America/Los_Angeles]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"BuddhistChronology[America/Los_Angeles]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfMinute((-1), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 1123200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Coordinated Universal Time/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, 0);
        org.joda.time.LocalDateTime localDateTime18 = dateTime17.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime17, dateTimeZone22);
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        try {
            long long30 = julianChronology24.getDateTimeMillis((long) (-292269045), (int) (byte) 10, 19440, 0, 23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19440 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(julianChronology24);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        boolean boolean8 = mutableDateTime2.isBeforeNow();
        boolean boolean9 = mutableDateTime2.isEqualNow();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        int int11 = property9.get();
//        org.joda.time.DateTimeField dateTimeField12 = property9.getField();
//        org.joda.time.DateTimeField dateTimeField13 = property9.getField();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19448 + "'", int11 == 19448);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTimeZoneOffset("hi!", "org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported", false, (int) '4', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.yearOfEra();
        mutableDateTime7.add((long) (short) 10);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray22 = new int[] { 19440521, 3, 20, 19440, (short) 1 };
        try {
            int[] intArray24 = offsetDateTimeField3.add(readablePartial15, 19441661, intArray22, 19434);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19441661");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 0, locale3);
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        try {
//            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) julianChronology5, dateTimeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.JulianChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology5);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 20, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2000L + "'", long2 == 2000L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology7.getZone();
        java.lang.Object obj9 = null;
        boolean boolean10 = julianChronology7.equals(obj9);
        org.joda.time.DateTimeField dateTimeField11 = julianChronology7.weekyear();
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(0, 0, 0, 324, (int) (byte) 100, (int) ' ', 10, (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 324 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField3.getType();
//        org.joda.time.Instant instant10 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = instant10.toMutableDateTime(chronology11);
//        int int13 = mutableDateTime12.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone15);
//        org.joda.time.DateTime dateTime18 = dateTime16.withYearOfCentury(0);
//        mutableDateTime12.setDate((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime21 = dateTime16.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime24 = dateTime21.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTime24.getZone();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getName((long) (short) 10, locale27);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField30 = gregorianChronology29.centuries();
//        org.joda.time.DurationField durationField31 = gregorianChronology29.eras();
//        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone33 = julianChronology32.getZone();
//        org.joda.time.DurationField durationField34 = julianChronology32.minutes();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField31, durationField34);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The unit milliseconds must be at least 1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(instant10);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Pacific Standard Time" + "'", str28.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(julianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(durationField34);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone3);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19437);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendTimeZoneOffset("1968", false, (int) (byte) 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 23);
        long long16 = offsetDateTimeField3.add(3061065600020L, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime(dateTimeZone22);
        org.joda.time.Instant instant24 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MutableDateTime mutableDateTime26 = instant24.toMutableDateTime(chronology25);
        int int27 = mutableDateTime26.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withYearOfCentury(0);
        mutableDateTime26.setDate((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime35 = dateTime30.minusWeeks((int) (short) 100);
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime dateTime37 = dateTime21.withChronology(chronology36);
        org.joda.time.TimeOfDay timeOfDay38 = dateTime21.toTimeOfDay();
        int int39 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay38);
        org.joda.time.ReadablePartial readablePartial40 = null;
        java.util.Locale locale41 = null;
        try {
            java.lang.String str42 = offsetDateTimeField3.getAsShortText(readablePartial40, locale41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 6216825600020L + "'", long16 == 6216825600020L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(instant24);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(timeOfDay38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 292273002 + "'", int39 == 292273002);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        int int11 = property9.get();
//        org.joda.time.DateTimeField dateTimeField12 = property9.getField();
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, 19439, 19442, 19439);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19439 for secondOfDay must be in the range [19442,19439]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19451 + "'", int11 == 19451);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.hours();
        long long4 = durationField1.subtract((-57600000L), 15);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-111600000L) + "'", long4 == (-111600000L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury((int) 'a');
        boolean boolean16 = dateTime15.isBeforeNow();
        try {
            org.joda.time.DateTime dateTime20 = dateTime15.withDate(19431, 10, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-28800000L), (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28800000L) + "'", long2 == (-28800000L));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 0, (int) (byte) 10, 0, 0, 0, 19442);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19442 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
        long long26 = offsetDateTimeField21.roundFloor((long) 3);
        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
        long long34 = offsetDateTimeField21.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = instant35.toMutableDateTime(chronology36);
        int int38 = mutableDateTime37.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone40);
        org.joda.time.DateTime dateTime43 = dateTime41.withYearOfCentury(0);
        mutableDateTime37.setDate((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime46 = dateTime41.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 0);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime53, locale54);
        int int56 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime53);
        org.joda.time.Instant instant57 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.MutableDateTime mutableDateTime59 = instant57.toMutableDateTime(chronology58);
        int int60 = mutableDateTime59.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone62);
        org.joda.time.DateTime dateTime65 = dateTime63.withYearOfCentury(0);
        mutableDateTime59.setDate((org.joda.time.ReadableInstant) dateTime63);
        org.joda.time.DateTime dateTime68 = dateTime63.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime71 = dateTime68.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod72 = null;
        org.joda.time.DateTime dateTime74 = dateTime71.withPeriodAdded(readablePeriod72, 0);
        org.joda.time.LocalDateTime localDateTime75 = dateTime74.toLocalDateTime();
        int[] intArray81 = new int[] { (-28800000), 19434, 1, 2000 };
        try {
            int[] intArray83 = delegatedDateTimeField14.set((org.joda.time.ReadablePartial) localDateTime75, 19440521, intArray81, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19440521");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3155760000003L + "'", long34 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1968" + "'", str55.equals("1968"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292273002 + "'", int56 == 292273002);
        org.junit.Assert.assertNotNull(instant57);
        org.junit.Assert.assertNotNull(mutableDateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(localDateTime75);
        org.junit.Assert.assertNotNull(intArray81);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear(0);
//        java.lang.String str4 = instant0.toString(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019163T122412Z" + "'", str4.equals("2019163T122412Z"));
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withEra(19437);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19437 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        int int18 = offsetDateTimeField13.getDifference(0L, 8417L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.dayOfWeek();
        try {
            long long7 = julianChronology0.getDateTimeMillis(19439435, (int) (short) 100, (int) (short) -1, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
//        java.util.Date date12 = dateTime9.toDate();
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
//        long long19 = offsetDateTimeField16.add((long) 1, (long) (short) -1);
//        long long21 = offsetDateTimeField16.roundFloor((long) 3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField16.getType();
//        org.joda.time.DateTime dateTime24 = dateTime9.withField(dateTimeFieldType22, (int) (short) 0);
//        org.joda.time.DateTime dateTime26 = dateTime9.minusWeeks(19438);
//        long long27 = dateTime26.getMillis();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31535999999L) + "'", long19 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-30412800000L) + "'", long21 == (-30412800000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-11756140968950L) + "'", long27 == (-11756140968950L));
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        long long17 = offsetDateTimeField13.roundFloor(8417L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-30412800000L) + "'", long17 == (-30412800000L));
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        java.io.Writer writer1 = null;
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
//        mutableDateTime4.setDate((org.joda.time.ReadableInstant) dateTime8);
//        int int12 = mutableDateTime4.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime4.secondOfMinute();
//        mutableDateTime4.addWeeks(0);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) mutableDateTime4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19453 + "'", int12 == 19453);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("2019-06-12T05:23:52.525-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T05:23:52.525-07:00\" is malformed at \"19-06-12T05:23:52.525-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.hours();
        org.joda.time.DurationField durationField2 = julianChronology0.halfdays();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        mutableDateTime2.addYears((int) '4');
        mutableDateTime2.setMillisOfSecond((int) ' ');
        mutableDateTime2.setTime((long) 4);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, 19454020, 19447);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        mutableDateTime2.addMinutes((int) (byte) 100);
//        try {
//            mutableDateTime2.setDateTime(19440, 19437, 19435, (int) '4', 19439, 323, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19454 + "'", int10 == 19454);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("DateTimeField[year]", "1968");
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        long long16 = offsetDateTimeField3.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant17 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = instant17.toMutableDateTime(chronology18);
        int int20 = mutableDateTime19.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury(0);
        mutableDateTime19.setDate((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime28 = dateTime23.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime31 = dateTime28.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.withPeriodAdded(readablePeriod32, 0);
        org.joda.time.LocalDateTime localDateTime35 = dateTime34.toLocalDateTime();
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDateTime35, locale36);
        long long39 = offsetDateTimeField3.roundHalfCeiling(3061065600020L);
        java.lang.String str40 = offsetDateTimeField3.getName();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3155760000003L + "'", long16 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDateTime35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1968" + "'", str37.equals("1968"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 3062188800000L + "'", long39 == 3062188800000L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "year" + "'", str40.equals("year"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
        long long26 = offsetDateTimeField21.roundFloor((long) 3);
        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
        long long34 = offsetDateTimeField21.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = instant35.toMutableDateTime(chronology36);
        int int38 = mutableDateTime37.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone40);
        org.joda.time.DateTime dateTime43 = dateTime41.withYearOfCentury(0);
        mutableDateTime37.setDate((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime46 = dateTime41.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 0);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime53, locale54);
        int int56 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime53);
        long long58 = delegatedDateTimeField14.remainder(1L);
        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = julianChronology59.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, 10);
        long long65 = offsetDateTimeField62.add((long) 1, (long) (short) -1);
        long long67 = offsetDateTimeField62.roundFloor((long) 3);
        long long70 = offsetDateTimeField62.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField72 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField62, (int) (short) 100);
        long long75 = offsetDateTimeField62.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant76 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology77 = null;
        org.joda.time.MutableDateTime mutableDateTime78 = instant76.toMutableDateTime(chronology77);
        int int79 = mutableDateTime78.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone81 = null;
        org.joda.time.DateTime dateTime82 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone81);
        org.joda.time.DateTime dateTime84 = dateTime82.withYearOfCentury(0);
        mutableDateTime78.setDate((org.joda.time.ReadableInstant) dateTime82);
        org.joda.time.DateTime dateTime87 = dateTime82.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime90 = dateTime87.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod91 = null;
        org.joda.time.DateTime dateTime93 = dateTime90.withPeriodAdded(readablePeriod91, 0);
        org.joda.time.LocalDateTime localDateTime94 = dateTime93.toLocalDateTime();
        java.util.Locale locale95 = null;
        java.lang.String str96 = offsetDateTimeField62.getAsText((org.joda.time.ReadablePartial) localDateTime94, locale95);
        int int97 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDateTime94);
        try {
            org.joda.time.MutableDateTime mutableDateTime98 = new org.joda.time.MutableDateTime((java.lang.Object) delegatedDateTimeField14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.DelegatedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3155760000003L + "'", long34 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1968" + "'", str55.equals("1968"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292273002 + "'", int56 == 292273002);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 30412800001L + "'", long58 == 30412800001L);
        org.junit.Assert.assertNotNull(julianChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-31535999999L) + "'", long65 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-30412800000L) + "'", long67 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 599616000001L + "'", long70 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 3155760000003L + "'", long75 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant76);
        org.junit.Assert.assertNotNull(mutableDateTime78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 6 + "'", int79 == 6);
        org.junit.Assert.assertNotNull(dateTime84);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(dateTime90);
        org.junit.Assert.assertNotNull(dateTime93);
        org.junit.Assert.assertNotNull(localDateTime94);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "1968" + "'", str96.equals("1968"));
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + (-292269045) + "'", int97 == (-292269045));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        int int10 = mutableDateTime2.getSecondOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
        mutableDateTime2.setMinuteOfDay((int) (short) 0);
        long long14 = mutableDateTime2.getMillis();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime2.dayOfYear();
        long long16 = property15.remainder();
        try {
            org.joda.time.MutableDateTime mutableDateTime18 = property15.set("1969-12-31T16");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31T16\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-57599999L) + "'", long14 == (-57599999L));
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) -1, false);
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.append(dateTimePrinter10);
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatterBuilder11.toParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.append(dateTimePrinter7, dateTimeParser12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1L + "'", long0 == 1L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("year");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'year' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (short) 10, locale17);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DurationField durationField20 = gregorianChronology19.centuries();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        try {
//            int[] intArray24 = gregorianChronology19.get(readablePeriod21, (long) (-292269045), 0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
        int int5 = mutableDateTime4.getCenturyOfEra();
        int int6 = mutableDateTime4.getYearOfCentury();
        mutableDateTime4.setDate((long) (-1));
        int int9 = mutableDateTime4.getMinuteOfDay();
        org.joda.time.Instant instant10 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = instant10.toMutableDateTime(chronology11);
        int int13 = mutableDateTime12.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        mutableDateTime12.setZone(dateTimeZone14);
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) mutableDateTime12);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) mutableDateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 960 + "'", int9 == 960);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(19448);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-19448) + "'", int1 == (-19448));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add(20);
        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundCeiling();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            mutableDateTime9.add(durationFieldType10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime dateTime3 = dateTime1.minusWeeks((int) '#');
        try {
            java.lang.String str5 = dateTime1.toString("DateTimeField[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
        long long26 = offsetDateTimeField21.roundFloor((long) 3);
        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
        long long34 = offsetDateTimeField21.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = instant35.toMutableDateTime(chronology36);
        int int38 = mutableDateTime37.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone40);
        org.joda.time.DateTime dateTime43 = dateTime41.withYearOfCentury(0);
        mutableDateTime37.setDate((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime46 = dateTime41.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 0);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime53, locale54);
        int int56 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime53);
        boolean boolean58 = delegatedDateTimeField14.isLeap((long) 23);
        java.util.Locale locale59 = null;
        int int60 = delegatedDateTimeField14.getMaximumShortTextLength(locale59);
        try {
            long long63 = delegatedDateTimeField14.set((long) 19442, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3155760000003L + "'", long34 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1968" + "'", str55.equals("1968"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292273002 + "'", int56 == 292273002);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 9 + "'", int60 == 9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(19441661);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-19441661) + "'", int1 == (-19441661));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
        int int4 = mutableDateTime3.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
        int int11 = mutableDateTime3.getSecondOfDay();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime3.secondOfMinute();
        int int15 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "2019-06-12T05:24:11.615-07:00", 19);
        int int16 = mutableDateTime3.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-20) + "'", int15 == (-20));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        long long1 = instant0.getMillis();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
        org.joda.time.Instant instant16 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MutableDateTime mutableDateTime18 = instant16.toMutableDateTime(chronology17);
        int int19 = mutableDateTime18.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone21);
        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury(0);
        mutableDateTime18.setDate((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime27 = dateTime22.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.withPeriodAdded(readablePeriod31, 0);
        org.joda.time.LocalDateTime localDateTime34 = dateTime33.toLocalDateTime();
        boolean boolean35 = dateTimeZone15.isLocalDateTimeGap(localDateTime34);
        org.joda.time.DateTime dateTime36 = dateTime11.withZone(dateTimeZone15);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15, 324);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 324");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) 'a', (-292273003), 19454, 19448);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        mutableDateTime2.addYears((int) '4');
        mutableDateTime2.addMinutes((int) (byte) 0);
        mutableDateTime2.add((long) (-292273003));
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
        org.joda.time.DateTimeField dateTimeField5 = property2.getField();
        int int6 = property2.getMaximumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (byte) 100);
        try {
            mutableDateTime7.setDateTime(19439435, (int) (short) 100, 12, 6, 6, 19438, 23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19438 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-11756140968950L), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-11756140968850L) + "'", long2 == (-11756140968850L));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add(30412800001L, (long) 6);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 219801600001L + "'", long11 == 219801600001L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
        int int4 = mutableDateTime3.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        mutableDateTime3.setZone(dateTimeZone5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add(20);
        org.joda.time.MutableDateTime mutableDateTime10 = property7.roundCeiling();
        org.joda.time.MutableDateTime mutableDateTime11 = property7.getMutableDateTime();
        java.lang.String str12 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4:00 PM" + "'", str12.equals("4:00 PM"));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (short) 10, locale17);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DurationField durationField20 = gregorianChronology19.centuries();
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        try {
//            long long23 = gregorianChronology19.set(readablePartial21, (long) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
        try {
            org.joda.time.DateTime dateTime16 = dateTime11.withDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
        long long26 = offsetDateTimeField21.roundFloor((long) 3);
        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
        long long34 = offsetDateTimeField21.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = instant35.toMutableDateTime(chronology36);
        int int38 = mutableDateTime37.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone40);
        org.joda.time.DateTime dateTime43 = dateTime41.withYearOfCentury(0);
        mutableDateTime37.setDate((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime46 = dateTime41.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 0);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime53, locale54);
        int int56 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime53);
        boolean boolean58 = delegatedDateTimeField14.isLeap((long) 23);
        long long61 = delegatedDateTimeField14.getDifferenceAsLong((long) 20, (long) 19441661);
        try {
            long long64 = delegatedDateTimeField14.set(6216825600020L, "2019163T122412Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019163T122412Z\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3155760000003L + "'", long34 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1968" + "'", str55.equals("1968"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292273002 + "'", int56 == 292273002);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        try {
            mutableDateTime2.setHourOfDay(57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        java.io.Writer writer4 = null;
        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = instant5.toMutableDateTime(chronology6);
        int int8 = mutableDateTime7.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withYearOfCentury(0);
        mutableDateTime7.setDate((org.joda.time.ReadableInstant) dateTime11);
        int int15 = mutableDateTime7.getSecondOfDay();
        org.joda.time.MutableDateTime mutableDateTime16 = mutableDateTime7.toMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime17 = mutableDateTime7.toMutableDateTimeISO();
        try {
            dateTimeFormatter0.printTo(writer4, (org.joda.time.ReadableInstant) mutableDateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 57600 + "'", int15 == 57600);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField3.getType();
        int int10 = offsetDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        long long17 = offsetDateTimeField14.add((long) 1, (long) (short) -1);
        long long19 = offsetDateTimeField14.roundFloor((long) 3);
        long long22 = offsetDateTimeField14.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, (int) (short) 100);
        long long27 = offsetDateTimeField14.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant28 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = instant28.toMutableDateTime(chronology29);
        int int31 = mutableDateTime30.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone33);
        org.joda.time.DateTime dateTime36 = dateTime34.withYearOfCentury(0);
        mutableDateTime30.setDate((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime dateTime39 = dateTime34.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.DateTime dateTime45 = dateTime42.withPeriodAdded(readablePeriod43, 0);
        org.joda.time.LocalDateTime localDateTime46 = dateTime45.toLocalDateTime();
        java.util.Locale locale47 = null;
        java.lang.String str48 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDateTime46, locale47);
        int[] intArray50 = new int[] {};
        try {
            int[] intArray52 = offsetDateTimeField3.addWrapField((org.joda.time.ReadablePartial) localDateTime46, (int) (byte) 0, intArray50, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292269045) + "'", int10 == (-292269045));
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-31535999999L) + "'", long17 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-30412800000L) + "'", long19 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 599616000001L + "'", long22 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3155760000003L + "'", long27 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(localDateTime46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1968" + "'", str48.equals("1968"));
        org.junit.Assert.assertNotNull(intArray50);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 19435, 59, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-20), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("2019-06-12T05:23:52.261-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '2019-06-12T05:23:52.261-07:00' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
        int int4 = mutableDateTime3.getMonthOfYear();
        java.lang.String str5 = mutableDateTime3.toString();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
        try {
            long long14 = gJChronology6.getDateTimeMillis((-10), (int) (short) 0, 19441, (int) (short) 1, 2000, 19438, 19435);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31T16:00:00.001-08:00" + "'", str5.equals("1969-12-31T16:00:00.001-08:00"));
        org.junit.Assert.assertNotNull(gJChronology6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundHalfCeiling();
        java.util.Locale locale11 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = property6.set("19438", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19438 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.Instant instant7 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = instant7.toMutableDateTime(chronology8);
//        int int10 = mutableDateTime9.getCenturyOfEra();
//        int int11 = mutableDateTime9.getYearOfCentury();
//        mutableDateTime9.setDate((long) (-1));
//        boolean boolean14 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime9.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime16 = property15.roundHalfFloor();
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology17.getZone();
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName((long) 0, locale20);
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
//        boolean boolean24 = dateTimeZone18.isStandardOffset(6216825600020L);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((java.lang.Object) property15, dateTimeZone18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MutableDateTime$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 69 + "'", int11 == 69);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordinated Universal Time" + "'", str21.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.year();
        try {
            mutableDateTime2.setWeekOfWeekyear((-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.append(dateTimeFormatter6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No formatter supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("Coordinated Universal Time", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        long long16 = offsetDateTimeField3.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant17 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = instant17.toMutableDateTime(chronology18);
        int int20 = mutableDateTime19.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury(0);
        mutableDateTime19.setDate((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime28 = dateTime23.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime31 = dateTime28.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.withPeriodAdded(readablePeriod32, 0);
        org.joda.time.LocalDateTime localDateTime35 = dateTime34.toLocalDateTime();
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDateTime35, locale36);
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 10);
        long long44 = offsetDateTimeField41.add((long) 1, (long) (short) -1);
        long long46 = offsetDateTimeField41.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = offsetDateTimeField41.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType47, (-292269045));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3155760000003L + "'", long16 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDateTime35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1968" + "'", str37.equals("1968"));
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-31535999999L) + "'", long44 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-30412800000L) + "'", long46 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 19441661);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime4.setZone(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        int int13 = property11.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
        int int18 = skipUndoDateTimeField17.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600 + "'", int13 == 57600);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        int int11 = property9.get();
        org.joda.time.DateTimeField dateTimeField12 = property9.getField();
        org.joda.time.MutableDateTime mutableDateTime14 = property9.add(9);
        mutableDateTime14.setMillisOfSecond(0);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 19454020, 323);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6283648460L + "'", long2 == 6283648460L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTimeZoneOffset("2019-06-12T05:24:11.615-07:00", false, 0, 19440521);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000116d + "'", double1 == 2440587.500000116d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(30412800001L, 57619);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1752355123257619L + "'", long2 == 1752355123257619L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = julianChronology0.withZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) 0, locale5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, dateTimeZone3);
//        int int8 = dateTime1.getWeekyear();
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeekText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendTimeZoneOffset("Jan 31, 1968 3:59:59 PM", false, 19438, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DurationField durationField2 = julianChronology0.hours();
        try {
            long long10 = julianChronology0.getDateTimeMillis(3, 59, 1, 3, 9, 0, 292273002);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292273002 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = julianChronology0.get(readablePeriod2, (long) 19439, (long) 19447);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekyearOfCentury();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.hours();
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField4 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 19454020);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (short) 100, 0, 19435, 19431);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19435 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.Object obj2 = null;
        boolean boolean3 = julianChronology0.equals(obj2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.era();
        org.joda.time.DurationField durationField5 = julianChronology0.halfdays();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 19431, 6283648460L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 122097573226260L + "'", long2 == 122097573226260L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond(0, (int) '#');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHourOfDay((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfMonth((int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType7, 19454020);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        try {
            long long3 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long10 = offsetDateTimeField3.roundHalfCeiling((long) (short) 0);
        long long12 = offsetDateTimeField3.roundHalfEven(0L);
        org.joda.time.DurationField durationField13 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField14 = offsetDateTimeField3.getDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1123200000L + "'", long10 == 1123200000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1123200000L + "'", long12 == 1123200000L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 0, locale3);
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField6 = julianChronology5.weekyears();
//        org.joda.time.DurationField durationField7 = julianChronology5.centuries();
//        long long10 = durationField7.subtract((long) 19441661, 19439);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61344818620558339L) + "'", long10 == (-61344818620558339L));
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-111600000L), (java.lang.Number) (byte) 100, (java.lang.Number) 19452);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfMonth((int) '4');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendPattern("4:00 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) -1, false);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfSecond((-1), 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime5 = property3.addToCopy((long) (short) 10);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime5.toYearMonthDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(yearMonthDay7);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (-111600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (short) 10, locale17);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology19);
//        try {
//            long long26 = gregorianChronology19.getDateTimeMillis((long) 19439435, 6, 57600, (int) (byte) 10, 12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560361715136L + "'", long1 == 1560361715136L);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfMonth();
        int int6 = dateTime2.getEra();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DurationField durationField2 = julianChronology0.months();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        boolean boolean15 = delegatedDateTimeField14.isLenient();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.Instant instant18 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = instant18.toMutableDateTime(chronology19);
        int int21 = mutableDateTime20.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.withYearOfCentury(0);
        mutableDateTime20.setDate((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime29 = dateTime24.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.DateTime dateTime35 = dateTime32.withPeriodAdded(readablePeriod33, 0);
        org.joda.time.LocalDateTime localDateTime36 = dateTime35.toLocalDateTime();
        boolean boolean37 = dateTimeZone17.isLocalDateTimeGap(localDateTime36);
        int[] intArray40 = new int[] { 19439435 };
        try {
            int[] intArray42 = delegatedDateTimeField14.addWrapField((org.joda.time.ReadablePartial) localDateTime36, (-19441661), intArray40, 19438);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -19441661");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        int int13 = offsetDateTimeField3.getLeapAmount((long) (short) 1);
        long long15 = offsetDateTimeField3.roundHalfFloor(8417L);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        org.joda.time.Instant instant18 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = instant18.toMutableDateTime(chronology19);
        int int21 = mutableDateTime20.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.withYearOfCentury(0);
        mutableDateTime20.setDate((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime29 = dateTime24.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.DateTime dateTime35 = dateTime32.withPeriodAdded(readablePeriod33, 0);
        org.joda.time.LocalDateTime localDateTime36 = dateTime35.toLocalDateTime();
        boolean boolean37 = dateTimeZone17.isLocalDateTimeGap(localDateTime36);
        int[] intArray45 = new int[] { (-19441661), 57600, 59, (short) 0, 38914, 19435 };
        try {
            int[] intArray47 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localDateTime36, 19437, intArray45, (-292269045));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19437");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1123200000L + "'", long15 == 1123200000L);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(intArray45);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        java.util.Date date12 = dateTime9.toDate();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime5 = dateTime2.withTimeAtStartOfDay();
        try {
            java.lang.String str7 = dateTime5.toString("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury((int) 'a');
//        int int16 = dateTime11.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 465 + "'", int16 == 465);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
        int int4 = mutableDateTime3.getCenturyOfEra();
        int int5 = mutableDateTime3.getYearOfCentury();
        mutableDateTime3.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime3.copy();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = mutableDateTime3.toDateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) ' ');
        java.util.Date date13 = dateTime10.toDate();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 10);
        long long20 = offsetDateTimeField17.add((long) 1, (long) (short) -1);
        long long22 = offsetDateTimeField17.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField17.getType();
        org.joda.time.DateTime dateTime25 = dateTime10.withField(dateTimeFieldType23, (int) (short) 0);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-31535999999L) + "'", long20 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-30412800000L) + "'", long22 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = instant5.toMutableDateTime(chronology6);
        int int8 = mutableDateTime7.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withYearOfCentury(0);
        mutableDateTime7.setDate((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime11.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone20 = dateTime19.getZone();
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((-10), 38914, 19441, 4, 19438, dateTimeZone20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19438 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 23);
        long long16 = offsetDateTimeField3.add(3061065600020L, (long) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime(dateTimeZone22);
        org.joda.time.Instant instant24 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MutableDateTime mutableDateTime26 = instant24.toMutableDateTime(chronology25);
        int int27 = mutableDateTime26.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withYearOfCentury(0);
        mutableDateTime26.setDate((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime35 = dateTime30.minusWeeks((int) (short) 100);
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime dateTime37 = dateTime21.withChronology(chronology36);
        org.joda.time.TimeOfDay timeOfDay38 = dateTime21.toTimeOfDay();
        int int39 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay38);
        int int41 = offsetDateTimeField3.get((-57591583L));
        java.lang.String str42 = offsetDateTimeField3.getName();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 6216825600020L + "'", long16 == 6216825600020L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(instant24);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(timeOfDay38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 292273002 + "'", int39 == 292273002);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1979 + "'", int41 == 1979);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "year" + "'", str42.equals("year"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.Instant instant6 = mutableDateTime2.toInstant();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser10 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.append(dateTimePrinter9, dateTimeParser10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.hours();
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DurationField durationField3 = julianChronology0.seconds();
        org.joda.time.DurationField durationField4 = julianChronology0.weekyears();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 100, (int) (short) 100, 0, 19439435, 9, (int) (short) -1, 19452, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19439435 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        java.lang.String str5 = mutableDateTime3.toString();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
//        mutableDateTime3.addYears(0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-12T10:48:36.931-07:00" + "'", str5.equals("2019-06-12T10:48:36.931-07:00"));
//        org.junit.Assert.assertNotNull(gJChronology6);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        int int19 = skipUndoDateTimeField17.get((long) 3);
//        try {
//            long long22 = skipUndoDateTimeField17.set((-30412800000L), "2019-06-12T05:24:11.615-07:00");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:24:11.615-07:00\" for secondOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 38916 + "'", int13 == 38916);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57600 + "'", int19 == 57600);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        mutableDateTime2.add(readablePeriod4);
        try {
            mutableDateTime2.setMonthOfYear(57619);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57619 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DurationField durationField2 = julianChronology0.hours();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = buddhistChronology2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        boolean boolean17 = offsetDateTimeField13.isLeap((long) 19435);
        long long20 = offsetDateTimeField13.set((long) 465, (-10));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-65892268799535L) + "'", long20 == (-65892268799535L));
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        try {
//            long long25 = gregorianChronology0.getDateTimeMillis((int) 'a', 12, 292273002, (int) (byte) 10, 19439, 0, 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19439 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 38917 + "'", int13 == 38917);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology9.getZone();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName((long) 0, locale12);
//        long long15 = dateTimeZone8.getMillisKeepLocal(dateTimeZone10, 0L);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(19434, (int) (byte) 1, (int) (short) -1, 20, 1979, dateTimeZone8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1979 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28800000L) + "'", long15 == (-28800000L));
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) 0, locale5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, dateTimeZone3);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) '#', (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime4.plus((long) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.withSecondOfMinute(3);
        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour(19);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 19454, (java.lang.Number) (-30412800000L), (java.lang.Number) 19431);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        try {
            mutableDateTime2.setTime(3, 19454020, 19452, (-20));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19454020 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 38916, 28800323L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28761407L) + "'", long2 == (-28761407L));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField14.getAsShortText(readablePartial15, 19438, locale17);
        int int21 = delegatedDateTimeField14.getDifference((-11756140968850L), (long) (byte) 0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-372) + "'", int21 == (-372));
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        boolean boolean18 = skipUndoDateTimeField17.isSupported();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 38918 + "'", int13 == 38918);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.set((-111600000L), 19454);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 551468970000000L + "'", long11 == 551468970000000L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.Object obj2 = null;
        boolean boolean3 = julianChronology0.equals(obj2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "BuddhistChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.Instant instant3 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime(chronology4);
//        int int6 = mutableDateTime5.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(0);
//        mutableDateTime5.setDate((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime14 = dateTime9.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
//        org.joda.time.Instant instant19 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.MutableDateTime mutableDateTime21 = instant19.toMutableDateTime(chronology20);
//        int int22 = mutableDateTime21.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withYearOfCentury(0);
//        mutableDateTime21.setDate((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime30 = dateTime25.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime33 = dateTime30.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone34 = dateTime33.getZone();
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = dateTimeZone34.getName((long) (short) 10, locale36);
//        long long39 = dateTimeZone18.getMillisKeepLocal(dateTimeZone34, (long) (short) 0);
//        org.joda.time.DateTime dateTime40 = dateTime1.toDateTime(dateTimeZone34);
//        java.lang.String str41 = dateTimeZone34.toString();
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
//        boolean boolean45 = dateTime43.equals((java.lang.Object) dateTimeFormatter44);
//        boolean boolean46 = dateTime43.isEqualNow();
//        try {
//            org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34, (org.joda.time.ReadableInstant) dateTime43, 19441661);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 19441661");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Pacific Standard Time" + "'", str37.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "America/Los_Angeles" + "'", str41.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.append(dateTimePrinter6);
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatterBuilder7.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser8);
        java.lang.Appendable appendable10 = null;
        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = instant11.toMutableDateTime(chronology12);
        int int14 = mutableDateTime13.getCenturyOfEra();
        int int15 = mutableDateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime16 = mutableDateTime13.toDateTimeISO();
        try {
            dateTimeFormatter9.printTo(appendable10, (org.joda.time.ReadableInstant) dateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime13 = property12.roundHalfEven();
//        try {
//            org.joda.time.MutableDateTime mutableDateTime15 = property12.set("Property[millisOfSecond]");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[millisOfSecond]\" for millisOfSecond is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 38919 + "'", int10 == 38919);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) instant0);
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMillis(19437);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime4.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.clockhourOfHalfday();
//        java.lang.String str7 = buddhistChronology5.toString();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = dateTime10.getZone();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone11.getShortName((-1L), locale13);
//        org.joda.time.Chronology chronology15 = buddhistChronology5.withZone(dateTimeZone11);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(38917, (-28800000), 19454020, (-292273003), (-292273003), (org.joda.time.Chronology) buddhistChronology5);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str7.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PST" + "'", str14.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology15);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.year();
        java.lang.String str11 = property10.getName();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "year" + "'", str11.equals("year"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
        int int5 = mutableDateTime4.getCenturyOfEra();
        int int6 = mutableDateTime4.getYearOfCentury();
        mutableDateTime4.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime4.copy();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = mutableDateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks((int) ' ');
        java.util.Date date14 = dateTime11.toDate();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        long long21 = offsetDateTimeField18.add((long) 1, (long) (short) -1);
        long long23 = offsetDateTimeField18.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField18.getType();
        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType24, (int) (short) 0);
        org.joda.time.DateTime dateTime28 = dateTime11.minusWeeks(19438);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-31535999999L) + "'", long21 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-30412800000L) + "'", long23 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfMonth();
        int int6 = dateTime2.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        int int11 = property9.get();
//        org.joda.time.DateTimeField dateTimeField12 = property9.getField();
//        org.joda.time.MutableDateTime mutableDateTime14 = property9.add(9);
//        org.joda.time.Interval interval15 = property9.toInterval();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 38920 + "'", int11 == 38920);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(interval15);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
        long long26 = offsetDateTimeField21.roundFloor((long) 3);
        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
        long long34 = offsetDateTimeField21.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = instant35.toMutableDateTime(chronology36);
        int int38 = mutableDateTime37.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone40);
        org.joda.time.DateTime dateTime43 = dateTime41.withYearOfCentury(0);
        mutableDateTime37.setDate((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime46 = dateTime41.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 0);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime53, locale54);
        int int56 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime53);
        boolean boolean58 = delegatedDateTimeField14.isLeap((long) 23);
        long long61 = delegatedDateTimeField14.getDifferenceAsLong((long) 20, (long) 19441661);
        boolean boolean62 = delegatedDateTimeField14.isSupported();
        java.lang.String str63 = delegatedDateTimeField14.getName();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3155760000003L + "'", long34 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1968" + "'", str55.equals("1968"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292273002 + "'", int56 == 292273002);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "year" + "'", str63.equals("year"));
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        mutableDateTime2.addMinutes((int) (byte) 100);
//        int int16 = mutableDateTime2.getRoundingMode();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone18);
//        org.joda.time.DateTime dateTime21 = dateTime19.withYearOfCentury(0);
//        org.joda.time.DateTime.Property property22 = dateTime19.dayOfMonth();
//        boolean boolean23 = mutableDateTime2.equals((java.lang.Object) property22);
//        org.joda.time.DurationField durationField24 = property22.getRangeDurationField();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 38920 + "'", int10 == 38920);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        int int13 = offsetDateTimeField3.getLeapAmount((long) (short) 1);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        long long21 = offsetDateTimeField18.add((long) 1, (long) (short) -1);
        long long23 = offsetDateTimeField18.roundFloor((long) 3);
        long long26 = offsetDateTimeField18.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, (int) (short) 100);
        int int30 = offsetDateTimeField28.getLeapAmount((long) 3);
        boolean boolean31 = offsetDateTimeField28.isLenient();
        boolean boolean33 = offsetDateTimeField28.isLeap((long) (-28800000));
        int int35 = offsetDateTimeField28.getLeapAmount(8417L);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone37);
        org.joda.time.DateTime dateTime40 = dateTime38.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.toDateTime(dateTimeZone41);
        org.joda.time.DateTime dateTime43 = dateTime40.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime45 = dateTime43.withMinuteOfHour(19);
        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone47 = julianChronology46.getZone();
        org.joda.time.Instant instant48 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.MutableDateTime mutableDateTime50 = instant48.toMutableDateTime(chronology49);
        int int51 = mutableDateTime50.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone53);
        org.joda.time.DateTime dateTime56 = dateTime54.withYearOfCentury(0);
        mutableDateTime50.setDate((org.joda.time.ReadableInstant) dateTime54);
        org.joda.time.DateTime dateTime59 = dateTime54.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime62 = dateTime59.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.DateTime dateTime65 = dateTime62.withPeriodAdded(readablePeriod63, 0);
        org.joda.time.LocalDateTime localDateTime66 = dateTime65.toLocalDateTime();
        boolean boolean67 = dateTimeZone47.isLocalDateTimeGap(localDateTime66);
        org.joda.time.DateTime dateTime68 = dateTime43.withFields((org.joda.time.ReadablePartial) localDateTime66);
        org.joda.time.chrono.JulianChronology julianChronology70 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField71 = julianChronology70.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField(dateTimeField71, 10);
        long long76 = offsetDateTimeField73.add((long) 1, (long) (short) -1);
        long long79 = offsetDateTimeField73.addWrapField((long) 20, (int) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology82 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField83 = buddhistChronology82.clockhourOfHalfday();
        java.lang.String str84 = buddhistChronology82.toString();
        java.util.Locale locale85 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket86 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology82, locale85);
        java.util.Locale locale87 = dateTimeParserBucket86.getLocale();
        java.lang.String str88 = offsetDateTimeField73.getAsText((long) 9, locale87);
        java.lang.String str89 = offsetDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDateTime66, (-372), locale87);
        java.lang.String str90 = offsetDateTimeField3.getAsShortText(19434, locale87);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-31535999999L) + "'", long21 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-30412800000L) + "'", long23 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 599616000001L + "'", long26 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(julianChronology46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(instant48);
        org.junit.Assert.assertNotNull(mutableDateTime50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(localDateTime66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(julianChronology70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-31535999999L) + "'", long76 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 3061065600020L + "'", long79 == 3061065600020L);
        org.junit.Assert.assertNotNull(buddhistChronology82);
        org.junit.Assert.assertNotNull(dateTimeField83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str84.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale87);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "1979" + "'", str88.equals("1979"));
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "-372" + "'", str89.equals("-372"));
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "19434" + "'", str90.equals("19434"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        long long7 = offsetDateTimeField4.add((long) 1, (long) (short) -1);
        long long9 = offsetDateTimeField4.roundFloor((long) 3);
        long long12 = offsetDateTimeField4.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField15.getAsShortText(readablePartial16, 19438, locale18);
        boolean boolean20 = delegatedDateTimeField15.isLenient();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.clockhourOfHalfday();
        java.lang.String str26 = buddhistChronology24.toString();
        java.util.Locale locale27 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology24, locale27);
        java.util.Locale locale29 = dateTimeParserBucket28.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter22.withLocale(locale29);
        java.lang.String str31 = delegatedDateTimeField15.getAsShortText(10, locale29);
        try {
            java.lang.String str32 = org.joda.time.format.DateTimeFormat.patternForStyle("2019-06-12T05:23:52.525-07:00", locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 2019-06-12T05:23:52.525-07:00");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31535999999L) + "'", long7 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-30412800000L) + "'", long9 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000001L + "'", long12 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "19438" + "'", str19.equals("19438"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str26.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10" + "'", str31.equals("10"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 19448);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19448 + "'", int1 == 19448);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime2.toMutableDateTimeISO();
//        mutableDateTime2.setWeekyear(19452);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 38921 + "'", int10 == 38921);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19437);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        mutableDateTime3.setZone(dateTimeZone5);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime9 = property7.add((-1));
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        int int12 = property10.get();
//        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0d, (java.lang.Object) property10);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 38921 + "'", int12 == 38921);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1969-12-31T16:00:00.000-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-111600000L));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        org.joda.time.DateTime dateTime12 = property7.getDateTime();
        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
        org.joda.time.DateTime dateTime15 = dateTime12.minusDays((int) (short) 1);
        org.joda.time.DateTime dateTime17 = dateTime15.withCenturyOfEra(1979);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("2019-06-12T05:23:52.525-07:00");
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
        org.joda.time.DateTimeField dateTimeField5 = property2.getField();
        org.joda.time.Instant instant6 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = instant6.toMutableDateTime(chronology7);
        int int9 = mutableDateTime8.getCenturyOfEra();
        int int10 = mutableDateTime8.getYearOfCentury();
        mutableDateTime8.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime13 = mutableDateTime8.copy();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = mutableDateTime8.toDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) ' ');
        java.util.Date date18 = dateTime15.toDate();
        boolean boolean20 = dateTime15.isEqual(10L);
        org.joda.time.DateTime dateTime21 = dateTime15.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology22.getZone();
        java.lang.Object obj24 = null;
        boolean boolean25 = julianChronology22.equals(obj24);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology22.weekyear();
        org.joda.time.Instant instant27 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.MutableDateTime mutableDateTime29 = instant27.toMutableDateTime(chronology28);
        int int30 = mutableDateTime29.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
        org.joda.time.DateTime dateTime35 = dateTime33.withYearOfCentury(0);
        mutableDateTime29.setDate((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime38 = dateTime33.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime41 = dateTime38.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.DateTime dateTime44 = dateTime41.withPeriodAdded(readablePeriod42, 0);
        org.joda.time.LocalDateTime localDateTime45 = dateTime44.toLocalDateTime();
        long long47 = julianChronology22.set((org.joda.time.ReadablePartial) localDateTime45, 0L);
        org.joda.time.DateTime dateTime48 = dateTime15.withFields((org.joda.time.ReadablePartial) localDateTime45);
        int int49 = property2.compareTo((org.joda.time.ReadableInstant) dateTime48);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(instant27);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(localDateTime45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-59385600090L) + "'", long47 == (-59385600090L));
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add(20);
//        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundCeiling();
//        org.joda.time.MutableDateTime mutableDateTime10 = property6.getMutableDateTime();
//        int int11 = mutableDateTime10.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        long long21 = offsetDateTimeField18.add((long) 1, (long) (short) -1);
        long long23 = offsetDateTimeField18.roundFloor((long) 3);
        long long26 = offsetDateTimeField18.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18);
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField29.getAsText(19438, locale31);
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology33.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 10);
        long long39 = offsetDateTimeField36.add((long) 1, (long) (short) -1);
        long long41 = offsetDateTimeField36.roundFloor((long) 3);
        long long44 = offsetDateTimeField36.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, (int) (short) 100);
        long long49 = offsetDateTimeField36.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant50 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.MutableDateTime mutableDateTime52 = instant50.toMutableDateTime(chronology51);
        int int53 = mutableDateTime52.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone55);
        org.joda.time.DateTime dateTime58 = dateTime56.withYearOfCentury(0);
        mutableDateTime52.setDate((org.joda.time.ReadableInstant) dateTime56);
        org.joda.time.DateTime dateTime61 = dateTime56.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime64 = dateTime61.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod65 = null;
        org.joda.time.DateTime dateTime67 = dateTime64.withPeriodAdded(readablePeriod65, 0);
        org.joda.time.LocalDateTime localDateTime68 = dateTime67.toLocalDateTime();
        java.util.Locale locale69 = null;
        java.lang.String str70 = offsetDateTimeField36.getAsText((org.joda.time.ReadablePartial) localDateTime68, locale69);
        int int71 = delegatedDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDateTime68);
        boolean boolean73 = delegatedDateTimeField29.isLeap((long) 23);
        long long76 = delegatedDateTimeField29.getDifferenceAsLong((long) 19440, 0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter78 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology80 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField81 = buddhistChronology80.clockhourOfHalfday();
        java.lang.String str82 = buddhistChronology80.toString();
        java.util.Locale locale83 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket84 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology80, locale83);
        java.util.Locale locale85 = dateTimeParserBucket84.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter86 = dateTimeFormatter78.withLocale(locale85);
        java.lang.String str87 = delegatedDateTimeField29.getAsShortText((-1), locale85);
        java.lang.String str88 = offsetDateTimeField3.getAsText((int) (short) -1, locale85);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-31535999999L) + "'", long21 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-30412800000L) + "'", long23 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 599616000001L + "'", long26 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "19438" + "'", str32.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-31535999999L) + "'", long39 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-30412800000L) + "'", long41 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 599616000001L + "'", long44 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 3155760000003L + "'", long49 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant50);
        org.junit.Assert.assertNotNull(mutableDateTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(localDateTime68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1968" + "'", str70.equals("1968"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 292273002 + "'", int71 == 292273002);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 0L + "'", long76 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter78);
        org.junit.Assert.assertNotNull(buddhistChronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str82.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale85);
        org.junit.Assert.assertNotNull(dateTimeFormatter86);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "-1" + "'", str87.equals("-1"));
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "-1" + "'", str88.equals("-1"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 19441);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-209187057600000L) + "'", long1 == (-209187057600000L));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.append(dateTimePrinter5);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder6.toParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter2, dateTimeParser7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfCentury(0);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillis((long) 4);
        org.joda.time.DateTime dateTime10 = dateTime6.plusMillis(19437);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks(19440521);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-31535999999L), (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-31535999999L) + "'", long2 == (-31535999999L));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1970", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        java.util.Date date12 = dateTime9.toDate();
        boolean boolean14 = dateTime9.isEqual(10L);
        org.joda.time.DateTime.Property property15 = dateTime9.millisOfDay();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField3.getType();
        java.util.Locale locale10 = null;
        int int11 = offsetDateTimeField3.getMaximumTextLength(locale10);
        int int12 = offsetDateTimeField3.getOffset();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear(2000, false);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField3.getType();
        int int10 = offsetDateTimeField3.getMinimumValue();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292269045) + "'", int10 == (-292269045));
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
//        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
//        int int11 = mutableDateTime3.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime3.secondOfMinute();
//        int int15 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "2019-06-12T05:24:11.615-07:00", 19);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime3.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 80670 + "'", int11 == 80670);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-20) + "'", int15 == (-20));
//        org.junit.Assert.assertNotNull(property16);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((-19448));
        boolean boolean8 = dateTime6.isAfter(0L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        try {
            org.joda.time.DateTime dateTime7 = property5.setCopy("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
//        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime12 = dateTime7.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        org.joda.time.Instant instant17 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.MutableDateTime mutableDateTime19 = instant17.toMutableDateTime(chronology18);
//        int int20 = mutableDateTime19.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone22);
//        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury(0);
//        mutableDateTime19.setDate((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime dateTime28 = dateTime23.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime31 = dateTime28.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = dateTimeZone32.getName((long) (short) 10, locale34);
//        long long37 = dateTimeZone16.getMillisKeepLocal(dateTimeZone32, (long) (short) 0);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = dateTimeZone32.getShortName((long) (short) 0, locale39);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) '#', dateTimeZone32);
//        org.joda.time.Chronology chronology42 = dateTime41.getChronology();
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Pacific Standard Time" + "'", str35.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PST" + "'", str40.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology42);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        boolean boolean16 = offsetDateTimeField13.isLenient();
        java.lang.String str17 = offsetDateTimeField13.getName();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "year" + "'", str17.equals("year"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime13 = dateTime6.plus((long) 2000);
        try {
            org.joda.time.DateTime dateTime15 = dateTime13.withDayOfMonth(57619);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57619 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.clockhourOfHalfday();
        java.lang.String str12 = buddhistChronology10.toString();
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology10, locale13);
        java.lang.Integer int15 = dateTimeParserBucket14.getOffsetInteger();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 10);
        long long22 = offsetDateTimeField19.add((long) 1, (long) (short) -1);
        long long24 = offsetDateTimeField19.roundFloor((long) 3);
        long long27 = offsetDateTimeField19.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField19, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField19);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsText(19438, locale32);
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = julianChronology34.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 10);
        long long40 = offsetDateTimeField37.add((long) 1, (long) (short) -1);
        long long42 = offsetDateTimeField37.roundFloor((long) 3);
        long long45 = offsetDateTimeField37.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField37, (int) (short) 100);
        long long50 = offsetDateTimeField37.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant51 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.MutableDateTime mutableDateTime53 = instant51.toMutableDateTime(chronology52);
        int int54 = mutableDateTime53.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone56);
        org.joda.time.DateTime dateTime59 = dateTime57.withYearOfCentury(0);
        mutableDateTime53.setDate((org.joda.time.ReadableInstant) dateTime57);
        org.joda.time.DateTime dateTime62 = dateTime57.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime65 = dateTime62.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod66 = null;
        org.joda.time.DateTime dateTime68 = dateTime65.withPeriodAdded(readablePeriod66, 0);
        org.joda.time.LocalDateTime localDateTime69 = dateTime68.toLocalDateTime();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField37.getAsText((org.joda.time.ReadablePartial) localDateTime69, locale70);
        int int72 = delegatedDateTimeField30.getMaximumValue((org.joda.time.ReadablePartial) localDateTime69);
        long long74 = delegatedDateTimeField30.remainder(1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = delegatedDateTimeField30.getType();
        org.joda.time.chrono.JulianChronology julianChronology77 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField78 = julianChronology77.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField78, 10);
        long long83 = offsetDateTimeField80.add((long) 1, (long) (short) -1);
        long long86 = offsetDateTimeField80.addWrapField((long) 20, (int) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology89 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField90 = buddhistChronology89.clockhourOfHalfday();
        java.lang.String str91 = buddhistChronology89.toString();
        java.util.Locale locale92 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket93 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology89, locale92);
        java.util.Locale locale94 = dateTimeParserBucket93.getLocale();
        java.lang.String str95 = offsetDateTimeField80.getAsText((long) 9, locale94);
        dateTimeParserBucket14.saveField(dateTimeFieldType75, "19438", locale94);
        try {
            java.lang.String str97 = dateTime4.toString("ISOChronology[UTC]", locale94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: I");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str12.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(int15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31535999999L) + "'", long22 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-30412800000L) + "'", long24 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 599616000001L + "'", long27 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "19438" + "'", str33.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-31535999999L) + "'", long40 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-30412800000L) + "'", long42 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 599616000001L + "'", long45 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 3155760000003L + "'", long50 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant51);
        org.junit.Assert.assertNotNull(mutableDateTime53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(localDateTime69);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "1968" + "'", str71.equals("1968"));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292273002 + "'", int72 == 292273002);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 30412800001L + "'", long74 == 30412800001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertNotNull(julianChronology77);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + (-31535999999L) + "'", long83 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 3061065600020L + "'", long86 == 3061065600020L);
        org.junit.Assert.assertNotNull(buddhistChronology89);
        org.junit.Assert.assertNotNull(dateTimeField90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str91.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale94);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "1979" + "'", str95.equals("1979"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
        java.lang.String str3 = buddhistChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
        java.lang.Integer int6 = dateTimeParserBucket5.getOffsetInteger();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 10);
        long long13 = offsetDateTimeField10.add((long) 1, (long) (short) -1);
        long long15 = offsetDateTimeField10.roundFloor((long) 3);
        long long18 = offsetDateTimeField10.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10);
        java.util.Locale locale23 = null;
        java.lang.String str24 = delegatedDateTimeField21.getAsText(19438, locale23);
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 10);
        long long31 = offsetDateTimeField28.add((long) 1, (long) (short) -1);
        long long33 = offsetDateTimeField28.roundFloor((long) 3);
        long long36 = offsetDateTimeField28.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField28, (int) (short) 100);
        long long41 = offsetDateTimeField28.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant42 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.MutableDateTime mutableDateTime44 = instant42.toMutableDateTime(chronology43);
        int int45 = mutableDateTime44.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone47);
        org.joda.time.DateTime dateTime50 = dateTime48.withYearOfCentury(0);
        mutableDateTime44.setDate((org.joda.time.ReadableInstant) dateTime48);
        org.joda.time.DateTime dateTime53 = dateTime48.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime56 = dateTime53.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.DateTime dateTime59 = dateTime56.withPeriodAdded(readablePeriod57, 0);
        org.joda.time.LocalDateTime localDateTime60 = dateTime59.toLocalDateTime();
        java.util.Locale locale61 = null;
        java.lang.String str62 = offsetDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDateTime60, locale61);
        int int63 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDateTime60);
        long long65 = delegatedDateTimeField21.remainder(1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = delegatedDateTimeField21.getType();
        org.joda.time.chrono.JulianChronology julianChronology68 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField69 = julianChronology68.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField(dateTimeField69, 10);
        long long74 = offsetDateTimeField71.add((long) 1, (long) (short) -1);
        long long77 = offsetDateTimeField71.addWrapField((long) 20, (int) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology80 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField81 = buddhistChronology80.clockhourOfHalfday();
        java.lang.String str82 = buddhistChronology80.toString();
        java.util.Locale locale83 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket84 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology80, locale83);
        java.util.Locale locale85 = dateTimeParserBucket84.getLocale();
        java.lang.String str86 = offsetDateTimeField71.getAsText((long) 9, locale85);
        dateTimeParserBucket5.saveField(dateTimeFieldType66, "19438", locale85);
        org.joda.time.Chronology chronology88 = dateTimeParserBucket5.getChronology();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31535999999L) + "'", long13 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-30412800000L) + "'", long15 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 599616000001L + "'", long18 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "19438" + "'", str24.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31535999999L) + "'", long31 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-30412800000L) + "'", long33 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 599616000001L + "'", long36 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 3155760000003L + "'", long41 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant42);
        org.junit.Assert.assertNotNull(mutableDateTime44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localDateTime60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1968" + "'", str62.equals("1968"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 292273002 + "'", int63 == 292273002);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 30412800001L + "'", long65 == 30412800001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNotNull(julianChronology68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-31535999999L) + "'", long74 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 3061065600020L + "'", long77 == 3061065600020L);
        org.junit.Assert.assertNotNull(buddhistChronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str82.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "1979" + "'", str86.equals("1979"));
        org.junit.Assert.assertNotNull(chronology88);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
        java.lang.String str3 = buddhistChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
        java.lang.Integer int6 = dateTimeParserBucket5.getOffsetInteger();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        boolean boolean8 = dateTimeParserBucket5.restoreState((java.lang.Object) gregorianChronology7);
        try {
            long long16 = gregorianChronology7.getDateTimeMillis((int) (byte) 0, (-292269045), (int) (short) 10, 19447, 1979, 19452, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19447 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        boolean boolean16 = offsetDateTimeField13.isLenient();
        boolean boolean18 = offsetDateTimeField13.isLeap((long) (-28800000));
        long long20 = offsetDateTimeField13.roundHalfCeiling((long) (short) 1);
        boolean boolean22 = offsetDateTimeField13.isLeap((long) (-19441661));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1123200000L + "'", long20 == 1123200000L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfFloor();
        mutableDateTime11.setMinuteOfDay(4);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime11.weekyear();
        boolean boolean15 = mutableDateTime11.isEqualNow();
        mutableDateTime11.addHours((int) (short) 10);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number8 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-19441661), (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19441661 + "'", int2 == 19441661);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.monthOfYear();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, 0);
        org.joda.time.LocalDateTime localDateTime18 = dateTime17.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime17, dateTimeZone22);
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.DateTime dateTime25 = dateTime17.plus(readableDuration24);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("1970");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        java.lang.String str4 = mutableDateTime2.toString();
//        mutableDateTime2.setMillis((long) 2000);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-10T22:24:32.523-07:00" + "'", str4.equals("2019-06-10T22:24:32.523-07:00"));
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfHour(4, 20);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendShortText(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2019-06-12T05:24:11.615-07:00", false);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("2019-06-10T22:24:29.914-07:00", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        int int11 = property9.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property9.getFieldType();
//        org.joda.time.DateTimeField dateTimeField13 = property9.getField();
//        org.joda.time.MutableDateTime mutableDateTime15 = property9.add(599616000001L);
//        org.joda.time.Interval interval16 = property9.toInterval();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 80672 + "'", int11 == 80672);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(interval16);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendFractionOfDay(2, (-372));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str8 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number9 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-12T05:23:49.972-07:00");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-12T05:23:49.972-07:00" + "'", str2.equals("2019-06-12T05:23:49.972-07:00"));
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.clockhourOfHalfday();
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology8.getZone();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName((long) 0, locale11);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
//        boolean boolean15 = dateTimeZone9.isStandardOffset(6216825600020L);
//        org.joda.time.Chronology chronology16 = buddhistChronology6.withZone(dateTimeZone9);
//        try {
//            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(31, 19437, 19441, 19452, (-292269045), 19448, chronology16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19437 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(chronology16);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 38916);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendLiteral("1968");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfHour((int) (short) -1, 38917);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 4);
        java.lang.String str4 = dateTimeFormatter2.print((long) 19434);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withPivotYear(38920);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16" + "'", str4.equals("1969-12-31T16"));
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundHalfCeiling();
        org.joda.time.MutableDateTime mutableDateTime10 = property6.getMutableDateTime();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getMillisOfDay();
//        try {
//            mutableDateTime2.setMillisOfSecond(57619);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57619 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 80673159 + "'", int10 == 80673159);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(323);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay((int) (byte) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendDayOfMonth((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        boolean boolean16 = offsetDateTimeField13.isLenient();
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField13.getMaximumTextLength(locale17);
        org.joda.time.DurationField durationField19 = offsetDateTimeField13.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        boolean boolean13 = offsetDateTimeField3.isLeap((long) 19435);
        long long15 = offsetDateTimeField3.roundHalfCeiling((-57585880L));
        int int17 = offsetDateTimeField3.getMaximumValue((long) 10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1123200000L + "'", long15 == 1123200000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292273002 + "'", int17 == 292273002);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField3.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 38920, 19441, 38914);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 38920 for year must be in the range [19441,38914]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        java.lang.String str4 = mutableDateTime2.toString();
//        int int5 = mutableDateTime2.getYearOfCentury();
//        int int6 = mutableDateTime2.getYear();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-10T22:24:34.005-07:00" + "'", str4.equals("2019-06-10T22:24:34.005-07:00"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.Instant instant7 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = instant7.toMutableDateTime(chronology8);
//        int int10 = mutableDateTime9.getCenturyOfEra();
//        int int11 = mutableDateTime9.getYearOfCentury();
//        mutableDateTime9.setDate((long) (-1));
//        boolean boolean14 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
//        try {
//            mutableDateTime9.setSecondOfMinute(465);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 465 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        try {
            long long9 = iSOChronology1.getDateTimeMillis(24, (int) (short) 10, 0, 19452, 1970, (int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19452 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        java.lang.Class<?> wildcardClass4 = dateTimeFormatter0.getClass();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
        long long19 = delegatedDateTimeField14.roundCeiling((long) 9);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1123200000L + "'", long19 == 1123200000L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundHalfCeiling();
        mutableDateTime9.setMinuteOfDay(0);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
//        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
//        int int11 = mutableDateTime3.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime3.toMutableDateTime();
//        mutableDateTime3.setMinuteOfDay((int) (short) 0);
//        long long15 = mutableDateTime3.getMillis();
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime3.dayOfYear();
//        int int19 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported", 292273002);
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime3.minuteOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 80674 + "'", int11 == 80674);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-57565816L) + "'", long15 == (-57565816L));
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-292273003) + "'", int19 == (-292273003));
//        org.junit.Assert.assertNotNull(property20);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        mutableDateTime2.addMinutes((int) (byte) 100);
//        int int16 = mutableDateTime2.getRoundingMode();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone18);
//        org.joda.time.DateTime dateTime21 = dateTime19.withYearOfCentury(0);
//        org.joda.time.DateTime.Property property22 = dateTime19.dayOfMonth();
//        boolean boolean23 = mutableDateTime2.equals((java.lang.Object) property22);
//        java.lang.String str24 = property22.getAsText();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 80674 + "'", int10 == 80674);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31" + "'", str24.equals("31"));
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        boolean boolean9 = dateTime4.isBefore(0L);
        org.joda.time.DateTime dateTime11 = dateTime4.withYearOfEra(57600);
        org.joda.time.DateTime dateTime13 = dateTime11.withSecondOfMinute(2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology10.getZone();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone11.getName((long) 0, locale13);
//        long long16 = dateTimeZone9.getMillisKeepLocal(dateTimeZone11, 0L);
//        org.joda.time.Instant instant17 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.MutableDateTime mutableDateTime19 = instant17.toMutableDateTime(chronology18);
//        int int20 = mutableDateTime19.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone22);
//        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury(0);
//        mutableDateTime19.setDate((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime dateTime28 = dateTime23.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime31 = dateTime28.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
//        org.joda.time.Instant instant33 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.MutableDateTime mutableDateTime35 = instant33.toMutableDateTime(chronology34);
//        int int36 = mutableDateTime35.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone38);
//        org.joda.time.DateTime dateTime41 = dateTime39.withYearOfCentury(0);
//        mutableDateTime35.setDate((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.DateTime dateTime44 = dateTime39.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime47 = dateTime44.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone48 = dateTime47.getZone();
//        java.util.Locale locale50 = null;
//        java.lang.String str51 = dateTimeZone48.getName((long) (short) 10, locale50);
//        long long53 = dateTimeZone32.getMillisKeepLocal(dateTimeZone48, (long) (short) 0);
//        java.util.Locale locale55 = null;
//        java.lang.String str56 = dateTimeZone48.getShortName((long) (short) 0, locale55);
//        long long58 = dateTimeZone11.getMillisKeepLocal(dateTimeZone48, (long) 323);
//        try {
//            org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(19454020, 19437, 19431, (-20), 23, (-1), dateTimeZone48);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -20 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-28800000L) + "'", long16 == (-28800000L));
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(instant33);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Pacific Standard Time" + "'", str51.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "PST" + "'", str56.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 28800323L + "'", long58 == 28800323L);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendFractionOfSecond(19440, 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) 0, locale5);
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
//        boolean boolean9 = dateTimeZone3.isStandardOffset(6216825600020L);
//        org.joda.time.Chronology chronology10 = buddhistChronology0.withZone(dateTimeZone3);
//        org.joda.time.DurationField durationField11 = buddhistChronology0.eras();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField3.getType();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFieldType9, obj10);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "BuddhistChronology[America/Los_Angeles]");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray19 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType9, dateTimeFieldType16 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList20 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList20, dateTimeFieldTypeArray19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList20, false, false);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.joda.time.Instant instant7 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = instant7.toMutableDateTime(chronology8);
//        int int10 = mutableDateTime9.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone12);
//        org.joda.time.DateTime dateTime15 = dateTime13.withYearOfCentury(0);
//        mutableDateTime9.setDate((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime18 = dateTime13.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime21 = dateTime18.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = dateTimeZone22.getName((long) (short) 10, locale24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DurationField durationField27 = gregorianChronology26.centuries();
//        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone29 = julianChronology28.getZone();
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = dateTimeZone29.getName((long) 0, locale31);
//        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField34 = julianChronology33.weekyears();
//        org.joda.time.DurationField durationField35 = julianChronology33.centuries();
//        boolean boolean36 = gregorianChronology26.equals((java.lang.Object) julianChronology33);
//        org.joda.time.DateTimeZone dateTimeZone37 = julianChronology33.getZone();
//        try {
//            org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(38918, (-28800000), 0, (int) (short) 0, 324, 38914, (-19448), dateTimeZone37);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 324 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Pacific Standard Time" + "'", str25.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(julianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Coordinated Universal Time" + "'", str32.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(28800052L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(30412800001L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.Instant instant4 = instant1.toInstant();
        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = instant5.toMutableDateTime(chronology6);
        int int8 = mutableDateTime7.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        mutableDateTime7.setZone(dateTimeZone9);
        mutableDateTime7.addWeekyears(0);
        int int13 = instant1.compareTo((org.joda.time.ReadableInstant) mutableDateTime7);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        try {
            long long5 = dateTimeFormatter0.parseMillis("1968");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1968\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime11.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTime.Property property16 = dateTime11.era();
        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 10);
        long long25 = offsetDateTimeField22.add((long) 1, (long) (short) -1);
        long long27 = offsetDateTimeField22.roundFloor((long) 3);
        long long30 = offsetDateTimeField22.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22);
        org.joda.time.ReadablePartial readablePartial34 = null;
        java.util.Locale locale36 = null;
        java.lang.String str37 = delegatedDateTimeField33.getAsShortText(readablePartial34, 19438, locale36);
        boolean boolean38 = delegatedDateTimeField33.isLenient();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.clockhourOfHalfday();
        java.lang.String str44 = buddhistChronology42.toString();
        java.util.Locale locale45 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology42, locale45);
        java.util.Locale locale47 = dateTimeParserBucket46.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatter40.withLocale(locale47);
        java.lang.String str49 = delegatedDateTimeField33.getAsShortText(10, locale47);
        try {
            org.joda.time.DateTime dateTime50 = property16.setCopy("ISOChronology[UTC]", locale47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[UTC]\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31535999999L) + "'", long25 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-30412800000L) + "'", long27 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000001L + "'", long30 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "19438" + "'", str37.equals("19438"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str44.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale47);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10" + "'", str49.equals("10"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(38915, 19439435, (int) (byte) 100, 80671, (-372), 6, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 80671 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendPattern("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology5.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField8, (int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.clockhourOfHalfday();
        java.lang.String str15 = buddhistChronology13.toString();
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology13, locale16);
        java.util.Locale locale18 = dateTimeParserBucket17.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter11.withLocale(locale18);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 1970, (org.joda.time.Chronology) julianChronology1, locale18);
        dateTimeParserBucket20.setPivotYear((java.lang.Integer) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "hi!");
        java.lang.String str26 = illegalFieldValueException25.getIllegalStringValue();
        illegalFieldValueException25.prependMessage("Jan 31, 1968 3:59:59 PM");
        boolean boolean29 = dateTimeParserBucket20.restoreState((java.lang.Object) illegalFieldValueException25);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str15.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime13 = property12.roundHalfEven();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.minuteOfDay();
//        try {
//            mutableDateTime13.setDayOfMonth(97);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 48275 + "'", int10 == 48275);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(property14);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 2, 1560230670512L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3120461341024L + "'", long2 == 3120461341024L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime5 = dateTime2.withTimeAtStartOfDay();
        long long6 = dateTime5.getMillis();
        long long7 = dateTime5.getMillis();
        org.joda.time.DateTime dateTime9 = dateTime5.plusWeeks(323);
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime13 = dateTime9.withYear(4);
        org.joda.time.DateTime.Property property14 = dateTime9.hourOfDay();
        org.joda.time.Interval interval15 = property14.toInterval();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-57600000L) + "'", long7 == (-57600000L));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(interval15);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime dateTime7 = dateTime4.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withYearOfCentury(19439435);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19439435 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, 0);
        org.joda.time.LocalDateTime localDateTime18 = dateTime17.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime17, dateTimeZone22);
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone22);
        try {
            long long32 = julianChronology24.getDateTimeMillis(38921, 0, 19441, 19454020, (int) (byte) 1, 19442, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19454020 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(julianChronology24);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        java.util.Date date12 = dateTime9.toDate();
        boolean boolean14 = dateTime9.isEqual(10L);
        org.joda.time.DateTime dateTime15 = dateTime9.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
        java.lang.Object obj18 = null;
        boolean boolean19 = julianChronology16.equals(obj18);
        org.joda.time.DateTimeField dateTimeField20 = julianChronology16.weekyear();
        org.joda.time.Instant instant21 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.MutableDateTime mutableDateTime23 = instant21.toMutableDateTime(chronology22);
        int int24 = mutableDateTime23.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.withYearOfCentury(0);
        mutableDateTime23.setDate((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime32 = dateTime27.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime35 = dateTime32.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.withPeriodAdded(readablePeriod36, 0);
        org.joda.time.LocalDateTime localDateTime39 = dateTime38.toLocalDateTime();
        long long41 = julianChronology16.set((org.joda.time.ReadablePartial) localDateTime39, 0L);
        org.joda.time.DateTime dateTime42 = dateTime9.withFields((org.joda.time.ReadablePartial) localDateTime39);
        org.joda.time.DateTime dateTime43 = dateTime42.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(instant21);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(localDateTime39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-59385600090L) + "'", long41 == (-59385600090L));
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        java.util.Date date3 = mutableDateTime2.toDate();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        boolean boolean16 = offsetDateTimeField13.isLenient();
        boolean boolean18 = offsetDateTimeField13.isLeap((long) (-28800000));
        long long20 = offsetDateTimeField13.roundHalfCeiling((long) (short) 1);
        try {
            long long23 = offsetDateTimeField13.set((long) 19447, "1969-12-31T16");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31T16\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1123200000L + "'", long20 == 1123200000L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour(19);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks(0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        int int7 = mutableDateTime2.getMinuteOfDay();
//        try {
//            mutableDateTime2.setDate((-292273003), 19438, (-19448));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19438 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 804 + "'", int7 == 804);
//    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        mutableDateTime2.addMinutes((int) (byte) 100);
//        mutableDateTime2.addMillis((-292269045));
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property20 = dateTime19.secondOfMinute();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfCeilingCopy();
//        int int22 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean23 = dateTime21.isBeforeNow();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
//        java.lang.String str25 = dateTime21.toString(dateTimeFormatter24);
//        org.joda.time.DateTime dateTime27 = dateTime21.minusHours(100);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 48276 + "'", int10 == 48276);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969-12-31T16:00:00.000-08:00" + "'", str25.equals("1969-12-31T16:00:00.000-08:00"));
//        org.junit.Assert.assertNotNull(dateTime27);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 1970);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500022801d + "'", double1 == 2440587.500022801d);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime13 = property11.addWrapField((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime14 = property11.roundCeiling();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 48276 + "'", int10 == 48276);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) (short) 10);
        int int5 = dateTime4.getDayOfWeek();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(19434, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58302 + "'", int2 == 58302);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "2019-06-12T10:48:36.931-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime dateTime3 = dateTime1.minusWeeks((int) '#');
        boolean boolean4 = dateTime1.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime4.setZone(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.add(20);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property12 = dateTime6.hourOfDay();
        try {
            org.joda.time.DateTime dateTime14 = property12.setCopy(19448);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19448 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, 0);
        boolean boolean19 = dateTime14.isBefore(3062188800000L);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        java.lang.String str5 = mutableDateTime3.toString();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
//        mutableDateTime3.setWeekOfWeekyear(1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.clockhourOfHalfday();
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName((long) 0, locale15);
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
//        boolean boolean19 = dateTimeZone13.isStandardOffset(6216825600020L);
//        org.joda.time.Chronology chronology20 = buddhistChronology10.withZone(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone22);
//        org.joda.time.Chronology chronology24 = buddhistChronology10.withZone(dateTimeZone22);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter9.withZone(dateTimeZone22);
//        org.joda.time.DateTime dateTime26 = mutableDateTime3.toDateTime(dateTimeZone22);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-12T13:24:36.882-07:00" + "'", str5.equals("2019-06-12T13:24:36.882-07:00"));
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfHour(4, 20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
        long long26 = offsetDateTimeField21.roundFloor((long) 3);
        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
        long long34 = offsetDateTimeField21.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = instant35.toMutableDateTime(chronology36);
        int int38 = mutableDateTime37.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone40);
        org.joda.time.DateTime dateTime43 = dateTime41.withYearOfCentury(0);
        mutableDateTime37.setDate((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime46 = dateTime41.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 0);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime53, locale54);
        int int56 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime53);
        long long58 = delegatedDateTimeField14.remainder(1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = delegatedDateTimeField14.getType();
        try {
            long long62 = delegatedDateTimeField14.set((long) 19447, "2019-06-12T05:23:59.102-07:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:23:59.102-07:00\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3155760000003L + "'", long34 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1968" + "'", str55.equals("1968"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292273002 + "'", int56 == 292273002);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 30412800001L + "'", long58 == 30412800001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
        java.lang.String str3 = buddhistChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
        java.lang.Integer int6 = dateTimeParserBucket5.getOffsetInteger();
        java.lang.Object obj7 = dateTimeParserBucket5.saveState();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        try {
            mutableDateTime2.setMonthOfYear(80674);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 80674 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.withMillisOfDay(19434);
        org.joda.time.TimeOfDay timeOfDay10 = dateTime6.toTimeOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(timeOfDay10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.Instant instant8 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.MutableDateTime mutableDateTime10 = instant8.toMutableDateTime(chronology9);
//        int int11 = mutableDateTime10.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime14.withYearOfCentury(0);
//        mutableDateTime10.setDate((org.joda.time.ReadableInstant) dateTime14);
//        int int18 = mutableDateTime10.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime10.secondOfMinute();
//        int int22 = dateTimeFormatter7.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "2019-06-12T05:24:11.615-07:00", 19);
//        try {
//            int int23 = property6.getDifference((org.joda.time.ReadableInstant) mutableDateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560380399999");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(instant8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 48277 + "'", int18 == 48277);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-20) + "'", int22 == (-20));
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundHalfCeiling();
        java.lang.String str10 = property6.toString();
        org.joda.time.MutableDateTime mutableDateTime11 = property6.roundHalfFloor();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[millisOfSecond]" + "'", str10.equals("Property[millisOfSecond]"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfHour(4, 20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField3.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 12, 38920, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for year must be in the range [38920,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        long long7 = offsetDateTimeField4.add((long) 1, (long) (short) -1);
        long long9 = offsetDateTimeField4.roundFloor((long) 3);
        long long12 = offsetDateTimeField4.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField15.getAsText(19438, locale17);
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 10);
        long long25 = offsetDateTimeField22.add((long) 1, (long) (short) -1);
        long long27 = offsetDateTimeField22.roundFloor((long) 3);
        long long30 = offsetDateTimeField22.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, (int) (short) 100);
        long long35 = offsetDateTimeField22.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant36 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.MutableDateTime mutableDateTime38 = instant36.toMutableDateTime(chronology37);
        int int39 = mutableDateTime38.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone41);
        org.joda.time.DateTime dateTime44 = dateTime42.withYearOfCentury(0);
        mutableDateTime38.setDate((org.joda.time.ReadableInstant) dateTime42);
        org.joda.time.DateTime dateTime47 = dateTime42.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime50 = dateTime47.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.DateTime dateTime53 = dateTime50.withPeriodAdded(readablePeriod51, 0);
        org.joda.time.LocalDateTime localDateTime54 = dateTime53.toLocalDateTime();
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField22.getAsText((org.joda.time.ReadablePartial) localDateTime54, locale55);
        int int57 = delegatedDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) localDateTime54);
        long long59 = delegatedDateTimeField15.remainder(1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = delegatedDateTimeField15.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField61 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31535999999L) + "'", long7 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-30412800000L) + "'", long9 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000001L + "'", long12 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31535999999L) + "'", long25 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-30412800000L) + "'", long27 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000001L + "'", long30 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3155760000003L + "'", long35 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant36);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(localDateTime54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "1968" + "'", str56.equals("1968"));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 292273002 + "'", int57 == 292273002);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 30412800001L + "'", long59 == 30412800001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundHalfFloor((long) 0);
        long long10 = offsetDateTimeField3.roundHalfEven((long) 19452);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1123200000L + "'", long8 == 1123200000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1123200000L + "'", long10 == 1123200000L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DurationField durationField2 = julianChronology0.hours();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField4 = julianChronology0.halfdays();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        boolean boolean7 = offsetDateTimeField3.isSupported();
        long long9 = offsetDateTimeField3.remainder((long) 2000);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 30412802000L + "'", long9 == 30412802000L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(12, (int) 'a', 19448, 19454020, (int) (short) 100, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19454020 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.halfdays();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(30412800001L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.Instant instant5 = instant3.minus((long) 1970);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour(19);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology10.getZone();
        org.joda.time.Instant instant12 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = instant12.toMutableDateTime(chronology13);
        int int15 = mutableDateTime14.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury(0);
        mutableDateTime14.setDate((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime23 = dateTime18.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, 0);
        org.joda.time.LocalDateTime localDateTime30 = dateTime29.toLocalDateTime();
        boolean boolean31 = dateTimeZone11.isLocalDateTimeGap(localDateTime30);
        org.joda.time.DateTime dateTime32 = dateTime7.withFields((org.joda.time.ReadablePartial) localDateTime30);
        org.joda.time.DateTime dateTime34 = dateTime7.withWeekOfWeekyear(19);
        org.joda.time.DateTime dateTime36 = dateTime34.withCenturyOfEra(19434);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localDateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) (short) 10);
        org.joda.time.DateTime dateTime5 = property2.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField14.getAsShortText(readablePartial15, 19438, locale17);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField14.getDurationField();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology20.getZone();
        java.lang.Object obj22 = null;
        boolean boolean23 = julianChronology20.equals(obj22);
        org.joda.time.DateTimeField dateTimeField24 = julianChronology20.weekyear();
        org.joda.time.Instant instant25 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.MutableDateTime mutableDateTime27 = instant25.toMutableDateTime(chronology26);
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone30);
        org.joda.time.DateTime dateTime33 = dateTime31.withYearOfCentury(0);
        mutableDateTime27.setDate((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime36 = dateTime31.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime39 = dateTime36.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.DateTime dateTime42 = dateTime39.withPeriodAdded(readablePeriod40, 0);
        org.joda.time.LocalDateTime localDateTime43 = dateTime42.toLocalDateTime();
        long long45 = julianChronology20.set((org.joda.time.ReadablePartial) localDateTime43, 0L);
        int[] intArray51 = new int[] { (byte) 0, 9, 20, '#', 19439 };
        int int52 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDateTime43, intArray51);
        long long55 = delegatedDateTimeField14.set((long) 4, 292273002);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(instant25);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localDateTime43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-59385600090L) + "'", long45 == (-59385600090L));
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-292269045) + "'", int52 == (-292269045));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 9223372035446400004L + "'", long55 == 9223372035446400004L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) ' ', 19441);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
        java.lang.String str3 = buddhistChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
        java.lang.Integer int6 = dateTimeParserBucket5.getOffsetInteger();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        boolean boolean8 = dateTimeParserBucket5.restoreState((java.lang.Object) gregorianChronology7);
        org.joda.time.Chronology chronology9 = dateTimeParserBucket5.getChronology();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime5 = property3.addToCopy((long) (short) 10);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.Object obj2 = null;
        boolean boolean3 = julianChronology0.equals(obj2);
        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
        try {
            long long12 = julianChronology0.getDateTimeMillis((int) ' ', (int) (byte) 0, 80672, 0, (int) (short) -1, 19437, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider4 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.clockhourOfHalfday();
        java.lang.String str9 = buddhistChronology7.toString();
        java.util.Locale locale10 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology7, locale10);
        java.lang.Integer int12 = dateTimeParserBucket11.getOffsetInteger();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        long long19 = offsetDateTimeField16.add((long) 1, (long) (short) -1);
        long long21 = offsetDateTimeField16.roundFloor((long) 3);
        long long24 = offsetDateTimeField16.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16);
        java.util.Locale locale29 = null;
        java.lang.String str30 = delegatedDateTimeField27.getAsText(19438, locale29);
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology31.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, 10);
        long long37 = offsetDateTimeField34.add((long) 1, (long) (short) -1);
        long long39 = offsetDateTimeField34.roundFloor((long) 3);
        long long42 = offsetDateTimeField34.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, (int) (short) 100);
        long long47 = offsetDateTimeField34.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant48 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.MutableDateTime mutableDateTime50 = instant48.toMutableDateTime(chronology49);
        int int51 = mutableDateTime50.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone53);
        org.joda.time.DateTime dateTime56 = dateTime54.withYearOfCentury(0);
        mutableDateTime50.setDate((org.joda.time.ReadableInstant) dateTime54);
        org.joda.time.DateTime dateTime59 = dateTime54.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime62 = dateTime59.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.DateTime dateTime65 = dateTime62.withPeriodAdded(readablePeriod63, 0);
        org.joda.time.LocalDateTime localDateTime66 = dateTime65.toLocalDateTime();
        java.util.Locale locale67 = null;
        java.lang.String str68 = offsetDateTimeField34.getAsText((org.joda.time.ReadablePartial) localDateTime66, locale67);
        int int69 = delegatedDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) localDateTime66);
        long long71 = delegatedDateTimeField27.remainder(1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = delegatedDateTimeField27.getType();
        org.joda.time.chrono.JulianChronology julianChronology74 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField75 = julianChronology74.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField(dateTimeField75, 10);
        long long80 = offsetDateTimeField77.add((long) 1, (long) (short) -1);
        long long83 = offsetDateTimeField77.addWrapField((long) 20, (int) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology86 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField87 = buddhistChronology86.clockhourOfHalfday();
        java.lang.String str88 = buddhistChronology86.toString();
        java.util.Locale locale89 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket90 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology86, locale89);
        java.util.Locale locale91 = dateTimeParserBucket90.getLocale();
        java.lang.String str92 = offsetDateTimeField77.getAsText((long) 9, locale91);
        dateTimeParserBucket11.saveField(dateTimeFieldType72, "19438", locale91);
        java.lang.String str96 = defaultNameProvider4.getName(locale91, "1970", "Jan 31, 1968 3:59:59 PM");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter97 = dateTimeFormatter3.withLocale(locale91);
        java.lang.String str98 = property2.getAsShortText(locale91);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str9.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(int12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31535999999L) + "'", long19 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-30412800000L) + "'", long21 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 599616000001L + "'", long24 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "19438" + "'", str30.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-31535999999L) + "'", long37 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-30412800000L) + "'", long39 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 599616000001L + "'", long42 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3155760000003L + "'", long47 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant48);
        org.junit.Assert.assertNotNull(mutableDateTime50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(localDateTime66);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "1968" + "'", str68.equals("1968"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 292273002 + "'", int69 == 292273002);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 30412800001L + "'", long71 == 30412800001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
        org.junit.Assert.assertNotNull(julianChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-31535999999L) + "'", long80 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 3061065600020L + "'", long83 == 3061065600020L);
        org.junit.Assert.assertNotNull(buddhistChronology86);
        org.junit.Assert.assertNotNull(dateTimeField87);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str88.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale91);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "1979" + "'", str92.equals("1979"));
        org.junit.Assert.assertNull(str96);
        org.junit.Assert.assertNotNull(dateTimeFormatter97);
        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "0" + "'", str98.equals("0"));
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime2.toMutableDateTimeISO();
//        mutableDateTime2.setTime(1560361715136L);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 48281 + "'", int10 == 48281);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        java.util.Date date12 = dateTime9.toDate();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        long long19 = offsetDateTimeField16.add((long) 1, (long) (short) -1);
        long long21 = offsetDateTimeField16.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField16.getType();
        org.joda.time.DateTime dateTime24 = dateTime9.withField(dateTimeFieldType22, (int) (short) 0);
        org.joda.time.DateTime dateTime26 = dateTime9.minusWeeks(19438);
        org.joda.time.DateTime dateTime28 = dateTime26.minusMinutes(0);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31535999999L) + "'", long19 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-30412800000L) + "'", long21 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) 0, locale6);
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
//        boolean boolean10 = dateTimeZone4.isStandardOffset(6216825600020L);
//        org.joda.time.Chronology chronology11 = buddhistChronology1.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.Chronology chronology15 = buddhistChronology1.withZone(dateTimeZone13);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withZone(dateTimeZone13);
//        java.lang.Appendable appendable17 = null;
//        org.joda.time.Instant instant18 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology19 = instant18.getChronology();
//        try {
//            dateTimeFormatter0.printTo(appendable17, (org.joda.time.ReadableInstant) instant18);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(instant18);
//        org.junit.Assert.assertNotNull(chronology19);
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        int int19 = skipUndoDateTimeField17.get((long) 19438);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 323);
//        int int24 = skipUndoDateTimeField17.getDifference((long) 19454, 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 48282 + "'", int13 == 48282);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 19 + "'", int24 == 19);
//    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        java.lang.String str5 = mutableDateTime3.toString();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime3);
//        mutableDateTime3.setWeekOfWeekyear(1);
//        org.joda.time.Instant instant9 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = instant9.toMutableDateTime(chronology10);
//        int int12 = mutableDateTime11.getCenturyOfEra();
//        int int13 = mutableDateTime11.getYearOfCentury();
//        mutableDateTime11.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime16 = mutableDateTime11.copy();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = mutableDateTime11.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) ' ');
//        java.util.Date date21 = dateTime18.toDate();
//        boolean boolean23 = dateTime18.isEqual(10L);
//        org.joda.time.DateTime dateTime24 = dateTime18.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone26 = julianChronology25.getZone();
//        java.lang.Object obj27 = null;
//        boolean boolean28 = julianChronology25.equals(obj27);
//        org.joda.time.DateTimeField dateTimeField29 = julianChronology25.weekyear();
//        org.joda.time.Instant instant30 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.MutableDateTime mutableDateTime32 = instant30.toMutableDateTime(chronology31);
//        int int33 = mutableDateTime32.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone35);
//        org.joda.time.DateTime dateTime38 = dateTime36.withYearOfCentury(0);
//        mutableDateTime32.setDate((org.joda.time.ReadableInstant) dateTime36);
//        org.joda.time.DateTime dateTime41 = dateTime36.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime44 = dateTime41.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod45 = null;
//        org.joda.time.DateTime dateTime47 = dateTime44.withPeriodAdded(readablePeriod45, 0);
//        org.joda.time.LocalDateTime localDateTime48 = dateTime47.toLocalDateTime();
//        long long50 = julianChronology25.set((org.joda.time.ReadablePartial) localDateTime48, 0L);
//        org.joda.time.DateTime dateTime51 = dateTime18.withFields((org.joda.time.ReadablePartial) localDateTime48);
//        boolean boolean52 = mutableDateTime3.isEqual((org.joda.time.ReadableInstant) dateTime18);
//        mutableDateTime3.setMillisOfDay(0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-12T13:24:42.232-07:00" + "'", str5.equals("2019-06-12T13:24:42.232-07:00"));
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 20 + "'", int12 == 20);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(instant30);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(localDateTime48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-59385600090L) + "'", long50 == (-59385600090L));
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology4.getZone();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) 0, locale7);
//        long long10 = dateTimeZone3.getMillisKeepLocal(dateTimeZone5, 0L);
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = instant11.toMutableDateTime(chronology12);
//        int int14 = mutableDateTime13.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime17.withYearOfCentury(0);
//        mutableDateTime13.setDate((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime22 = dateTime17.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
//        org.joda.time.Instant instant27 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology28 = null;
//        org.joda.time.MutableDateTime mutableDateTime29 = instant27.toMutableDateTime(chronology28);
//        int int30 = mutableDateTime29.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
//        org.joda.time.DateTime dateTime35 = dateTime33.withYearOfCentury(0);
//        mutableDateTime29.setDate((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime dateTime38 = dateTime33.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime41 = dateTime38.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone42 = dateTime41.getZone();
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = dateTimeZone42.getName((long) (short) 10, locale44);
//        long long47 = dateTimeZone26.getMillisKeepLocal(dateTimeZone42, (long) (short) 0);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = dateTimeZone42.getShortName((long) (short) 0, locale49);
//        long long52 = dateTimeZone5.getMillisKeepLocal(dateTimeZone42, (long) 323);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone42, (-57540010L), 1979);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1979");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28800000L) + "'", long10 == (-28800000L));
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(instant27);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Pacific Standard Time" + "'", str45.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "PST" + "'", str50.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 28800323L + "'", long52 == 28800323L);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        mutableDateTime2.addMinutes((int) (byte) 100);
//        int int16 = mutableDateTime2.getRoundingMode();
//        org.joda.time.Instant instant17 = mutableDateTime2.toInstant();
//        boolean boolean19 = instant17.isEqual((long) 19435);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 48282 + "'", int10 == 48282);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.plusWeeks(0);
        org.joda.time.DateTime dateTime16 = dateTime14.minusWeeks((-19448));
        org.joda.time.DateTime dateTime17 = dateTime14.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) 0, locale5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, dateTimeZone3);
//        org.joda.time.DateTime dateTime9 = dateTime7.withCenturyOfEra((int) (short) 0);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.withDurationAdded(readableDuration10, 38917);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYearOfCentury(80672, (-10));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", (java.lang.Number) 292273002, (java.lang.Number) (-10), (java.lang.Number) 48280);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.clockhourOfHalfday();
//        java.lang.String str12 = buddhistChronology10.toString();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getShortName((-1L), locale18);
//        org.joda.time.Chronology chronology20 = buddhistChronology10.withZone(dateTimeZone16);
//        mutableDateTime2.setZoneRetainFields(dateTimeZone16);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16, (-292269045));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -292269045");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str12.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology20);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "80669");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        long long13 = offsetDateTimeField3.roundHalfEven((long) (short) 1);
        boolean boolean14 = offsetDateTimeField3.isLenient();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
//        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
//        int int11 = mutableDateTime3.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime3.secondOfMinute();
//        mutableDateTime3.addWeeks(0);
//        mutableDateTime3.addMinutes((int) (byte) 100);
//        int int17 = mutableDateTime3.getRoundingMode();
//        org.joda.time.Instant instant18 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant20 = instant18.minus((long) (short) -1);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) instant18);
//        int int24 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "", 19447);
//        org.joda.time.MutableDateTime.Property property25 = mutableDateTime3.yearOfEra();
//        try {
//            mutableDateTime3.setSecondOfMinute((-292269045));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269045 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 48283 + "'", int11 == 48283);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(instant18);
//        org.junit.Assert.assertNotNull(instant20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-19448) + "'", int24 == (-19448));
//        org.junit.Assert.assertNotNull(property25);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfMonth();
        org.joda.time.DateTime dateTime7 = property5.addToCopy(1L);
        org.joda.time.DateTime dateTime9 = property5.setCopy(10);
        int int10 = property5.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy((-372));
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(19454, 38920, 19437);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime2.millisOfDay();
//        mutableDateTime2.addWeeks(6);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 48283 + "'", int10 == 48283);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property14);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitYear(0, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.joda.time.Instant instant6 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = instant6.toMutableDateTime(chronology7);
//        int int9 = mutableDateTime8.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime12.withYearOfCentury(0);
//        mutableDateTime8.setDate((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime17 = dateTime12.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTime20.getZone();
//        org.joda.time.Instant instant22 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = instant22.toMutableDateTime(chronology23);
//        int int25 = mutableDateTime24.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone27);
//        org.joda.time.DateTime dateTime30 = dateTime28.withYearOfCentury(0);
//        mutableDateTime24.setDate((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime dateTime33 = dateTime28.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone37 = dateTime36.getZone();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = dateTimeZone37.getName((long) (short) 10, locale39);
//        long long42 = dateTimeZone21.getMillisKeepLocal(dateTimeZone37, (long) (short) 0);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = dateTimeZone37.getShortName((long) (short) 0, locale44);
//        java.lang.String str47 = dateTimeZone37.getShortName(0L);
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone49);
//        org.joda.time.DateTime dateTime52 = dateTime50.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTime dateTime54 = dateTime52.toDateTime(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = dateTime52.withLaterOffsetAtOverlap();
//        int int56 = dateTimeZone37.getOffset((org.joda.time.ReadableInstant) dateTime52);
//        try {
//            org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((-292269045), 97, (int) (byte) -1, 19440, 0, 19431, dateTimeZone37);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19440 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(instant22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Pacific Standard Time" + "'", str40.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "PST" + "'", str45.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "PST" + "'", str47.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-28800000) + "'", int56 == (-28800000));
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField3.getType();
        long long12 = offsetDateTimeField3.getDifferenceAsLong(100L, 30412800001L);
        org.joda.time.DurationField durationField13 = offsetDateTimeField3.getLeapDurationField();
        org.joda.time.DurationFieldType durationFieldType14 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField15 = new org.joda.time.field.DecoratedDurationField(durationField13, durationFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField14.getAsShortText(readablePartial15, 19438, locale17);
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 10);
        long long27 = offsetDateTimeField24.add((long) 1, (long) (short) -1);
        long long29 = offsetDateTimeField24.roundFloor((long) 3);
        long long32 = offsetDateTimeField24.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, (int) (short) 100);
        int int36 = offsetDateTimeField34.getLeapAmount((long) 3);
        boolean boolean37 = offsetDateTimeField34.isLenient();
        boolean boolean39 = offsetDateTimeField34.isLeap((long) (-28800000));
        int int41 = offsetDateTimeField34.getLeapAmount(8417L);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone43);
        org.joda.time.DateTime dateTime46 = dateTime44.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = dateTime46.toDateTime(dateTimeZone47);
        org.joda.time.DateTime dateTime49 = dateTime46.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime51 = dateTime49.withMinuteOfHour(19);
        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone53 = julianChronology52.getZone();
        org.joda.time.Instant instant54 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology55 = null;
        org.joda.time.MutableDateTime mutableDateTime56 = instant54.toMutableDateTime(chronology55);
        int int57 = mutableDateTime56.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone59);
        org.joda.time.DateTime dateTime62 = dateTime60.withYearOfCentury(0);
        mutableDateTime56.setDate((org.joda.time.ReadableInstant) dateTime60);
        org.joda.time.DateTime dateTime65 = dateTime60.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime68 = dateTime65.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod69 = null;
        org.joda.time.DateTime dateTime71 = dateTime68.withPeriodAdded(readablePeriod69, 0);
        org.joda.time.LocalDateTime localDateTime72 = dateTime71.toLocalDateTime();
        boolean boolean73 = dateTimeZone53.isLocalDateTimeGap(localDateTime72);
        org.joda.time.DateTime dateTime74 = dateTime49.withFields((org.joda.time.ReadablePartial) localDateTime72);
        org.joda.time.chrono.JulianChronology julianChronology76 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField77 = julianChronology76.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField79 = new org.joda.time.field.OffsetDateTimeField(dateTimeField77, 10);
        long long82 = offsetDateTimeField79.add((long) 1, (long) (short) -1);
        long long85 = offsetDateTimeField79.addWrapField((long) 20, (int) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology88 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField89 = buddhistChronology88.clockhourOfHalfday();
        java.lang.String str90 = buddhistChronology88.toString();
        java.util.Locale locale91 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket92 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology88, locale91);
        java.util.Locale locale93 = dateTimeParserBucket92.getLocale();
        java.lang.String str94 = offsetDateTimeField79.getAsText((long) 9, locale93);
        java.lang.String str95 = offsetDateTimeField34.getAsShortText((org.joda.time.ReadablePartial) localDateTime72, (-372), locale93);
        try {
            long long96 = delegatedDateTimeField14.set((-57600000L), "minuteOfDay", locale93);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"minuteOfDay\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31535999999L) + "'", long27 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-30412800000L) + "'", long29 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 599616000001L + "'", long32 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(julianChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(instant54);
        org.junit.Assert.assertNotNull(mutableDateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(localDateTime72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(julianChronology76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-31535999999L) + "'", long82 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 3061065600020L + "'", long85 == 3061065600020L);
        org.junit.Assert.assertNotNull(buddhistChronology88);
        org.junit.Assert.assertNotNull(dateTimeField89);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str90.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale93);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "1979" + "'", str94.equals("1979"));
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "-372" + "'", str95.equals("-372"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime5 = property3.addToCopy((long) (short) 10);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) property7, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        int int6 = mutableDateTime2.getMillisOfDay();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
//        org.joda.time.DateTime dateTime11 = property9.setCopy(10);
//        mutableDateTime2.setMillis((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.plus(readableDuration13);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 48284254 + "'", int6 == 48284254);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 10, 19442);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19452 + "'", int2 == 19452);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        int int19 = skipUndoDateTimeField17.get((long) 19438);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, dateTimeFieldType20, 80671, 19441661, 292273002);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 48284 + "'", int13 == 48284);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury((int) 'a');
        try {
            org.joda.time.DateTime dateTime19 = dateTime11.withDate(0, 0, 38914);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        int int19 = skipUndoDateTimeField17.get((long) 19438);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 323);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology22.clockhourOfHalfday();
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getName((long) 0, locale27);
//        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
//        boolean boolean31 = dateTimeZone25.isStandardOffset(6216825600020L);
//        org.joda.time.Chronology chronology32 = buddhistChronology22.withZone(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone34);
//        org.joda.time.Chronology chronology36 = buddhistChronology22.withZone(dateTimeZone34);
//        org.joda.time.Instant instant38 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology39 = null;
//        org.joda.time.MutableDateTime mutableDateTime40 = instant38.toMutableDateTime(chronology39);
//        int int41 = mutableDateTime40.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone43);
//        org.joda.time.DateTime dateTime46 = dateTime44.withYearOfCentury(0);
//        mutableDateTime40.setDate((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTime dateTime49 = dateTime44.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime52 = dateTime49.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod53 = null;
//        org.joda.time.DateTime dateTime55 = dateTime52.withPeriodAdded(readablePeriod53, 0);
//        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone58);
//        org.joda.time.DateTimeZone dateTimeZone60 = dateTime59.getZone();
//        org.joda.time.MutableDateTime mutableDateTime61 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime55, dateTimeZone60);
//        org.joda.time.chrono.JulianChronology julianChronology62 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone60);
//        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime(1L, dateTimeZone60);
//        org.joda.time.Chronology chronology64 = buddhistChronology22.withZone(dateTimeZone60);
//        try {
//            org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((java.lang.Object) skipUndoDateTimeField17, dateTimeZone60);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.SkipUndoDateTimeField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 48284 + "'", int13 == 48284);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Coordinated Universal Time" + "'", str28.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(buddhistChronology35);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(instant38);
//        org.junit.Assert.assertNotNull(mutableDateTime40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(localDateTime56);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(julianChronology62);
//        org.junit.Assert.assertNotNull(chronology64);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(80671, 1901, 80673, 0, 0, (-19441661), 19439435, (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -19441661 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfFloor();
        mutableDateTime11.setMinuteOfDay(4);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime11.weekyear();
        boolean boolean15 = mutableDateTime11.isEqualNow();
        try {
            mutableDateTime11.setTime(80671, 20, 0, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 80671 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(1560230670512L);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        int int11 = property9.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property9.getFieldType();
//        org.joda.time.DateTimeField dateTimeField13 = property9.getField();
//        org.joda.time.MutableDateTime mutableDateTime15 = property9.add(599616000001L);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        mutableDateTime15.add(readableDuration16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.secondOfMinute();
//        java.lang.String str19 = property18.toString();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35354 + "'", int11 == 35354);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[secondOfMinute]" + "'", str19.equals("Property[secondOfMinute]"));
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder7.appendTimeZoneOffset("2019163T122412Z", "America/Los_Angeles", true, 2000, 19435);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        int int14 = mutableDateTime2.getWeekyear();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35354 + "'", int10 == 35354);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendMinuteOfHour(1970);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
        try {
            org.joda.time.DateTime dateTime10 = dateTime4.withYearOfCentury(38921);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 38921 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getCenturyOfEra();
//        int int5 = mutableDateTime3.getYearOfCentury();
//        mutableDateTime3.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime3.copy();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = mutableDateTime3.toDateTime(dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) ' ');
//        java.util.Date date13 = dateTime10.toDate();
//        boolean boolean15 = dateTime10.isEqual(10L);
//        org.joda.time.DateTime dateTime16 = dateTime10.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology17.getZone();
//        java.lang.Object obj19 = null;
//        boolean boolean20 = julianChronology17.equals(obj19);
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology17.weekyear();
//        org.joda.time.Instant instant22 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = instant22.toMutableDateTime(chronology23);
//        int int25 = mutableDateTime24.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone27);
//        org.joda.time.DateTime dateTime30 = dateTime28.withYearOfCentury(0);
//        mutableDateTime24.setDate((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime dateTime33 = dateTime28.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.DateTime dateTime39 = dateTime36.withPeriodAdded(readablePeriod37, 0);
//        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
//        long long42 = julianChronology17.set((org.joda.time.ReadablePartial) localDateTime40, 0L);
//        org.joda.time.DateTime dateTime43 = dateTime10.withFields((org.joda.time.ReadablePartial) localDateTime40);
//        java.lang.String str44 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime40);
//        try {
//            org.joda.time.LocalDate localDate46 = dateTimeFormatter0.parseLocalDate("57599");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"57599\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 68 + "'", int5 == 68);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(instant22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 11 + "'", int25 == 11);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(localDateTime40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-59385600090L) + "'", long42 == (-59385600090L));
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Jan 31, 1968 3:59:59 PM" + "'", str44.equals("Jan 31, 1968 3:59:59 PM"));
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundHalfCeiling();
//        mutableDateTime9.addWeeks(323);
//        org.joda.time.Instant instant12 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = instant12.toMutableDateTime(chronology13);
//        int int15 = mutableDateTime14.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        mutableDateTime14.setZone(dateTimeZone16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime20 = property18.add((-1));
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField22 = property21.getField();
//        int int23 = property21.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property21.getFieldType();
//        boolean boolean25 = mutableDateTime9.isSupported(dateTimeFieldType24);
//        boolean boolean27 = mutableDateTime9.isAfter((long) (short) 0);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime9);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 11 + "'", int15 == 11);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 35355 + "'", int23 == 35355);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 3315923355316L + "'", long28 == 3315923355316L);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        org.joda.time.DateTime dateTime12 = property7.getDateTime();
        org.joda.time.DateTime dateTime14 = dateTime12.withWeekyear(38921);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.field.FieldUtils.verifyValueBounds("2019-06-12T05:23:52.525-07:00", 48284, 19442, 57619);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) ' ', 19441);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendFractionOfDay((int) '4', (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendLiteral("77041");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (short) 10, locale17);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        java.lang.String str20 = gregorianChronology19.toString();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.millisOfSecond();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str20.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.DurationField durationField3 = julianChronology1.hours();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider5 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider5);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.clockhourOfHalfday();
//        java.lang.String str10 = buddhistChronology8.toString();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology8, locale11);
//        java.lang.Integer int13 = dateTimeParserBucket12.getOffsetInteger();
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 10);
//        long long20 = offsetDateTimeField17.add((long) 1, (long) (short) -1);
//        long long22 = offsetDateTimeField17.roundFloor((long) 3);
//        long long25 = offsetDateTimeField17.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = delegatedDateTimeField28.getAsText(19438, locale30);
//        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 10);
//        long long38 = offsetDateTimeField35.add((long) 1, (long) (short) -1);
//        long long40 = offsetDateTimeField35.roundFloor((long) 3);
//        long long43 = offsetDateTimeField35.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField35, (int) (short) 100);
//        long long48 = offsetDateTimeField35.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant49 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology50 = null;
//        org.joda.time.MutableDateTime mutableDateTime51 = instant49.toMutableDateTime(chronology50);
//        int int52 = mutableDateTime51.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone54);
//        org.joda.time.DateTime dateTime57 = dateTime55.withYearOfCentury(0);
//        mutableDateTime51.setDate((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime dateTime60 = dateTime55.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime63 = dateTime60.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod64 = null;
//        org.joda.time.DateTime dateTime66 = dateTime63.withPeriodAdded(readablePeriod64, 0);
//        org.joda.time.LocalDateTime localDateTime67 = dateTime66.toLocalDateTime();
//        java.util.Locale locale68 = null;
//        java.lang.String str69 = offsetDateTimeField35.getAsText((org.joda.time.ReadablePartial) localDateTime67, locale68);
//        int int70 = delegatedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) localDateTime67);
//        long long72 = delegatedDateTimeField28.remainder(1L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = delegatedDateTimeField28.getType();
//        org.joda.time.chrono.JulianChronology julianChronology75 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField76 = julianChronology75.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField78 = new org.joda.time.field.OffsetDateTimeField(dateTimeField76, 10);
//        long long81 = offsetDateTimeField78.add((long) 1, (long) (short) -1);
//        long long84 = offsetDateTimeField78.addWrapField((long) 20, (int) 'a');
//        org.joda.time.chrono.BuddhistChronology buddhistChronology87 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField88 = buddhistChronology87.clockhourOfHalfday();
//        java.lang.String str89 = buddhistChronology87.toString();
//        java.util.Locale locale90 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket91 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology87, locale90);
//        java.util.Locale locale92 = dateTimeParserBucket91.getLocale();
//        java.lang.String str93 = offsetDateTimeField78.getAsText((long) 9, locale92);
//        dateTimeParserBucket12.saveField(dateTimeFieldType73, "19438", locale92);
//        java.lang.String str97 = defaultNameProvider5.getName(locale92, "1970", "Jan 31, 1968 3:59:59 PM");
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket98 = new org.joda.time.format.DateTimeParserBucket(3155760000003L, (org.joda.time.Chronology) julianChronology1, locale92);
//        java.lang.String str99 = julianChronology1.toString();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str10.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNull(int13);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-31535999999L) + "'", long20 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-30412800000L) + "'", long22 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 599616000001L + "'", long25 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "19438" + "'", str31.equals("19438"));
//        org.junit.Assert.assertNotNull(julianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-31535999999L) + "'", long38 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-30412800000L) + "'", long40 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 599616000001L + "'", long43 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 3155760000003L + "'", long48 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant49);
//        org.junit.Assert.assertNotNull(mutableDateTime51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 11 + "'", int52 == 11);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(localDateTime67);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "1968" + "'", str69.equals("1968"));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 292273002 + "'", int70 == 292273002);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 30412800001L + "'", long72 == 30412800001L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertNotNull(julianChronology75);
//        org.junit.Assert.assertNotNull(dateTimeField76);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-31535999999L) + "'", long81 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 3061065600020L + "'", long84 == 3061065600020L);
//        org.junit.Assert.assertNotNull(buddhistChronology87);
//        org.junit.Assert.assertNotNull(dateTimeField88);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str89.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(locale92);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "1979" + "'", str93.equals("1979"));
//        org.junit.Assert.assertNull(str97);
//        org.junit.Assert.assertTrue("'" + str99 + "' != '" + "JulianChronology[UTC]" + "'", str99.equals("JulianChronology[UTC]"));
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        org.joda.time.DateTime dateTime12 = property7.getDateTime();
        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
        org.joda.time.DateTime dateTime15 = dateTime12.minusDays((int) (short) 1);
        org.joda.time.DateTime.Property property16 = dateTime15.hourOfDay();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime dateTime19 = dateTime18.withTimeAtStartOfDay();
        int int20 = property16.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType8, 19452, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-31535999999L));
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
//        boolean boolean16 = offsetDateTimeField13.isLenient();
//        long long18 = offsetDateTimeField13.roundCeiling((long) 59);
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 10);
//        long long25 = offsetDateTimeField22.add((long) 1, (long) (short) -1);
//        long long27 = offsetDateTimeField22.roundFloor((long) 3);
//        long long30 = offsetDateTimeField22.add((long) (short) 1, (long) 19);
//        long long32 = offsetDateTimeField22.roundHalfEven((long) 23);
//        long long35 = offsetDateTimeField22.add(3061065600020L, (long) 100);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone37);
//        org.joda.time.DateTime dateTime40 = dateTime38.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTime dateTime42 = dateTime40.toDateTime(dateTimeZone41);
//        org.joda.time.Instant instant43 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology44 = null;
//        org.joda.time.MutableDateTime mutableDateTime45 = instant43.toMutableDateTime(chronology44);
//        int int46 = mutableDateTime45.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone48);
//        org.joda.time.DateTime dateTime51 = dateTime49.withYearOfCentury(0);
//        mutableDateTime45.setDate((org.joda.time.ReadableInstant) dateTime49);
//        org.joda.time.DateTime dateTime54 = dateTime49.minusWeeks((int) (short) 100);
//        org.joda.time.Chronology chronology55 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime54);
//        org.joda.time.DateTime dateTime56 = dateTime40.withChronology(chronology55);
//        org.joda.time.TimeOfDay timeOfDay57 = dateTime40.toTimeOfDay();
//        int int58 = offsetDateTimeField22.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay57);
//        int[] intArray60 = null;
//        try {
//            int[] intArray62 = offsetDateTimeField13.add((org.joda.time.ReadablePartial) timeOfDay57, 15, intArray60, 19439435);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1123200000L + "'", long18 == 1123200000L);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31535999999L) + "'", long25 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-30412800000L) + "'", long27 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000001L + "'", long30 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1123200000L + "'", long32 == 1123200000L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 6216825600020L + "'", long35 == 6216825600020L);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(instant43);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 11 + "'", int46 == 11);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(timeOfDay57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 292273002 + "'", int58 == 292273002);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 23);
        long long16 = offsetDateTimeField3.add(3061065600020L, (long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField18 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 6216825600020L + "'", long16 == 6216825600020L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
//        int int13 = dateTime11.getDayOfYear();
//        int int14 = dateTime11.getDayOfYear();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField14.getAsShortText(readablePartial15, 19438, locale17);
        int int20 = delegatedDateTimeField14.getMaximumValue((long) 2000);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292273002 + "'", int20 == 292273002);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((java.lang.Object) julianChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.JulianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
        org.joda.time.Instant instant5 = mutableDateTime2.toInstant();
        mutableDateTime2.addHours((int) '#');
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.era();
        org.joda.time.DurationField durationField2 = iSOChronology0.minutes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        int int7 = mutableDateTime2.getMinuteOfDay();
//        mutableDateTime2.setSecondOfMinute((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        mutableDateTime2.add(readablePeriod10);
//        org.joda.time.Instant instant12 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = instant12.toMutableDateTime(chronology13);
//        int int15 = mutableDateTime14.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury(0);
//        mutableDateTime14.setDate((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime23 = dateTime18.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
//        org.joda.time.Instant instant28 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.MutableDateTime mutableDateTime30 = instant28.toMutableDateTime(chronology29);
//        int int31 = mutableDateTime30.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone33);
//        org.joda.time.DateTime dateTime36 = dateTime34.withYearOfCentury(0);
//        mutableDateTime30.setDate((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime dateTime39 = dateTime34.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone43 = dateTime42.getZone();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = dateTimeZone43.getName((long) (short) 10, locale45);
//        long long48 = dateTimeZone27.getMillisKeepLocal(dateTimeZone43, (long) (short) 0);
//        long long50 = dateTimeZone27.convertUTCToLocal(8417L);
//        mutableDateTime2.setZone(dateTimeZone27);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 589 + "'", int7 == 589);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 11 + "'", int15 == 11);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(instant28);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Pacific Standard Time" + "'", str46.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-28791583L) + "'", long50 == (-28791583L));
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendLiteral(' ');
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        long long16 = offsetDateTimeField3.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant17 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.MutableDateTime mutableDateTime19 = instant17.toMutableDateTime(chronology18);
//        int int20 = mutableDateTime19.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone22);
//        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury(0);
//        mutableDateTime19.setDate((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime dateTime28 = dateTime23.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime31 = dateTime28.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime34 = dateTime31.withPeriodAdded(readablePeriod32, 0);
//        org.joda.time.LocalDateTime localDateTime35 = dateTime34.toLocalDateTime();
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDateTime35, locale36);
//        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 10);
//        long long44 = offsetDateTimeField41.add((long) 1, (long) (short) -1);
//        long long46 = offsetDateTimeField41.roundFloor((long) 3);
//        long long49 = offsetDateTimeField41.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField41, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField41);
//        org.joda.time.ReadablePartial readablePartial53 = null;
//        java.util.Locale locale55 = null;
//        java.lang.String str56 = delegatedDateTimeField52.getAsShortText(readablePartial53, 19438, locale55);
//        org.joda.time.DurationField durationField57 = delegatedDateTimeField52.getDurationField();
//        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone59 = julianChronology58.getZone();
//        java.lang.Object obj60 = null;
//        boolean boolean61 = julianChronology58.equals(obj60);
//        org.joda.time.DateTimeField dateTimeField62 = julianChronology58.weekyear();
//        org.joda.time.Instant instant63 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology64 = null;
//        org.joda.time.MutableDateTime mutableDateTime65 = instant63.toMutableDateTime(chronology64);
//        int int66 = mutableDateTime65.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone68 = null;
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone68);
//        org.joda.time.DateTime dateTime71 = dateTime69.withYearOfCentury(0);
//        mutableDateTime65.setDate((org.joda.time.ReadableInstant) dateTime69);
//        org.joda.time.DateTime dateTime74 = dateTime69.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime77 = dateTime74.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod78 = null;
//        org.joda.time.DateTime dateTime80 = dateTime77.withPeriodAdded(readablePeriod78, 0);
//        org.joda.time.LocalDateTime localDateTime81 = dateTime80.toLocalDateTime();
//        long long83 = julianChronology58.set((org.joda.time.ReadablePartial) localDateTime81, 0L);
//        int[] intArray89 = new int[] { (byte) 0, 9, 20, '#', 19439 };
//        int int90 = delegatedDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) localDateTime81, intArray89);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology93 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField94 = buddhistChronology93.clockhourOfHalfday();
//        java.lang.String str95 = buddhistChronology93.toString();
//        java.util.Locale locale96 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket97 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology93, locale96);
//        java.util.Locale locale98 = dateTimeParserBucket97.getLocale();
//        java.lang.String str99 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDateTime81, 19439, locale98);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3155760000003L + "'", long16 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 11 + "'", int20 == 11);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localDateTime35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1968" + "'", str37.equals("1968"));
//        org.junit.Assert.assertNotNull(julianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-31535999999L) + "'", long44 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-30412800000L) + "'", long46 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 599616000001L + "'", long49 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "19438" + "'", str56.equals("19438"));
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(julianChronology58);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(instant63);
//        org.junit.Assert.assertNotNull(mutableDateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 11 + "'", int66 == 11);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(localDateTime81);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + (-59385600090L) + "'", long83 == (-59385600090L));
//        org.junit.Assert.assertNotNull(intArray89);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-292269045) + "'", int90 == (-292269045));
//        org.junit.Assert.assertNotNull(buddhistChronology93);
//        org.junit.Assert.assertNotNull(dateTimeField94);
//        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str95.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(locale98);
//        org.junit.Assert.assertTrue("'" + str99 + "' != '" + "19439" + "'", str99.equals("19439"));
//    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getShortName((-1L), locale5);
//        java.lang.String str8 = dateTimeZone3.getName((long) 19439435);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
        org.joda.time.DateTimeField dateTimeField5 = property2.getField();
        org.joda.time.DateTime dateTime6 = property2.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getShortName((-1L), locale5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        long long20 = skipUndoDateTimeField17.getDifferenceAsLong((long) 19441, (-209187057600000L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35358 + "'", int13 == 35358);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 209187057619L + "'", long20 == 209187057619L);
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property12 = dateTime6.hourOfDay();
//        int int13 = property12.getLeapAmount();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = julianChronology0.get(readablePeriod5, (long) 100, (long) (-372));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        mutableDateTime2.addMinutes((int) (byte) 100);
//        mutableDateTime2.addMillis((-292269045));
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime2.centuryOfEra();
//        int int19 = mutableDateTime2.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35358 + "'", int10 == 35358);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 539 + "'", int19 == 539);
//    }
//}

