import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 19439435, 19447);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 378038692445L + "'", long2 == 378038692445L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfDay();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(2000);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) 19447, dateTimeZone2);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime dateTime7 = dateTime6.withLaterOffsetAtOverlap();
        int int8 = dateTime7.getMinuteOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withCenturyOfEra(6);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 960 + "'", int8 == 960);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfHour();
//        int int11 = property10.getLeapAmount();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 1560230670512L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        org.joda.time.MutableDateTime mutableDateTime12 = property9.add((long) 35360);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder7.appendTimeZoneOffset("2019163T122412Z", "America/Los_Angeles", true, 2000, 19435);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendLiteral("America/Los_Angeles");
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 10);
        long long25 = offsetDateTimeField22.add((long) 1, (long) (short) -1);
        long long27 = offsetDateTimeField22.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField22.getType();
        java.lang.Object obj29 = null;
        boolean boolean30 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFieldType28, obj29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder18.appendDecimal(dateTimeFieldType28, (int) (short) 100, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType28, 38915, 19452);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder7.appendMinuteOfHour(48280);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31535999999L) + "'", long25 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-30412800000L) + "'", long27 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
        java.lang.String str3 = buddhistChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
        java.lang.Integer int6 = dateTimeParserBucket5.getOffsetInteger();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        boolean boolean8 = dateTimeParserBucket5.restoreState((java.lang.Object) gregorianChronology7);
        org.joda.time.DurationField durationField9 = gregorianChronology7.years();
        org.joda.time.Chronology chronology10 = gregorianChronology7.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(chronology10);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-12T05:23:49.972-07:00");
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        boolean boolean11 = jodaTimePermission1.equals((java.lang.Object) (-1));
//        boolean boolean13 = jodaTimePermission1.equals((java.lang.Object) false);
//        java.security.PermissionCollection permissionCollection14 = jodaTimePermission1.newPermissionCollection();
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(permissionCollection14);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DurationField durationField2 = julianChronology0.minutes();
        try {
            long long7 = julianChronology0.getDateTimeMillis(960, 80670, 0, (-292269045));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269045 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("2079", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2079\" is malformed at \"79\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology5.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField8, (int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.clockhourOfHalfday();
        java.lang.String str15 = buddhistChronology13.toString();
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology13, locale16);
        java.util.Locale locale18 = dateTimeParserBucket17.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter11.withLocale(locale18);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 1970, (org.joda.time.Chronology) julianChronology1, locale18);
        dateTimeParserBucket20.setPivotYear((java.lang.Integer) 0);
        long long23 = dateTimeParserBucket20.computeMillis();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str15.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1970L + "'", long23 == 1970L);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        int int11 = property9.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property9.getFieldType();
//        org.joda.time.MutableDateTime mutableDateTime14 = property9.addWrapField(0);
//        org.joda.time.MutableDateTime mutableDateTime15 = property9.getMutableDateTime();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35360 + "'", int11 == 35360);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        long long18 = dateTimeZone15.adjustOffset((long) '#', true);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology22.clockhourOfHalfday();
//        java.lang.String str24 = buddhistChronology22.toString();
//        java.util.Locale locale25 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology22, locale25);
//        java.util.Locale locale27 = dateTimeParserBucket26.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter20.withLocale(locale27);
//        java.lang.String str29 = dateTimeZone15.getShortName((long) (short) -1, locale27);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone15);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 35L + "'", long18 == 35L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str24.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(locale27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PST" + "'", str29.equals("PST"));
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        long long16 = offsetDateTimeField3.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant17 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.MutableDateTime mutableDateTime19 = instant17.toMutableDateTime(chronology18);
//        int int20 = mutableDateTime19.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone22);
//        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury(0);
//        mutableDateTime19.setDate((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime dateTime28 = dateTime23.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime31 = dateTime28.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime34 = dateTime31.withPeriodAdded(readablePeriod32, 0);
//        org.joda.time.LocalDateTime localDateTime35 = dateTime34.toLocalDateTime();
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDateTime35, locale36);
//        long long39 = offsetDateTimeField3.roundHalfCeiling(3061065600020L);
//        boolean boolean40 = offsetDateTimeField3.isLenient();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3155760000003L + "'", long16 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 11 + "'", int20 == 11);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localDateTime35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1968" + "'", str37.equals("1968"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 3062188800000L + "'", long39 == 3062188800000L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.Instant instant3 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime(chronology4);
//        int int6 = mutableDateTime5.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(0);
//        mutableDateTime5.setDate((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime14 = dateTime9.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
//        org.joda.time.Instant instant19 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.MutableDateTime mutableDateTime21 = instant19.toMutableDateTime(chronology20);
//        int int22 = mutableDateTime21.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withYearOfCentury(0);
//        mutableDateTime21.setDate((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime30 = dateTime25.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime33 = dateTime30.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone34 = dateTime33.getZone();
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = dateTimeZone34.getName((long) (short) 10, locale36);
//        long long39 = dateTimeZone18.getMillisKeepLocal(dateTimeZone34, (long) (short) 0);
//        org.joda.time.DateTime dateTime40 = dateTime1.toDateTime(dateTimeZone34);
//        try {
//            org.joda.time.DateTime dateTime42 = dateTime40.withDayOfMonth(48283);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 48283 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 11 + "'", int22 == 11);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Pacific Standard Time" + "'", str37.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(dateTime40);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(292273002, 324);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 292273002");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 48280);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        boolean boolean3 = dateTime1.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.Chronology chronology4 = dateTimeFormatter2.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        long long10 = property7.remainder();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 230400004L + "'", long10 == 230400004L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendFractionOfSecond(2019, (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((-19448));
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.withPeriodAdded(readablePeriod7, 1);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        long long17 = offsetDateTimeField14.add((long) 1, (long) (short) -1);
        long long19 = offsetDateTimeField14.roundFloor((long) 3);
        long long22 = offsetDateTimeField14.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14);
        java.util.Locale locale27 = null;
        java.lang.String str28 = delegatedDateTimeField25.getAsText(19438, locale27);
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 10);
        long long35 = offsetDateTimeField32.add((long) 1, (long) (short) -1);
        long long37 = offsetDateTimeField32.roundFloor((long) 3);
        long long40 = offsetDateTimeField32.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, (int) (short) 100);
        long long45 = offsetDateTimeField32.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant46 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.MutableDateTime mutableDateTime48 = instant46.toMutableDateTime(chronology47);
        int int49 = mutableDateTime48.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone51);
        org.joda.time.DateTime dateTime54 = dateTime52.withYearOfCentury(0);
        mutableDateTime48.setDate((org.joda.time.ReadableInstant) dateTime52);
        org.joda.time.DateTime dateTime57 = dateTime52.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime60 = dateTime57.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod61 = null;
        org.joda.time.DateTime dateTime63 = dateTime60.withPeriodAdded(readablePeriod61, 0);
        org.joda.time.LocalDateTime localDateTime64 = dateTime63.toLocalDateTime();
        java.util.Locale locale65 = null;
        java.lang.String str66 = offsetDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDateTime64, locale65);
        int int67 = delegatedDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localDateTime64);
        boolean boolean69 = delegatedDateTimeField25.isLeap((long) 23);
        long long72 = delegatedDateTimeField25.getDifferenceAsLong((long) 19440, 0L);
        boolean boolean73 = delegatedDateTimeField25.isLenient();
        org.joda.time.DateTimeFieldType dateTimeFieldType74 = delegatedDateTimeField25.getType();
        boolean boolean75 = dateTime4.isSupported(dateTimeFieldType74);
        org.joda.time.DurationField durationField76 = null;
        org.joda.time.chrono.ISOChronology iSOChronology77 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str78 = iSOChronology77.toString();
        org.joda.time.Chronology chronology79 = iSOChronology77.withUTC();
        org.joda.time.DurationField durationField80 = iSOChronology77.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField81 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType74, durationField76, durationField80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-31535999999L) + "'", long17 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-30412800000L) + "'", long19 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 599616000001L + "'", long22 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "19438" + "'", str28.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-31535999999L) + "'", long35 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-30412800000L) + "'", long37 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 599616000001L + "'", long40 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3155760000003L + "'", long45 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant46);
        org.junit.Assert.assertNotNull(mutableDateTime48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 12 + "'", int49 == 12);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localDateTime64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1968" + "'", str66.equals("1968"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 292273002 + "'", int67 == 292273002);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(iSOChronology77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "ISOChronology[UTC]" + "'", str78.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology79);
        org.junit.Assert.assertNotNull(durationField80);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Pacific Standard Time");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("2019-06-12T05:23:49.972-07:00");
        java.lang.Object obj4 = null;
        jodaTimePermission3.checkGuard(obj4);
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str7 = jodaTimePermission3.getActions();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
        org.joda.time.DateTime dateTime11 = property10.roundHalfCeilingCopy();
        jodaTimePermission3.checkGuard((java.lang.Object) property10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("-1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-1\" is malformed at \"1\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("DateTimeField[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'DateTimeField[year]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2019-06-12T05:24:11.615-07:00", false);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("1", 19452, (int) (byte) 10, 48283, 'a', 35355, 12, 19441, false, 38921);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField14.getAsShortText(readablePartial15, 19438, locale17);
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField22.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField14, dateTimeFieldType23, 5, 19, (-10));
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, "10");
        java.lang.String str30 = illegalFieldValueException29.getIllegalStringValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10" + "'", str30.equals("10"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.append(dateTimePrinter5);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder6.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimeParser7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendYearOfCentury(19454, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter12.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withDefaultYear(0);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder0.append(dateTimePrinter13, dateTimeParser17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFractionOfMinute(38916, 38915);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 23);
        try {
            long long16 = offsetDateTimeField3.set(2440588L, "2019-06-12T13:24:36.882-07:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T13:24:36.882-07:00\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (-372));
        long long2 = instant1.getMillis();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-372L) + "'", long2 == (-372L));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        long long5 = delegatedDateTimeField3.remainder((long) 2019);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) 0, locale5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime1, dateTimeZone3);
//        org.joda.time.DateTime dateTime9 = dateTime7.withCenturyOfEra((int) (short) 0);
//        org.joda.time.DurationFieldType durationFieldType10 = null;
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime7.withFieldAdded(durationFieldType10, 324);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 23);
        int int15 = offsetDateTimeField3.getLeapAmount((long) 324);
        org.joda.time.DurationField durationField16 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DurationField durationField15 = delegatedDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury(0);
        org.joda.time.DateTime dateTime22 = dateTime20.withMillis((long) 4);
        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillisOfDay(19434);
        org.joda.time.TimeOfDay timeOfDay26 = dateTime22.toTimeOfDay();
        java.util.Locale locale28 = null;
        java.lang.String str29 = delegatedDateTimeField14.getAsText((org.joda.time.ReadablePartial) timeOfDay26, 80670, locale28);
        long long31 = delegatedDateTimeField14.roundHalfEven((long) (byte) 1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(timeOfDay26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "80670" + "'", str29.equals("80670"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1123200000L + "'", long31 == 1123200000L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
        java.lang.String str3 = buddhistChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
        java.lang.Integer int6 = dateTimeParserBucket5.getOffsetInteger();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        boolean boolean8 = dateTimeParserBucket5.restoreState((java.lang.Object) gregorianChronology7);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 4);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.year();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (byte) 100);
//        org.joda.time.Instant instant9 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = instant9.toMutableDateTime(chronology10);
//        int int12 = mutableDateTime11.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withYearOfCentury(0);
//        mutableDateTime11.setDate((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime20 = dateTime15.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
//        long long27 = dateTimeZone24.adjustOffset((long) '#', true);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.clockhourOfHalfday();
//        java.lang.String str33 = buddhistChronology31.toString();
//        java.util.Locale locale34 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology31, locale34);
//        java.util.Locale locale36 = dateTimeParserBucket35.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter29.withLocale(locale36);
//        java.lang.String str38 = dateTimeZone24.getShortName((long) (short) -1, locale36);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime39 = property5.set("ISOChronology[UTC]", locale36);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[UTC]\" for year is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 35L + "'", long27 == 35L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str33.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(locale36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "PST" + "'", str38.equals("PST"));
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        java.lang.String str12 = property9.getName();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "57648" + "'", str11.equals("57648"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfDay" + "'", str12.equals("secondOfDay"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime5 = dateTime2.withTimeAtStartOfDay();
        long long6 = dateTime5.getMillis();
        long long7 = dateTime5.getMillis();
        org.joda.time.DateTime dateTime9 = dateTime5.withDayOfWeek(6);
        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-57600000L) + "'", long7 == (-57600000L));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.clockhourOfDay();
        long long8 = julianChronology0.add((long) 324, (-59385600090L), (-1));
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 59385600414L + "'", long8 == 59385600414L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "");
        java.lang.String str3 = illegalFieldValueException2.toString();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported"));
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 10);
        long long14 = offsetDateTimeField11.add((long) 1, (long) (short) -1);
        long long16 = offsetDateTimeField11.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField11.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder6.appendFraction(dateTimeFieldType17, 1901, 19454020);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withDefaultYear(0);
        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatter23.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.append(dateTimeParser24);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-31535999999L) + "'", long14 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-30412800000L) + "'", long16 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeParser24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        mutableDateTime2.addYears((int) '4');
        mutableDateTime2.addMinutes((int) (byte) 0);
        mutableDateTime2.setSecondOfDay(19434);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.millisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        mutableDateTime2.add(readablePeriod11);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
        java.lang.String str3 = buddhistChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
        java.util.Locale locale6 = dateTimeParserBucket5.getLocale();
        long long8 = dateTimeParserBucket5.computeMillis(false);
        org.joda.time.Chronology chronology9 = dateTimeParserBucket5.getChronology();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28800052L + "'", long8 == 28800052L);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 3155760000003L, (java.lang.Number) 38915, (java.lang.Number) 48282);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        long long2 = dateTimeFormatter0.parseMillis("19");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61567661222000L) + "'", long2 == (-61567661222000L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 2019");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((-19448));
        int int7 = dateTime6.getEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime4.setZone(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        int int13 = property11.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
        int int19 = skipUndoDateTimeField17.get((long) 19438);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 323);
        org.joda.time.DurationField durationField22 = offsetDateTimeField21.getLeapDurationField();
        long long24 = offsetDateTimeField21.roundHalfEven((-57585880L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57648 + "'", int13 == 57648);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-57586000L) + "'", long24 == (-57586000L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(2000);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) 19447, dateTimeZone2);
        try {
            mutableDateTime3.setHourOfDay(19441661);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19441661 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        boolean boolean9 = dateTime4.isBefore(0L);
        org.joda.time.DateTime dateTime11 = dateTime4.withYearOfEra(57600);
        org.joda.time.DateTime dateTime13 = dateTime11.plus(100L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
        long long26 = offsetDateTimeField21.roundFloor((long) 3);
        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
        long long34 = offsetDateTimeField21.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = instant35.toMutableDateTime(chronology36);
        int int38 = mutableDateTime37.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone40);
        org.joda.time.DateTime dateTime43 = dateTime41.withYearOfCentury(0);
        mutableDateTime37.setDate((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime46 = dateTime41.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 0);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime53, locale54);
        int int56 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime53);
        long long58 = delegatedDateTimeField14.remainder(1L);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField14, (int) (byte) -1, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for year must be in the range [0,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3155760000003L + "'", long34 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1968" + "'", str55.equals("1968"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292273002 + "'", int56 == 292273002);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 30412800001L + "'", long58 == 30412800001L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.withMaximumValue();
        boolean boolean4 = property2.isLeap();
        boolean boolean5 = property2.isLeap();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime4.setZone(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        int int13 = property11.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
        int int19 = skipUndoDateTimeField17.get((long) 19438);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 323);
        java.lang.String str23 = offsetDateTimeField21.getAsShortText((long) 19);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57648 + "'", int13 == 57648);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "57923" + "'", str23.equals("57923"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((-19448));
        org.joda.time.DateTime dateTime8 = dateTime4.plusMillis((int) 'a');
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(323);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        org.joda.time.Instant instant16 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = instant16.toMutableDateTime(chronology17);
//        int int19 = mutableDateTime18.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone21);
//        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury(0);
//        mutableDateTime18.setDate((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime dateTime27 = dateTime22.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dateTimeZone31.getName((long) (short) 10, locale33);
//        long long36 = dateTimeZone15.getMillisKeepLocal(dateTimeZone31, (long) (short) 0);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dateTimeZone31.getShortName((long) (short) 0, locale38);
//        java.lang.String str41 = dateTimeZone31.getShortName(0L);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone42, 19442L, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Pacific Standard Time" + "'", str34.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PST" + "'", str39.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone2 = buddhistChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = buddhistChronology0.get(readablePeriod3, (long) 80670);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        long long7 = offsetDateTimeField4.add((long) 1, (long) (short) -1);
        long long9 = offsetDateTimeField4.roundFloor((long) 3);
        long long12 = offsetDateTimeField4.add((long) (short) 1, (long) 19);
        long long14 = offsetDateTimeField4.roundHalfEven((long) (short) 1);
        int int16 = offsetDateTimeField4.getMaximumValue((long) 19441);
        boolean boolean17 = gregorianChronology0.equals((java.lang.Object) offsetDateTimeField4);
        boolean boolean18 = offsetDateTimeField4.isSupported();
        int int19 = offsetDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31535999999L) + "'", long7 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-30412800000L) + "'", long9 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 599616000001L + "'", long12 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1123200000L + "'", long14 == 1123200000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 292273002 + "'", int16 == 292273002);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 292273002 + "'", int19 == 292273002);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((long) (short) -1);
        org.joda.time.DateTime dateTime3 = instant2.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
        int int4 = mutableDateTime3.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
        int int11 = mutableDateTime3.getSecondOfDay();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime3.secondOfMinute();
        mutableDateTime3.addWeeks(0);
        mutableDateTime3.addMinutes((int) (byte) 100);
        int int17 = mutableDateTime3.getRoundingMode();
        org.joda.time.Instant instant18 = org.joda.time.Instant.now();
        org.joda.time.Instant instant20 = instant18.minus((long) (short) -1);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) instant18);
        int int24 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "", 19447);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime3.yearOfEra();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime3.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57648 + "'", int11 == 57648);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-19448) + "'", int24 == (-19448));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.clockhourOfDay();
        long long8 = julianChronology0.add((long) 324, (-59385600090L), (-1));
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 59385600414L + "'", long8 == 59385600414L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("America/Los_Angeles");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 10);
        long long11 = offsetDateTimeField8.add((long) 1, (long) (short) -1);
        long long13 = offsetDateTimeField8.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField8.getType();
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFieldType14, obj15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder4.appendDecimal(dateTimeFieldType14, (int) (short) 100, 6);
        try {
            org.joda.time.Instant instant20 = new org.joda.time.Instant((java.lang.Object) dateTimeFormatterBuilder4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-31535999999L) + "'", long11 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-30412800000L) + "'", long13 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMillis(19437);
        org.joda.time.DateTime.Property property9 = dateTime4.minuteOfDay();
        java.lang.String str10 = property9.getName();
        try {
            org.joda.time.DateTime dateTime12 = property9.setCopy(80672);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 80672 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "minuteOfDay" + "'", str10.equals("minuteOfDay"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.year();
        mutableDateTime2.addHours(1979);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfCentury(0);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillis((long) 4);
        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfDay(19434);
        org.joda.time.LocalDateTime localDateTime12 = dateTime8.toLocalDateTime();
        org.joda.time.DateTime dateTime14 = dateTime8.withMillisOfSecond(0);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) 0, locale4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 1979, dateTimeZone2);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2019-06-12T05:24:11.615-07:00", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(23);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder5.setFixedSavings("4:00 PM", (int) '#');
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover(19442, '4', (-19441661), (int) (short) 1, 0, false, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
        int int4 = mutableDateTime3.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime12 = dateTime7.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime7.plus((long) 2000);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField18.getType();
        org.joda.time.DateTime dateTime21 = dateTime14.withField(dateTimeFieldType19, 1901);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField22 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendYearOfCentury(35355, (int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime4 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.DateTime dateTime6 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = property2.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("ISOChronology[UTC]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ISOChronology[UTC]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = dateTime6.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfHour();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property13 = dateTime12.secondOfMinute();
//        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = instant14.toMutableDateTime(chronology15);
//        int int17 = mutableDateTime16.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone19);
//        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
//        mutableDateTime16.setDate((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime25 = dateTime20.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone29 = dateTime28.getZone();
//        org.joda.time.Instant instant30 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.MutableDateTime mutableDateTime32 = instant30.toMutableDateTime(chronology31);
//        int int33 = mutableDateTime32.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone35);
//        org.joda.time.DateTime dateTime38 = dateTime36.withYearOfCentury(0);
//        mutableDateTime32.setDate((org.joda.time.ReadableInstant) dateTime36);
//        org.joda.time.DateTime dateTime41 = dateTime36.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime44 = dateTime41.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone45 = dateTime44.getZone();
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = dateTimeZone45.getName((long) (short) 10, locale47);
//        long long50 = dateTimeZone29.getMillisKeepLocal(dateTimeZone45, (long) (short) 0);
//        org.joda.time.DateTime dateTime51 = dateTime12.toDateTime(dateTimeZone45);
//        java.lang.String str52 = dateTimeZone45.toString();
//        org.joda.time.DateTime dateTime53 = dateTime9.withZoneRetainFields(dateTimeZone45);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime53);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(instant30);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Pacific Standard Time" + "'", str48.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "America/Los_Angeles" + "'", str52.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime53);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfFloor();
        mutableDateTime11.setMinuteOfDay(4);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime11.weekyear();
        boolean boolean15 = mutableDateTime11.isEqualNow();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField19.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "BuddhistChronology[America/Los_Angeles]");
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime11.property(dateTimeFieldType20);
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) 589, "1979");
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(property23);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
        int int4 = mutableDateTime3.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
        int int11 = mutableDateTime3.getSecondOfDay();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime3.secondOfMinute();
        mutableDateTime3.addWeeks(0);
        mutableDateTime3.addMinutes((int) (byte) 100);
        int int17 = mutableDateTime3.getRoundingMode();
        org.joda.time.Instant instant18 = org.joda.time.Instant.now();
        org.joda.time.Instant instant20 = instant18.minus((long) (short) -1);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) instant18);
        int int24 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "", 19447);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime3.yearOfEra();
        long long26 = property25.remainder();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57648 + "'", int11 == 57648);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-19448) + "'", int24 == (-19448));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31513248280L + "'", long26 == 31513248280L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        int int11 = property9.get();
        org.joda.time.DateTimeField dateTimeField12 = property9.getField();
        org.joda.time.MutableDateTime mutableDateTime14 = property9.add(9);
        org.joda.time.MutableDateTime mutableDateTime15 = property9.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime16 = property9.roundHalfCeiling();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57648 + "'", int11 == 57648);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusHours((-19441661));
        int int9 = dateTime8.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder1.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfMinute(19437, 19440521);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitYear(48280, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.minusHours(0);
        org.joda.time.DateTime dateTime6 = dateTime1.plusDays(20);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime4 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        java.lang.String str7 = property6.getAsString();
        java.lang.String str8 = property6.getAsText();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField14.getAsShortText(readablePartial15, 19438, locale17);
        boolean boolean19 = delegatedDateTimeField14.isLenient();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.clockhourOfHalfday();
        java.lang.String str25 = buddhistChronology23.toString();
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology23, locale26);
        java.util.Locale locale28 = dateTimeParserBucket27.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter21.withLocale(locale28);
        java.lang.String str30 = delegatedDateTimeField14.getAsShortText(10, locale28);
        long long32 = delegatedDateTimeField14.roundFloor(19402L);
        long long34 = delegatedDateTimeField14.roundFloor((long) (byte) 0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str25.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10" + "'", str30.equals("10"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-30412800000L) + "'", long32 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-30412800000L) + "'", long34 == (-30412800000L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        mutableDateTime2.addWeekyears(19439);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.secondOfMinute();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime2.dayOfYear();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        int int10 = mutableDateTime2.getSecondOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.secondOfMinute();
        try {
            org.joda.time.MutableDateTime mutableDateTime14 = property12.set("2019-06-12T10:48:36.931-07:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T10:48:36.931-07:00\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57648 + "'", int10 == 57648);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour(19);
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        int int10 = mutableDateTime2.getSecondOfDay();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime13 = property11.addWrapField((int) (short) 10);
        mutableDateTime13.addWeekyears(0);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.millisOfDay();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57648 + "'", int10 == 57648);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(19442, (int) (short) 0, 3, 9, 2000, 48284, 19440);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.Instant instant4 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = instant4.toMutableDateTime(chronology5);
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        mutableDateTime6.setZone(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime12 = property10.add((-1));
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        int int15 = property13.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType16, 80674);
        boolean boolean19 = dateTimeFormatterBuilder3.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 57648 + "'", int15 == 57648);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.weekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime4.setZone(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        int int13 = property11.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
        int int19 = skipUndoDateTimeField17.get((long) 19438);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 323);
        long long23 = offsetDateTimeField21.roundHalfCeiling((long) 2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57648 + "'", int13 == 57648);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
        try {
            org.joda.time.DateTime dateTime15 = dateTime11.withWeekOfWeekyear(19438);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19438 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType5, "BuddhistChronology[America/Los_Angeles]");
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField14.getAsShortText(readablePartial15, 19438, locale17);
        boolean boolean19 = delegatedDateTimeField14.isLenient();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.clockhourOfHalfday();
        java.lang.String str25 = buddhistChronology23.toString();
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology23, locale26);
        java.util.Locale locale28 = dateTimeParserBucket27.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter21.withLocale(locale28);
        java.lang.String str30 = delegatedDateTimeField14.getAsShortText(10, locale28);
        long long32 = delegatedDateTimeField14.roundFloor(19402L);
        boolean boolean33 = delegatedDateTimeField14.isSupported();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str25.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10" + "'", str30.equals("10"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-30412800000L) + "'", long32 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField8.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "BuddhistChronology[America/Los_Angeles]");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        java.lang.Number number13 = illegalFieldValueException11.getLowerBound();
        java.lang.Throwable[] throwableArray14 = illegalFieldValueException11.getSuppressed();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.plusWeeks(0);
        org.joda.time.DateTime dateTime16 = dateTime14.minusWeeks((-19448));
        try {
            org.joda.time.DateTime dateTime18 = dateTime14.withEra(2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-57586000L), 31513248280L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1814721915452080000L) + "'", long2 == (-1814721915452080000L));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(48284, 19447, 97, 1, 323, 0, 48284, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 323 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter2.getParser();
        try {
            org.joda.time.LocalDateTime localDateTime5 = dateTimeFormatter2.parseLocalDateTime("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime4.setZone(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        int int13 = property11.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
        int int19 = skipUndoDateTimeField17.get((long) 19438);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 323);
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipUndoDateTimeField17.getAsShortText(57619, locale23);
        int int26 = skipUndoDateTimeField17.get((long) 19434);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57648 + "'", int13 == 57648);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "57619" + "'", str24.equals("57619"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 57619 + "'", int26 == 57619);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime12 = property9.roundHalfFloor();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.era();
        try {
            mutableDateTime12.setDayOfYear((-20));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -20 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "57648" + "'", str11.equals("57648"));
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 0, locale3);
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField6 = julianChronology5.weekyears();
//        org.joda.time.DurationField durationField7 = julianChronology5.seconds();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(durationField7);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField14.getAsShortText(readablePartial15, 19438, locale17);
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField22.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField14, dateTimeFieldType23, 5, 19, (-10));
        long long30 = delegatedDateTimeField14.set(19442L, 323);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-52259385580558L) + "'", long30 == (-52259385580558L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime4.plus((long) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.withSecondOfMinute(3);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
        org.joda.time.Instant instant13 = dateTime11.toInstant();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(instant13);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.Class<?> wildcardClass2 = dateTimeZone1.getClass();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        java.util.TimeZone timeZone4 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        int int11 = property9.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property9.getFieldType();
        org.joda.time.MutableDateTime mutableDateTime13 = property9.roundFloor();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfMinute();
        org.joda.time.DateTime dateTime19 = property17.addToCopy((long) (short) 10);
        boolean boolean20 = gregorianChronology14.equals((java.lang.Object) dateTime19);
        long long21 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime19);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57648 + "'", int11 == 57648);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 38L + "'", long21 == 38L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long9 = offsetDateTimeField3.getDifferenceAsLong((long) 38921, 0L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(30412800001L, chronology2, locale3, (java.lang.Integer) (-292269045));
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology2);
        try {
            org.joda.time.DateTime dateTime10 = dateTime6.withDate(19434, 35355, 38915);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35355 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField3.getType();
        long long12 = offsetDateTimeField3.getDifferenceAsLong(100L, 30412800001L);
        org.joda.time.DurationField durationField13 = offsetDateTimeField3.getLeapDurationField();
        long long16 = offsetDateTimeField3.getDifferenceAsLong((-28761407L), (long) 35355);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 10);
        long long9 = offsetDateTimeField6.add((long) 1, (long) (short) -1);
        long long11 = offsetDateTimeField6.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField6.getType();
        java.lang.Object obj13 = null;
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFieldType12, obj13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31535999999L) + "'", long9 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-30412800000L) + "'", long11 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 0, locale3);
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField6 = julianChronology5.weekyears();
//        try {
//            long long11 = julianChronology5.getDateTimeMillis((int) (short) 10, 19439435, 24, 2019);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19439435 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("2019-06-12T10:48:36.931-07:00", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        org.joda.time.DateTime dateTime13 = property7.setCopy(12);
        try {
            org.joda.time.DateTime dateTime15 = property7.setCopy("2019-06-10T22:24:34.005-07:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-10T22:24:34.005-07:00\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone2 = buddhistChronology0.getZone();
        java.lang.Object obj3 = null;
        boolean boolean4 = buddhistChronology0.equals(obj3);
        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = instant5.toMutableDateTime(chronology6);
        int int8 = mutableDateTime7.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        mutableDateTime7.setZone(dateTimeZone9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime7.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime13 = property11.add((-1));
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
        int int16 = property14.get();
        org.joda.time.DateTimeField dateTimeField17 = property14.getField();
        boolean boolean18 = buddhistChronology0.equals((java.lang.Object) dateTimeField17);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57648 + "'", int16 == 57648);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra(20, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfDay(23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("22:24:29");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '22:24:29' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(30412800001L, chronology2, locale3, (java.lang.Integer) (-292269045));
        dateTimeParserBucket5.setPivotYear((java.lang.Integer) 19437);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
//        org.joda.time.Instant instant10 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = instant10.toMutableDateTime(chronology11);
//        int int13 = mutableDateTime12.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone15);
//        org.joda.time.DateTime dateTime18 = dateTime16.withYearOfCentury(0);
//        mutableDateTime12.setDate((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime21 = dateTime16.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime24 = dateTime21.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTime24.getZone();
//        org.joda.time.Instant instant26 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.MutableDateTime mutableDateTime28 = instant26.toMutableDateTime(chronology27);
//        int int29 = mutableDateTime28.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone31);
//        org.joda.time.DateTime dateTime34 = dateTime32.withYearOfCentury(0);
//        mutableDateTime28.setDate((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTime dateTime37 = dateTime32.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime40 = dateTime37.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone41 = dateTime40.getZone();
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = dateTimeZone41.getName((long) (short) 10, locale43);
//        long long46 = dateTimeZone25.getMillisKeepLocal(dateTimeZone41, (long) (short) 0);
//        org.joda.time.DateTime dateTime47 = dateTime8.toDateTime(dateTimeZone41);
//        java.lang.String str48 = dateTimeZone41.toString();
//        try {
//            org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((int) (byte) -1, 19441661, 57619, 19438, 19440521, 19437, 353, dateTimeZone41);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19438 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(instant10);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(instant26);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Pacific Standard Time" + "'", str44.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "America/Los_Angeles" + "'", str48.equals("America/Los_Angeles"));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime12 = property9.roundHalfFloor();
        int int13 = property9.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "57648" + "'", str11.equals("57648"));
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.weekyearOfCentury();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withDefaultYear(0);
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatter7.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter7.withPivotYear(23);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTime.Property property15 = dateTime13.minuteOfDay();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.clockhourOfHalfday();
        java.lang.String str19 = buddhistChronology17.toString();
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology17, locale20);
        java.util.Locale locale22 = dateTimeParserBucket21.getLocale();
        java.lang.String str23 = property15.getAsText(locale22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter7.withLocale(locale22);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket((long) 57648, (org.joda.time.Chronology) julianChronology1, locale22, (java.lang.Integer) 19454, 0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str19.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "960" + "'", str23.equals("960"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMillisOfSecond(19442);
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeFormatterBuilder0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        boolean boolean4 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        int int13 = offsetDateTimeField3.getMaximumValue(3062188800000L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 292273002 + "'", int13 == 292273002);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (byte) 100);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour(19);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        boolean boolean11 = dateTime9.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        java.lang.String str4 = mutableDateTime2.toString();
        mutableDateTime2.setDate(59385600414L);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:48.280-08:00" + "'", str4.equals("1969-12-31T16:00:48.280-08:00"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-292269045));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-292269045) + "'", int1 == (-292269045));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
        int int4 = mutableDateTime3.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime12 = dateTime7.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.DateTime dateTime16 = dateTime15.toDateTimeISO();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime15);
        try {
            java.lang.String str19 = dateTime15.toString("2019-06-10T22:24:34.005-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        org.joda.time.Chronology chronology3 = instant0.getChronology();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant0.minus(readableDuration4);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
        java.lang.String str3 = buddhistChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
        java.util.Locale locale6 = dateTimeParserBucket5.getLocale();
        dateTimeParserBucket5.setOffset((java.lang.Integer) 19431);
        java.lang.Integer int9 = dateTimeParserBucket5.getPivotYear();
        org.joda.time.Chronology chronology10 = dateTimeParserBucket5.getChronology();
        long long13 = dateTimeParserBucket5.computeMillis(true, "1976-03-10T16:00:48.279-08:00");
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertNull(int9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-19379L) + "'", long13 == (-19379L));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (byte) 100);
        mutableDateTime7.addMonths(19442);
        org.joda.time.DateTime dateTime10 = mutableDateTime7.toDateTime();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime7.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField12 = mutableDateTime7.getRoundingField();
        mutableDateTime7.addMonths(2);
        mutableDateTime7.setMonthOfYear((int) (short) 1);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNull(dateTimeField12);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        mutableDateTime2.addWeekyears(19439);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime9 = property8.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.roundHalfFloor();
        java.lang.String str11 = property8.getName();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "secondOfMinute" + "'", str11.equals("secondOfMinute"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
        int int4 = mutableDateTime3.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
        int int11 = mutableDateTime3.getSecondOfDay();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime3.secondOfMinute();
        int int15 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "2019-06-12T05:24:11.615-07:00", 19);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime3.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57648 + "'", int11 == 57648);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-20) + "'", int15 == (-20));
        org.junit.Assert.assertNotNull(property16);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) 0, locale4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 1979, dateTimeZone2);
//        java.lang.String str8 = dateTimeZone2.getShortName((long) 19431);
//        java.util.TimeZone timeZone9 = dateTimeZone2.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter0.parseLocalTime("DateTimeField[secondOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[secondOfDay]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 57600);
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime4.setZone(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        int int13 = property11.get();
        org.joda.time.DateTimeField dateTimeField14 = property11.getField();
        org.joda.time.MutableDateTime mutableDateTime16 = property11.add(9);
        org.joda.time.MutableDateTime mutableDateTime17 = property11.roundHalfEven();
        boolean boolean18 = mutableDateTime1.isAfter((org.joda.time.ReadableInstant) mutableDateTime17);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57648 + "'", int13 == 57648);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime4.setZone(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        int int13 = property11.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField17.getAsText((long) (-1), locale19);
        java.lang.String str22 = skipUndoDateTimeField17.getAsShortText((long) 19441661);
        long long25 = skipUndoDateTimeField17.addWrapField((-19379L), 80674);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57648 + "'", int13 == 57648);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "57599" + "'", str20.equals("57599"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "77041" + "'", str22.equals("77041"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-5745379L) + "'", long25 == (-5745379L));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMillis(19437);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.toDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime18 = dateTime13.plus((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime18.withSecondOfMinute(3);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime8, (org.joda.time.ReadableInstant) dateTime20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName((long) 0, locale4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 1979, dateTimeZone2);
//        java.lang.String str8 = dateTimeZone2.getShortName((long) 19431);
//        java.util.TimeZone timeZone9 = dateTimeZone2.toTimeZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withDefaultYear(0);
//        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
//        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone2, (java.lang.Object) dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeParser13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            mutableDateTime2.set(dateTimeFieldType6, 19439);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfHour(4, 20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(30412800001L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.DateTime dateTime4 = instant1.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField14.getAsShortText(readablePartial15, 19438, locale17);
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField22.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField14, dateTimeFieldType23, 5, 19, (-10));
        try {
            long long30 = offsetDateTimeField27.add((long) 19454, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2081 for year must be in the range [19,-10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 19440);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(38918, 6, (int) 'a', 19440, (int) '#', (-28800000), 804, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19440 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DurationField durationField2 = julianChronology0.hours();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        java.lang.Object obj4 = null;
        boolean boolean5 = julianChronology0.equals(obj4);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime4.setZone(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        int int13 = property11.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField17.getAsText((long) (-1), locale19);
        int int23 = skipUndoDateTimeField17.getDifference(100L, 28800323L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57619 + "'", int13 == 57619);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "57599" + "'", str20.equals("57599"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800) + "'", int23 == (-28800));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("2019-06-12T05:23:59.102-07:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-12T05:23:59.102-07:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        org.joda.time.DateTime dateTime12 = property7.getDateTime();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) 80671);
        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DurationField durationField2 = julianChronology0.minutes();
        org.joda.time.DurationField durationField3 = julianChronology0.minutes();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
        try {
            long long12 = julianChronology0.getDateTimeMillis((int) (short) 1, 38917, 35360, 38914, 0, 4, 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 38914 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        long long13 = offsetDateTimeField3.roundHalfEven((long) 23);
        long long16 = offsetDateTimeField3.add(3061065600020L, (long) 100);
        long long18 = offsetDateTimeField3.roundHalfCeiling((long) 19439);
        long long20 = offsetDateTimeField3.roundFloor((long) 19431);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 6216825600020L + "'", long16 == 6216825600020L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1123200000L + "'", long18 == 1123200000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-30412800000L) + "'", long20 == (-30412800000L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DurationField durationField2 = julianChronology0.hours();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        int int4 = mutableDateTime3.getDayOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime3.toMutableDateTime();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 353 + "'", int4 == 353);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
        java.lang.String str3 = buddhistChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
        java.util.Locale locale6 = dateTimeParserBucket5.getLocale();
        dateTimeParserBucket5.setOffset((java.lang.Integer) 19431);
        java.lang.Integer int9 = dateTimeParserBucket5.getPivotYear();
        org.joda.time.Chronology chronology10 = dateTimeParserBucket5.getChronology();
        long long12 = dateTimeParserBucket5.computeMillis(true);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertNull(int9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-19379L) + "'", long12 == (-19379L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DurationField durationField2 = julianChronology0.hours();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = julianChronology0.withZone(dateTimeZone5);
        org.joda.time.DurationField durationField8 = julianChronology0.years();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime4.setZone(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        int int13 = property11.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField17.getAsText((long) (-1), locale19);
        java.lang.String str22 = skipUndoDateTimeField17.getAsShortText((long) 19441661);
        int int23 = skipUndoDateTimeField17.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57619 + "'", int13 == 57619);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "57599" + "'", str20.equals("57599"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "77041" + "'", str22.equals("77041"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 86399 + "'", int23 == 86399);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMillisOfSecond(19442);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendSecondOfDay((-19441661));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1L), (java.lang.Number) 38917, (java.lang.Number) 31513248280L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 19439435);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        long long13 = offsetDateTimeField3.roundHalfEven((long) (short) 1);
        long long15 = offsetDateTimeField3.roundCeiling((long) 19439435);
        long long17 = offsetDateTimeField3.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1123200000L + "'", long15 == 1123200000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1123200000L + "'", long17 == 1123200000L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(19431);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-19431) + "'", int1 == (-19431));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology5.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField8, (int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.clockhourOfHalfday();
        java.lang.String str15 = buddhistChronology13.toString();
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology13, locale16);
        java.util.Locale locale18 = dateTimeParserBucket17.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter11.withLocale(locale18);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 1970, (org.joda.time.Chronology) julianChronology1, locale18);
        java.lang.Integer int21 = dateTimeParserBucket20.getPivotYear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str15.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNull(int21);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 38914, 8417L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 327539138 + "'", int2 == 327539138);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone2 = buddhistChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 10);
        long long9 = offsetDateTimeField6.add((long) 1, (long) (short) -1);
        long long11 = offsetDateTimeField6.roundFloor((long) 3);
        long long14 = offsetDateTimeField6.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6);
        java.util.Locale locale19 = null;
        java.lang.String str20 = delegatedDateTimeField17.getAsText(19438, locale19);
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 10);
        long long27 = offsetDateTimeField24.add((long) 1, (long) (short) -1);
        long long29 = offsetDateTimeField24.roundFloor((long) 3);
        long long32 = offsetDateTimeField24.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, (int) (short) 100);
        long long37 = offsetDateTimeField24.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant38 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.MutableDateTime mutableDateTime40 = instant38.toMutableDateTime(chronology39);
        int int41 = mutableDateTime40.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone43);
        org.joda.time.DateTime dateTime46 = dateTime44.withYearOfCentury(0);
        mutableDateTime40.setDate((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.DateTime dateTime49 = dateTime44.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime52 = dateTime49.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.DateTime dateTime55 = dateTime52.withPeriodAdded(readablePeriod53, 0);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        java.util.Locale locale57 = null;
        java.lang.String str58 = offsetDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDateTime56, locale57);
        int int59 = delegatedDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) localDateTime56);
        boolean boolean61 = delegatedDateTimeField17.isLeap((long) 23);
        long long64 = delegatedDateTimeField17.getDifferenceAsLong((long) 19440, 0L);
        boolean boolean65 = delegatedDateTimeField17.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField67 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField17, 6);
        org.joda.time.DateTime dateTime68 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31535999999L) + "'", long9 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-30412800000L) + "'", long11 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 599616000001L + "'", long14 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "19438" + "'", str20.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31535999999L) + "'", long27 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-30412800000L) + "'", long29 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 599616000001L + "'", long32 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3155760000003L + "'", long37 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant38);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1968" + "'", str58.equals("1968"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 292273002 + "'", int59 == 292273002);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(dateTime68);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime5 = dateTime2.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
        org.joda.time.DateTime.Property property7 = dateTime5.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime16.getZone();
        org.joda.time.DateTime.Property property18 = dateTime16.minuteOfDay();
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.clockhourOfHalfday();
        java.lang.String str22 = buddhistChronology20.toString();
        java.util.Locale locale23 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket24 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology20, locale23);
        java.util.Locale locale25 = dateTimeParserBucket24.getLocale();
        java.lang.String str26 = property18.getAsText(locale25);
        int int27 = offsetDateTimeField3.getMaximumTextLength(locale25);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str22.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "960" + "'", str26.equals("960"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        java.lang.String str4 = mutableDateTime2.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        java.lang.String str6 = mutableDateTime2.toString(dateTimeFormatter5);
//        try {
//            mutableDateTime2.setDateTime(35355, 0, 1901, 19452, 19442, (int) 'a', 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19452 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-12T10:48:59.544-07:00" + "'", str4.equals("2019-06-12T10:48:59.544-07:00"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10:48:59" + "'", str6.equals("10:48:59"));
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime2.dayOfMonth();
//        mutableDateTime2.setTime(2440588L);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 38939 + "'", int10 == 38939);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        mutableDateTime2.addMinutes((int) (byte) 100);
//        mutableDateTime2.addMillis((-292269045));
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property20 = dateTime19.secondOfMinute();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfCeilingCopy();
//        int int22 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime.Property property23 = dateTime21.secondOfDay();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 38939 + "'", int10 == 38939);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(property23);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("-1", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"-1/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider1 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.clockhourOfHalfday();
        java.lang.String str6 = buddhistChronology4.toString();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology4, locale7);
        java.lang.Integer int9 = dateTimeParserBucket8.getOffsetInteger();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
        long long16 = offsetDateTimeField13.add((long) 1, (long) (short) -1);
        long long18 = offsetDateTimeField13.roundFloor((long) 3);
        long long21 = offsetDateTimeField13.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13);
        java.util.Locale locale26 = null;
        java.lang.String str27 = delegatedDateTimeField24.getAsText(19438, locale26);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = julianChronology28.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 10);
        long long34 = offsetDateTimeField31.add((long) 1, (long) (short) -1);
        long long36 = offsetDateTimeField31.roundFloor((long) 3);
        long long39 = offsetDateTimeField31.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField31, (int) (short) 100);
        long long44 = offsetDateTimeField31.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant45 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology46 = null;
        org.joda.time.MutableDateTime mutableDateTime47 = instant45.toMutableDateTime(chronology46);
        int int48 = mutableDateTime47.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime51.withYearOfCentury(0);
        mutableDateTime47.setDate((org.joda.time.ReadableInstant) dateTime51);
        org.joda.time.DateTime dateTime56 = dateTime51.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod60 = null;
        org.joda.time.DateTime dateTime62 = dateTime59.withPeriodAdded(readablePeriod60, 0);
        org.joda.time.LocalDateTime localDateTime63 = dateTime62.toLocalDateTime();
        java.util.Locale locale64 = null;
        java.lang.String str65 = offsetDateTimeField31.getAsText((org.joda.time.ReadablePartial) localDateTime63, locale64);
        int int66 = delegatedDateTimeField24.getMaximumValue((org.joda.time.ReadablePartial) localDateTime63);
        long long68 = delegatedDateTimeField24.remainder(1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = delegatedDateTimeField24.getType();
        org.joda.time.chrono.JulianChronology julianChronology71 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField72 = julianChronology71.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, 10);
        long long77 = offsetDateTimeField74.add((long) 1, (long) (short) -1);
        long long80 = offsetDateTimeField74.addWrapField((long) 20, (int) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology83 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField84 = buddhistChronology83.clockhourOfHalfday();
        java.lang.String str85 = buddhistChronology83.toString();
        java.util.Locale locale86 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket87 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology83, locale86);
        java.util.Locale locale88 = dateTimeParserBucket87.getLocale();
        java.lang.String str89 = offsetDateTimeField74.getAsText((long) 9, locale88);
        dateTimeParserBucket8.saveField(dateTimeFieldType69, "19438", locale88);
        java.lang.String str93 = defaultNameProvider1.getName(locale88, "1970", "Jan 31, 1968 3:59:59 PM");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter94 = dateTimeFormatter0.withLocale(locale88);
        java.util.Locale locale95 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str6.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNull(int9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31535999999L) + "'", long16 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-30412800000L) + "'", long18 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 599616000001L + "'", long21 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "19438" + "'", str27.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-31535999999L) + "'", long34 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-30412800000L) + "'", long36 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 599616000001L + "'", long39 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 3155760000003L + "'", long44 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant45);
        org.junit.Assert.assertNotNull(mutableDateTime47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(localDateTime63);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1968" + "'", str65.equals("1968"));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 292273002 + "'", int66 == 292273002);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 30412800001L + "'", long68 == 30412800001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertNotNull(julianChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-31535999999L) + "'", long77 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 3061065600020L + "'", long80 == 3061065600020L);
        org.junit.Assert.assertNotNull(buddhistChronology83);
        org.junit.Assert.assertNotNull(dateTimeField84);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str85.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "1979" + "'", str89.equals("1979"));
        org.junit.Assert.assertNull(str93);
        org.junit.Assert.assertNotNull(dateTimeFormatter94);
        org.junit.Assert.assertNull(locale95);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
//        java.lang.String str3 = buddhistChronology1.toString();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
//        java.lang.String str6 = buddhistChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology1.secondOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology9 = gregorianChronology8.withUTC();
//        org.joda.time.Instant instant10 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = instant10.toMutableDateTime(chronology11);
//        int int13 = mutableDateTime12.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        mutableDateTime12.setZone(dateTimeZone14);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime12.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime18 = property16.add((-1));
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = property19.getField();
//        int int21 = property19.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property19.getFieldType();
//        org.joda.time.DateTimeField dateTimeField23 = property19.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField23, 19448);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField23, 58302);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str6.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(instant10);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 38939 + "'", int21 == 38939);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearText();
        boolean boolean6 = dateTimeFormatterBuilder4.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long10 = offsetDateTimeField3.roundHalfCeiling((long) (short) 0);
        int int12 = offsetDateTimeField3.getLeapAmount((long) (-20));
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        java.lang.Object obj15 = null;
        boolean boolean16 = julianChronology13.equals(obj15);
        org.joda.time.DateTimeField dateTimeField17 = julianChronology13.weekyear();
        org.joda.time.Instant instant18 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = instant18.toMutableDateTime(chronology19);
        int int21 = mutableDateTime20.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.withYearOfCentury(0);
        mutableDateTime20.setDate((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime29 = dateTime24.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.DateTime dateTime35 = dateTime32.withPeriodAdded(readablePeriod33, 0);
        org.joda.time.LocalDateTime localDateTime36 = dateTime35.toLocalDateTime();
        long long38 = julianChronology13.set((org.joda.time.ReadablePartial) localDateTime36, 0L);
        int int39 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) localDateTime36);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1123200000L + "'", long10 == 1123200000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDateTime36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-59385600090L) + "'", long38 == (-59385600090L));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 292273002 + "'", int39 == 292273002);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField14.getAsShortText(readablePartial15, 19438, locale17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime23.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime28 = dateTime26.withMinuteOfHour(19);
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology29.getZone();
        org.joda.time.Instant instant31 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.MutableDateTime mutableDateTime33 = instant31.toMutableDateTime(chronology32);
        int int34 = mutableDateTime33.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime37.withYearOfCentury(0);
        mutableDateTime33.setDate((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime dateTime42 = dateTime37.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime45 = dateTime42.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, 0);
        org.joda.time.LocalDateTime localDateTime49 = dateTime48.toLocalDateTime();
        boolean boolean50 = dateTimeZone30.isLocalDateTimeGap(localDateTime49);
        org.joda.time.DateTime dateTime51 = dateTime26.withFields((org.joda.time.ReadablePartial) localDateTime49);
        int[] intArray52 = null;
        int int53 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime49, intArray52);
        long long55 = delegatedDateTimeField14.roundFloor(230400004L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(instant31);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(localDateTime49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 292273002 + "'", int53 == 292273002);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-30412800000L) + "'", long55 == (-30412800000L));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder1.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendFractionOfMinute(19437, 19440521);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatterBuilder1.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException2.toString();
        java.lang.String str8 = illegalFieldValueException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported" + "'", str8.equals("org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long10 = offsetDateTimeField3.roundHalfCeiling((long) (short) 0);
        int int12 = offsetDateTimeField3.getLeapAmount((long) (-20));
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withYearOfCentury(0);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) 4);
        org.joda.time.DateTime.Property property20 = dateTime19.weekyear();
        org.joda.time.DateTime dateTime22 = dateTime19.withMillisOfDay(19434);
        org.joda.time.LocalDateTime localDateTime23 = dateTime19.toLocalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.clockhourOfHalfday();
        java.lang.String str29 = buddhistChronology27.toString();
        java.util.Locale locale30 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology27, locale30);
        java.util.Locale locale32 = dateTimeParserBucket31.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter25.withLocale(locale32);
        java.lang.String str34 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDateTime23, 19, locale32);
        int int36 = offsetDateTimeField3.getLeapAmount((long) 539);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType37, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1123200000L + "'", long10 == 1123200000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str29.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(locale32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "19" + "'", str34.equals("19"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long5 = gJChronology0.getDateTimeMillis(19448, 48276, 58302, 48280);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 48276 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillis((long) 4);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        boolean boolean13 = dateTime11.isBefore(1752355123257619L);
        long long14 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-4L) + "'", long14 == (-4L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        int int19 = skipUndoDateTimeField17.get((long) 19438);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 323);
//        java.lang.String str23 = skipUndoDateTimeField17.getAsText(0L);
//        int int25 = skipUndoDateTimeField17.getLeapAmount((-1L));
//        int int26 = skipUndoDateTimeField17.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 38940 + "'", int13 == 38940);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "57600" + "'", str23.equals("57600"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear(0);
        boolean boolean8 = dateTimeFormatter7.isPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.append(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology4.getZone();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) 0, locale7);
//        long long10 = dateTimeZone3.getMillisKeepLocal(dateTimeZone5, 0L);
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = instant11.toMutableDateTime(chronology12);
//        int int14 = mutableDateTime13.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime17.withYearOfCentury(0);
//        mutableDateTime13.setDate((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime22 = dateTime17.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
//        org.joda.time.Instant instant27 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology28 = null;
//        org.joda.time.MutableDateTime mutableDateTime29 = instant27.toMutableDateTime(chronology28);
//        int int30 = mutableDateTime29.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
//        org.joda.time.DateTime dateTime35 = dateTime33.withYearOfCentury(0);
//        mutableDateTime29.setDate((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime dateTime38 = dateTime33.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime41 = dateTime38.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone42 = dateTime41.getZone();
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = dateTimeZone42.getName((long) (short) 10, locale44);
//        long long47 = dateTimeZone26.getMillisKeepLocal(dateTimeZone42, (long) (short) 0);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = dateTimeZone42.getShortName((long) (short) 0, locale49);
//        long long52 = dateTimeZone5.getMillisKeepLocal(dateTimeZone42, (long) 323);
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28800000L) + "'", long10 == (-28800000L));
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(instant27);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Pacific Standard Time" + "'", str45.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "PST" + "'", str50.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 28800323L + "'", long52 == 28800323L);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTime54);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
        long long26 = offsetDateTimeField21.roundFloor((long) 3);
        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
        long long34 = offsetDateTimeField21.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = instant35.toMutableDateTime(chronology36);
        int int38 = mutableDateTime37.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone40);
        org.joda.time.DateTime dateTime43 = dateTime41.withYearOfCentury(0);
        mutableDateTime37.setDate((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime46 = dateTime41.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 0);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime53, locale54);
        int int56 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime53);
        long long58 = delegatedDateTimeField14.remainder(1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = delegatedDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException63 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType59, (java.lang.Number) 35358, (java.lang.Number) (-57585880L), (java.lang.Number) 100L);
        org.joda.time.DurationFieldType durationFieldType64 = illegalFieldValueException63.getDurationFieldType();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3155760000003L + "'", long34 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1968" + "'", str55.equals("1968"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292273002 + "'", int56 == 292273002);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 30412800001L + "'", long58 == 30412800001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertNull(durationFieldType64);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(19440);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendLiteral("year");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        java.lang.Object obj0 = null;
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
//        mutableDateTime4.setDate((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime13 = dateTime8.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone17 = dateTime16.getZone();
//        org.joda.time.Instant instant18 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.MutableDateTime mutableDateTime20 = instant18.toMutableDateTime(chronology19);
//        int int21 = mutableDateTime20.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone23);
//        org.joda.time.DateTime dateTime26 = dateTime24.withYearOfCentury(0);
//        mutableDateTime20.setDate((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime29 = dateTime24.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone33 = dateTime32.getZone();
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = dateTimeZone33.getName((long) (short) 10, locale35);
//        long long38 = dateTimeZone17.getMillisKeepLocal(dateTimeZone33, (long) (short) 0);
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dateTimeZone33.getShortName((long) (short) 0, locale40);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) '#', dateTimeZone33);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(obj0, dateTimeZone33);
//        org.joda.time.DateTime.Property property44 = dateTime43.hourOfDay();
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(instant18);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Pacific Standard Time" + "'", str36.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PST" + "'", str41.equals("PST"));
//        org.junit.Assert.assertNotNull(property44);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException2.getSuppressed();
        java.lang.String str7 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
        long long26 = offsetDateTimeField21.roundFloor((long) 3);
        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
        long long34 = offsetDateTimeField21.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = instant35.toMutableDateTime(chronology36);
        int int38 = mutableDateTime37.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone40);
        org.joda.time.DateTime dateTime43 = dateTime41.withYearOfCentury(0);
        mutableDateTime37.setDate((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime dateTime46 = dateTime41.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 0);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime53, locale54);
        int int56 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime53);
        long long58 = delegatedDateTimeField14.remainder(1L);
        org.joda.time.DurationField durationField59 = delegatedDateTimeField14.getRangeDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3155760000003L + "'", long34 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1968" + "'", str55.equals("1968"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292273002 + "'", int56 == 292273002);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 30412800001L + "'", long58 == 30412800001L);
        org.junit.Assert.assertNull(durationField59);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 4);
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 100, (-292273003));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-292272903) + "'", int2 == (-292272903));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime4 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.DateTime dateTime6 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime8 = property2.roundFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.Instant instant7 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = instant7.toMutableDateTime(chronology8);
//        int int10 = mutableDateTime9.getCenturyOfEra();
//        int int11 = mutableDateTime9.getYearOfCentury();
//        mutableDateTime9.setDate((long) (-1));
//        boolean boolean14 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime9.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime16 = property15.roundFloor();
//        java.lang.String str17 = property15.getAsShortText();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "665" + "'", str17.equals("665"));
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        mutableDateTime2.addMinutes((int) (byte) 100);
//        mutableDateTime2.addMillis((-292269045));
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime2.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        mutableDateTime2.add(readablePeriod19, 86399);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 38942 + "'", int10 == 38942);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property18);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.Object obj2 = null;
        boolean boolean3 = julianChronology0.equals(obj2);
        int int4 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        mutableDateTime2.addMinutes((int) (byte) 100);
//        boolean boolean17 = mutableDateTime2.isBefore((long) 59);
//        mutableDateTime2.addWeeks(11);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 38942 + "'", int10 == 38942);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime5 = dateTime2.withTimeAtStartOfDay();
        long long6 = dateTime5.getMillis();
        long long7 = dateTime5.getMillis();
        org.joda.time.DateTime dateTime9 = dateTime5.plusWeeks(323);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime15 = dateTime9.withTime(48284, 0, 48282, (-19448));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 48284 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-57600000L) + "'", long7 == (-57600000L));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime5 = property3.addToCopy((long) (short) 10);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.plusMinutes((int) (short) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.hours();
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 19447);
        org.joda.time.DateMidnight dateMidnight2 = dateTime1.toDateMidnight();
        org.junit.Assert.assertNotNull(dateMidnight2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
        org.joda.time.Chronology chronology4 = dateTimeFormatter2.getChronolgy();
        boolean boolean5 = dateTimeFormatter2.isOffsetParsed();
        boolean boolean6 = dateTimeFormatter2.isOffsetParsed();
        boolean boolean7 = julianChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 19454);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        int int11 = property9.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property9.getFieldType();
//        org.joda.time.MutableDateTime mutableDateTime13 = property9.roundFloor();
//        java.lang.String str14 = mutableDateTime13.toString();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 38943 + "'", int11 == 38943);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-06-12T10:49:03.000-07:00" + "'", str14.equals("2019-06-12T10:49:03.000-07:00"));
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        boolean boolean7 = offsetDateTimeField3.isSupported();
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField3.getWrappedField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19437);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(19442);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
//        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfMinute();
//        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) (short) 10);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusWeeks((-19448));
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime8.withPeriodAdded(readablePeriod11, 1);
//        boolean boolean14 = iSOChronology0.equals((java.lang.Object) dateTime13);
//        org.joda.time.Instant instant15 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.MutableDateTime mutableDateTime17 = instant15.toMutableDateTime(chronology16);
//        int int18 = mutableDateTime17.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.withYearOfCentury(0);
//        mutableDateTime17.setDate((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime26 = dateTime21.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime29 = dateTime26.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime29.getZone();
//        org.joda.time.Instant instant31 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology32 = null;
//        org.joda.time.MutableDateTime mutableDateTime33 = instant31.toMutableDateTime(chronology32);
//        int int34 = mutableDateTime33.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone36);
//        org.joda.time.DateTime dateTime39 = dateTime37.withYearOfCentury(0);
//        mutableDateTime33.setDate((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.DateTime dateTime42 = dateTime37.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime45 = dateTime42.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone46 = dateTime45.getZone();
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dateTimeZone46.getName((long) (short) 10, locale48);
//        long long51 = dateTimeZone30.getMillisKeepLocal(dateTimeZone46, (long) (short) 0);
//        long long53 = dateTimeZone30.convertUTCToLocal(8417L);
//        org.joda.time.Chronology chronology54 = iSOChronology0.withZone(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(instant31);
//        org.junit.Assert.assertNotNull(mutableDateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Coordinated Universal Time" + "'", str49.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 8417L + "'", long53 == 8417L);
//        org.junit.Assert.assertNotNull(chronology54);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundHalfCeiling();
//        mutableDateTime9.addWeeks(323);
//        org.joda.time.Instant instant12 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = instant12.toMutableDateTime(chronology13);
//        int int15 = mutableDateTime14.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        mutableDateTime14.setZone(dateTimeZone16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime20 = property18.add((-1));
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField22 = property21.getField();
//        int int23 = property21.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property21.getFieldType();
//        boolean boolean25 = mutableDateTime9.isSupported(dateTimeFieldType24);
//        boolean boolean27 = mutableDateTime9.isAfter((long) (short) 0);
//        org.joda.time.MutableDateTime.Property property28 = mutableDateTime9.dayOfYear();
//        int int29 = mutableDateTime9.getMillisOfDay();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime9.dayOfMonth();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 64144 + "'", int23 == 64144);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 64144215 + "'", int29 == 64144215);
//        org.junit.Assert.assertNotNull(property30);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime9 = dateTime4.plus((long) (short) 10);
//        org.joda.time.DateTime dateTime11 = dateTime9.withSecondOfMinute(3);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = property12.roundHalfEvenCopy();
//        int int14 = dateTime13.getWeekyear();
//        org.joda.time.DateTime.Property property15 = dateTime13.minuteOfDay();
//        java.lang.Class<?> wildcardClass16 = property15.getClass();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.append(dateTimePrinter5);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder6.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimeParser7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendYearOfCentury(19454, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter12.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withDefaultYear(0);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder0.append(dateTimePrinter13, dateTimeParser17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder19.appendFractionOfSecond(0, (int) '#');
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatterBuilder24.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeParser25);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfSecond(19438);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear(1979);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfSecond((int) ' ', 19441);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField16.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, "BuddhistChronology[America/Los_Angeles]");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder12.appendFraction(dateTimeFieldType17, 19434, 2000);
//        int int23 = dateTime1.get(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DurationField durationField2 = julianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        org.joda.time.Instant instant16 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = instant16.toMutableDateTime(chronology17);
//        int int19 = mutableDateTime18.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone21);
//        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury(0);
//        mutableDateTime18.setDate((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime dateTime27 = dateTime22.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dateTimeZone31.getName((long) (short) 10, locale33);
//        long long36 = dateTimeZone15.getMillisKeepLocal(dateTimeZone31, (long) (short) 0);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dateTimeZone31.getShortName((long) (short) 0, locale38);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31, 38917);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 38917");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Coordinated Universal Time" + "'", str34.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "UTC" + "'", str39.equals("UTC"));
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        org.joda.time.DurationField durationField15 = delegatedDateTimeField14.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime22 = dateTime20.withMillis((long) 4);
//        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillisOfDay(19434);
//        org.joda.time.TimeOfDay timeOfDay26 = dateTime22.toTimeOfDay();
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = delegatedDateTimeField14.getAsText((org.joda.time.ReadablePartial) timeOfDay26, 80670, locale28);
//        java.lang.String str30 = delegatedDateTimeField14.getName();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology34.clockhourOfHalfday();
//        java.lang.String str36 = buddhistChronology34.toString();
//        java.util.Locale locale37 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology34, locale37);
//        java.util.Locale locale39 = dateTimeParserBucket38.getLocale();
//        try {
//            long long40 = delegatedDateTimeField14.set((-31535999999L), "DateTimeField[secondOfDay]", locale39);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[secondOfDay]\" for year is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(timeOfDay26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "80670" + "'", str29.equals("80670"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "year" + "'", str30.equals("year"));
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "BuddhistChronology[UTC]" + "'", str36.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale39);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        boolean boolean4 = dateTime2.equals((java.lang.Object) dateTimeFormatter3);
        try {
            org.joda.time.Instant instant5 = org.joda.time.Instant.parse("2019-06-12T10:48:36.931-07:00", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T10:48:36.931-07:00\" is malformed at \"-06-12T10:48:36.931-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName((long) (short) 10, locale17);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.withFields(readablePartial21);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Coordinated Universal Time" + "'", str18.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        int int4 = mutableDateTime2.getYearOfCentury();
        mutableDateTime2.setDate((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
        java.util.Date date12 = dateTime9.toDate();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        long long19 = offsetDateTimeField16.add((long) 1, (long) (short) -1);
        long long21 = offsetDateTimeField16.roundFloor((long) 3);
        long long23 = offsetDateTimeField16.roundHalfCeiling((long) (short) 0);
        int int24 = dateTime9.get((org.joda.time.DateTimeField) offsetDateTimeField16);
        org.joda.time.DateTime.Property property25 = dateTime9.secondOfDay();
        org.joda.time.DateTime dateTime27 = property25.addToCopy(6);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31535999999L) + "'", long19 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-30412800000L) + "'", long21 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1123200000L + "'", long23 == 1123200000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1979 + "'", int24 == 1979);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        org.joda.time.DateTime dateTime11 = property7.addToCopy(1L);
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime4 = property2.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
//        org.joda.time.Instant instant6 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = instant6.toMutableDateTime(chronology7);
//        int int9 = mutableDateTime8.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime12.withYearOfCentury(0);
//        mutableDateTime8.setDate((org.joda.time.ReadableInstant) dateTime12);
//        int int16 = mutableDateTime8.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime17 = mutableDateTime8.toMutableDateTime();
//        mutableDateTime8.setMillis((long) 20);
//        boolean boolean20 = property2.equals((java.lang.Object) mutableDateTime8);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 64145 + "'", int16 == 64145);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = julianChronology0.equals(obj2);
//        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.dayOfMonth();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 10);
//        long long12 = offsetDateTimeField9.add((long) 1, (long) (short) -1);
//        long long14 = offsetDateTimeField9.roundFloor((long) 3);
//        long long16 = offsetDateTimeField9.roundHalfCeiling((long) (short) 0);
//        int int18 = offsetDateTimeField9.getLeapAmount((long) (-20));
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime25 = dateTime23.withMillis((long) 4);
//        org.joda.time.DateTime.Property property26 = dateTime25.weekyear();
//        org.joda.time.DateTime dateTime28 = dateTime25.withMillisOfDay(19434);
//        org.joda.time.LocalDateTime localDateTime29 = dateTime25.toLocalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology33.clockhourOfHalfday();
//        java.lang.String str35 = buddhistChronology33.toString();
//        java.util.Locale locale36 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket37 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology33, locale36);
//        java.util.Locale locale38 = dateTimeParserBucket37.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = dateTimeFormatter31.withLocale(locale38);
//        java.lang.String str40 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDateTime29, 19, locale38);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology42 = gregorianChronology41.withUTC();
//        org.joda.time.Instant instant43 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology44 = null;
//        org.joda.time.MutableDateTime mutableDateTime45 = instant43.toMutableDateTime(chronology44);
//        int int46 = mutableDateTime45.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        mutableDateTime45.setZone(dateTimeZone47);
//        org.joda.time.MutableDateTime.Property property49 = mutableDateTime45.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime51 = property49.add((-1));
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime51.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField53 = property52.getField();
//        int int54 = property52.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property52.getFieldType();
//        org.joda.time.DateTimeField dateTimeField56 = property52.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField58 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology41, dateTimeField56, 19448);
//        java.lang.String str60 = skipUndoDateTimeField58.getAsShortText(6216825600020L);
//        org.joda.time.ReadablePartial readablePartial61 = null;
//        int[] intArray65 = new int[] { 48280, (byte) 0, 1901 };
//        int int66 = skipUndoDateTimeField58.getMinimumValue(readablePartial61, intArray65);
//        try {
//            julianChronology0.validate((org.joda.time.ReadablePartial) localDateTime29, intArray65);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31535999999L) + "'", long12 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-30412800000L) + "'", long14 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1123200000L + "'", long16 == 1123200000L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDateTime29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "BuddhistChronology[UTC]" + "'", str35.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "19" + "'", str40.equals("19"));
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(instant43);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(mutableDateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 64145 + "'", int54 == 64145);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "0" + "'", str60.equals("0"));
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundHalfFloor((long) 0);
        long long11 = offsetDateTimeField3.add((long) (byte) 100, 38917);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1123200000L + "'", long8 == 1123200000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1228127097600100L + "'", long11 == 1228127097600100L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        boolean boolean17 = offsetDateTimeField13.isLeap((long) 19435);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfSecond((int) ' ', 19441);
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField30.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "BuddhistChronology[America/Los_Angeles]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder26.appendFraction(dateTimeFieldType31, 19434, 2000);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType31, 19442);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField38);
        int int40 = remainderDateTimeField39.getMaximumValue();
        int int41 = remainderDateTimeField39.getMinimumValue();
        long long43 = remainderDateTimeField39.roundFloor(2019L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19441 + "'", int40 == 19441);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-30412800000L) + "'", long43 == (-30412800000L));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime4 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = property2.roundFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 19440);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-209187144000000L) + "'", long1 == (-209187144000000L));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusHours((-19441661));
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.year();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (byte) 100);
        mutableDateTime7.addMonths(19442);
        org.joda.time.DateTime dateTime10 = mutableDateTime7.toDateTime();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime7.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField12 = mutableDateTime7.getRoundingField();
        mutableDateTime7.addMonths(2);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime7.dayOfYear();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNull(dateTimeField12);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        boolean boolean13 = offsetDateTimeField3.isLeap((long) 19435);
        long long15 = offsetDateTimeField3.roundCeiling((long) 38921);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1123200000L + "'", long15 == 1123200000L);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
//        org.joda.time.Instant instant4 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.MutableDateTime mutableDateTime6 = instant4.toMutableDateTime(chronology5);
//        int int7 = mutableDateTime6.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfCentury(0);
//        mutableDateTime6.setDate((org.joda.time.ReadableInstant) dateTime10);
//        int int14 = mutableDateTime6.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime6.toMutableDateTime();
//        mutableDateTime6.setMinuteOfDay((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone19);
//        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime23 = dateTime20.withTimeAtStartOfDay();
//        long long24 = dateTime23.getMillis();
//        long long25 = dateTime23.getMillis();
//        org.joda.time.DateTime dateTime27 = dateTime23.plusWeeks(323);
//        org.joda.time.DateTime dateTime29 = dateTime27.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime31 = dateTime27.withYear(4);
//        org.joda.time.DateTime.Property property32 = dateTime27.hourOfDay();
//        int int33 = mutableDateTime6.compareTo((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField35 = julianChronology34.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 10);
//        long long40 = offsetDateTimeField37.add((long) 1, (long) (short) -1);
//        long long42 = offsetDateTimeField37.roundFloor((long) 3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField37.getType();
//        java.lang.Object obj44 = null;
//        boolean boolean45 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFieldType43, obj44);
//        mutableDateTime6.set(dateTimeFieldType43, 324);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType43, 48284);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 64146 + "'", int14 == 64146);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-31535999999L) + "'", long40 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-30412800000L) + "'", long42 == (-30412800000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((-19448));
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.withPeriodAdded(readablePeriod7, 1);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        long long17 = offsetDateTimeField14.add((long) 1, (long) (short) -1);
        long long19 = offsetDateTimeField14.roundFloor((long) 3);
        long long22 = offsetDateTimeField14.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14);
        java.util.Locale locale27 = null;
        java.lang.String str28 = delegatedDateTimeField25.getAsText(19438, locale27);
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 10);
        long long35 = offsetDateTimeField32.add((long) 1, (long) (short) -1);
        long long37 = offsetDateTimeField32.roundFloor((long) 3);
        long long40 = offsetDateTimeField32.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, (int) (short) 100);
        long long45 = offsetDateTimeField32.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant46 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.MutableDateTime mutableDateTime48 = instant46.toMutableDateTime(chronology47);
        int int49 = mutableDateTime48.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone51);
        org.joda.time.DateTime dateTime54 = dateTime52.withYearOfCentury(0);
        mutableDateTime48.setDate((org.joda.time.ReadableInstant) dateTime52);
        org.joda.time.DateTime dateTime57 = dateTime52.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime60 = dateTime57.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod61 = null;
        org.joda.time.DateTime dateTime63 = dateTime60.withPeriodAdded(readablePeriod61, 0);
        org.joda.time.LocalDateTime localDateTime64 = dateTime63.toLocalDateTime();
        java.util.Locale locale65 = null;
        java.lang.String str66 = offsetDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDateTime64, locale65);
        int int67 = delegatedDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localDateTime64);
        boolean boolean69 = delegatedDateTimeField25.isLeap((long) 23);
        long long72 = delegatedDateTimeField25.getDifferenceAsLong((long) 19440, 0L);
        boolean boolean73 = delegatedDateTimeField25.isLenient();
        org.joda.time.DateTimeFieldType dateTimeFieldType74 = delegatedDateTimeField25.getType();
        boolean boolean75 = dateTime4.isSupported(dateTimeFieldType74);
        org.joda.time.DateTime.Property property76 = dateTime4.weekyear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-31535999999L) + "'", long17 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-30412800000L) + "'", long19 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 599616000001L + "'", long22 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "19438" + "'", str28.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-31535999999L) + "'", long35 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-30412800000L) + "'", long37 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 599616000001L + "'", long40 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3155760000003L + "'", long45 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant46);
        org.junit.Assert.assertNotNull(mutableDateTime48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localDateTime64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1968" + "'", str66.equals("1968"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 292273002 + "'", int67 == 292273002);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(property76);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        boolean boolean13 = offsetDateTimeField3.isLeap((long) 19435);
        long long15 = offsetDateTimeField3.roundHalfCeiling(30412800001L);
        long long18 = offsetDateTimeField3.getDifferenceAsLong((long) 48283, 0L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 32659200000L + "'", long15 == 32659200000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = julianChronology0.hours();
//        org.joda.time.DurationField durationField2 = julianChronology0.years();
//        org.joda.time.DurationField durationField3 = julianChronology0.seconds();
//        org.joda.time.ReadablePartial readablePartial4 = null;
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 10);
//        long long11 = offsetDateTimeField8.add((long) 1, (long) (short) -1);
//        long long13 = offsetDateTimeField8.roundFloor((long) 3);
//        long long16 = offsetDateTimeField8.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8);
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = delegatedDateTimeField19.getAsShortText(readablePartial20, 19438, locale22);
//        org.joda.time.DurationField durationField24 = delegatedDateTimeField19.getDurationField();
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone26 = julianChronology25.getZone();
//        java.lang.Object obj27 = null;
//        boolean boolean28 = julianChronology25.equals(obj27);
//        org.joda.time.DateTimeField dateTimeField29 = julianChronology25.weekyear();
//        org.joda.time.Instant instant30 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.MutableDateTime mutableDateTime32 = instant30.toMutableDateTime(chronology31);
//        int int33 = mutableDateTime32.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone35);
//        org.joda.time.DateTime dateTime38 = dateTime36.withYearOfCentury(0);
//        mutableDateTime32.setDate((org.joda.time.ReadableInstant) dateTime36);
//        org.joda.time.DateTime dateTime41 = dateTime36.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime44 = dateTime41.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod45 = null;
//        org.joda.time.DateTime dateTime47 = dateTime44.withPeriodAdded(readablePeriod45, 0);
//        org.joda.time.LocalDateTime localDateTime48 = dateTime47.toLocalDateTime();
//        long long50 = julianChronology25.set((org.joda.time.ReadablePartial) localDateTime48, 0L);
//        int[] intArray56 = new int[] { (byte) 0, 9, 20, '#', 19439 };
//        int int57 = delegatedDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) localDateTime48, intArray56);
//        try {
//            julianChronology0.validate(readablePartial4, intArray56);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-31535999999L) + "'", long11 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-30412800000L) + "'", long13 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 599616000001L + "'", long16 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "19438" + "'", str23.equals("19438"));
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(instant30);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(localDateTime48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-59356800090L) + "'", long50 == (-59356800090L));
//        org.junit.Assert.assertNotNull(intArray56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-292269045) + "'", int57 == (-292269045));
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.dayOfMonth();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology5.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField8, (int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.clockhourOfHalfday();
//        java.lang.String str15 = buddhistChronology13.toString();
//        java.util.Locale locale16 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology13, locale16);
//        java.util.Locale locale18 = dateTimeParserBucket17.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter11.withLocale(locale18);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 1970, (org.joda.time.Chronology) julianChronology1, locale18);
//        boolean boolean22 = dateTimeParserBucket20.restoreState((java.lang.Object) 378038692445L);
//        dateTimeParserBucket20.setPivotYear((java.lang.Integer) 19438);
//        java.lang.Integer int25 = dateTimeParserBucket20.getPivotYear();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BuddhistChronology[UTC]" + "'", str15.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 19438 + "'", int25.equals(19438));
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZone(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add(20);
        try {
            mutableDateTime8.setSecondOfMinute(465);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 465 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
        org.joda.time.DateTime dateTime11 = dateTime9.withMillis((long) 4);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology13 = gregorianChronology12.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology12.getZone();
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime9, (org.joda.time.Chronology) gregorianChronology12);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((-10), (int) (short) -1, 0, 804, 804, (org.joda.time.Chronology) gregorianChronology12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 804 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 10);
        long long13 = offsetDateTimeField10.add((long) 1, (long) (short) -1);
        long long15 = offsetDateTimeField10.roundFloor((long) 3);
        long long18 = offsetDateTimeField10.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10);
        java.util.Locale locale23 = null;
        java.lang.String str24 = delegatedDateTimeField21.getAsText(19438, locale23);
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 10);
        long long31 = offsetDateTimeField28.add((long) 1, (long) (short) -1);
        long long33 = offsetDateTimeField28.roundFloor((long) 3);
        long long36 = offsetDateTimeField28.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField28, (int) (short) 100);
        long long41 = offsetDateTimeField28.add((long) 3, (long) (byte) 100);
        org.joda.time.Instant instant42 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.MutableDateTime mutableDateTime44 = instant42.toMutableDateTime(chronology43);
        int int45 = mutableDateTime44.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone47);
        org.joda.time.DateTime dateTime50 = dateTime48.withYearOfCentury(0);
        mutableDateTime44.setDate((org.joda.time.ReadableInstant) dateTime48);
        org.joda.time.DateTime dateTime53 = dateTime48.minusWeeks((int) (short) 100);
        org.joda.time.DateTime dateTime56 = dateTime53.withDurationAdded((long) (short) 100, (int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.DateTime dateTime59 = dateTime56.withPeriodAdded(readablePeriod57, 0);
        org.joda.time.LocalDateTime localDateTime60 = dateTime59.toLocalDateTime();
        java.util.Locale locale61 = null;
        java.lang.String str62 = offsetDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDateTime60, locale61);
        int int63 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDateTime60);
        long long65 = delegatedDateTimeField21.remainder(1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = delegatedDateTimeField21.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType66, "hi!");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException68);
        java.lang.Number number70 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"\" for Coordinated Universal Time is not supported"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31535999999L) + "'", long13 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-30412800000L) + "'", long15 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 599616000001L + "'", long18 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "19438" + "'", str24.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31535999999L) + "'", long31 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-30412800000L) + "'", long33 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 599616000001L + "'", long36 == 599616000001L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 3155760000003L + "'", long41 == 3155760000003L);
        org.junit.Assert.assertNotNull(instant42);
        org.junit.Assert.assertNotNull(mutableDateTime44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localDateTime60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1968" + "'", str62.equals("1968"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 292273002 + "'", int63 == 292273002);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 30412800001L + "'", long65 == 30412800001L);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertNull(number70);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (byte) 1);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getCenturyOfEra();
//        int int5 = mutableDateTime3.getYearOfCentury();
//        mutableDateTime3.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime3.copy();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = mutableDateTime3.toDateTime(dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) ' ');
//        java.util.Date date13 = dateTime10.toDate();
//        boolean boolean15 = dateTime10.isEqual(10L);
//        org.joda.time.DateTime dateTime16 = dateTime10.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology17.getZone();
//        java.lang.Object obj19 = null;
//        boolean boolean20 = julianChronology17.equals(obj19);
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology17.weekyear();
//        org.joda.time.Instant instant22 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = instant22.toMutableDateTime(chronology23);
//        int int25 = mutableDateTime24.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone27);
//        org.joda.time.DateTime dateTime30 = dateTime28.withYearOfCentury(0);
//        mutableDateTime24.setDate((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime dateTime33 = dateTime28.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.DateTime dateTime39 = dateTime36.withPeriodAdded(readablePeriod37, 0);
//        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
//        long long42 = julianChronology17.set((org.joda.time.ReadablePartial) localDateTime40, 0L);
//        org.joda.time.DateTime dateTime43 = dateTime10.withFields((org.joda.time.ReadablePartial) localDateTime40);
//        java.lang.String str44 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 70 + "'", int5 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(instant22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(localDateTime40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-59356800090L) + "'", long42 == (-59356800090L));
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "000000Z" + "'", str44.equals("000000Z"));
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2019-06-12T05:24:11.615-07:00", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("-372", 80672, 19440, 804, '4', (int) (short) 10, 100, 0, true, 1979);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        illegalFieldValueException2.prependMessage("Jan 31, 1968 3:59:59 PM");
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        mutableDateTime2.addYears((int) '4');
//        mutableDateTime2.addMinutes((int) (byte) 0);
//        mutableDateTime2.setSecondOfDay(19434);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        mutableDateTime2.setChronology((org.joda.time.Chronology) buddhistChronology10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property14 = dateTime13.secondOfMinute();
//        org.joda.time.DateTime dateTime16 = property14.addToCopy((long) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime16.minusWeeks((-19448));
//        org.joda.time.DateTime dateTime20 = dateTime18.withCenturyOfEra((int) '#');
//        org.joda.time.DateTime dateTime22 = dateTime18.plusSeconds(292273002);
//        boolean boolean23 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) dateTime22);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
//        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
//        long long26 = offsetDateTimeField21.roundFloor((long) 3);
//        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
//        long long34 = offsetDateTimeField21.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology36 = null;
//        org.joda.time.MutableDateTime mutableDateTime37 = instant35.toMutableDateTime(chronology36);
//        int int38 = mutableDateTime37.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone40);
//        org.joda.time.DateTime dateTime43 = dateTime41.withYearOfCentury(0);
//        mutableDateTime37.setDate((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTime dateTime46 = dateTime41.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 0);
//        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
//        java.util.Locale locale54 = null;
//        java.lang.String str55 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime53, locale54);
//        int int56 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime53);
//        boolean boolean58 = delegatedDateTimeField14.isLeap((long) 23);
//        long long61 = delegatedDateTimeField14.getDifferenceAsLong((long) 20, (long) 19441661);
//        long long63 = delegatedDateTimeField14.roundHalfFloor((long) (byte) 10);
//        java.lang.String str64 = delegatedDateTimeField14.toString();
//        org.joda.time.chrono.JulianChronology julianChronology66 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField67 = julianChronology66.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField69 = new org.joda.time.field.OffsetDateTimeField(dateTimeField67, 10);
//        long long72 = offsetDateTimeField69.add((long) 1, (long) (short) -1);
//        long long74 = offsetDateTimeField69.roundFloor((long) 3);
//        long long76 = offsetDateTimeField69.roundHalfCeiling((long) (short) 0);
//        long long78 = offsetDateTimeField69.roundHalfFloor(3062188800000L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter80 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology82 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField83 = buddhistChronology82.clockhourOfHalfday();
//        java.lang.String str84 = buddhistChronology82.toString();
//        java.util.Locale locale85 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket86 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology82, locale85);
//        java.util.Locale locale87 = dateTimeParserBucket86.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter88 = dateTimeFormatter80.withLocale(locale87);
//        java.lang.String str89 = offsetDateTimeField69.getAsText((-1), locale87);
//        java.lang.String str90 = delegatedDateTimeField14.getAsText((-57565816L), locale87);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3155760000003L + "'", long34 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant35);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDateTime53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1968" + "'", str55.equals("1968"));
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292273002 + "'", int56 == 292273002);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1123200000L + "'", long63 == 1123200000L);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "DateTimeField[year]" + "'", str64.equals("DateTimeField[year]"));
//        org.junit.Assert.assertNotNull(julianChronology66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-31535999999L) + "'", long72 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-30412800000L) + "'", long74 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1123200000L + "'", long76 == 1123200000L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 3062188800000L + "'", long78 == 3062188800000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter80);
//        org.junit.Assert.assertNotNull(buddhistChronology82);
//        org.junit.Assert.assertNotNull(dateTimeField83);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "BuddhistChronology[UTC]" + "'", str84.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale87);
//        org.junit.Assert.assertNotNull(dateTimeFormatter88);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "-1" + "'", str89.equals("-1"));
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "1979" + "'", str90.equals("1979"));
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("80669");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"80669\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(30412800001L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.Instant instant4 = instant1.toInstant();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant7 = instant4.withDurationAdded(readableDuration5, 589);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
//        org.joda.time.DateTime dateTime7 = dateTime6.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded((long) 15, 6);
//        org.joda.time.Instant instant12 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = instant12.toMutableDateTime(chronology13);
//        int int15 = mutableDateTime14.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury(0);
//        mutableDateTime14.setDate((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime23 = dateTime18.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, 0);
//        org.joda.time.LocalDateTime localDateTime30 = dateTime29.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
//        org.joda.time.DateTimeZone dateTimeZone34 = dateTime33.getZone();
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime29, dateTimeZone34);
//        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
//        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime(1L, dateTimeZone34);
//        org.joda.time.MutableDateTime mutableDateTime38 = dateTime6.toMutableDateTime(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(julianChronology36);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField3.getType();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime12.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = dateTime14.withMillis((long) 4);
//        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
//        org.joda.time.DateTime dateTime19 = dateTime16.withMillisOfDay(19434);
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology20.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 10);
//        long long26 = offsetDateTimeField23.add((long) 1, (long) (short) -1);
//        long long28 = offsetDateTimeField23.roundFloor((long) 3);
//        long long31 = offsetDateTimeField23.add((long) (short) 1, (long) 19);
//        long long33 = offsetDateTimeField23.roundHalfEven((long) 23);
//        long long36 = offsetDateTimeField23.add(3061065600020L, (long) 100);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone38);
//        org.joda.time.DateTime dateTime41 = dateTime39.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTime dateTime43 = dateTime41.toDateTime(dateTimeZone42);
//        org.joda.time.Instant instant44 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology45 = null;
//        org.joda.time.MutableDateTime mutableDateTime46 = instant44.toMutableDateTime(chronology45);
//        int int47 = mutableDateTime46.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone49);
//        org.joda.time.DateTime dateTime52 = dateTime50.withYearOfCentury(0);
//        mutableDateTime46.setDate((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTime dateTime55 = dateTime50.minusWeeks((int) (short) 100);
//        org.joda.time.Chronology chronology56 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime dateTime57 = dateTime41.withChronology(chronology56);
//        org.joda.time.TimeOfDay timeOfDay58 = dateTime41.toTimeOfDay();
//        int int59 = offsetDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay58);
//        org.joda.time.DateTime dateTime60 = dateTime16.withFields((org.joda.time.ReadablePartial) timeOfDay58);
//        int[] intArray68 = new int[] { 11, 38940, 38940673, 57600, 4, 80674 };
//        try {
//            int[] intArray70 = offsetDateTimeField3.add((org.joda.time.ReadablePartial) timeOfDay58, (-28800000), intArray68, 48276);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -28800000");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31535999999L) + "'", long26 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-30412800000L) + "'", long28 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 599616000001L + "'", long31 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1123200000L + "'", long33 == 1123200000L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 6216825600020L + "'", long36 == 6216825600020L);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(instant44);
//        org.junit.Assert.assertNotNull(mutableDateTime46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(chronology56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(timeOfDay58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 292273002 + "'", int59 == 292273002);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(intArray68);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra(19437, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
//        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
//        long long26 = offsetDateTimeField21.roundFloor((long) 3);
//        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
//        long long34 = offsetDateTimeField21.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology36 = null;
//        org.joda.time.MutableDateTime mutableDateTime37 = instant35.toMutableDateTime(chronology36);
//        int int38 = mutableDateTime37.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone40);
//        org.joda.time.DateTime dateTime43 = dateTime41.withYearOfCentury(0);
//        mutableDateTime37.setDate((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTime dateTime46 = dateTime41.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 0);
//        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
//        java.util.Locale locale54 = null;
//        java.lang.String str55 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime53, locale54);
//        int int56 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime53);
//        boolean boolean58 = delegatedDateTimeField14.isLeap((long) 23);
//        long long61 = delegatedDateTimeField14.getDifferenceAsLong((long) 19440, 0L);
//        boolean boolean63 = delegatedDateTimeField14.isLeap((long) 57619);
//        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property66 = dateTime65.secondOfMinute();
//        org.joda.time.DateTime dateTime68 = property66.addToCopy((long) (short) 10);
//        org.joda.time.TimeOfDay timeOfDay69 = dateTime68.toTimeOfDay();
//        int[] intArray71 = null;
//        try {
//            int[] intArray73 = delegatedDateTimeField14.add((org.joda.time.ReadablePartial) timeOfDay69, (-292273003), intArray71, 35356);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3155760000003L + "'", long34 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant35);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDateTime53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1968" + "'", str55.equals("1968"));
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292273002 + "'", int56 == 292273002);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertNotNull(timeOfDay69);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        int int19 = skipUndoDateTimeField17.get((long) 19438);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 323);
//        org.joda.time.DurationField durationField22 = offsetDateTimeField21.getLeapDurationField();
//        int int24 = offsetDateTimeField21.getMinimumValue((long) 0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNull(durationField22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 324 + "'", int24 == 324);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19438);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
//        org.joda.time.Instant instant4 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.MutableDateTime mutableDateTime6 = instant4.toMutableDateTime(chronology5);
//        int int7 = mutableDateTime6.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        mutableDateTime6.setZone(dateTimeZone8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime12 = property10.add((-1));
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
//        int int15 = property13.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property13.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType16, 80674);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendMinuteOfDay(5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder19.appendFractionOfSecond(0, (int) '#');
//        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatterBuilder24.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder18.appendOptional(dateTimeParser25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeParser25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        int int9 = property6.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 999 + "'", int9 == 999);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
//        java.util.Date date12 = dateTime9.toDate();
//        boolean boolean14 = dateTime9.isEqual(10L);
//        org.joda.time.DateTime dateTime15 = dateTime9.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology16.getZone();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = julianChronology16.equals(obj18);
//        org.joda.time.DateTimeField dateTimeField20 = julianChronology16.weekyear();
//        org.joda.time.Instant instant21 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.MutableDateTime mutableDateTime23 = instant21.toMutableDateTime(chronology22);
//        int int24 = mutableDateTime23.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone26);
//        org.joda.time.DateTime dateTime29 = dateTime27.withYearOfCentury(0);
//        mutableDateTime23.setDate((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTime dateTime32 = dateTime27.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime35 = dateTime32.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod36 = null;
//        org.joda.time.DateTime dateTime38 = dateTime35.withPeriodAdded(readablePeriod36, 0);
//        org.joda.time.LocalDateTime localDateTime39 = dateTime38.toLocalDateTime();
//        long long41 = julianChronology16.set((org.joda.time.ReadablePartial) localDateTime39, 0L);
//        org.joda.time.DateTime dateTime42 = dateTime9.withFields((org.joda.time.ReadablePartial) localDateTime39);
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone44 = gJChronology43.getZone();
//        org.joda.time.DateTime dateTime45 = dateTime42.toDateTime(dateTimeZone44);
//        org.joda.time.Instant instant46 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.MutableDateTime mutableDateTime48 = instant46.toMutableDateTime(chronology47);
//        int int49 = mutableDateTime48.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone51);
//        org.joda.time.DateTime dateTime54 = dateTime52.withYearOfCentury(0);
//        mutableDateTime48.setDate((org.joda.time.ReadableInstant) dateTime52);
//        int int56 = mutableDateTime48.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property57 = mutableDateTime48.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime59 = property57.addWrapField((int) (short) 10);
//        mutableDateTime59.addWeekyears(0);
//        int int62 = dateTimeZone44.getOffset((org.joda.time.ReadableInstant) mutableDateTime59);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(instant21);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(localDateTime39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-59356800090L) + "'", long41 == (-59356800090L));
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(instant46);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(mutableDateTime59);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        int int19 = skipUndoDateTimeField17.get((long) 19438);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 323);
//        org.joda.time.DurationField durationField22 = offsetDateTimeField21.getLeapDurationField();
//        boolean boolean24 = offsetDateTimeField21.isLeap((long) (-20));
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.year();
//        org.joda.time.DateTimeField dateTimeField29 = julianChronology27.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology27.dayOfMonth();
//        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField32 = julianChronology31.year();
//        org.joda.time.DateTimeField dateTimeField33 = julianChronology31.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField34 = julianChronology31.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology27, dateTimeField34, (int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField40 = buddhistChronology39.clockhourOfHalfday();
//        java.lang.String str41 = buddhistChronology39.toString();
//        java.util.Locale locale42 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket43 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology39, locale42);
//        java.util.Locale locale44 = dateTimeParserBucket43.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = dateTimeFormatter37.withLocale(locale44);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket((long) 1970, (org.joda.time.Chronology) julianChronology27, locale44);
//        java.lang.String str47 = offsetDateTimeField21.getAsText(1970L, locale44);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNull(durationField22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(julianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "BuddhistChronology[UTC]" + "'", str41.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "325" + "'", str47.equals("325"));
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        int int2 = dateTimeFormatter0.getDefaultYear();
        boolean boolean3 = dateTimeFormatter0.isPrinter();
        java.util.Locale locale4 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(locale4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfMonth();
        int int6 = property5.getLeapAmount();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property5.getFieldType();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField3 = property2.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.seconds();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, 0);
//        org.joda.time.DateTime.Property property18 = dateTime14.weekyear();
//        int int19 = dateTime14.getEra();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField3.getType();
        long long12 = offsetDateTimeField3.getDifferenceAsLong(100L, 30412800001L);
        org.joda.time.DurationField durationField13 = offsetDateTimeField3.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
        java.lang.Class<?> wildcardClass15 = dateTimeField14.getClass();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.Object obj2 = null;
        boolean boolean3 = julianChronology0.equals(obj2);
        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray8 = julianChronology0.get(readablePeriod6, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add(20);
//        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundCeiling();
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.yearOfEra();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add(20);
//        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundCeiling();
//        org.joda.time.MutableDateTime mutableDateTime10 = property6.getMutableDateTime();
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = julianChronology13.equals(obj15);
//        org.joda.time.DateTimeField dateTimeField17 = julianChronology13.weekyear();
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
//        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
//        long long26 = offsetDateTimeField21.roundFloor((long) 3);
//        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = delegatedDateTimeField32.getAsText(19438, locale34);
//        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField37 = julianChronology36.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 10);
//        long long42 = offsetDateTimeField39.add((long) 1, (long) (short) -1);
//        long long44 = offsetDateTimeField39.roundFloor((long) 3);
//        long long47 = offsetDateTimeField39.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField39, (int) (short) 100);
//        long long52 = offsetDateTimeField39.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant53 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology54 = null;
//        org.joda.time.MutableDateTime mutableDateTime55 = instant53.toMutableDateTime(chronology54);
//        int int56 = mutableDateTime55.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone58);
//        org.joda.time.DateTime dateTime61 = dateTime59.withYearOfCentury(0);
//        mutableDateTime55.setDate((org.joda.time.ReadableInstant) dateTime59);
//        org.joda.time.DateTime dateTime64 = dateTime59.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime67 = dateTime64.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod68 = null;
//        org.joda.time.DateTime dateTime70 = dateTime67.withPeriodAdded(readablePeriod68, 0);
//        org.joda.time.LocalDateTime localDateTime71 = dateTime70.toLocalDateTime();
//        java.util.Locale locale72 = null;
//        java.lang.String str73 = offsetDateTimeField39.getAsText((org.joda.time.ReadablePartial) localDateTime71, locale72);
//        int int74 = delegatedDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDateTime71);
//        boolean boolean76 = delegatedDateTimeField32.isLeap((long) 23);
//        long long79 = delegatedDateTimeField32.getDifferenceAsLong((long) 19440, 0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter81 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology83 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField84 = buddhistChronology83.clockhourOfHalfday();
//        java.lang.String str85 = buddhistChronology83.toString();
//        java.util.Locale locale86 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket87 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology83, locale86);
//        java.util.Locale locale88 = dateTimeParserBucket87.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter89 = dateTimeFormatter81.withLocale(locale88);
//        java.lang.String str90 = delegatedDateTimeField32.getAsShortText((-1), locale88);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket93 = new org.joda.time.format.DateTimeParserBucket(551468970000000L, (org.joda.time.Chronology) julianChronology13, locale88, (java.lang.Integer) 2000, 38917);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime94 = property6.set("2079", locale88);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2079 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "19438" + "'", str35.equals("19438"));
//        org.junit.Assert.assertNotNull(julianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-31535999999L) + "'", long42 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-30412800000L) + "'", long44 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 599616000001L + "'", long47 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 3155760000003L + "'", long52 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant53);
//        org.junit.Assert.assertNotNull(mutableDateTime55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(localDateTime71);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "1968" + "'", str73.equals("1968"));
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 292273002 + "'", int74 == 292273002);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter81);
//        org.junit.Assert.assertNotNull(buddhistChronology83);
//        org.junit.Assert.assertNotNull(dateTimeField84);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "BuddhistChronology[UTC]" + "'", str85.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale88);
//        org.junit.Assert.assertNotNull(dateTimeFormatter89);
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "-1" + "'", str90.equals("-1"));
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfHalfday();
//        java.lang.String str2 = buddhistChronology0.toString();
//        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology3);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        java.lang.String str19 = skipUndoDateTimeField17.getAsShortText(6216825600020L);
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        int[] intArray24 = new int[] { 48280, (byte) 0, 1901 };
//        int int25 = skipUndoDateTimeField17.getMinimumValue(readablePartial20, intArray24);
//        long long27 = skipUndoDateTimeField17.remainder((long) 80673);
//        int int29 = skipUndoDateTimeField17.get((long) 48284254);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 673L + "'", long27 == 673L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 48284 + "'", int29 == 48284);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        org.joda.time.Instant instant16 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = instant16.toMutableDateTime(chronology17);
//        int int19 = mutableDateTime18.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone21);
//        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury(0);
//        mutableDateTime18.setDate((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime dateTime27 = dateTime22.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.withPeriodAdded(readablePeriod31, 0);
//        org.joda.time.LocalDateTime localDateTime34 = dateTime33.toLocalDateTime();
//        boolean boolean35 = dateTimeZone15.isLocalDateTimeGap(localDateTime34);
//        org.joda.time.DateTime dateTime36 = dateTime11.withZone(dateTimeZone15);
//        int int37 = dateTime11.getYearOfCentury();
//        boolean boolean38 = dateTime11.isAfterNow();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(localDateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 70 + "'", int37 == 70);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[America/Los_...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) ' ', 19441);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendFractionOfDay((int) '4', (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendMillisOfDay(48280);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder5.appendFractionOfSecond(19441, (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (byte) -1, false);
//        org.joda.time.Instant instant7 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = instant7.toMutableDateTime(chronology8);
//        int int10 = mutableDateTime9.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        mutableDateTime9.setZone(dateTimeZone11);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime15 = property13.add((-1));
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = property16.getField();
//        int int18 = property16.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType19, 0, 19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimePrinter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.DateMidnight dateMidnight4 = dateTime1.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 19441661, chronology14);
        org.joda.time.DateTime dateTime16 = dateMidnight4.toDateTime(chronology14);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.yearOfEra();
//        int int9 = property8.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        boolean boolean16 = offsetDateTimeField13.isLenient();
        boolean boolean18 = offsetDateTimeField13.isLeap((long) (-28800000));
        long long20 = offsetDateTimeField13.roundFloor((long) 19);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-30412800000L) + "'", long20 == (-30412800000L));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfMonth();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(0);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillis((long) 4);
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        boolean boolean15 = property5.equals((java.lang.Object) dateTime14);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime14);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology16);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        mutableDateTime2.addYears((int) '4');
//        mutableDateTime2.addMinutes((int) (byte) 0);
//        mutableDateTime2.setSecondOfDay(19434);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.millisOfSecond();
//        org.joda.time.Interval interval11 = property10.toInterval();
//        org.joda.time.MutableDateTime mutableDateTime12 = property10.roundFloor();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(interval11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) ' ', 19441);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "BuddhistChronology[America/Los_Angeles]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendFraction(dateTimeFieldType13, 19434, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder8.appendLiteral('#');
        boolean boolean21 = dateTimeFormatterBuilder8.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.year();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology6.dayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.year();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology11.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology11.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology11.dayOfWeek();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology6, dateTimeField16);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(0, 539, 0, 539, 0, 0, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 539 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        int int19 = skipUndoDateTimeField17.get((long) 3);
//        int int20 = skipUndoDateTimeField17.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendClockhourOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(38916, (-1), 38914, 38920, 19452, 9, 465);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 38920 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        int int19 = skipUndoDateTimeField17.get((long) 19438);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 323);
//        org.joda.time.DurationField durationField22 = offsetDateTimeField21.getLeapDurationField();
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.year();
//        org.joda.time.DateTimeField dateTimeField26 = julianChronology24.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField27 = julianChronology24.dayOfMonth();
//        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = julianChronology28.year();
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology28.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField31 = julianChronology28.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology24, dateTimeField31, (int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.clockhourOfHalfday();
//        java.lang.String str38 = buddhistChronology36.toString();
//        java.util.Locale locale39 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket40 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology36, locale39);
//        java.util.Locale locale41 = dateTimeParserBucket40.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = dateTimeFormatter34.withLocale(locale41);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket43 = new org.joda.time.format.DateTimeParserBucket((long) 1970, (org.joda.time.Chronology) julianChronology24, locale41);
//        int int44 = offsetDateTimeField21.getMaximumTextLength(locale41);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology46 = gregorianChronology45.withUTC();
//        org.joda.time.Instant instant47 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology48 = null;
//        org.joda.time.MutableDateTime mutableDateTime49 = instant47.toMutableDateTime(chronology48);
//        int int50 = mutableDateTime49.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        mutableDateTime49.setZone(dateTimeZone51);
//        org.joda.time.MutableDateTime.Property property53 = mutableDateTime49.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime55 = property53.add((-1));
//        org.joda.time.MutableDateTime.Property property56 = mutableDateTime55.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField57 = property56.getField();
//        int int58 = property56.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property56.getFieldType();
//        org.joda.time.DateTimeField dateTimeField60 = property56.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology45, dateTimeField60, 19448);
//        int int64 = skipUndoDateTimeField62.get((long) 19438);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField62, 323);
//        org.joda.time.DateTimeZone dateTimeZone68 = null;
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone68);
//        org.joda.time.DateTimeZone dateTimeZone70 = dateTime69.getZone();
//        org.joda.time.DateTime.Property property71 = dateTime69.minuteOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology73 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField74 = buddhistChronology73.clockhourOfHalfday();
//        java.lang.String str75 = buddhistChronology73.toString();
//        java.util.Locale locale76 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket77 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology73, locale76);
//        java.util.Locale locale78 = dateTimeParserBucket77.getLocale();
//        java.lang.String str79 = property71.getAsText(locale78);
//        int int80 = skipUndoDateTimeField62.getMaximumTextLength(locale78);
//        int int81 = offsetDateTimeField21.getMaximumShortTextLength(locale78);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField21, 2019, 19439435, 64144);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for secondOfDay must be in the range [19439435,64144]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNull(durationField22);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(julianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "BuddhistChronology[UTC]" + "'", str38.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 5 + "'", int44 == 5);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(instant47);
//        org.junit.Assert.assertNotNull(mutableDateTime49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(mutableDateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 20 + "'", int64 == 20);
//        org.junit.Assert.assertNotNull(dateTimeZone70);
//        org.junit.Assert.assertNotNull(property71);
//        org.junit.Assert.assertNotNull(buddhistChronology73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "BuddhistChronology[UTC]" + "'", str75.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "0" + "'", str79.equals("0"));
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 5 + "'", int80 == 5);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 5 + "'", int81 == 5);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.parse("-372", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-372\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
//        boolean boolean17 = offsetDateTimeField13.isLeap((long) 19435);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond(19438);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfYear(1979);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfSecond((int) ' ', 19441);
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField30.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "BuddhistChronology[America/Los_Angeles]");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder26.appendFraction(dateTimeFieldType31, 19434, 2000);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType31, 19442);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField38);
//        int int40 = remainderDateTimeField39.getMaximumValue();
//        long long42 = remainderDateTimeField39.roundHalfCeiling(3155760000003L);
//        org.joda.time.Instant instant43 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology44 = null;
//        org.joda.time.MutableDateTime mutableDateTime45 = instant43.toMutableDateTime(chronology44);
//        int int46 = mutableDateTime45.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        mutableDateTime45.setZone(dateTimeZone47);
//        org.joda.time.MutableDateTime.Property property49 = mutableDateTime45.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime51 = property49.add((-1));
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime51.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField53 = property52.getField();
//        org.joda.time.MutableDateTime mutableDateTime54 = property52.roundHalfFloor();
//        mutableDateTime54.setMinuteOfDay(4);
//        org.joda.time.MutableDateTime.Property property57 = mutableDateTime54.weekyear();
//        boolean boolean58 = mutableDateTime54.isEqualNow();
//        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = julianChronology59.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType63 = offsetDateTimeField62.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType63, "BuddhistChronology[America/Los_Angeles]");
//        org.joda.time.MutableDateTime.Property property66 = mutableDateTime54.property(dateTimeFieldType63);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField67 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField39, dateTimeFieldType63);
//        long long69 = remainderDateTimeField39.roundFloor((long) 38920);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19441 + "'", int40 == 19441);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3156883200000L + "'", long42 == 3156883200000L);
//        org.junit.Assert.assertNotNull(instant43);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(mutableDateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(mutableDateTime54);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(julianChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeFieldType63);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-30412800000L) + "'", long69 == (-30412800000L));
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundHalfCeiling();
//        org.joda.time.MutableDateTime mutableDateTime10 = property6.roundHalfFloor();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2019-06-12T05:24:11.615-07:00", false);
        long long5 = dateTimeZone3.convertUTCToLocal((long) 19438);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 19438L + "'", long5 == 19438L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
//        java.lang.String str4 = dateTimeFormatter0.print((long) 19441);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T000019Z" + "'", str4.equals("1970001T000019Z"));
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
//        java.util.Date date12 = dateTime9.toDate();
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
//        long long19 = offsetDateTimeField16.add((long) 1, (long) (short) -1);
//        long long21 = offsetDateTimeField16.roundFloor((long) 3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField16.getType();
//        org.joda.time.DateTime dateTime24 = dateTime9.withField(dateTimeFieldType22, (int) (short) 0);
//        org.joda.time.DateTime dateTime26 = dateTime9.minusWeeks(19438);
//        org.joda.time.DateTime.Property property27 = dateTime26.dayOfYear();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31535999999L) + "'", long19 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-30412800000L) + "'", long21 == (-30412800000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfHalfday();
//        java.lang.String str2 = buddhistChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getShortName((-1L), locale8);
//        org.joda.time.Chronology chronology10 = buddhistChronology0.withZone(dateTimeZone6);
//        long long13 = dateTimeZone6.convertLocalToUTC((long) 1901, true);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1901L + "'", long13 == 1901L);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(1900, 80672, 57600, 64144, (int) '4', (-19441661), 19442);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 64144 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfFloor();
//        mutableDateTime11.setMinuteOfDay(4);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime11.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime15 = property14.roundHalfFloor();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = delegatedDateTimeField14.getAsShortText(readablePartial15, 19438, locale17);
//        boolean boolean19 = delegatedDateTimeField14.isLenient();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.clockhourOfHalfday();
//        java.lang.String str25 = buddhistChronology23.toString();
//        java.util.Locale locale26 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology23, locale26);
//        java.util.Locale locale28 = dateTimeParserBucket27.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter21.withLocale(locale28);
//        java.lang.String str30 = delegatedDateTimeField14.getAsShortText(10, locale28);
//        long long32 = delegatedDateTimeField14.roundFloor(19402L);
//        long long34 = delegatedDateTimeField14.roundCeiling(38L);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "BuddhistChronology[UTC]" + "'", str25.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10" + "'", str30.equals("10"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-30412800000L) + "'", long32 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1123200000L + "'", long34 == 1123200000L);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfHour(4, 20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendMonthOfYear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter10.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.append(dateTimePrinter11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withDefaultYear(0);
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder8.append(dateTimePrinter11, dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        mutableDateTime2.addMinutes((int) (byte) 100);
//        mutableDateTime2.addMillis((-292269045));
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property20 = dateTime19.secondOfMinute();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfCeilingCopy();
//        int int22 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) dateTime21);
//        mutableDateTime2.setSecondOfDay(38917);
//        mutableDateTime2.setMillis((long) 48276);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfFloor();
//        mutableDateTime11.setMinuteOfDay(4);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime11.hourOfDay();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property14);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getCenturyOfEra();
//        int int5 = mutableDateTime3.getYearOfCentury();
//        mutableDateTime3.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime3.copy();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = mutableDateTime3.toDateTime(dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) ' ');
//        java.util.Date date13 = dateTime10.toDate();
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 10);
//        long long20 = offsetDateTimeField17.add((long) 1, (long) (short) -1);
//        long long22 = offsetDateTimeField17.roundFloor((long) 3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField17.getType();
//        org.joda.time.DateTime dateTime25 = dateTime10.withField(dateTimeFieldType23, (int) (short) 0);
//        org.joda.time.DateTime dateTime27 = dateTime10.minusWeeks(19438);
//        int int28 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime30 = dateTime10.minusHours(6);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 70 + "'", int5 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-31535999999L) + "'", long20 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-30412800000L) + "'", long22 == (-30412800000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test318");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        org.joda.time.Instant instant16 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = instant16.toMutableDateTime(chronology17);
//        int int19 = mutableDateTime18.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone21);
//        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury(0);
//        mutableDateTime18.setDate((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime dateTime27 = dateTime22.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dateTimeZone31.getName((long) (short) 10, locale33);
//        long long36 = dateTimeZone15.getMillisKeepLocal(dateTimeZone31, (long) (short) 0);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dateTimeZone31.getShortName((long) (short) 0, locale38);
//        java.lang.String str41 = dateTimeZone31.getShortName(0L);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone43);
//        org.joda.time.DateTime dateTime46 = dateTime44.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateTime dateTime48 = dateTime46.toDateTime(dateTimeZone47);
//        org.joda.time.DateTime dateTime49 = dateTime46.withLaterOffsetAtOverlap();
//        int int50 = dateTimeZone31.getOffset((org.joda.time.ReadableInstant) dateTime46);
//        org.joda.time.DateTime dateTime52 = dateTime46.plusMinutes(5);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Coordinated Universal Time" + "'", str34.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "UTC" + "'", str39.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "UTC" + "'", str41.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//        org.junit.Assert.assertNotNull(dateTime52);
//    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = delegatedDateTimeField14.getAsShortText(readablePartial15, 19438, locale17);
//        org.joda.time.DurationField durationField19 = delegatedDateTimeField14.getDurationField();
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology20.getZone();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = julianChronology20.equals(obj22);
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology20.weekyear();
//        org.joda.time.Instant instant25 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology26 = null;
//        org.joda.time.MutableDateTime mutableDateTime27 = instant25.toMutableDateTime(chronology26);
//        int int28 = mutableDateTime27.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone30);
//        org.joda.time.DateTime dateTime33 = dateTime31.withYearOfCentury(0);
//        mutableDateTime27.setDate((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime dateTime36 = dateTime31.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime39 = dateTime36.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod40 = null;
//        org.joda.time.DateTime dateTime42 = dateTime39.withPeriodAdded(readablePeriod40, 0);
//        org.joda.time.LocalDateTime localDateTime43 = dateTime42.toLocalDateTime();
//        long long45 = julianChronology20.set((org.joda.time.ReadablePartial) localDateTime43, 0L);
//        int[] intArray51 = new int[] { (byte) 0, 9, 20, '#', 19439 };
//        int int52 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDateTime43, intArray51);
//        long long54 = delegatedDateTimeField14.remainder((long) 10);
//        org.joda.time.DurationField durationField55 = delegatedDateTimeField14.getDurationField();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "19438" + "'", str18.equals("19438"));
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(instant25);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(localDateTime43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-59356800090L) + "'", long45 == (-59356800090L));
//        org.junit.Assert.assertNotNull(intArray51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-292269045) + "'", int52 == (-292269045));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 30412800010L + "'", long54 == 30412800010L);
//        org.junit.Assert.assertNotNull(durationField55);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Pacific Standard Time");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("2019-06-12T05:23:49.972-07:00");
        java.lang.Object obj4 = null;
        jodaTimePermission3.checkGuard(obj4);
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.security.PermissionCollection permissionCollection7 = jodaTimePermission3.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(permissionCollection7);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
//        java.lang.String str3 = buddhistChronology1.toString();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
//        java.lang.Integer int6 = dateTimeParserBucket5.getOffsetInteger();
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 10);
//        long long13 = offsetDateTimeField10.add((long) 1, (long) (short) -1);
//        long long15 = offsetDateTimeField10.roundFloor((long) 3);
//        long long18 = offsetDateTimeField10.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = delegatedDateTimeField21.getAsText(19438, locale23);
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 10);
//        long long31 = offsetDateTimeField28.add((long) 1, (long) (short) -1);
//        long long33 = offsetDateTimeField28.roundFloor((long) 3);
//        long long36 = offsetDateTimeField28.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField28, (int) (short) 100);
//        long long41 = offsetDateTimeField28.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant42 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.MutableDateTime mutableDateTime44 = instant42.toMutableDateTime(chronology43);
//        int int45 = mutableDateTime44.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone47);
//        org.joda.time.DateTime dateTime50 = dateTime48.withYearOfCentury(0);
//        mutableDateTime44.setDate((org.joda.time.ReadableInstant) dateTime48);
//        org.joda.time.DateTime dateTime53 = dateTime48.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime56 = dateTime53.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod57 = null;
//        org.joda.time.DateTime dateTime59 = dateTime56.withPeriodAdded(readablePeriod57, 0);
//        org.joda.time.LocalDateTime localDateTime60 = dateTime59.toLocalDateTime();
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = offsetDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDateTime60, locale61);
//        int int63 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDateTime60);
//        long long65 = delegatedDateTimeField21.remainder(1L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = delegatedDateTimeField21.getType();
//        org.joda.time.chrono.JulianChronology julianChronology68 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField69 = julianChronology68.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField(dateTimeField69, 10);
//        long long74 = offsetDateTimeField71.add((long) 1, (long) (short) -1);
//        long long77 = offsetDateTimeField71.addWrapField((long) 20, (int) 'a');
//        org.joda.time.chrono.BuddhistChronology buddhistChronology80 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField81 = buddhistChronology80.clockhourOfHalfday();
//        java.lang.String str82 = buddhistChronology80.toString();
//        java.util.Locale locale83 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket84 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology80, locale83);
//        java.util.Locale locale85 = dateTimeParserBucket84.getLocale();
//        java.lang.String str86 = offsetDateTimeField71.getAsText((long) 9, locale85);
//        dateTimeParserBucket5.saveField(dateTimeFieldType66, "19438", locale85);
//        dateTimeParserBucket5.setOffset((-19448));
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNull(int6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31535999999L) + "'", long13 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-30412800000L) + "'", long15 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 599616000001L + "'", long18 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "19438" + "'", str24.equals("19438"));
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31535999999L) + "'", long31 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-30412800000L) + "'", long33 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 599616000001L + "'", long36 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 3155760000003L + "'", long41 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant42);
//        org.junit.Assert.assertNotNull(mutableDateTime44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(localDateTime60);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1968" + "'", str62.equals("1968"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 292273002 + "'", int63 == 292273002);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 30412800001L + "'", long65 == 30412800001L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType66);
//        org.junit.Assert.assertNotNull(julianChronology68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-31535999999L) + "'", long74 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 3061065600020L + "'", long77 == 3061065600020L);
//        org.junit.Assert.assertNotNull(buddhistChronology80);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "BuddhistChronology[UTC]" + "'", str82.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale85);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "1979" + "'", str86.equals("1979"));
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.addSeconds(0);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
//        mutableDateTime2.setMinuteOfDay((int) (short) 0);
//        long long14 = mutableDateTime2.getMillis();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime2.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone18 = buddhistChronology16.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 10);
//        long long25 = offsetDateTimeField22.add((long) 1, (long) (short) -1);
//        long long27 = offsetDateTimeField22.roundFloor((long) 3);
//        long long30 = offsetDateTimeField22.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = delegatedDateTimeField33.getAsText(19438, locale35);
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, 10);
//        long long43 = offsetDateTimeField40.add((long) 1, (long) (short) -1);
//        long long45 = offsetDateTimeField40.roundFloor((long) 3);
//        long long48 = offsetDateTimeField40.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField40, (int) (short) 100);
//        long long53 = offsetDateTimeField40.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant54 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology55 = null;
//        org.joda.time.MutableDateTime mutableDateTime56 = instant54.toMutableDateTime(chronology55);
//        int int57 = mutableDateTime56.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone59 = null;
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone59);
//        org.joda.time.DateTime dateTime62 = dateTime60.withYearOfCentury(0);
//        mutableDateTime56.setDate((org.joda.time.ReadableInstant) dateTime60);
//        org.joda.time.DateTime dateTime65 = dateTime60.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime68 = dateTime65.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod69 = null;
//        org.joda.time.DateTime dateTime71 = dateTime68.withPeriodAdded(readablePeriod69, 0);
//        org.joda.time.LocalDateTime localDateTime72 = dateTime71.toLocalDateTime();
//        java.util.Locale locale73 = null;
//        java.lang.String str74 = offsetDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDateTime72, locale73);
//        int int75 = delegatedDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) localDateTime72);
//        boolean boolean77 = delegatedDateTimeField33.isLeap((long) 23);
//        long long80 = delegatedDateTimeField33.getDifferenceAsLong((long) 19440, 0L);
//        boolean boolean81 = delegatedDateTimeField33.isLenient();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField83 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology16, (org.joda.time.DateTimeField) delegatedDateTimeField33, 6);
//        mutableDateTime2.setChronology((org.joda.time.Chronology) buddhistChronology16);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31535999999L) + "'", long25 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-30412800000L) + "'", long27 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 599616000001L + "'", long30 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "19438" + "'", str36.equals("19438"));
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-31535999999L) + "'", long43 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-30412800000L) + "'", long45 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 599616000001L + "'", long48 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 3155760000003L + "'", long53 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant54);
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDateTime72);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1968" + "'", str74.equals("1968"));
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 292273002 + "'", int75 == 292273002);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 0L + "'", long80 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getMillisOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.yearOfCentury();
//        try {
//            mutableDateTime2.setSecondOfMinute(19454020);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19454020 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        boolean boolean9 = dateTime4.isBefore(0L);
        org.joda.time.DateTime.Property property10 = dateTime4.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-12T13:24:36.882-07:00", number1, (java.lang.Number) 38943, (java.lang.Number) 35354);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property8 = dateTime7.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfMinute();
//        org.joda.time.Instant instant12 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = instant12.toMutableDateTime(chronology13);
//        int int15 = mutableDateTime14.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury(0);
//        mutableDateTime14.setDate((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime23 = dateTime18.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
//        org.joda.time.Instant instant28 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.MutableDateTime mutableDateTime30 = instant28.toMutableDateTime(chronology29);
//        int int31 = mutableDateTime30.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone33);
//        org.joda.time.DateTime dateTime36 = dateTime34.withYearOfCentury(0);
//        mutableDateTime30.setDate((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime dateTime39 = dateTime34.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone43 = dateTime42.getZone();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = dateTimeZone43.getName((long) (short) 10, locale45);
//        long long48 = dateTimeZone27.getMillisKeepLocal(dateTimeZone43, (long) (short) 0);
//        org.joda.time.DateTime dateTime49 = dateTime10.toDateTime(dateTimeZone43);
//        java.lang.String str50 = dateTimeZone43.toString();
//        org.joda.time.DateTime dateTime51 = dateTime7.withZoneRetainFields(dateTimeZone43);
//        org.joda.time.DateTime dateTime53 = dateTime7.minusSeconds(38940);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(instant28);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Coordinated Universal Time" + "'", str46.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "UTC" + "'", str50.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime5 = dateTime2.withTimeAtStartOfDay();
//        long long6 = dateTime5.getMillis();
//        long long7 = dateTime5.getMillis();
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.year();
//        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology8.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = dateTime5.withChronology((org.joda.time.Chronology) julianChronology8);
//        org.joda.time.DurationFieldType durationFieldType13 = null;
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime12.withFieldAdded(durationFieldType13, 38914);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.year();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (byte) 100);
//        mutableDateTime7.addMonths(19442);
//        org.joda.time.DateTime dateTime10 = mutableDateTime7.toDateTime();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = instant11.toMutableDateTime(chronology12);
//        int int14 = mutableDateTime13.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime17.withYearOfCentury(0);
//        mutableDateTime13.setDate((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime22 = dateTime17.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, 0);
//        org.joda.time.LocalDateTime localDateTime29 = dateTime28.toLocalDateTime();
//        org.joda.time.DateTime dateTime30 = dateTime10.withFields((org.joda.time.ReadablePartial) localDateTime29);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property33 = dateTime32.secondOfMinute();
//        org.joda.time.Chronology chronology34 = dateTime32.getChronology();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((java.lang.Object) dateTime10, chronology34);
//        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField37 = julianChronology36.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 10);
//        long long42 = offsetDateTimeField39.add((long) 1, (long) (short) -1);
//        long long44 = offsetDateTimeField39.roundFloor((long) 3);
//        long long47 = offsetDateTimeField39.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField39, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField39);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = delegatedDateTimeField50.getAsText(19438, locale52);
//        org.joda.time.chrono.JulianChronology julianChronology54 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField55 = julianChronology54.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, 10);
//        long long60 = offsetDateTimeField57.add((long) 1, (long) (short) -1);
//        long long62 = offsetDateTimeField57.roundFloor((long) 3);
//        long long65 = offsetDateTimeField57.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField57, (int) (short) 100);
//        long long70 = offsetDateTimeField57.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant71 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology72 = null;
//        org.joda.time.MutableDateTime mutableDateTime73 = instant71.toMutableDateTime(chronology72);
//        int int74 = mutableDateTime73.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone76 = null;
//        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone76);
//        org.joda.time.DateTime dateTime79 = dateTime77.withYearOfCentury(0);
//        mutableDateTime73.setDate((org.joda.time.ReadableInstant) dateTime77);
//        org.joda.time.DateTime dateTime82 = dateTime77.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime85 = dateTime82.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod86 = null;
//        org.joda.time.DateTime dateTime88 = dateTime85.withPeriodAdded(readablePeriod86, 0);
//        org.joda.time.LocalDateTime localDateTime89 = dateTime88.toLocalDateTime();
//        java.util.Locale locale90 = null;
//        java.lang.String str91 = offsetDateTimeField57.getAsText((org.joda.time.ReadablePartial) localDateTime89, locale90);
//        int int92 = delegatedDateTimeField50.getMaximumValue((org.joda.time.ReadablePartial) localDateTime89);
//        long long94 = delegatedDateTimeField50.remainder(1L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType95 = delegatedDateTimeField50.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException97 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType95, "hi!");
//        org.joda.time.DateTime dateTime99 = dateTime35.withField(dateTimeFieldType95, 0);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(julianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-31535999999L) + "'", long42 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-30412800000L) + "'", long44 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 599616000001L + "'", long47 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "19438" + "'", str53.equals("19438"));
//        org.junit.Assert.assertNotNull(julianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-31535999999L) + "'", long60 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-30412800000L) + "'", long62 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 599616000001L + "'", long65 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 3155760000003L + "'", long70 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant71);
//        org.junit.Assert.assertNotNull(mutableDateTime73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(dateTime82);
//        org.junit.Assert.assertNotNull(dateTime85);
//        org.junit.Assert.assertNotNull(dateTime88);
//        org.junit.Assert.assertNotNull(localDateTime89);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "1968" + "'", str91.equals("1968"));
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 292273002 + "'", int92 == 292273002);
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 30412800001L + "'", long94 == 30412800001L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType95);
//        org.junit.Assert.assertNotNull(dateTime99);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        org.joda.time.DateTime dateTime11 = property7.addToCopy(1L);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfYear();
        org.joda.time.Chronology chronology3 = iSOChronology1.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) ' ', 19441);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "BuddhistChronology[America/Los_Angeles]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendFraction(dateTimeFieldType13, 19434, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder8.appendClockhourOfDay(38918);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.year();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (byte) 100);
//        mutableDateTime7.addMonths(19442);
//        org.joda.time.DateTime dateTime10 = mutableDateTime7.toDateTime();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = instant11.toMutableDateTime(chronology12);
//        int int14 = mutableDateTime13.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime17.withYearOfCentury(0);
//        mutableDateTime13.setDate((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime22 = dateTime17.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, 0);
//        org.joda.time.LocalDateTime localDateTime29 = dateTime28.toLocalDateTime();
//        org.joda.time.DateTime dateTime30 = dateTime10.withFields((org.joda.time.ReadablePartial) localDateTime29);
//        org.joda.time.DateTime dateTime32 = dateTime10.minusYears(15);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour(19);
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology10.getZone();
//        org.joda.time.Instant instant12 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = instant12.toMutableDateTime(chronology13);
//        int int15 = mutableDateTime14.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury(0);
//        mutableDateTime14.setDate((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime23 = dateTime18.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, 0);
//        org.joda.time.LocalDateTime localDateTime30 = dateTime29.toLocalDateTime();
//        boolean boolean31 = dateTimeZone11.isLocalDateTimeGap(localDateTime30);
//        org.joda.time.DateTime dateTime32 = dateTime7.withFields((org.joda.time.ReadablePartial) localDateTime30);
//        org.joda.time.DateTime.Property property33 = dateTime7.hourOfDay();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) 4);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        java.util.Locale locale16 = null;
//        int int17 = property15.getMaximumShortTextLength(locale16);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = property15.getAsText(locale18);
//        org.joda.time.DateTime dateTime21 = property15.setCopy(12);
//        boolean boolean22 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.MutableDateTime.Property property23 = mutableDateTime2.yearOfEra();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970" + "'", str19.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(property23);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = dateTime6.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime11 = dateTime9.withMinuteOfHour(19);
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
//        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = instant14.toMutableDateTime(chronology15);
//        int int17 = mutableDateTime16.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone19);
//        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
//        mutableDateTime16.setDate((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime25 = dateTime20.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime31 = dateTime28.withPeriodAdded(readablePeriod29, 0);
//        org.joda.time.LocalDateTime localDateTime32 = dateTime31.toLocalDateTime();
//        boolean boolean33 = dateTimeZone13.isLocalDateTimeGap(localDateTime32);
//        org.joda.time.DateTime dateTime34 = dateTime9.withFields((org.joda.time.ReadablePartial) localDateTime32);
//        org.joda.time.DateTime dateTime36 = dateTime9.withWeekOfWeekyear(19);
//        boolean boolean37 = gJChronology0.equals((java.lang.Object) dateTime36);
//        org.joda.time.Instant instant39 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology40 = null;
//        org.joda.time.MutableDateTime mutableDateTime41 = instant39.toMutableDateTime(chronology40);
//        int int42 = mutableDateTime41.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone44);
//        org.joda.time.DateTime dateTime47 = dateTime45.withYearOfCentury(0);
//        mutableDateTime41.setDate((org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.DateTime dateTime50 = dateTime45.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime53 = dateTime50.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone54 = dateTime53.getZone();
//        org.joda.time.Instant instant55 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology56 = null;
//        org.joda.time.MutableDateTime mutableDateTime57 = instant55.toMutableDateTime(chronology56);
//        int int58 = mutableDateTime57.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone60);
//        org.joda.time.DateTime dateTime63 = dateTime61.withYearOfCentury(0);
//        mutableDateTime57.setDate((org.joda.time.ReadableInstant) dateTime61);
//        org.joda.time.DateTime dateTime66 = dateTime61.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime69 = dateTime66.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone70 = dateTime69.getZone();
//        java.util.Locale locale72 = null;
//        java.lang.String str73 = dateTimeZone70.getName((long) (short) 10, locale72);
//        long long75 = dateTimeZone54.getMillisKeepLocal(dateTimeZone70, (long) (short) 0);
//        java.util.Locale locale77 = null;
//        java.lang.String str78 = dateTimeZone70.getShortName((long) (short) 0, locale77);
//        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((java.lang.Object) (-57600000L), dateTimeZone70);
//        org.joda.time.Chronology chronology80 = gJChronology0.withZone(dateTimeZone70);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localDateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(instant39);
//        org.junit.Assert.assertNotNull(mutableDateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(instant55);
//        org.junit.Assert.assertNotNull(mutableDateTime57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTimeZone70);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Coordinated Universal Time" + "'", str73.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "UTC" + "'", str78.equals("UTC"));
//        org.junit.Assert.assertNotNull(chronology80);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.Object obj2 = null;
        boolean boolean3 = julianChronology0.equals(obj2);
        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
        try {
            long long12 = julianChronology0.getDateTimeMillis(20, 38943, 19435, 35360, 5, 324, 19441);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35360 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.Instant instant7 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = instant7.toMutableDateTime(chronology8);
//        int int10 = mutableDateTime9.getCenturyOfEra();
//        int int11 = mutableDateTime9.getYearOfCentury();
//        mutableDateTime9.setDate((long) (-1));
//        boolean boolean14 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime9.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime16 = property15.roundFloor();
//        try {
//            mutableDateTime16.setMillisOfSecond(38939);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 38939 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 70 + "'", int11 == 70);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        boolean boolean17 = offsetDateTimeField13.isLeap((long) 19435);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfSecond((int) ' ', 19441);
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField30.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "BuddhistChronology[America/Los_Angeles]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder26.appendFraction(dateTimeFieldType31, 19434, 2000);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType31, 19442);
        long long40 = dividedDateTimeField38.roundFloor((long) (-372));
        int int43 = dividedDateTimeField38.getDifference((long) 6, (long) (-28800));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-65607148800000L) + "'", long40 == (-65607148800000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test345");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
//        boolean boolean17 = offsetDateTimeField13.isLeap((long) 19435);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond(19438);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfYear(1979);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfSecond((int) ' ', 19441);
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField30.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "BuddhistChronology[America/Los_Angeles]");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder26.appendFraction(dateTimeFieldType31, 19434, 2000);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType31, 19442);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField38);
//        int int40 = remainderDateTimeField39.getMaximumValue();
//        long long42 = remainderDateTimeField39.roundHalfCeiling(3155760000003L);
//        org.joda.time.Instant instant43 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology44 = null;
//        org.joda.time.MutableDateTime mutableDateTime45 = instant43.toMutableDateTime(chronology44);
//        int int46 = mutableDateTime45.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        mutableDateTime45.setZone(dateTimeZone47);
//        org.joda.time.MutableDateTime.Property property49 = mutableDateTime45.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime51 = property49.add((-1));
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime51.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField53 = property52.getField();
//        org.joda.time.MutableDateTime mutableDateTime54 = property52.roundHalfFloor();
//        mutableDateTime54.setMinuteOfDay(4);
//        org.joda.time.MutableDateTime.Property property57 = mutableDateTime54.weekyear();
//        boolean boolean58 = mutableDateTime54.isEqualNow();
//        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = julianChronology59.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType63 = offsetDateTimeField62.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType63, "BuddhistChronology[America/Los_Angeles]");
//        org.joda.time.MutableDateTime.Property property66 = mutableDateTime54.property(dateTimeFieldType63);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField67 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField39, dateTimeFieldType63);
//        org.joda.time.Instant instant68 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology69 = null;
//        org.joda.time.MutableDateTime mutableDateTime70 = instant68.toMutableDateTime(chronology69);
//        int int71 = mutableDateTime70.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone72 = null;
//        mutableDateTime70.setZone(dateTimeZone72);
//        org.joda.time.MutableDateTime.Property property74 = mutableDateTime70.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime76 = property74.add((-1));
//        org.joda.time.MutableDateTime.Property property77 = mutableDateTime76.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField78 = property77.getField();
//        org.joda.time.Instant instant79 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology80 = null;
//        org.joda.time.MutableDateTime mutableDateTime81 = instant79.toMutableDateTime(chronology80);
//        int int82 = mutableDateTime81.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone83 = null;
//        mutableDateTime81.setZone(dateTimeZone83);
//        org.joda.time.MutableDateTime.Property property85 = mutableDateTime81.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime87 = property85.add((-1));
//        org.joda.time.MutableDateTime.Property property88 = mutableDateTime87.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField89 = property88.getField();
//        int int90 = property88.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType91 = property88.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField93 = new org.joda.time.field.OffsetDateTimeField(dateTimeField78, dateTimeFieldType91, 19431);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField94 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField67, dateTimeFieldType91);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19441 + "'", int40 == 19441);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3156883200000L + "'", long42 == 3156883200000L);
//        org.junit.Assert.assertNotNull(instant43);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(mutableDateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(mutableDateTime54);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(julianChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeFieldType63);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertNotNull(instant68);
//        org.junit.Assert.assertNotNull(mutableDateTime70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertNotNull(mutableDateTime76);
//        org.junit.Assert.assertNotNull(property77);
//        org.junit.Assert.assertNotNull(dateTimeField78);
//        org.junit.Assert.assertNotNull(instant79);
//        org.junit.Assert.assertNotNull(mutableDateTime81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
//        org.junit.Assert.assertNotNull(property85);
//        org.junit.Assert.assertNotNull(mutableDateTime87);
//        org.junit.Assert.assertNotNull(property88);
//        org.junit.Assert.assertNotNull(dateTimeField89);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType91);
//    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test346");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology4.getZone();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName((long) 0, locale7);
//        long long10 = dateTimeZone3.getMillisKeepLocal(dateTimeZone5, 0L);
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = instant11.toMutableDateTime(chronology12);
//        int int14 = mutableDateTime13.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime17.withYearOfCentury(0);
//        mutableDateTime13.setDate((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime22 = dateTime17.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
//        org.joda.time.Instant instant27 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology28 = null;
//        org.joda.time.MutableDateTime mutableDateTime29 = instant27.toMutableDateTime(chronology28);
//        int int30 = mutableDateTime29.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
//        org.joda.time.DateTime dateTime35 = dateTime33.withYearOfCentury(0);
//        mutableDateTime29.setDate((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime dateTime38 = dateTime33.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime41 = dateTime38.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone42 = dateTime41.getZone();
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = dateTimeZone42.getName((long) (short) 10, locale44);
//        long long47 = dateTimeZone26.getMillisKeepLocal(dateTimeZone42, (long) (short) 0);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = dateTimeZone42.getShortName((long) (short) 0, locale49);
//        long long52 = dateTimeZone5.getMillisKeepLocal(dateTimeZone42, (long) 323);
//        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(instant27);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Coordinated Universal Time" + "'", str45.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "UTC" + "'", str50.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 323L + "'", long52 == 323L);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology2 = gregorianChronology1.withUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.clockhourOfHalfday();
//        java.lang.String str7 = buddhistChronology5.toString();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology5, locale8);
//        java.lang.Integer int10 = dateTimeParserBucket9.getOffsetInteger();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        boolean boolean12 = dateTimeParserBucket9.restoreState((java.lang.Object) gregorianChronology11);
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTimeParserBucket9.getZone();
//        java.util.Locale locale14 = dateTimeParserBucket9.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket((long) 4, (org.joda.time.Chronology) gregorianChronology1, locale14);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BuddhistChronology[UTC]" + "'", str7.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNull(int10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(locale14);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.year();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (byte) 100);
//        mutableDateTime7.addMonths(19442);
//        org.joda.time.DateTime dateTime10 = mutableDateTime7.toDateTime();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = instant11.toMutableDateTime(chronology12);
//        int int14 = mutableDateTime13.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime17.withYearOfCentury(0);
//        mutableDateTime13.setDate((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime22 = dateTime17.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, 0);
//        org.joda.time.LocalDateTime localDateTime29 = dateTime28.toLocalDateTime();
//        org.joda.time.DateTime dateTime30 = dateTime10.withFields((org.joda.time.ReadablePartial) localDateTime29);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property33 = dateTime32.secondOfMinute();
//        org.joda.time.Chronology chronology34 = dateTime32.getChronology();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((java.lang.Object) dateTime10, chronology34);
//        org.joda.time.Instant instant36 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology37 = null;
//        org.joda.time.MutableDateTime mutableDateTime38 = instant36.toMutableDateTime(chronology37);
//        int int39 = mutableDateTime38.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        mutableDateTime38.setZone(dateTimeZone40);
//        org.joda.time.MutableDateTime.Property property42 = mutableDateTime38.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime44 = property42.add((-1));
//        org.joda.time.MutableDateTime.Property property45 = mutableDateTime44.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField46 = property45.getField();
//        int int47 = property45.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property45.getFieldType();
//        org.joda.time.MutableDateTime mutableDateTime49 = property45.roundFloor();
//        org.joda.time.MutableDateTime.Property property50 = mutableDateTime49.minuteOfDay();
//        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime49);
//        org.joda.time.DateTime dateTime52 = dateTime35.toDateTime(chronology51);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(instant36);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(mutableDateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertNotNull(mutableDateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(chronology51);
//        org.junit.Assert.assertNotNull(dateTime52);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test349");
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology8.getZone();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName((long) 0, locale11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 1979, dateTimeZone9);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(64144215, 48276, 0, 68, 38943, 38940, 31, dateTimeZone9);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 68 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019-06-12T13:24:36.882-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime dateTime7 = dateTime6.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property8 = dateTime6.millisOfSecond();
        boolean boolean10 = dateTime6.isEqual((long) 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime4.plus((long) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.withSecondOfMinute(3);
        org.joda.time.DateTime dateTime13 = dateTime11.plusYears(19441);
        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfDay(68);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        org.joda.time.DateTime dateTime12 = property7.getDateTime();
        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
        org.joda.time.DateTime dateTime15 = dateTime12.minusDays((int) (short) 1);
        org.joda.time.DateTime.Property property16 = dateTime15.hourOfDay();
        org.joda.time.Interval interval17 = property16.toInterval();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(interval17);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.Object obj2 = null;
        boolean boolean3 = julianChronology0.equals(obj2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.yearOfEra();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 10);
        long long11 = offsetDateTimeField8.add((long) 1, (long) (short) -1);
        long long13 = offsetDateTimeField8.roundFloor((long) 3);
        long long16 = offsetDateTimeField8.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField19.getAsShortText(readablePartial20, 19438, locale22);
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField19, dateTimeFieldType28, 5, 19, (-10));
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField32);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-31535999999L) + "'", long11 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-30412800000L) + "'", long13 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 599616000001L + "'", long16 == 599616000001L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "19438" + "'", str23.equals("19438"));
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        org.joda.time.DateTime dateTime12 = property7.getDateTime();
        org.joda.time.DateTime dateTime13 = property7.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime14 = dateTime13.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        org.joda.time.Instant instant16 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = instant16.toMutableDateTime(chronology17);
//        int int19 = mutableDateTime18.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone21);
//        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury(0);
//        mutableDateTime18.setDate((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime dateTime27 = dateTime22.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dateTimeZone31.getName((long) (short) 10, locale33);
//        long long36 = dateTimeZone15.getMillisKeepLocal(dateTimeZone31, (long) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Coordinated Universal Time" + "'", str34.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test357");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfFloor();
//        mutableDateTime11.setMinuteOfDay(4);
//        mutableDateTime11.addYears(38917);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test358");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        java.lang.String str4 = mutableDateTime2.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        java.lang.String str6 = mutableDateTime2.toString(dateTimeFormatter5);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks((-19448));
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.withPeriodAdded(readablePeriod14, 1);
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
//        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
//        long long26 = offsetDateTimeField21.roundFloor((long) 3);
//        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = delegatedDateTimeField32.getAsText(19438, locale34);
//        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField37 = julianChronology36.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 10);
//        long long42 = offsetDateTimeField39.add((long) 1, (long) (short) -1);
//        long long44 = offsetDateTimeField39.roundFloor((long) 3);
//        long long47 = offsetDateTimeField39.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField39, (int) (short) 100);
//        long long52 = offsetDateTimeField39.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant53 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology54 = null;
//        org.joda.time.MutableDateTime mutableDateTime55 = instant53.toMutableDateTime(chronology54);
//        int int56 = mutableDateTime55.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone58);
//        org.joda.time.DateTime dateTime61 = dateTime59.withYearOfCentury(0);
//        mutableDateTime55.setDate((org.joda.time.ReadableInstant) dateTime59);
//        org.joda.time.DateTime dateTime64 = dateTime59.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime67 = dateTime64.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod68 = null;
//        org.joda.time.DateTime dateTime70 = dateTime67.withPeriodAdded(readablePeriod68, 0);
//        org.joda.time.LocalDateTime localDateTime71 = dateTime70.toLocalDateTime();
//        java.util.Locale locale72 = null;
//        java.lang.String str73 = offsetDateTimeField39.getAsText((org.joda.time.ReadablePartial) localDateTime71, locale72);
//        int int74 = delegatedDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDateTime71);
//        boolean boolean76 = delegatedDateTimeField32.isLeap((long) 23);
//        long long79 = delegatedDateTimeField32.getDifferenceAsLong((long) 19440, 0L);
//        boolean boolean80 = delegatedDateTimeField32.isLenient();
//        org.joda.time.DateTimeFieldType dateTimeFieldType81 = delegatedDateTimeField32.getType();
//        boolean boolean82 = dateTime11.isSupported(dateTimeFieldType81);
//        mutableDateTime2.set(dateTimeFieldType81, 38918);
//        org.joda.time.chrono.JulianChronology julianChronology85 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField86 = julianChronology85.year();
//        org.joda.time.DateTimeField dateTimeField87 = julianChronology85.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField88 = julianChronology85.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField89 = julianChronology85.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology90 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField91 = julianChronology90.year();
//        org.joda.time.DateTimeField dateTimeField92 = julianChronology90.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField93 = julianChronology90.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField94 = julianChronology90.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField95 = julianChronology90.dayOfWeek();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField96 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology85, dateTimeField95);
//        mutableDateTime2.setRounding(dateTimeField95);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.001Z" + "'", str4.equals("1970-01-01T00:00:00.001Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "00:00:00" + "'", str6.equals("00:00:00"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "19438" + "'", str35.equals("19438"));
//        org.junit.Assert.assertNotNull(julianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-31535999999L) + "'", long42 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-30412800000L) + "'", long44 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 599616000001L + "'", long47 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 3155760000003L + "'", long52 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant53);
//        org.junit.Assert.assertNotNull(mutableDateTime55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(localDateTime71);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "1968" + "'", str73.equals("1968"));
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 292273002 + "'", int74 == 292273002);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
//        org.junit.Assert.assertNotNull(julianChronology85);
//        org.junit.Assert.assertNotNull(dateTimeField86);
//        org.junit.Assert.assertNotNull(dateTimeField87);
//        org.junit.Assert.assertNotNull(dateTimeField88);
//        org.junit.Assert.assertNotNull(dateTimeField89);
//        org.junit.Assert.assertNotNull(julianChronology90);
//        org.junit.Assert.assertNotNull(dateTimeField91);
//        org.junit.Assert.assertNotNull(dateTimeField92);
//        org.junit.Assert.assertNotNull(dateTimeField93);
//        org.junit.Assert.assertNotNull(dateTimeField94);
//        org.junit.Assert.assertNotNull(dateTimeField95);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test359");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
//        long long8 = offsetDateTimeField5.add((long) 1, (long) (short) -1);
//        long long10 = offsetDateTimeField5.roundFloor((long) 3);
//        long long13 = offsetDateTimeField5.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = delegatedDateTimeField16.getAsText(19438, locale18);
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology20.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 10);
//        long long26 = offsetDateTimeField23.add((long) 1, (long) (short) -1);
//        long long28 = offsetDateTimeField23.roundFloor((long) 3);
//        long long31 = offsetDateTimeField23.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField23, (int) (short) 100);
//        long long36 = offsetDateTimeField23.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant37 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology38 = null;
//        org.joda.time.MutableDateTime mutableDateTime39 = instant37.toMutableDateTime(chronology38);
//        int int40 = mutableDateTime39.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone42);
//        org.joda.time.DateTime dateTime45 = dateTime43.withYearOfCentury(0);
//        mutableDateTime39.setDate((org.joda.time.ReadableInstant) dateTime43);
//        org.joda.time.DateTime dateTime48 = dateTime43.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime51 = dateTime48.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        org.joda.time.DateTime dateTime54 = dateTime51.withPeriodAdded(readablePeriod52, 0);
//        org.joda.time.LocalDateTime localDateTime55 = dateTime54.toLocalDateTime();
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = offsetDateTimeField23.getAsText((org.joda.time.ReadablePartial) localDateTime55, locale56);
//        int int58 = delegatedDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDateTime55);
//        boolean boolean60 = delegatedDateTimeField16.isLeap((long) 23);
//        java.util.Locale locale61 = null;
//        int int62 = delegatedDateTimeField16.getMaximumShortTextLength(locale61);
//        org.joda.time.DateTimeFieldType dateTimeFieldType63 = delegatedDateTimeField16.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType63, 19440, (int) (byte) 1, (-19441661));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-31535999999L) + "'", long8 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-30412800000L) + "'", long10 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 599616000001L + "'", long13 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "19438" + "'", str19.equals("19438"));
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31535999999L) + "'", long26 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-30412800000L) + "'", long28 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 599616000001L + "'", long31 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 3155760000003L + "'", long36 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant37);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(localDateTime55);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "1968" + "'", str57.equals("1968"));
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 292273002 + "'", int58 == 292273002);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 9 + "'", int62 == 9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType63);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(30412800001L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.Instant instant6 = instant3.withDurationAdded(2019L, 57648);
        org.joda.time.MutableDateTime mutableDateTime7 = instant3.toMutableDateTimeISO();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant3.minus(readableDuration8);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(instant9);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        java.lang.String str4 = mutableDateTime2.toString();
//        mutableDateTime2.setSecondOfDay(20);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.001Z" + "'", str4.equals("1970-01-01T00:00:00.001Z"));
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test362");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
//        java.lang.String str3 = buddhistChronology1.toString();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
//        java.util.Locale locale6 = dateTimeParserBucket5.getLocale();
//        long long8 = dateTimeParserBucket5.computeMillis(false);
//        java.lang.Integer int9 = dateTimeParserBucket5.getPivotYear();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
//        org.junit.Assert.assertNull(int9);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYearOfCentury(353, 59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test364");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        java.lang.String str4 = mutableDateTime2.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        java.lang.String str6 = mutableDateTime2.toString(dateTimeFormatter5);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks((-19448));
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.withPeriodAdded(readablePeriod14, 1);
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
//        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
//        long long26 = offsetDateTimeField21.roundFloor((long) 3);
//        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = delegatedDateTimeField32.getAsText(19438, locale34);
//        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField37 = julianChronology36.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 10);
//        long long42 = offsetDateTimeField39.add((long) 1, (long) (short) -1);
//        long long44 = offsetDateTimeField39.roundFloor((long) 3);
//        long long47 = offsetDateTimeField39.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField39, (int) (short) 100);
//        long long52 = offsetDateTimeField39.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant53 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology54 = null;
//        org.joda.time.MutableDateTime mutableDateTime55 = instant53.toMutableDateTime(chronology54);
//        int int56 = mutableDateTime55.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone58);
//        org.joda.time.DateTime dateTime61 = dateTime59.withYearOfCentury(0);
//        mutableDateTime55.setDate((org.joda.time.ReadableInstant) dateTime59);
//        org.joda.time.DateTime dateTime64 = dateTime59.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime67 = dateTime64.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod68 = null;
//        org.joda.time.DateTime dateTime70 = dateTime67.withPeriodAdded(readablePeriod68, 0);
//        org.joda.time.LocalDateTime localDateTime71 = dateTime70.toLocalDateTime();
//        java.util.Locale locale72 = null;
//        java.lang.String str73 = offsetDateTimeField39.getAsText((org.joda.time.ReadablePartial) localDateTime71, locale72);
//        int int74 = delegatedDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDateTime71);
//        boolean boolean76 = delegatedDateTimeField32.isLeap((long) 23);
//        long long79 = delegatedDateTimeField32.getDifferenceAsLong((long) 19440, 0L);
//        boolean boolean80 = delegatedDateTimeField32.isLenient();
//        org.joda.time.DateTimeFieldType dateTimeFieldType81 = delegatedDateTimeField32.getType();
//        boolean boolean82 = dateTime11.isSupported(dateTimeFieldType81);
//        mutableDateTime2.set(dateTimeFieldType81, 38918);
//        org.joda.time.DateTimeZone dateTimeZone86 = null;
//        org.joda.time.DateTime dateTime87 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone86);
//        org.joda.time.DateTime dateTime89 = dateTime87.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime90 = dateTime87.withTimeAtStartOfDay();
//        long long91 = dateTime90.getMillis();
//        long long92 = dateTime90.getMillis();
//        org.joda.time.DateTime dateTime94 = dateTime90.plusWeeks(323);
//        org.joda.time.DateTime.Property property95 = dateTime94.weekyear();
//        org.joda.time.DateTime dateTime96 = property95.withMaximumValue();
//        org.joda.time.DateMidnight dateMidnight97 = dateTime96.toDateMidnight();
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime96);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.001Z" + "'", str4.equals("1970-01-01T00:00:00.001Z"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "00:00:00" + "'", str6.equals("00:00:00"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "19438" + "'", str35.equals("19438"));
//        org.junit.Assert.assertNotNull(julianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-31535999999L) + "'", long42 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-30412800000L) + "'", long44 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 599616000001L + "'", long47 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 3155760000003L + "'", long52 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant53);
//        org.junit.Assert.assertNotNull(mutableDateTime55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(localDateTime71);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "1968" + "'", str73.equals("1968"));
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 292273002 + "'", int74 == 292273002);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
//        org.junit.Assert.assertNotNull(dateTime89);
//        org.junit.Assert.assertNotNull(dateTime90);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 0L + "'", long91 == 0L);
//        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 0L + "'", long92 == 0L);
//        org.junit.Assert.assertNotNull(dateTime94);
//        org.junit.Assert.assertNotNull(property95);
//        org.junit.Assert.assertNotNull(dateTime96);
//        org.junit.Assert.assertNotNull(dateMidnight97);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfHour(0, 31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(10);
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withDayOfYear(19454020);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19454020 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test367");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property8 = dateTime7.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfMinute();
//        org.joda.time.Instant instant12 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = instant12.toMutableDateTime(chronology13);
//        int int15 = mutableDateTime14.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury(0);
//        mutableDateTime14.setDate((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime23 = dateTime18.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
//        org.joda.time.Instant instant28 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.MutableDateTime mutableDateTime30 = instant28.toMutableDateTime(chronology29);
//        int int31 = mutableDateTime30.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone33);
//        org.joda.time.DateTime dateTime36 = dateTime34.withYearOfCentury(0);
//        mutableDateTime30.setDate((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime dateTime39 = dateTime34.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone43 = dateTime42.getZone();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = dateTimeZone43.getName((long) (short) 10, locale45);
//        long long48 = dateTimeZone27.getMillisKeepLocal(dateTimeZone43, (long) (short) 0);
//        org.joda.time.DateTime dateTime49 = dateTime10.toDateTime(dateTimeZone43);
//        java.lang.String str50 = dateTimeZone43.toString();
//        org.joda.time.DateTime dateTime51 = dateTime7.withZoneRetainFields(dateTimeZone43);
//        long long53 = dateTimeZone43.convertUTCToLocal((long) 38942);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(instant28);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Coordinated Universal Time" + "'", str46.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "UTC" + "'", str50.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 38942L + "'", long53 == 38942L);
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test368");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        mutableDateTime2.addMinutes((int) (byte) 100);
//        int int16 = mutableDateTime2.getRoundingMode();
//        int int17 = mutableDateTime2.getRoundingMode();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("57923");
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime dateTime7 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime4.plusMinutes(64144);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test371");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((long) 0, locale6);
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
//        boolean boolean10 = dateTimeZone4.isStandardOffset(6216825600020L);
//        org.joda.time.Chronology chronology11 = buddhistChronology1.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.Chronology chronology15 = buddhistChronology1.withZone(dateTimeZone13);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withZone(dateTimeZone13);
//        org.joda.time.Instant instant17 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.MutableDateTime mutableDateTime19 = instant17.toMutableDateTime(chronology18);
//        int int20 = mutableDateTime19.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone22);
//        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury(0);
//        mutableDateTime19.setDate((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime dateTime28 = dateTime23.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime31 = dateTime28.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test372");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
//        long long24 = offsetDateTimeField21.add((long) 1, (long) (short) -1);
//        long long26 = offsetDateTimeField21.roundFloor((long) 3);
//        long long29 = offsetDateTimeField21.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21, (int) (short) 100);
//        long long34 = offsetDateTimeField21.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant35 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology36 = null;
//        org.joda.time.MutableDateTime mutableDateTime37 = instant35.toMutableDateTime(chronology36);
//        int int38 = mutableDateTime37.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone40);
//        org.joda.time.DateTime dateTime43 = dateTime41.withYearOfCentury(0);
//        mutableDateTime37.setDate((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTime dateTime46 = dateTime41.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 0);
//        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
//        java.util.Locale locale54 = null;
//        java.lang.String str55 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime53, locale54);
//        int int56 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime53);
//        org.joda.time.DurationField durationField57 = delegatedDateTimeField14.getDurationField();
//        org.joda.time.DurationFieldType durationFieldType58 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField60 = new org.joda.time.field.ScaledDurationField(durationField57, durationFieldType58, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31535999999L) + "'", long24 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-30412800000L) + "'", long26 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 599616000001L + "'", long29 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3155760000003L + "'", long34 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant35);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDateTime53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1968" + "'", str55.equals("1968"));
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292273002 + "'", int56 == 292273002);
//        org.junit.Assert.assertNotNull(durationField57);
//    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test373");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) 4);
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        java.util.Locale locale16 = null;
//        int int17 = property15.getMaximumShortTextLength(locale16);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = property15.getAsText(locale18);
//        org.joda.time.DateTime dateTime21 = property15.setCopy(12);
//        boolean boolean22 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.LocalDateTime localDateTime23 = dateTime21.toLocalDateTime();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970" + "'", str19.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(localDateTime23);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        org.joda.time.DateTime dateTime12 = property7.getDateTime();
        org.joda.time.DateTime dateTime13 = property7.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField14 = property7.getField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test375");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology0.monthOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test376");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        int int19 = skipUndoDateTimeField17.get((long) 19438);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 323);
//        java.lang.String str23 = skipUndoDateTimeField17.getAsText(0L);
//        long long25 = skipUndoDateTimeField17.roundHalfCeiling((long) 324);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime5 = dateTime2.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
        org.joda.time.DateTime.Property property7 = dateTime5.millisOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test379");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.dayOfMonth();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology5.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField8, (int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.clockhourOfHalfday();
//        java.lang.String str15 = buddhistChronology13.toString();
//        java.util.Locale locale16 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology13, locale16);
//        java.util.Locale locale18 = dateTimeParserBucket17.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter11.withLocale(locale18);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 1970, (org.joda.time.Chronology) julianChronology1, locale18);
//        boolean boolean22 = dateTimeParserBucket20.restoreState((java.lang.Object) 378038692445L);
//        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology23.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        long long29 = offsetDateTimeField26.add((long) 1, (long) (short) -1);
//        long long31 = offsetDateTimeField26.roundFloor((long) 3);
//        long long34 = offsetDateTimeField26.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField26);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = delegatedDateTimeField37.getAsText(19438, locale39);
//        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField42 = julianChronology41.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, 10);
//        long long47 = offsetDateTimeField44.add((long) 1, (long) (short) -1);
//        long long49 = offsetDateTimeField44.roundFloor((long) 3);
//        long long52 = offsetDateTimeField44.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, (int) (short) 100);
//        long long57 = offsetDateTimeField44.add((long) 3, (long) (byte) 100);
//        org.joda.time.Instant instant58 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology59 = null;
//        org.joda.time.MutableDateTime mutableDateTime60 = instant58.toMutableDateTime(chronology59);
//        int int61 = mutableDateTime60.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone63);
//        org.joda.time.DateTime dateTime66 = dateTime64.withYearOfCentury(0);
//        mutableDateTime60.setDate((org.joda.time.ReadableInstant) dateTime64);
//        org.joda.time.DateTime dateTime69 = dateTime64.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime72 = dateTime69.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod73 = null;
//        org.joda.time.DateTime dateTime75 = dateTime72.withPeriodAdded(readablePeriod73, 0);
//        org.joda.time.LocalDateTime localDateTime76 = dateTime75.toLocalDateTime();
//        java.util.Locale locale77 = null;
//        java.lang.String str78 = offsetDateTimeField44.getAsText((org.joda.time.ReadablePartial) localDateTime76, locale77);
//        int int79 = delegatedDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) localDateTime76);
//        boolean boolean81 = delegatedDateTimeField37.isLeap((long) 23);
//        long long84 = delegatedDateTimeField37.getDifferenceAsLong((long) 19440, 0L);
//        boolean boolean85 = delegatedDateTimeField37.isLenient();
//        int int87 = delegatedDateTimeField37.get((long) (short) 100);
//        dateTimeParserBucket20.saveField((org.joda.time.DateTimeField) delegatedDateTimeField37, 20);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BuddhistChronology[UTC]" + "'", str15.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(julianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-31535999999L) + "'", long29 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-30412800000L) + "'", long31 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 599616000001L + "'", long34 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "19438" + "'", str40.equals("19438"));
//        org.junit.Assert.assertNotNull(julianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-31535999999L) + "'", long47 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-30412800000L) + "'", long49 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 599616000001L + "'", long52 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 3155760000003L + "'", long57 == 3155760000003L);
//        org.junit.Assert.assertNotNull(instant58);
//        org.junit.Assert.assertNotNull(mutableDateTime60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(localDateTime76);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "1968" + "'", str78.equals("1968"));
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 292273002 + "'", int79 == 292273002);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1979 + "'", int87 == 1979);
//    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test380");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        long long13 = offsetDateTimeField3.roundHalfEven((long) 23);
//        long long16 = offsetDateTimeField3.add(3061065600020L, (long) 100);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone18);
//        org.joda.time.DateTime dateTime21 = dateTime19.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime(dateTimeZone22);
//        org.joda.time.Instant instant24 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.MutableDateTime mutableDateTime26 = instant24.toMutableDateTime(chronology25);
//        int int27 = mutableDateTime26.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone29);
//        org.joda.time.DateTime dateTime32 = dateTime30.withYearOfCentury(0);
//        mutableDateTime26.setDate((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime35 = dateTime30.minusWeeks((int) (short) 100);
//        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTime dateTime37 = dateTime21.withChronology(chronology36);
//        org.joda.time.TimeOfDay timeOfDay38 = dateTime21.toTimeOfDay();
//        int int39 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay38);
//        long long42 = offsetDateTimeField3.getDifferenceAsLong((long) (byte) 1, (long) 35356);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 6216825600020L + "'", long16 == 6216825600020L);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(instant24);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(timeOfDay38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 292273002 + "'", int39 == 292273002);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
//    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test381");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        int int11 = property9.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property9.getFieldType();
//        org.joda.time.MutableDateTime mutableDateTime13 = property9.roundFloor();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.minuteOfDay();
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime13);
//        mutableDateTime13.setSecondOfMinute(6);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test382");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        org.joda.time.DurationField durationField15 = delegatedDateTimeField14.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime22 = dateTime20.withMillis((long) 4);
//        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillisOfDay(19434);
//        org.joda.time.TimeOfDay timeOfDay26 = dateTime22.toTimeOfDay();
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = delegatedDateTimeField14.getAsText((org.joda.time.ReadablePartial) timeOfDay26, 80670, locale28);
//        java.lang.String str30 = delegatedDateTimeField14.getName();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology33.clockhourOfHalfday();
//        java.lang.String str35 = buddhistChronology33.toString();
//        java.util.Locale locale36 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket37 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology33, locale36);
//        java.lang.Integer int38 = dateTimeParserBucket37.getOffsetInteger();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        boolean boolean40 = dateTimeParserBucket37.restoreState((java.lang.Object) gregorianChronology39);
//        org.joda.time.DateTimeZone dateTimeZone41 = dateTimeParserBucket37.getZone();
//        java.util.Locale locale42 = dateTimeParserBucket37.getLocale();
//        java.lang.String str43 = delegatedDateTimeField14.getAsText((long) 0, locale42);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(timeOfDay26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "80670" + "'", str29.equals("80670"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "year" + "'", str30.equals("year"));
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "BuddhistChronology[UTC]" + "'", str35.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNull(int38);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(locale42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1979" + "'", str43.equals("1979"));
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DurationField durationField15 = delegatedDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury(0);
        org.joda.time.DateTime dateTime22 = dateTime20.withMillis((long) 4);
        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
        org.joda.time.DateTime dateTime25 = dateTime22.withMillisOfDay(19434);
        org.joda.time.TimeOfDay timeOfDay26 = dateTime22.toTimeOfDay();
        java.util.Locale locale28 = null;
        java.lang.String str29 = delegatedDateTimeField14.getAsText((org.joda.time.ReadablePartial) timeOfDay26, 80670, locale28);
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        long long36 = offsetDateTimeField33.add((long) 1, (long) (short) -1);
        long long38 = offsetDateTimeField33.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField33.getType();
        boolean boolean41 = offsetDateTimeField33.isLeap((-59385600090L));
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField33.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField14, dateTimeFieldType42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(timeOfDay26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "80670" + "'", str29.equals("80670"));
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-31535999999L) + "'", long36 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-30412800000L) + "'", long38 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test384");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology0.getZone();
//        org.joda.time.Chronology chronology19 = gregorianChronology0.withUTC();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(chronology19);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfMonth();
        org.joda.time.DateTime dateTime6 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(0);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillis((long) 4);
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        boolean boolean15 = property5.equals((java.lang.Object) dateTime14);
        int int16 = dateTime14.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test386");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime9 = dateTime4.plus((long) (short) 10);
//        org.joda.time.DateTime dateTime11 = dateTime9.withSecondOfMinute(3);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = property12.roundHalfEvenCopy();
//        int int14 = dateTime13.getWeekyear();
//        org.joda.time.DateTime.Property property15 = dateTime13.minuteOfDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.toDateTime();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test387");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfHalfday();
//        java.lang.String str2 = buddhistChronology0.toString();
//        java.lang.String str3 = buddhistChronology0.toString();
//        java.lang.String str4 = buddhistChronology0.toString();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BuddhistChronology[UTC]" + "'", str4.equals("BuddhistChronology[UTC]"));
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendLiteral("1968");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test389");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) 0, locale3);
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        boolean boolean7 = dateTimeZone1.isStandardOffset(6216825600020L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        boolean boolean17 = offsetDateTimeField13.isLeap((long) 19435);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfSecond((int) ' ', 19441);
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField30.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "BuddhistChronology[America/Los_Angeles]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder26.appendFraction(dateTimeFieldType31, 19434, 2000);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType31, 19442);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField38);
        long long42 = dividedDateTimeField38.addWrapField(1L, 19440521);
        long long44 = dividedDateTimeField38.roundFloor((-57565816L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-7870527766281599999L) + "'", long42 == (-7870527766281599999L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-65607148800000L) + "'", long44 == (-65607148800000L));
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test391");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        int int19 = skipUndoDateTimeField17.get((long) 19438);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, 323);
//        java.lang.String str23 = skipUndoDateTimeField17.getAsText(0L);
//        org.joda.time.Instant instant24 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.MutableDateTime mutableDateTime26 = instant24.toMutableDateTime(chronology25);
//        int int27 = mutableDateTime26.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone29);
//        org.joda.time.DateTime dateTime32 = dateTime30.withYearOfCentury(0);
//        mutableDateTime26.setDate((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime35 = dateTime30.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone39 = dateTime38.getZone();
//        long long42 = dateTimeZone39.adjustOffset((long) '#', true);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField47 = buddhistChronology46.clockhourOfHalfday();
//        java.lang.String str48 = buddhistChronology46.toString();
//        java.util.Locale locale49 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket50 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology46, locale49);
//        java.util.Locale locale51 = dateTimeParserBucket50.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = dateTimeFormatter44.withLocale(locale51);
//        java.lang.String str53 = dateTimeZone39.getShortName((long) (short) -1, locale51);
//        int int54 = skipUndoDateTimeField17.getMaximumTextLength(locale51);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
//        org.junit.Assert.assertNotNull(instant24);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 35L + "'", long42 == 35L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "BuddhistChronology[UTC]" + "'", str48.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 5 + "'", int54 == 5);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTime(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime3.withWeekyear(589);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test393");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
//        mutableDateTime2.addWeekyears(5);
//        mutableDateTime2.setSecondOfDay(80673);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime2.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime17 = property16.roundHalfEven();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter2.getParser();
        try {
            long long5 = dateTimeFormatter2.parseMillis("-372");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-372\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test395");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
//        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
//        int int11 = mutableDateTime3.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime3.secondOfMinute();
//        int int15 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "2019-06-12T05:24:11.615-07:00", 19);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        mutableDateTime3.add(readableDuration16, 19431);
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime3.millisOfSecond();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-20) + "'", int15 == (-20));
//        org.junit.Assert.assertNotNull(property19);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.Chronology chronology3 = dateTime1.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfWeek();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test397");
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = instant1.getChronology();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 10);
//        long long9 = offsetDateTimeField6.add((long) 1, (long) (short) -1);
//        long long12 = offsetDateTimeField6.addWrapField((long) 20, (int) 'a');
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.clockhourOfHalfday();
//        java.lang.String str17 = buddhistChronology15.toString();
//        java.util.Locale locale18 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology15, locale18);
//        java.util.Locale locale20 = dateTimeParserBucket19.getLocale();
//        java.lang.String str21 = offsetDateTimeField6.getAsText((long) 9, locale20);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket24 = new org.joda.time.format.DateTimeParserBucket((long) 23, chronology2, locale20, (java.lang.Integer) 3, 0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31535999999L) + "'", long9 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3061065600020L + "'", long12 == 3061065600020L);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BuddhistChronology[UTC]" + "'", str17.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1979" + "'", str21.equals("1979"));
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) ' ', 19431, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime2.plusYears((int) (short) 10);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withSecondOfMinute((-372));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -372 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test400");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.dayOfMonth();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology5.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField8, (int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.clockhourOfHalfday();
//        java.lang.String str15 = buddhistChronology13.toString();
//        java.util.Locale locale16 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology13, locale16);
//        java.util.Locale locale18 = dateTimeParserBucket17.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter11.withLocale(locale18);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 1970, (org.joda.time.Chronology) julianChronology1, locale18);
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeParserBucket20.getZone();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BuddhistChronology[UTC]" + "'", str15.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test401");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(19438);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
//        org.joda.time.Instant instant4 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.MutableDateTime mutableDateTime6 = instant4.toMutableDateTime(chronology5);
//        int int7 = mutableDateTime6.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        mutableDateTime6.setZone(dateTimeZone8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime12 = property10.add((-1));
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
//        int int15 = property13.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property13.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType16, 80674);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendClockhourOfHalfday((int) (short) 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        int int3 = mutableDateTime2.getCenturyOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.centuryOfEra();
        int int5 = mutableDateTime2.getWeekyear();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test403");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName((long) 0, locale9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 1979, dateTimeZone7);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime2, dateTimeZone7);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime2.plus(readableDuration13);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1968");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfMinute();
        org.joda.time.Chronology chronology6 = dateTime4.getChronology();
        boolean boolean7 = jodaTimePermission1.equals((java.lang.Object) dateTime4);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test405");
//        java.lang.Object obj0 = null;
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
//        mutableDateTime4.setDate((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime13 = dateTime8.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone17 = dateTime16.getZone();
//        org.joda.time.Instant instant18 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.MutableDateTime mutableDateTime20 = instant18.toMutableDateTime(chronology19);
//        int int21 = mutableDateTime20.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone23);
//        org.joda.time.DateTime dateTime26 = dateTime24.withYearOfCentury(0);
//        mutableDateTime20.setDate((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime29 = dateTime24.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone33 = dateTime32.getZone();
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = dateTimeZone33.getName((long) (short) 10, locale35);
//        long long38 = dateTimeZone17.getMillisKeepLocal(dateTimeZone33, (long) (short) 0);
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dateTimeZone33.getShortName((long) (short) 0, locale40);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) '#', dateTimeZone33);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(obj0, dateTimeZone33);
//        long long45 = dateTimeZone33.convertUTCToLocal(551468970000000L);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(instant18);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Coordinated Universal Time" + "'", str36.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "UTC" + "'", str41.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 551468970000000L + "'", long45 == 551468970000000L);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((-19448));
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) '#');
        org.joda.time.DateTime dateTime10 = dateTime6.plusSeconds(292273002);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime10.getZone();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test407");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.year();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.dayOfMonth();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.year();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology5.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField8, (int) (short) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.clockhourOfHalfday();
//        java.lang.String str15 = buddhistChronology13.toString();
//        java.util.Locale locale16 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology13, locale16);
//        java.util.Locale locale18 = dateTimeParserBucket17.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter11.withLocale(locale18);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 1970, (org.joda.time.Chronology) julianChronology1, locale18);
//        boolean boolean22 = dateTimeParserBucket20.restoreState((java.lang.Object) 378038692445L);
//        dateTimeParserBucket20.setPivotYear((java.lang.Integer) 19438);
//        int int25 = dateTimeParserBucket20.getOffset();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BuddhistChronology[UTC]" + "'", str15.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test408");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
//        java.lang.String str3 = buddhistChronology1.toString();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
//        java.util.Locale locale6 = dateTimeParserBucket5.getLocale();
//        dateTimeParserBucket5.setOffset((java.lang.Integer) 19431);
//        java.lang.Integer int9 = dateTimeParserBucket5.getPivotYear();
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        long long16 = offsetDateTimeField13.add((long) 1, (long) (short) -1);
//        long long18 = offsetDateTimeField13.roundFloor((long) 3);
//        long long21 = offsetDateTimeField13.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13);
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = delegatedDateTimeField24.getAsShortText(readablePartial25, 19438, locale27);
//        boolean boolean29 = delegatedDateTimeField24.isLenient();
//        boolean boolean30 = dateTimeParserBucket5.restoreState((java.lang.Object) delegatedDateTimeField24);
//        dateTimeParserBucket5.setOffset((java.lang.Integer) 2019);
//        long long33 = dateTimeParserBucket5.computeMillis();
//        java.lang.Integer int34 = dateTimeParserBucket5.getPivotYear();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale6);
//        org.junit.Assert.assertNull(int9);
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31535999999L) + "'", long16 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-30412800000L) + "'", long18 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 599616000001L + "'", long21 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "19438" + "'", str28.equals("19438"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1967L) + "'", long33 == (-1967L));
//        org.junit.Assert.assertNull(int34);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 64145);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("America/Los_Angeles");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(19452, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter12.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.append(dateTimePrinter13);
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatterBuilder14.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder8.append(dateTimeParser15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder8.appendYearOfCentury(19454, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withDefaultYear(0);
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatter24.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder8.append(dateTimePrinter21, dateTimeParser25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder7.appendOptional(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test411");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = dateTime6.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime11 = dateTime9.withMinuteOfHour(19);
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
//        org.joda.time.Instant instant14 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = instant14.toMutableDateTime(chronology15);
//        int int17 = mutableDateTime16.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone19);
//        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfCentury(0);
//        mutableDateTime16.setDate((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime25 = dateTime20.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime28 = dateTime25.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime31 = dateTime28.withPeriodAdded(readablePeriod29, 0);
//        org.joda.time.LocalDateTime localDateTime32 = dateTime31.toLocalDateTime();
//        boolean boolean33 = dateTimeZone13.isLocalDateTimeGap(localDateTime32);
//        org.joda.time.DateTime dateTime34 = dateTime9.withFields((org.joda.time.ReadablePartial) localDateTime32);
//        org.joda.time.DateTime dateTime36 = dateTime9.withWeekOfWeekyear(19);
//        boolean boolean37 = gJChronology0.equals((java.lang.Object) dateTime36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = gJChronology0.equals(obj38);
//        org.joda.time.DurationField durationField40 = gJChronology0.weeks();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localDateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(durationField40);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test412");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.withZoneRetainFields(dateTimeZone12);
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        org.joda.time.Instant instant16 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = instant16.toMutableDateTime(chronology17);
//        int int19 = mutableDateTime18.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone21);
//        org.joda.time.DateTime dateTime24 = dateTime22.withYearOfCentury(0);
//        mutableDateTime18.setDate((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime dateTime27 = dateTime22.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.withPeriodAdded(readablePeriod31, 0);
//        org.joda.time.LocalDateTime localDateTime34 = dateTime33.toLocalDateTime();
//        boolean boolean35 = dateTimeZone15.isLocalDateTimeGap(localDateTime34);
//        org.joda.time.DateTime dateTime36 = dateTime11.withZone(dateTimeZone15);
//        int int37 = dateTime11.getYearOfCentury();
//        java.lang.String str39 = dateTime11.toString("57599");
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(localDateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 70 + "'", int37 == 70);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "57599" + "'", str39.equals("57599"));
//    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test413");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfHalfday();
//        java.lang.String str3 = buddhistChronology1.toString();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology1, locale4);
//        java.util.Locale locale6 = dateTimeParserBucket5.getLocale();
//        dateTimeParserBucket5.setOffset((java.lang.Integer) 19431);
//        org.joda.time.Instant instant9 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = instant9.toMutableDateTime(chronology10);
//        int int12 = mutableDateTime11.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withYearOfCentury(0);
//        mutableDateTime11.setDate((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime20 = dateTime15.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
//        long long26 = dateTimeZone24.convertUTCToLocal((long) 38921);
//        dateTimeParserBucket5.setZone(dateTimeZone24);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale6);
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 38921L + "'", long26 == 38921L);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1969-12-31T16:00:00.000-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test415");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getCenturyOfEra();
//        int int4 = mutableDateTime2.getYearOfCentury();
//        mutableDateTime2.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = mutableDateTime2.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) ' ');
//        java.util.Date date12 = dateTime9.toDate();
//        boolean boolean14 = dateTime9.isEqual(10L);
//        org.joda.time.DateTime dateTime15 = dateTime9.toDateTimeISO();
//        org.joda.time.Instant instant16 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = instant16.toMutableDateTime(chronology17);
//        int int19 = mutableDateTime18.getCenturyOfEra();
//        int int20 = mutableDateTime18.getYearOfCentury();
//        mutableDateTime18.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime23 = mutableDateTime18.copy();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = mutableDateTime18.toDateTime(dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) ' ');
//        java.util.Date date28 = dateTime25.toDate();
//        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 10);
//        long long35 = offsetDateTimeField32.add((long) 1, (long) (short) -1);
//        long long37 = offsetDateTimeField32.roundFloor((long) 3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField32.getType();
//        org.joda.time.DateTime dateTime40 = dateTime25.withField(dateTimeFieldType38, (int) (short) 0);
//        org.joda.time.DateTime dateTime42 = dateTime25.minusWeeks(19438);
//        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone44 = julianChronology43.getZone();
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = dateTimeZone44.getName((long) 0, locale46);
//        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone44);
//        boolean boolean50 = dateTimeZone44.isStandardOffset(6216825600020L);
//        org.joda.time.DateTime dateTime51 = dateTime25.toDateTime(dateTimeZone44);
//        org.joda.time.Chronology chronology52 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTime dateTime54 = dateTime9.minusMillis(19441);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 70 + "'", int20 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(julianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-31535999999L) + "'", long35 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-30412800000L) + "'", long37 == (-30412800000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(julianChronology43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Coordinated Universal Time" + "'", str47.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology48);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertNotNull(dateTime54);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test417");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        long long13 = offsetDateTimeField3.roundHalfEven((long) (short) 1);
//        int int15 = offsetDateTimeField3.getMaximumValue((long) 19441);
//        org.joda.time.Instant instant16 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.MutableDateTime mutableDateTime18 = instant16.toMutableDateTime(chronology17);
//        int int19 = mutableDateTime18.getCenturyOfEra();
//        int int20 = mutableDateTime18.getYearOfCentury();
//        mutableDateTime18.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime23 = mutableDateTime18.copy();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = mutableDateTime18.toDateTime(dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.withZoneRetainFields(dateTimeZone28);
//        int int30 = dateTime29.getMinuteOfHour();
//        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localDateTime31, locale32);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1123200000L + "'", long13 == 1123200000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 292273002 + "'", int15 == 292273002);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 70 + "'", int20 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(localDateTime31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1970" + "'", str33.equals("1970"));
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 57600);
        mutableDateTime1.setMillisOfSecond(0);
        mutableDateTime1.addMonths(19439435);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        org.joda.time.Instant instant4 = instant0.plus((long) 19447);
        org.joda.time.Instant instant6 = instant0.plus((long) (byte) 100);
        long long7 = instant0.getMillis();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
        org.joda.time.Chronology chronology3 = instant0.getChronology();
        org.joda.time.MutableDateTime mutableDateTime4 = instant0.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test422");
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
//        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime12 = dateTime7.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName((long) (short) 10, locale18);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(3156883200000L, (org.joda.time.Chronology) gregorianChronology20);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordinated Universal Time" + "'", str19.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfYear();
        try {
            long long10 = iSOChronology1.getDateTimeMillis((int) (byte) -1, 64144, (int) '4', 324, 999, 59, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 324 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test424");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
//        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
//        int int11 = mutableDateTime3.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime3.secondOfMinute();
//        int int15 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "2019-06-12T05:24:11.615-07:00", 19);
//        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter0.getParser();
//        java.io.Writer writer17 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property20 = dateTime19.secondOfMinute();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime22 = property20.withMinimumValue();
//        try {
//            dateTimeFormatter0.printTo(writer17, (org.joda.time.ReadableInstant) dateTime22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-20) + "'", int15 == (-20));
//        org.junit.Assert.assertNotNull(dateTimeParser16);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test425");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime.Property property12 = dateTime6.hourOfDay();
//        org.joda.time.DateTime.Property property13 = dateTime6.era();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay((-19431));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.year();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.weekOfWeekyear();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((long) 97, (org.joda.time.Chronology) buddhistChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test428");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        org.joda.time.Instant instant11 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = instant11.toMutableDateTime(chronology12);
//        int int14 = mutableDateTime13.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        mutableDateTime13.setZone(dateTimeZone15);
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime13.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime19 = property17.add((-1));
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField21 = property20.getField();
//        int int22 = property20.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property20.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType23, 19431);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology28 = gregorianChronology27.withUTC();
//        org.joda.time.Instant instant29 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology30 = null;
//        org.joda.time.MutableDateTime mutableDateTime31 = instant29.toMutableDateTime(chronology30);
//        int int32 = mutableDateTime31.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        mutableDateTime31.setZone(dateTimeZone33);
//        org.joda.time.MutableDateTime.Property property35 = mutableDateTime31.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime37 = property35.add((-1));
//        org.joda.time.MutableDateTime.Property property38 = mutableDateTime37.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField39 = property38.getField();
//        int int40 = property38.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property38.getFieldType();
//        org.joda.time.DateTimeField dateTimeField42 = property38.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField42, 19448);
//        int int46 = skipUndoDateTimeField44.get((long) 3);
//        org.joda.time.ReadablePartial readablePartial47 = null;
//        org.joda.time.Instant instant49 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology50 = null;
//        org.joda.time.MutableDateTime mutableDateTime51 = instant49.toMutableDateTime(chronology50);
//        int int52 = mutableDateTime51.getCenturyOfEra();
//        int int53 = mutableDateTime51.getYearOfCentury();
//        mutableDateTime51.setDate((long) (-1));
//        org.joda.time.MutableDateTime mutableDateTime56 = mutableDateTime51.copy();
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.DateTime dateTime58 = mutableDateTime51.toDateTime(dateTimeZone57);
//        org.joda.time.DateTime dateTime60 = dateTime58.plusWeeks((int) ' ');
//        java.util.Date date61 = dateTime58.toDate();
//        org.joda.time.chrono.JulianChronology julianChronology62 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField63 = julianChronology62.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, 10);
//        long long68 = offsetDateTimeField65.add((long) 1, (long) (short) -1);
//        long long70 = offsetDateTimeField65.roundFloor((long) 3);
//        long long72 = offsetDateTimeField65.roundHalfCeiling((long) (short) 0);
//        int int73 = dateTime58.get((org.joda.time.DateTimeField) offsetDateTimeField65);
//        org.joda.time.DateTime.Property property74 = dateTime58.secondOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology76 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField77 = buddhistChronology76.clockhourOfHalfday();
//        java.lang.String str78 = buddhistChronology76.toString();
//        java.util.Locale locale79 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket80 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology76, locale79);
//        java.lang.Integer int81 = dateTimeParserBucket80.getOffsetInteger();
//        org.joda.time.chrono.GregorianChronology gregorianChronology82 = org.joda.time.chrono.GregorianChronology.getInstance();
//        boolean boolean83 = dateTimeParserBucket80.restoreState((java.lang.Object) gregorianChronology82);
//        org.joda.time.DateTimeZone dateTimeZone84 = dateTimeParserBucket80.getZone();
//        java.util.Locale locale85 = dateTimeParserBucket80.getLocale();
//        java.lang.String str86 = property74.getAsShortText(locale85);
//        java.lang.String str87 = skipUndoDateTimeField44.getAsShortText(readablePartial47, 48281, locale85);
//        java.lang.String str88 = offsetDateTimeField25.getAsText(0, locale85);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(instant29);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(instant49);
//        org.junit.Assert.assertNotNull(mutableDateTime51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 19 + "'", int52 == 19);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 70 + "'", int53 == 70);
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(julianChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-31535999999L) + "'", long68 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-30412800000L) + "'", long70 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1123200000L + "'", long72 == 1123200000L);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1979 + "'", int73 == 1979);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertNotNull(buddhistChronology76);
//        org.junit.Assert.assertNotNull(dateTimeField77);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "BuddhistChronology[UTC]" + "'", str78.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNull(int81);
//        org.junit.Assert.assertNotNull(gregorianChronology82);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone84);
//        org.junit.Assert.assertNotNull(locale85);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "0" + "'", str86.equals("0"));
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "48281" + "'", str87.equals("48281"));
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "0" + "'", str88.equals("0"));
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        java.lang.Object obj2 = null;
        boolean boolean3 = julianChronology0.equals(obj2);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.era();
        org.joda.time.DurationField durationField5 = julianChronology0.minutes();
        org.joda.time.DurationField durationField6 = julianChronology0.millis();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test430");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.Instant instant3 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime(chronology4);
//        int int6 = mutableDateTime5.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(0);
//        mutableDateTime5.setDate((org.joda.time.ReadableInstant) dateTime9);
//        int int13 = mutableDateTime5.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime5.secondOfMinute();
//        mutableDateTime5.addWeeks(0);
//        mutableDateTime5.addMinutes((int) (byte) 100);
//        int int19 = mutableDateTime5.getRoundingMode();
//        org.joda.time.Instant instant20 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant22 = instant20.minus((long) (short) -1);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime5, (org.joda.time.ReadableInstant) instant20);
//        int int26 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "", 19447);
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(instant20);
//        org.junit.Assert.assertNotNull(instant22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-19448) + "'", int26 == (-19448));
//        org.junit.Assert.assertNotNull(gJChronology27);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 4);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMillis(19437);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks(19440521);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test432");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-1));
//        try {
//            org.joda.time.MutableDateTime mutableDateTime10 = property6.set(48280);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 48280 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime.Property property2 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((-1L));
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test434");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
//        boolean boolean17 = offsetDateTimeField13.isLeap((long) 19435);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond(19438);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfYear(1979);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfSecond((int) ' ', 19441);
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField30.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "BuddhistChronology[America/Los_Angeles]");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder26.appendFraction(dateTimeFieldType31, 19434, 2000);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType31, 19442);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField38);
//        int int40 = remainderDateTimeField39.getMaximumValue();
//        long long42 = remainderDateTimeField39.roundHalfCeiling(3155760000003L);
//        org.joda.time.Instant instant43 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology44 = null;
//        org.joda.time.MutableDateTime mutableDateTime45 = instant43.toMutableDateTime(chronology44);
//        int int46 = mutableDateTime45.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        mutableDateTime45.setZone(dateTimeZone47);
//        org.joda.time.MutableDateTime.Property property49 = mutableDateTime45.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime51 = property49.add((-1));
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime51.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField53 = property52.getField();
//        org.joda.time.MutableDateTime mutableDateTime54 = property52.roundHalfFloor();
//        mutableDateTime54.setMinuteOfDay(4);
//        org.joda.time.MutableDateTime.Property property57 = mutableDateTime54.weekyear();
//        boolean boolean58 = mutableDateTime54.isEqualNow();
//        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = julianChronology59.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType63 = offsetDateTimeField62.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType63, "BuddhistChronology[America/Los_Angeles]");
//        org.joda.time.MutableDateTime.Property property66 = mutableDateTime54.property(dateTimeFieldType63);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField67 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField39, dateTimeFieldType63);
//        long long69 = remainderDateTimeField39.roundCeiling(2440588L);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19441 + "'", int40 == 19441);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3156883200000L + "'", long42 == 3156883200000L);
//        org.junit.Assert.assertNotNull(instant43);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(mutableDateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(mutableDateTime54);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(julianChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeFieldType63);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1123200000L + "'", long69 == 1123200000L);
//    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test435");
//        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("1969-12-31T16");
//        int int2 = mutableDateTime1.getYearOfEra();
//        org.joda.time.Instant instant3 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime(chronology4);
//        int int6 = mutableDateTime5.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(0);
//        mutableDateTime5.setDate((org.joda.time.ReadableInstant) dateTime9);
//        int int13 = mutableDateTime5.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime5.toMutableDateTime();
//        mutableDateTime5.addWeekyears(5);
//        mutableDateTime1.setTime((org.joda.time.ReadableInstant) mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test436");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfHalfday();
//        java.lang.String str2 = buddhistChronology0.toString();
//        org.joda.time.DurationField durationField3 = buddhistChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.year();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test437");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
//        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
//        long long8 = offsetDateTimeField3.roundFloor((long) 3);
//        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField14.getAsText(19438, locale16);
//        boolean boolean18 = delegatedDateTimeField14.isLenient();
//        org.joda.time.DateTimeField dateTimeField19 = delegatedDateTimeField14.getWrappedField();
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology20.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 10);
//        long long26 = offsetDateTimeField23.add((long) 1, (long) (short) -1);
//        long long28 = offsetDateTimeField23.roundFloor((long) 3);
//        long long30 = offsetDateTimeField23.roundHalfCeiling((long) (short) 0);
//        int int32 = offsetDateTimeField23.getLeapAmount((long) (-20));
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone34);
//        org.joda.time.DateTime dateTime37 = dateTime35.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime39 = dateTime37.withMillis((long) 4);
//        org.joda.time.DateTime.Property property40 = dateTime39.weekyear();
//        org.joda.time.DateTime dateTime42 = dateTime39.withMillisOfDay(19434);
//        org.joda.time.LocalDateTime localDateTime43 = dateTime39.toLocalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology47.clockhourOfHalfday();
//        java.lang.String str49 = buddhistChronology47.toString();
//        java.util.Locale locale50 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket51 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) buddhistChronology47, locale50);
//        java.util.Locale locale52 = dateTimeParserBucket51.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter45.withLocale(locale52);
//        java.lang.String str54 = offsetDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) localDateTime43, 19, locale52);
//        int int55 = delegatedDateTimeField14.getMaximumShortTextLength(locale52);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19438" + "'", str17.equals("19438"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31535999999L) + "'", long26 == (-31535999999L));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-30412800000L) + "'", long28 == (-30412800000L));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1123200000L + "'", long30 == 1123200000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(localDateTime43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "BuddhistChronology[UTC]" + "'", str49.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(locale52);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "19" + "'", str54.equals("19"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 9 + "'", int55 == 9);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
        org.joda.time.DateTime dateTime2 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime7 = dateTime1.withTime(0, 1, (int) '4', 12);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime1.plus(readablePeriod8);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test440");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime2.dayOfYear();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test441");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime(chronology3);
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime4.setZone(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
//        int int13 = property11.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.DateTimeField dateTimeField15 = property11.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField15, 19448);
//        int int19 = skipUndoDateTimeField17.get((long) 19438);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property22 = dateTime21.secondOfMinute();
//        org.joda.time.DateTime dateTime24 = property22.addToCopy((long) (short) 10);
//        org.joda.time.TimeOfDay timeOfDay25 = dateTime24.toTimeOfDay();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField17.getAsText((org.joda.time.ReadablePartial) timeOfDay25, 1900, locale27);
//        int int29 = skipUndoDateTimeField17.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(timeOfDay25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1900" + "'", str28.equals("1900"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test443");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime2.setZone(dateTimeZone4);
//        org.joda.time.Instant instant6 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = instant6.toMutableDateTime(chronology7);
//        int int9 = mutableDateTime8.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime12.withYearOfCentury(0);
//        mutableDateTime8.setDate((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime17 = dateTime12.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTime20.getZone();
//        org.joda.time.Instant instant22 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = instant22.toMutableDateTime(chronology23);
//        int int25 = mutableDateTime24.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone27);
//        org.joda.time.DateTime dateTime30 = dateTime28.withYearOfCentury(0);
//        mutableDateTime24.setDate((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime dateTime33 = dateTime28.minusWeeks((int) (short) 100);
//        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded((long) (short) 100, (int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone37 = dateTime36.getZone();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = dateTimeZone37.getName((long) (short) 10, locale39);
//        long long42 = dateTimeZone21.getMillisKeepLocal(dateTimeZone37, (long) (short) 0);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = dateTimeZone37.getShortName((long) (short) 0, locale44);
//        java.lang.String str47 = dateTimeZone37.getShortName(0L);
//        org.joda.time.MutableDateTime mutableDateTime48 = org.joda.time.MutableDateTime.now(dateTimeZone37);
//        mutableDateTime2.setZoneRetainFields(dateTimeZone37);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(instant22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Coordinated Universal Time" + "'", str40.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UTC" + "'", str45.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UTC" + "'", str47.equals("UTC"));
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test444");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime2.toMutableDateTime();
//        int int12 = mutableDateTime2.getYearOfEra();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        boolean boolean17 = offsetDateTimeField13.isLeap((long) 19435);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfSecond((int) ' ', 19441);
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField30.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "BuddhistChronology[America/Los_Angeles]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder26.appendFraction(dateTimeFieldType31, 19434, 2000);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType31, 19442);
        int int40 = dividedDateTimeField38.getLeapAmount((long) 23);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test446");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
//        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
//        int int11 = mutableDateTime3.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime3.secondOfMinute();
//        int int15 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "2019-06-12T05:24:11.615-07:00", 19);
//        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter0.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZoneUTC();
//        try {
//            org.joda.time.DateTime dateTime19 = dateTimeFormatter0.parseDateTime("1968");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1968\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-20) + "'", int15 == (-20));
//        org.junit.Assert.assertNotNull(dateTimeParser16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime2.plusYears((int) (short) 10);
        int int8 = dateTime2.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("-1");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekyear();
        java.lang.String str3 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test453");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfCentury(0);
//        org.joda.time.DateTime.Property property5 = dateTime2.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(1L);
//        org.joda.time.DateTime dateTime9 = property5.setCopy(10);
//        org.joda.time.DateTime dateTime10 = property5.roundHalfEvenCopy();
//        boolean boolean11 = dateTime10.isAfterNow();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test454");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury(0);
//        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime7);
//        int int11 = mutableDateTime3.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime3.secondOfMinute();
//        int int15 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "2019-06-12T05:24:11.615-07:00", 19);
//        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter0.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZoneUTC();
//        java.lang.Appendable appendable18 = null;
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        try {
//            dateTimeFormatter17.printTo(appendable18, readablePartial19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-20) + "'", int15 == (-20));
//        org.junit.Assert.assertNotNull(dateTimeParser16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test455");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName((long) 0, locale5);
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
//        boolean boolean9 = dateTimeZone3.isStandardOffset(6216825600020L);
//        org.joda.time.Chronology chronology10 = buddhistChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        boolean boolean17 = offsetDateTimeField13.isLeap((long) 19435);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfSecond((int) ' ', 19441);
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField30.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "BuddhistChronology[America/Los_Angeles]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder26.appendFraction(dateTimeFieldType31, 19434, 2000);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType31, 19442);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField38);
        int int40 = remainderDateTimeField39.getMaximumValue();
        int int41 = remainderDateTimeField39.getMinimumValue();
        int int42 = remainderDateTimeField39.getMaximumValue();
        org.joda.time.DurationField durationField43 = remainderDateTimeField39.getRangeDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19441 + "'", int40 == 19441);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 19441 + "'", int42 == 19441);
        org.junit.Assert.assertNotNull(durationField43);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test457");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
//        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.addWeeks(0);
//        mutableDateTime2.addMinutes((int) (byte) 100);
//        mutableDateTime2.addMillis((-292269045));
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(0L);
//        org.joda.time.DateTime.Property property20 = dateTime19.secondOfMinute();
//        org.joda.time.DateTime dateTime21 = property20.roundHalfCeilingCopy();
//        int int22 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean23 = dateTime21.isBeforeNow();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
//        java.lang.String str25 = dateTime21.toString(dateTimeFormatter24);
//        org.joda.time.DateTime.Property property26 = dateTime21.minuteOfHour();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str25.equals("1970-01-01T00:00:00.000Z"));
//        org.junit.Assert.assertNotNull(property26);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.clockhourOfDay();
        long long8 = julianChronology0.add((long) 324, (-59385600090L), (-1));
        org.joda.time.DurationField durationField9 = julianChronology0.years();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 59385600414L + "'", long8 == 59385600414L);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 10);
        long long6 = offsetDateTimeField3.add((long) 1, (long) (short) -1);
        long long8 = offsetDateTimeField3.roundFloor((long) 3);
        long long11 = offsetDateTimeField3.add((long) (short) 1, (long) 19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 3);
        boolean boolean17 = offsetDateTimeField13.isLeap((long) 19435);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond(19438);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfYear(1979);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfSecond((int) ' ', 19441);
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField30.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "BuddhistChronology[America/Los_Angeles]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder26.appendFraction(dateTimeFieldType31, 19434, 2000);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType31, 19442);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder41.appendLiteral("America/Los_Angeles");
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = julianChronology44.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, 10);
        long long50 = offsetDateTimeField47.add((long) 1, (long) (short) -1);
        long long52 = offsetDateTimeField47.roundFloor((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = offsetDateTimeField47.getType();
        java.lang.Object obj54 = null;
        boolean boolean55 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFieldType53, obj54);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder43.appendDecimal(dateTimeFieldType53, (int) (short) 100, 6);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField38, dateTimeFieldType53);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31535999999L) + "'", long6 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-30412800000L) + "'", long8 == (-30412800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599616000001L + "'", long11 == 599616000001L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-31535999999L) + "'", long50 == (-31535999999L));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-30412800000L) + "'", long52 == (-30412800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
    }
}

