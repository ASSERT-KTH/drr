import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        try {
            org.joda.time.Partial partial4 = new org.joda.time.Partial(dateTimeFieldType0, 0, (org.joda.time.Chronology) buddhistChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 10, (int) (short) -1, 0, (int) (short) 10, (int) (byte) 1, 1, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(1L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) true, (org.joda.time.Chronology) buddhistChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        long long2 = org.joda.time.field.FieldUtils.safeDivide(0L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 0, 0, (int) (byte) 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = buddhistChronology1.get(readablePeriod3, (long) '#', (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        try {
            org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) buddhistChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.BuddhistChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = null;
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter4, dateTimeParser5);
        try {
            java.lang.String str7 = partial3.toString(dateTimeFormatter6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology(chronology2);
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1, (int) (short) 0, 0, (int) (byte) 10, (int) '#', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology(chronology1);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = buddhistChronology5.minutes();
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology5);
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) partial7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.Partial partial8 = partial3.with(dateTimeFieldType6, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology(chronology1);
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter0.parseLocalTime("Property[hourOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[hourOfDay]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.Partial partial8 = partial5.withField(dateTimeFieldType6, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(partial5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = buddhistChronology8.minutes();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology8.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(0, (-1), 100, 0, (-1), 10, (-1), (org.joda.time.Chronology) buddhistChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime2.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            int int9 = dateTime2.get(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
        try {
            org.joda.time.LocalDate localDate5 = localDate1.withDayOfMonth((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTime.Property property5 = dateTime4.hourOfDay();
        java.lang.String str6 = property5.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime9.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readablePeriod15);
        int int17 = property5.getDifference((org.joda.time.ReadableInstant) dateTime14);
        try {
            org.joda.time.DateTime dateTime19 = property5.setCopy((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[hourOfDay]" + "'", str6.equals("Property[hourOfDay]"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(dateTimeZone3);
        org.joda.time.LocalDate localDate6 = localDate4.plusMonths((int) (byte) 100);
        int[] intArray14 = new int[] { (short) 1, (-1), 31, 'a', 10, (byte) 1 };
        try {
            int[] intArray16 = delegatedDateTimeField2.set((org.joda.time.ReadablePartial) localDate4, (int) (byte) 1, intArray14, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(1560637897829L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2458650.43863228d + "'", double1 == 2458650.43863228d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Property[hourOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("Property[hourOfDay]", (int) (byte) 0, 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for Property[hourOfDay] must be in the range [10,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property13 = localDate8.yearOfEra();
//        java.util.Locale locale15 = null;
//        try {
//            org.joda.time.LocalDate localDate16 = property13.setCopy("hi!", locale15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for yearOfEra is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.LocalDate.Property property5 = localDate3.property(dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField2 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-1), (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.DurationField durationField5 = buddhistChronology1.minutes();
        long long8 = durationField5.subtract((long) (short) -1, (int) 'a');
        long long11 = durationField5.subtract((long) 264, (int) (byte) -1);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-5820001L) + "'", long8 == (-5820001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 60264L + "'", long11 == 60264L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("15");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-15573946021999L), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 1, (int) '4', 6, 100, 19, (int) (byte) 10, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "����-��-��");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial10 = partial8.minus(readablePeriod9);
        int[] intArray14 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology1.validate((org.joda.time.ReadablePartial) partial8, intArray14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.Partial partial17 = partial8.minus(readablePeriod16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        try {
            org.joda.time.Partial partial20 = partial17.withField(dateTimeFieldType18, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(partial17);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.String str2 = dateTimeFormatter0.print((long) 31);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "19691231T160000-0800" + "'", str2.equals("19691231T160000-0800"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = buddhistChronology1.add(readablePeriod5, (long) 349, 19);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 349L + "'", long8 == 349L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatterBuilder0.toParser();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.centuryOfEra();
        org.joda.time.DurationField durationField6 = buddhistChronology2.days();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField9 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, durationField6, dateTimeFieldType7, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10, 349, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 349 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
//        org.joda.time.DurationField durationField8 = buddhistChronology7.minutes();
//        org.joda.time.Partial partial9 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology7);
//        org.joda.time.Instant instant10 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime11 = partial9.toDateTime((org.joda.time.ReadableInstant) instant10);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(dateTimeZone12);
//        java.lang.String str15 = dateTimeZone12.getName(0L);
//        org.joda.time.Chronology chronology16 = julianChronology5.withZone(dateTimeZone12);
//        try {
//            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(0, 19, (int) (short) 0, (int) ' ', 0, dateTimeZone12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology16);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendYear((int) (short) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        java.util.Date date1 = instant0.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = instant0.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) instant0);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury(15);
//        int int4 = localDate1.getYearOfEra();
//        int int5 = localDate1.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property6 = localDate1.yearOfEra();
//        try {
//            org.joda.time.LocalDate localDate8 = localDate1.withYearOfEra(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(property6);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 900, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = buddhistChronology5.minutes();
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime9 = partial7.toDateTime((org.joda.time.ReadableInstant) instant8);
        try {
            org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime3, (org.joda.time.ReadableDateTime) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.halfdayOfDay();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(24, 937, (int) ' ', 2019, 264, 0, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTime.Property property5 = dateTime4.hourOfDay();
        java.lang.String str6 = property5.toString();
        java.util.Locale locale8 = null;
        try {
            org.joda.time.DateTime dateTime9 = property5.setCopy("Coordinated Universal Time", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Coordinated Universal Time\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[hourOfDay]" + "'", str6.equals("Property[hourOfDay]"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTime.Property property5 = dateTime4.hourOfDay();
        java.lang.String str6 = property5.toString();
        int int7 = property5.get();
        java.util.Locale locale9 = null;
        try {
            org.joda.time.DateTime dateTime10 = property5.setCopy("minuteOfHour", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"minuteOfHour\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[hourOfDay]" + "'", str6.equals("Property[hourOfDay]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        int int10 = delegatedDateTimeField2.get((long) '#');
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.Partial partial8 = partial6.minus(readablePeriod7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial10 = partial8.plus(readablePeriod9);
        try {
            java.lang.String str11 = dateTimeFormatter2.print((org.joda.time.ReadablePartial) partial10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(partial10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) '#', (long) 24);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 840L + "'", long2 == 840L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfMonth();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray2 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parsers supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            long long5 = gJChronology0.getDateTimeMillis((int) (short) -1, 366, 19, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = instant0.toInstant();
//        boolean boolean2 = instant1.isEqualNow();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        java.lang.String str4 = instant1.toString(dateTimeFormatter3);
//        org.joda.time.Instant instant5 = instant1.toInstant();
//        long long6 = instant1.getMillis();
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "20190615T223147Z" + "'", str4.equals("20190615T223147Z"));
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560637907179L + "'", long6 == 1560637907179L);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendOptional(dateTimeParser4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField7 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.DurationField durationField5 = buddhistChronology1.minutes();
        long long8 = durationField5.subtract((long) (short) -1, (int) 'a');
        long long11 = durationField5.subtract(0L, 0L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-5820001L) + "'", long8 == (-5820001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
        boolean boolean7 = dateTimeFormatter6.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        try {
            long long8 = delegatedDateTimeField2.set((long) 'a', "20190615T223147Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"20190615T223147Z\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        org.joda.time.DateTime dateTime9 = property6.roundHalfCeilingCopy();
        try {
            org.joda.time.DateTime dateTime11 = property6.setCopy("20190615T223147Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"20190615T223147Z\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "960" + "'", str8.equals("960"));
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 349, "20190615T223144Z");
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.centuryOfEra();
        org.joda.time.DurationField durationField10 = buddhistChronology6.days();
        try {
            org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((java.lang.Object) delegatedDateTimeField2, (org.joda.time.Chronology) buddhistChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.field.DelegatedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
        java.lang.Appendable appendable7 = null;
        try {
            dateTimeFormatter6.printTo(appendable7, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
//        int int8 = dateTime5.getWeekyear();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.dayOfWeek();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(366, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 366");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 1, (java.lang.Number) 668, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime2.withMonthOfYear((int) (short) 1);
        try {
            org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((java.lang.Object) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1560637905681L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) -1, (int) (byte) 0, (int) '#', 900, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 900 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("19691231T160000-0800", (java.lang.Number) (-15573946021999L), (java.lang.Number) 2458650.43863228d, (java.lang.Number) 100L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendDecimal(dateTimeFieldType4, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DurationField durationField5 = buddhistChronology1.days();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField8 = new org.joda.time.field.ScaledDurationField(durationField5, durationFieldType6, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.minutes();
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology9.millisOfSecond();
//        int int12 = dateTime7.get(dateTimeField11);
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        java.util.Date date14 = instant13.toDate();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        boolean boolean16 = instant13.isSupported(dateTimeFieldType15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) instant13);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = buddhistChronology19.minutes();
//        org.joda.time.Partial partial21 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology19);
//        org.joda.time.Instant instant22 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime23 = partial21.toDateTime((org.joda.time.ReadableInstant) instant22);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime25 = dateTime23.toDateTime(dateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime17.toMutableDateTime(dateTimeZone24);
//        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime7, (java.lang.Object) dateTime17);
//        org.joda.time.Instant instant28 = dateTime17.toInstant();
//        boolean boolean29 = instant28.isEqualNow();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 170 + "'", int12 == 170);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(instant28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.centuryOfEra();
        try {
            org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(264, 170, 173, (org.joda.time.Chronology) buddhistChronology4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 170 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial10 = partial8.minus(readablePeriod9);
        int[] intArray14 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology1.validate((org.joda.time.ReadablePartial) partial8, intArray14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.Partial partial17 = partial8.minus(readablePeriod16);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType19 = partial8.getFieldType((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(partial17);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate localDate14 = localDate8.withYearOfCentury((int) '#');
//        try {
//            org.joda.time.LocalDate localDate16 = localDate8.withMonthOfYear(389);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 389 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(localDate14);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        try {
            org.joda.time.DateTimeField dateTimeField3 = localDate1.getField(173);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 173");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property13 = localDate8.yearOfEra();
//        org.joda.time.DurationFieldType durationFieldType14 = null;
//        try {
//            org.joda.time.LocalDate localDate16 = localDate8.withFieldAdded(durationFieldType14, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 389);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime8 = partial6.toDateTime((org.joda.time.ReadableInstant) instant7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
        org.joda.time.Chronology chronology11 = gJChronology0.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial10 = partial8.minus(readablePeriod9);
        int[] intArray14 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology1.validate((org.joda.time.ReadablePartial) partial8, intArray14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.Partial partial17 = partial8.minus(readablePeriod16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial8.plus(readablePeriod18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        int int21 = partial19.indexOf(dateTimeFieldType20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.Partial.Property property23 = partial19.property(dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(partial17);
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.minusWeeks((int) (byte) -1);
        int int6 = localDate5.getYearOfCentury();
        org.joda.time.LocalDate localDate8 = localDate5.plusMonths((int) (short) 100);
        org.joda.time.LocalDate localDate10 = localDate5.minusDays((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = buddhistChronology15.minutes();
        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology15);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial17.minus(readablePeriod18);
        int[] intArray22 = new int[] { (byte) -1, (short) 1 };
        buddhistChronology12.validate((org.joda.time.ReadablePartial) partial17, intArray22);
        try {
            buddhistChronology1.validate((org.joda.time.ReadablePartial) localDate5, intArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = buddhistChronology1.get(readablePeriod5, 600010L, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.LocalDate.Property property3 = localDate1.property(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.DurationField durationField5 = buddhistChronology1.minutes();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField8 = new org.joda.time.field.ScaledDurationField(durationField5, durationFieldType6, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1), (java.lang.Number) 24, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime2.withMonthOfYear((int) (short) 1);
        java.util.Date date8 = dateTime7.toDate();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.add((long) '4', 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate localDate14 = localDate8.withYearOfCentury((int) '#');
//        org.joda.time.LocalDate localDate16 = localDate14.withYear(24);
//        java.util.Locale locale18 = null;
//        try {
//            java.lang.String str19 = localDate14.toString("19691231T160000-0800", locale18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendText(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime5.centuryOfEra();
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = dateTime5.toString("20190615T223147Z", locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 28800000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2277453240000000L + "'", long1 == 2277453240000000L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField9);
        long long12 = skipUndoDateTimeField10.roundHalfFloor((long) (short) 1);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
//        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime7, (java.lang.Object) dateTimeFormatter8);
//        java.lang.StringBuffer stringBuffer10 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = buddhistChronology13.minutes();
//        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology13.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology13.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter11.withChronology((org.joda.time.Chronology) buddhistChronology13);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(dateTimeZone18);
//        org.joda.time.LocalDate localDate21 = localDate19.minusWeeks((int) (byte) -1);
//        long long23 = buddhistChronology13.set((org.joda.time.ReadablePartial) localDate19, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property24 = localDate19.yearOfEra();
//        org.joda.time.DateTime dateTime25 = localDate19.toDateTimeAtMidnight();
//        try {
//            dateTimeFormatter8.printTo(stringBuffer10, (org.joda.time.ReadablePartial) localDate19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-15573946021999L) + "'", long23 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.minusWeeks((int) (byte) -1);
        int int6 = localDate5.getYearOfCentury();
        org.joda.time.LocalDate localDate8 = localDate5.plusMonths((int) (short) 100);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertNotNull(localDate8);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.minutes();
//        org.joda.time.Partial partial11 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology9);
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime13 = partial11.toDateTime((org.joda.time.ReadableInstant) instant12);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime15 = dateTime13.toDateTime(dateTimeZone14);
//        int int16 = dateTime15.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
//        org.joda.time.DurationField durationField19 = buddhistChronology18.minutes();
//        org.joda.time.Partial partial20 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology18);
//        org.joda.time.Instant instant21 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime22 = partial20.toDateTime((org.joda.time.ReadableInstant) instant21);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime24 = dateTime22.toDateTime(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.minutes();
//        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology26.millisOfSecond();
//        int int29 = dateTime24.get(dateTimeField28);
//        org.joda.time.Instant instant30 = new org.joda.time.Instant();
//        java.util.Date date31 = instant30.toDate();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
//        boolean boolean33 = instant30.isSupported(dateTimeFieldType32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((java.lang.Object) instant30);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone35);
//        org.joda.time.DurationField durationField37 = buddhistChronology36.minutes();
//        org.joda.time.Partial partial38 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.Instant instant39 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime40 = partial38.toDateTime((org.joda.time.ReadableInstant) instant39);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime42 = dateTime40.toDateTime(dateTimeZone41);
//        org.joda.time.MutableDateTime mutableDateTime43 = dateTime34.toMutableDateTime(dateTimeZone41);
//        boolean boolean44 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime24, (java.lang.Object) dateTime34);
//        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime15, (org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime46 = dateTime5.withChronology(chronology45);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone47);
//        org.joda.time.DurationField durationField49 = buddhistChronology48.minutes();
//        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology48.millisOfSecond();
//        org.joda.time.DurationField durationField51 = buddhistChronology48.hours();
//        org.joda.time.Chronology chronology52 = buddhistChronology48.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime53 = dateTime46.toMutableDateTime((org.joda.time.Chronology) buddhistChronology48);
//        int int54 = mutableDateTime53.getYear();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 264 + "'", int29 == 264);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(mutableDateTime43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(buddhistChronology48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertNotNull(mutableDateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2562 + "'", int54 == 2562);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime5.centuryOfEra();
        try {
            java.lang.String str10 = dateTime5.toString("20190615T223144Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 0, 2019, 2562, (int) ' ', 549, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendLiteral(' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendText(dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 19, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(937);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfWeek(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
//        int int4 = localDate3.getYearOfCentury();
//        org.joda.time.LocalDate localDate6 = localDate3.plusYears(0);
//        org.joda.time.LocalDate.Property property7 = localDate3.centuryOfEra();
//        int int8 = localDate3.getDayOfYear();
//        try {
//            org.joda.time.LocalDate localDate10 = localDate3.withEra(2);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 173 + "'", int8 == 173);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        int int9 = property6.get();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "960" + "'", str8.equals("960"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 960 + "'", int9 == 960);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology(chronology1);
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter2.printTo(stringBuffer3, (-5820001L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = instant0.toInstant();
        boolean boolean2 = instant1.isEqualNow();
        org.joda.time.DateTime dateTime3 = instant1.toDateTime();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withFieldAdded(durationFieldType4, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder16.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder16.appendMinuteOfDay(31);
        org.joda.time.format.DateTimePrinter dateTimePrinter24 = dateTimeFormatterBuilder16.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser25 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray26 = new org.joda.time.format.DateTimeParser[] { dateTimeParser25 };
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder10.append(dateTimePrinter24, dateTimeParserArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimePrinter24);
        org.junit.Assert.assertNotNull(dateTimeParserArray26);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury(15);
        int int4 = localDate3.size();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 52L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        try {
            java.lang.String str4 = dateTime2.toString("20190615T223147Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str2 = gJChronology1.toString();
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) gJChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant2);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        org.joda.time.LocalDate localDate12 = localDate10.minusWeeks((int) (byte) -1);
//        long long14 = buddhistChronology4.set((org.joda.time.ReadablePartial) localDate10, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property15 = localDate10.yearOfEra();
//        org.joda.time.DateTime dateTime16 = localDate10.toDateTimeAtMidnight();
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-15573946021999L) + "'", long14 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        try {
            long long7 = julianChronology0.getDateTimeMillis((int) (short) 1, 31, 960, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime2.minusMinutes((int) (byte) 0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.DateTime dateTime12 = dateTime2.withFieldAdded(durationFieldType10, 2562);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
        org.joda.time.LocalDate.Property property4 = localDate1.yearOfEra();
        java.util.Locale locale6 = null;
        try {
            org.joda.time.LocalDate localDate7 = property4.setCopy("GJChronology[UTC]", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[UTC]\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant((long) (short) 100);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) instant3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.String str1 = gJChronology0.toString();
//        java.lang.String str2 = gJChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
//        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
//        org.joda.time.Instant instant7 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime8 = partial6.toDateTime((org.joda.time.ReadableInstant) instant7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
//        org.joda.time.Chronology chronology11 = gJChronology0.withZone(dateTimeZone9);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone9.getShortName(1560637907179L, locale13);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 100, 937, (int) (short) 100, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (byte) 100);
        try {
            org.joda.time.LocalDate localDate5 = localDate3.withWeekOfWeekyear(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (byte) 100);
        org.joda.time.LocalDate localDate7 = localDate3.minusWeeks((int) (byte) 100);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.millisOfSecond();
        org.joda.time.DurationField durationField9 = buddhistChronology6.hours();
        org.joda.time.DurationField durationField10 = buddhistChronology6.minutes();
        org.joda.time.DurationField durationField11 = buddhistChronology6.weeks();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) (short) -1, 0, 3, 6, 349, (org.joda.time.Chronology) buddhistChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime5.centuryOfEra();
        java.lang.String str9 = property8.getAsText();
        java.lang.String str10 = property8.getAsShortText();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "20" + "'", str9.equals("20"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "20" + "'", str10.equals("20"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.Chronology chronology3 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField4 = gJChronology0.hours();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 100, 173, 668, 549, (int) (short) 10, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 549 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("GJChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DurationField durationField5 = buddhistChronology1.days();
        org.joda.time.Chronology chronology6 = buddhistChronology1.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "15");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.String str4 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"15\" for hi! is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"15\" for hi! is not supported"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        int int10 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType11, (int) (short) 10, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("20", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"20/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime4.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.toDateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateMidnight dateMidnight12 = dateTime9.toDateMidnight();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateMidnight12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateMidnight12);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        int[] intArray1 = null;
        try {
            org.joda.time.Partial partial2 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
        int int4 = localDate3.getYearOfCentury();
        org.joda.time.LocalDate localDate6 = localDate3.plusMonths((int) (short) 100);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfMonth();
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            int int9 = localDate6.compareTo(readablePartial8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.yearOfEra();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter0.parseLocalDateTime("yearOfEra");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"yearOfEra\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTime.Property property5 = dateTime4.hourOfDay();
        java.lang.String str6 = property5.toString();
        long long7 = property5.remainder();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[hourOfDay]" + "'", str6.equals("Property[hourOfDay]"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3599900L + "'", long7 == 3599900L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial10 = partial8.minus(readablePeriod9);
        int[] intArray14 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology1.validate((org.joda.time.ReadablePartial) partial8, intArray14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.Partial partial17 = partial8.minus(readablePeriod16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial8.plus(readablePeriod18);
        try {
            org.joda.time.DateTimeField dateTimeField21 = partial19.getField(2562);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2562");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(partial17);
        org.junit.Assert.assertNotNull(partial19);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendFractionOfMinute(549, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder17.appendMinuteOfDay(31);
        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatterBuilder17.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser26 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray27 = new org.joda.time.format.DateTimeParser[] { dateTimeParser26 };
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder11.append(dateTimePrinter25, dateTimeParserArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimePrinter25);
        org.junit.Assert.assertNotNull(dateTimeParserArray27);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology(chronology1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = instant3.toInstant();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.Instant instant6 = instant4.plus(readableDuration5);
//        java.lang.String str7 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) instant4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15T22:32:05.045" + "'", str7.equals("2019-06-15T22:32:05.045"));
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(1560637919518L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(668, 1, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("minuteOfHour", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"minuteOfHour/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField13 = buddhistChronology12.minutes();
        org.joda.time.Partial partial14 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.Partial partial16 = partial14.minus(readablePeriod15);
        int[] intArray19 = new int[] { (byte) -1, (short) 1 };
        buddhistChronology9.validate((org.joda.time.ReadablePartial) partial14, intArray19);
        try {
            int[] intArray22 = delegatedDateTimeField2.add(readablePartial6, 937, intArray19, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(partial16);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        int int6 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime8 = dateTime4.plusWeeks((int) 'a');
        org.joda.time.DateTime dateTime10 = dateTime8.withMillisOfSecond(1);
        int int11 = dateTime8.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = buddhistChronology9.minutes();
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology9.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology9.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) buddhistChronology9);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate17 = localDate15.minusWeeks((int) (byte) -1);
//        long long19 = buddhistChronology9.set((org.joda.time.ReadablePartial) localDate15, (long) (byte) 1);
//        org.joda.time.LocalDate localDate21 = localDate15.withYearOfCentury((int) '#');
//        org.joda.time.LocalDate localDate23 = localDate21.withYear(24);
//        try {
//            int int24 = property6.compareTo((org.joda.time.ReadablePartial) localDate23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-15573946021999L) + "'", long19 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate23);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property13 = localDate8.yearOfEra();
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtMidnight();
//        org.joda.time.LocalDate localDate16 = localDate8.plusMonths(0);
//        try {
//            org.joda.time.LocalDate localDate18 = localDate8.withYearOfCentury(2019);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for yearOfCentury must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localDate16);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.weekyear();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology1.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("20190615T223207Z", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"20190615T223207Z/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(937);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendCenturyOfEra(549, 349);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendPattern("");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 10L, (java.lang.Number) 10L, (java.lang.Number) (-1L));
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10L + "'", number6.equals(10L));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (short) 100, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.Instant instant3 = gJChronology0.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(instant3);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
//        int int8 = dateTime7.getDayOfWeek();
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime7.withDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 518, 1560637905681L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 808410435142758");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-210865896000000L), "20");
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        boolean boolean4 = delegatedDateTimeField2.isLeap(1L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        try {
            long long9 = delegatedDateTimeField2.set(0L, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 600010L + "'", long5 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property13 = localDate8.yearOfEra();
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtMidnight();
//        org.joda.time.LocalDate localDate16 = localDate8.plusMonths(0);
//        int[] intArray17 = localDate8.getValues();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone19);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusMillis(100);
//        org.joda.time.DateTime.Property property23 = dateTime22.hourOfDay();
//        java.lang.String str24 = property23.toString();
//        boolean boolean25 = localDate8.equals((java.lang.Object) property23);
//        try {
//            int int27 = localDate8.getValue((int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 10");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Property[hourOfDay]" + "'", str24.equals("Property[hourOfDay]"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property13 = localDate8.yearOfEra();
//        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
//        try {
//            long long17 = durationField14.subtract(600010L, (long) 173);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray28 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType23 };
        int[] intArray33 = new int[] { (short) 0, 2562, 2562, 349 };
        try {
            org.joda.time.Partial partial34 = new org.joda.time.Partial(dateTimeFieldTypeArray28, intArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray28);
        org.junit.Assert.assertNotNull(intArray33);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property13 = localDate8.yearOfEra();
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime16 = dateTime14.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusMillis(100);
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean25 = cachedDateTimeZone17.equals((java.lang.Object) dateTimeZone18);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = buddhistChronology30.minutes();
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology30.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology30.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter28.withChronology((org.joda.time.Chronology) buddhistChronology30);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(dateTimeZone35);
//        org.joda.time.LocalDate localDate38 = localDate36.minusWeeks((int) (byte) -1);
//        long long40 = buddhistChronology30.set((org.joda.time.ReadablePartial) localDate36, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property41 = localDate36.yearOfEra();
//        org.joda.time.DateTime dateTime42 = localDate36.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime44 = dateTime42.withZoneRetainFields(dateTimeZone43);
//        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology26, dateTimeZone43);
//        java.lang.String str47 = dateTimeZone43.getShortName((long) 6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(buddhistChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-15573946021999L) + "'", long40 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(zonedChronology45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UTC" + "'", str47.equals("UTC"));
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property13 = localDate8.yearOfEra();
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime16 = dateTime14.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusMillis(100);
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean25 = cachedDateTimeZone17.equals((java.lang.Object) dateTimeZone18);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = buddhistChronology30.minutes();
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology30.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology30.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter28.withChronology((org.joda.time.Chronology) buddhistChronology30);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(dateTimeZone35);
//        org.joda.time.LocalDate localDate38 = localDate36.minusWeeks((int) (byte) -1);
//        long long40 = buddhistChronology30.set((org.joda.time.ReadablePartial) localDate36, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property41 = localDate36.yearOfEra();
//        org.joda.time.DateTime dateTime42 = localDate36.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime44 = dateTime42.withZoneRetainFields(dateTimeZone43);
//        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology26, dateTimeZone43);
//        try {
//            long long53 = gregorianChronology26.getDateTimeMillis(3, (-1), 937, 549, 349, (int) (byte) 0, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 549 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(buddhistChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-15573946021999L) + "'", long40 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(zonedChronology45);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial10 = partial8.minus(readablePeriod9);
        int[] intArray14 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology1.validate((org.joda.time.ReadablePartial) partial8, intArray14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.Partial partial17 = partial8.minus(readablePeriod16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial8.plus(readablePeriod18);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        try {
            org.joda.time.Partial partial22 = partial19.withFieldAddWrapped(durationFieldType20, 173);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(partial17);
        org.junit.Assert.assertNotNull(partial19);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.Instant instant5 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime6 = partial4.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
//        java.lang.String str10 = dateTimeZone7.getName(0L);
//        org.joda.time.Chronology chronology11 = julianChronology0.withZone(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone12, 1560637904158L, 194);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 194");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.Partial partial8 = partial6.minus(readablePeriod7);
        int[] intArray11 = new int[] { (byte) -1, (short) 1 };
        buddhistChronology1.validate((org.joda.time.ReadablePartial) partial6, intArray11);
        org.joda.time.Partial partial13 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial6);
        int int14 = partial13.size();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.minusWeeks((int) (byte) -1);
        int int16 = localDate15.getYearOfCentury();
        org.joda.time.LocalDate localDate18 = localDate15.plusMonths((int) (short) 100);
        org.joda.time.LocalDate.Property property19 = localDate18.dayOfMonth();
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = offsetDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate18, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 19 + "'", int16 == 19);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime2.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime2.withDayOfMonth((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths(0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        boolean boolean4 = delegatedDateTimeField2.isLeap(0L);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField2.getAsText((long) 31, locale6);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
        int int4 = localDate3.getYearOfCentury();
        org.joda.time.LocalDate localDate6 = localDate3.plusMonths((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMillis(100);
        int int13 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = localDate3.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.LocalDate.Property property15 = localDate3.dayOfMonth();
        org.joda.time.LocalDate localDate17 = localDate3.minusDays(960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        long long32 = delegatedDateTimeField29.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField29.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType33, 173, 2562);
        try {
            org.joda.time.LocalDate localDate38 = localDate17.withField(dateTimeFieldType33, 937);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 600010L + "'", long32 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 366, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 366L + "'", long2 == 366L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendMinuteOfDay(31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder12.toFormatter();
        java.io.Writer writer14 = null;
        try {
            dateTimeFormatter13.printTo(writer14, (long) 2562);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 100, 840L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 84000L + "'", long2 == 84000L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.DateMidnight dateMidnight10 = dateTime7.toDateMidnight();
        long long11 = dateMidnight10.getMillis();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField9);
        long long12 = skipUndoDateTimeField10.roundHalfCeiling(60264L);
        int int14 = skipUndoDateTimeField10.get(10L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 365 + "'", int14 == 365);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
        int int4 = localDate3.getYearOfCentury();
        org.joda.time.LocalDate localDate6 = localDate3.plusMonths((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMillis(100);
        int int13 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = localDate3.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.LocalDate localDate16 = localDate3.withCenturyOfEra(0);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone17);
        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) (byte) -1);
        int int21 = localDate20.getYearOfCentury();
        org.joda.time.LocalDate localDate23 = localDate20.plusMonths((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime27.minusMillis(100);
        int int30 = dateTimeZone24.getOffset((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime31 = localDate20.toDateTimeAtStartOfDay(dateTimeZone24);
        org.joda.time.LocalDate.Property property32 = localDate20.dayOfMonth();
        org.joda.time.LocalDate localDate34 = localDate20.minusDays(960);
        org.joda.time.LocalDate localDate35 = localDate16.withFields((org.joda.time.ReadablePartial) localDate34);
        org.joda.time.LocalDate.Property property36 = localDate16.era();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder37.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder42.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField47 = gJChronology46.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField47);
        long long51 = delegatedDateTimeField48.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = delegatedDateTimeField48.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder45.appendDecimal(dateTimeFieldType52, 173, 2562);
        try {
            org.joda.time.LocalDate.Property property56 = localDate16.property(dateTimeFieldType52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 19 + "'", int21 == 19);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 600010L + "'", long51 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property13 = localDate8.yearOfEra();
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime16 = dateTime14.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusMillis(100);
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean25 = cachedDateTimeZone17.equals((java.lang.Object) dateTimeZone18);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = buddhistChronology30.minutes();
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology30.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology30.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter28.withChronology((org.joda.time.Chronology) buddhistChronology30);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(dateTimeZone35);
//        org.joda.time.LocalDate localDate38 = localDate36.minusWeeks((int) (byte) -1);
//        long long40 = buddhistChronology30.set((org.joda.time.ReadablePartial) localDate36, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property41 = localDate36.yearOfEra();
//        org.joda.time.DateTime dateTime42 = localDate36.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime44 = dateTime42.withZoneRetainFields(dateTimeZone43);
//        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology26, dateTimeZone43);
//        java.lang.String str46 = zonedChronology45.toString();
//        org.joda.time.ReadablePeriod readablePeriod47 = null;
//        try {
//            int[] intArray49 = zonedChronology45.get(readablePeriod47, 0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(buddhistChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-15573946021999L) + "'", long40 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(zonedChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str46.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
//        int int4 = localDate3.getYearOfCentury();
//        org.joda.time.LocalDate localDate6 = localDate3.plusYears(0);
//        org.joda.time.LocalDate.Property property7 = localDate3.centuryOfEra();
//        int int8 = localDate3.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone9);
//        org.joda.time.LocalDate localDate12 = localDate10.plusMonths((int) (byte) 100);
//        int int13 = localDate3.compareTo((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.LocalDate.Property property14 = localDate12.year();
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        java.util.Date date16 = instant15.toDate();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        boolean boolean18 = instant15.isSupported(dateTimeFieldType17);
//        org.joda.time.DateTime dateTime19 = instant15.toDateTimeISO();
//        int int20 = property14.getDifference((org.joda.time.ReadableInstant) instant15);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 173 + "'", int8 == 173);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        boolean boolean5 = localDate3.isSupported(dateTimeFieldType4);
        try {
            int int7 = localDate3.getValue(19);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 19");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = buddhistChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology7.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) buddhistChronology2);
        try {
            org.joda.time.DateTime dateTime15 = dateTime13.withWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000-07:52:58 (BuddhistChronology[America/Los_Angeles])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("20190615T223207Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"20190615T223207Z\" is malformed at \"T223207Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
//        int int4 = localDate3.getYearOfCentury();
//        org.joda.time.LocalDate localDate6 = localDate3.plusMonths((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusMillis(100);
//        int int13 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime14 = localDate3.toDateTimeAtStartOfDay(dateTimeZone7);
//        org.joda.time.LocalDate.Property property15 = localDate3.dayOfMonth();
//        org.joda.time.LocalDate localDate17 = localDate3.minusDays(960);
//        org.joda.time.LocalDate.Property property18 = localDate3.yearOfCentury();
//        int int19 = localDate3.getMonthOfYear();
//        try {
//            org.joda.time.LocalDate localDate21 = localDate3.withMonthOfYear(937);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 937 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury(15);
        try {
            int int5 = localDate3.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 100");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        long long14 = offsetDateTimeField11.roundFloor((long) 937);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
        org.joda.time.LocalDate localDate18 = localDate16.plusMonths((int) (byte) 100);
        org.joda.time.LocalDate localDate20 = localDate16.minusYears(19);
        int int21 = localDate20.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = buddhistChronology24.minutes();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology24.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology24.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.Partial partial31 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology29);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.Partial partial33 = partial31.minus(readablePeriod32);
        int[] intArray37 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology24.validate((org.joda.time.ReadablePartial) partial31, intArray37);
        java.util.Locale locale40 = null;
        try {
            int[] intArray41 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localDate20, (int) (byte) 10, intArray37, "hi!", locale40);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(partial33);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial10 = partial8.minus(readablePeriod9);
        int[] intArray14 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology1.validate((org.joda.time.ReadablePartial) partial8, intArray14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.Partial partial17 = partial8.minus(readablePeriod16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial8.plus(readablePeriod18);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str21 = gJChronology20.toString();
        java.lang.String str22 = gJChronology20.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = buddhistChronology24.minutes();
        org.joda.time.Partial partial26 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology24);
        org.joda.time.Instant instant27 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime28 = partial26.toDateTime((org.joda.time.ReadableInstant) instant27);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = dateTime28.toDateTime(dateTimeZone29);
        org.joda.time.Chronology chronology31 = gJChronology20.withZone(dateTimeZone29);
        org.joda.time.Partial partial32 = partial8.withChronologyRetainFields((org.joda.time.Chronology) gJChronology20);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
        long long38 = delegatedDateTimeField35.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = delegatedDateTimeField35.getType();
        try {
            org.joda.time.Partial partial41 = partial8.withField(dateTimeFieldType39, (-101));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(partial17);
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GJChronology[UTC]" + "'", str21.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GJChronology[UTC]" + "'", str22.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(partial32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 600010L + "'", long38 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        java.lang.String str11 = property10.toString();
        org.joda.time.DurationField durationField12 = property10.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[minuteOfDay]" + "'", str11.equals("Property[minuteOfDay]"));
        org.junit.Assert.assertNotNull(durationField12);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
//        org.joda.time.DurationField durationField9 = buddhistChronology8.minutes();
//        org.joda.time.Partial partial10 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.Instant instant11 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime12 = partial10.toDateTime((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime14 = dateTime12.toDateTime(dateTimeZone13);
//        java.lang.String str16 = dateTimeZone13.getName(0L);
//        try {
//            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((-53), 2, 2562, 2019, (int) '4', (-1), 19, dateTimeZone13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(937);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendCenturyOfEra(549, 349);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        boolean boolean11 = dateTimeFormatterBuilder10.canBuildParser();
        org.joda.time.format.DateTimeParser dateTimeParser12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendOptional(dateTimeParser12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("BuddhistChronology[America/Los_Angeles]");
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.minusWeeks((int) (byte) -1);
        int int6 = localDate5.getYearOfCentury();
        org.joda.time.LocalDate localDate8 = localDate5.plusMonths((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMillis(100);
        int int15 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime16 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
        org.joda.time.LocalDate.Property property17 = localDate5.dayOfMonth();
        org.joda.time.LocalDate localDate19 = localDate5.minusDays(960);
        org.joda.time.LocalDate.Property property20 = localDate5.yearOfCentury();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(349L, 366L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 715L + "'", long2 == 715L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = delegatedDateTimeField11.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendDecimal(dateTimeFieldType15, 173, 2562);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder8.appendTimeZoneOffset("UTC", "", true, 0, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 600010L + "'", long14 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
        int int4 = localDate3.getYearOfCentury();
        org.joda.time.LocalDate localDate6 = localDate3.plusMonths((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMillis(100);
        int int13 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = localDate3.toDateTimeAtStartOfDay(dateTimeZone7);
        org.joda.time.LocalDate.Property property15 = localDate3.dayOfMonth();
        org.joda.time.DurationField durationField16 = property15.getDurationField();
        org.joda.time.LocalDate localDate17 = property15.withMaximumValue();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(localDate17);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "19691231T160000-0800");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.Partial partial8 = partial6.minus(readablePeriod7);
        int[] intArray11 = new int[] { (byte) -1, (short) 1 };
        buddhistChronology1.validate((org.joda.time.ReadablePartial) partial6, intArray11);
        org.joda.time.Partial partial13 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial6);
        java.lang.String str14 = partial13.toStringList();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "[]" + "'", str14.equals("[]"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField11.getMaximumShortTextLength(locale12);
        org.joda.time.Instant instant14 = new org.joda.time.Instant();
        java.util.Date date15 = instant14.toDate();
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.fromDateFields(date15);
        int[] intArray23 = new int[] { 170, 17, 194, 2, 194 };
        try {
            int[] intArray25 = offsetDateTimeField11.addWrapField((org.joda.time.ReadablePartial) localDate16, 366, intArray23, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 366");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendHourOfHalfday(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
        int int4 = localDate3.getYearOfCentury();
        org.joda.time.LocalDate localDate6 = localDate3.plusMonths((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        long long21 = delegatedDateTimeField18.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = delegatedDateTimeField18.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder15.appendDecimal(dateTimeFieldType22, 173, 2562);
        try {
            org.joda.time.LocalDate localDate27 = localDate6.withField(dateTimeFieldType22, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 600010L + "'", long21 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        org.joda.time.DateTime dateTime8 = property6.setCopy((int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime10 = property6.setCopy("GJChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[UTC]\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime2.minusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime2.withDayOfYear((int) '4');
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readableDuration12);
        try {
            java.lang.String str15 = dateTime13.toString("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField11.getMaximumShortTextLength(locale12);
        try {
            long long16 = offsetDateTimeField11.set(0L, "20190615T223207Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"20190615T223207Z\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime5.centuryOfEra();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths(960);
//        org.joda.time.DateTime dateTime14 = dateTime10.minusMonths(17);
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
//        org.joda.time.DurationField durationField18 = buddhistChronology17.minutes();
//        org.joda.time.Partial partial19 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.Instant instant20 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime21 = partial19.toDateTime((org.joda.time.ReadableInstant) instant20);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime(dateTimeZone22);
//        java.lang.String str25 = dateTimeZone22.getName(0L);
//        org.joda.time.Chronology chronology26 = julianChronology15.withZone(dateTimeZone22);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone22);
//        org.joda.time.DateTime dateTime28 = dateTime10.withZone(dateTimeZone22);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Coordinated Universal Time" + "'", str25.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        long long14 = offsetDateTimeField11.roundFloor((long) 937);
        java.lang.String str15 = offsetDateTimeField11.getName();
        int int16 = offsetDateTimeField11.getMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "minuteOfHour" + "'", str15.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 78 + "'", int16 == 78);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime2.minusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime2.withDayOfYear((int) '4');
        org.joda.time.DateTime.Property property12 = dateTime2.minuteOfDay();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime2.plus(readableDuration13);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
//        java.io.Writer writer4 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
//        org.joda.time.DurationField durationField8 = buddhistChronology7.minutes();
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology7.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) buddhistChronology7);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone12);
//        org.joda.time.LocalDate localDate15 = localDate13.minusWeeks((int) (byte) -1);
//        long long17 = buddhistChronology7.set((org.joda.time.ReadablePartial) localDate13, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property18 = localDate13.yearOfEra();
//        org.joda.time.DateTime dateTime19 = localDate13.toDateTimeAtMidnight();
//        org.joda.time.LocalDate localDate21 = localDate13.plusDays((int) (byte) 0);
//        try {
//            dateTimeFormatter2.printTo(writer4, (org.joda.time.ReadablePartial) localDate21);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-15573946021999L) + "'", long17 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDate21);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "15");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        illegalFieldValueException2.prependMessage("UTC");
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial10 = partial8.minus(readablePeriod9);
        int[] intArray14 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology1.validate((org.joda.time.ReadablePartial) partial8, intArray14);
        org.joda.time.DateTimeField[] dateTimeFieldArray16 = partial8.getFields();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeFieldArray16);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property13 = localDate8.yearOfEra();
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime16 = dateTime14.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusMillis(100);
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean25 = cachedDateTimeZone17.equals((java.lang.Object) dateTimeZone18);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = buddhistChronology30.minutes();
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology30.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology30.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter28.withChronology((org.joda.time.Chronology) buddhistChronology30);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(dateTimeZone35);
//        org.joda.time.LocalDate localDate38 = localDate36.minusWeeks((int) (byte) -1);
//        long long40 = buddhistChronology30.set((org.joda.time.ReadablePartial) localDate36, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property41 = localDate36.yearOfEra();
//        org.joda.time.DateTime dateTime42 = localDate36.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime44 = dateTime42.withZoneRetainFields(dateTimeZone43);
//        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology26, dateTimeZone43);
//        java.lang.String str46 = zonedChronology45.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone48);
//        org.joda.time.DurationField durationField50 = buddhistChronology49.minutes();
//        org.joda.time.DateTimeField dateTimeField51 = buddhistChronology49.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField52 = buddhistChronology49.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter47.withChronology((org.joda.time.Chronology) buddhistChronology49);
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(dateTimeZone54);
//        org.joda.time.LocalDate localDate57 = localDate55.minusWeeks((int) (byte) -1);
//        long long59 = buddhistChronology49.set((org.joda.time.ReadablePartial) localDate55, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property60 = localDate55.yearOfEra();
//        org.joda.time.DateTime dateTime61 = localDate55.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime63 = dateTime61.withZoneRetainFields(dateTimeZone62);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone64 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone62);
//        org.joda.time.DateTimeZone dateTimeZone65 = cachedDateTimeZone64.getUncachedZone();
//        org.joda.time.Chronology chronology66 = zonedChronology45.withZone(dateTimeZone65);
//        try {
//            org.joda.time.Instant instant67 = new org.joda.time.Instant((java.lang.Object) zonedChronology45);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(buddhistChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-15573946021999L) + "'", long40 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(zonedChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str46.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNotNull(buddhistChronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-15573946021999L) + "'", long59 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone64);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(chronology66);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.Partial partial8 = partial6.minus(readablePeriod7);
        int[] intArray11 = new int[] { (byte) -1, (short) 1 };
        buddhistChronology1.validate((org.joda.time.ReadablePartial) partial6, intArray11);
        org.joda.time.DurationField durationField13 = buddhistChronology1.months();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone12);
        org.joda.time.LocalDate localDate15 = localDate13.plusMonths((int) (byte) 100);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.LocalDate localDate18 = localDate15.withPeriodAdded(readablePeriod16, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = buddhistChronology24.minutes();
        org.joda.time.Partial partial26 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology24);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.Partial partial28 = partial26.minus(readablePeriod27);
        int[] intArray31 = new int[] { (byte) -1, (short) 1 };
        buddhistChronology21.validate((org.joda.time.ReadablePartial) partial26, intArray31);
        try {
            int[] intArray34 = offsetDateTimeField11.addWrapPartial((org.joda.time.ReadablePartial) localDate15, 6, intArray31, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(partial28);
        org.junit.Assert.assertNotNull(intArray31);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property13 = localDate8.yearOfEra();
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime16 = dateTime14.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusMillis(100);
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean25 = cachedDateTimeZone17.equals((java.lang.Object) dateTimeZone18);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = buddhistChronology30.minutes();
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology30.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology30.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter28.withChronology((org.joda.time.Chronology) buddhistChronology30);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(dateTimeZone35);
//        org.joda.time.LocalDate localDate38 = localDate36.minusWeeks((int) (byte) -1);
//        long long40 = buddhistChronology30.set((org.joda.time.ReadablePartial) localDate36, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property41 = localDate36.yearOfEra();
//        org.joda.time.DateTime dateTime42 = localDate36.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime44 = dateTime42.withZoneRetainFields(dateTimeZone43);
//        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology26, dateTimeZone43);
//        java.lang.String str46 = zonedChronology45.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone48);
//        org.joda.time.DurationField durationField50 = buddhistChronology49.minutes();
//        org.joda.time.DateTimeField dateTimeField51 = buddhistChronology49.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField52 = buddhistChronology49.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter47.withChronology((org.joda.time.Chronology) buddhistChronology49);
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(dateTimeZone54);
//        org.joda.time.LocalDate localDate57 = localDate55.minusWeeks((int) (byte) -1);
//        long long59 = buddhistChronology49.set((org.joda.time.ReadablePartial) localDate55, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property60 = localDate55.yearOfEra();
//        org.joda.time.DateTime dateTime61 = localDate55.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime63 = dateTime61.withZoneRetainFields(dateTimeZone62);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone64 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone62);
//        org.joda.time.DateTimeZone dateTimeZone65 = cachedDateTimeZone64.getUncachedZone();
//        org.joda.time.Chronology chronology66 = zonedChronology45.withZone(dateTimeZone65);
//        try {
//            long long71 = zonedChronology45.getDateTimeMillis(2562, 3, 0, 960);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(buddhistChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-15573946021999L) + "'", long40 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(zonedChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str46.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNotNull(buddhistChronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-15573946021999L) + "'", long59 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone64);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(chronology66);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.Instant instant5 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime6 = partial4.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
//        java.lang.String str10 = dateTimeZone7.getName(0L);
//        org.joda.time.Chronology chronology11 = julianChronology0.withZone(dateTimeZone7);
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology13 = julianChronology12.withUTC();
//        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) chronology11, (java.lang.Object) chronology13);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 170);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = delegatedDateTimeField2.getAsText((long) (short) 10, locale4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate9 = localDate7.minusWeeks((int) (byte) -1);
        int int10 = localDate9.getYearOfCentury();
        org.joda.time.LocalDate localDate12 = localDate9.plusYears(0);
        org.joda.time.LocalDate.Property property13 = localDate9.centuryOfEra();
        int[] intArray19 = new int[] { (-101), 31, 78, (short) 1 };
        java.util.Locale locale21 = null;
        try {
            int[] intArray22 = delegatedDateTimeField2.set((org.joda.time.ReadablePartial) localDate9, 78, intArray19, "ISOChronology[UTC]", locale21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[UTC]\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(intArray19);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
//        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
//        boolean boolean5 = delegatedDateTimeField2.isLenient();
//        java.lang.String str6 = delegatedDateTimeField2.getName();
//        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
//        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
//        java.util.Locale locale12 = null;
//        int int13 = offsetDateTimeField11.getMaximumShortTextLength(locale12);
//        org.joda.time.DurationField durationField14 = offsetDateTimeField11.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone15);
//        org.joda.time.LocalDate localDate18 = localDate16.minusWeeks((int) (byte) -1);
//        int int19 = localDate18.getYearOfCentury();
//        org.joda.time.LocalDate localDate21 = localDate18.plusMonths((int) (short) 100);
//        org.joda.time.LocalDate localDate23 = localDate18.minusDays((int) (short) 10);
//        org.joda.time.LocalDate.Property property24 = localDate18.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(dateTimeZone26);
//        org.joda.time.LocalDate localDate29 = localDate27.minusWeeks((int) (byte) -1);
//        int int30 = localDate29.getYearOfCentury();
//        org.joda.time.LocalDate localDate32 = localDate29.plusMonths((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone35);
//        org.joda.time.DateTime dateTime38 = dateTime36.minusMillis(100);
//        int int39 = dateTimeZone33.getOffset((org.joda.time.ReadableInstant) dateTime36);
//        org.joda.time.DateTime dateTime40 = localDate29.toDateTimeAtStartOfDay(dateTimeZone33);
//        org.joda.time.LocalDate localDate42 = localDate29.withCenturyOfEra(0);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray43 = localDate42.getFieldTypes();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone45);
//        org.joda.time.DurationField durationField47 = buddhistChronology46.minutes();
//        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology46.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology46.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = dateTimeFormatter44.withChronology((org.joda.time.Chronology) buddhistChronology46);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate(dateTimeZone51);
//        org.joda.time.LocalDate localDate54 = localDate52.minusWeeks((int) (byte) -1);
//        long long56 = buddhistChronology46.set((org.joda.time.ReadablePartial) localDate52, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property57 = localDate52.yearOfEra();
//        org.joda.time.DateTime dateTime58 = localDate52.toDateTimeAtMidnight();
//        org.joda.time.LocalDate localDate60 = localDate52.plusMonths(0);
//        int[] intArray61 = localDate52.getValues();
//        org.joda.time.Partial partial62 = new org.joda.time.Partial(dateTimeFieldTypeArray43, intArray61);
//        try {
//            int[] intArray64 = offsetDateTimeField11.addWrapPartial((org.joda.time.ReadablePartial) localDate18, (int) (byte) -1, intArray61, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
//        org.junit.Assert.assertNull(durationField14);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 19 + "'", int30 == 19);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter50);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-15573946021999L) + "'", long56 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(localDate60);
//        org.junit.Assert.assertNotNull(intArray61);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        org.joda.time.DateTime dateTime9 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekyear(8);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "960" + "'", str8.equals("960"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(840L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 840 + "'", int1 == 840);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.minusWeeks((int) (byte) -1);
        org.joda.time.LocalDate.Property property4 = localDate1.yearOfEra();
        org.joda.time.LocalDate localDate5 = property4.roundHalfCeilingCopy();
        org.joda.time.DurationField durationField6 = property4.getDurationField();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField8 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) (byte) -1);
//        long long12 = buddhistChronology2.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 1);
//        org.joda.time.LocalDate.Property property13 = localDate8.yearOfEra();
//        org.joda.time.DateTime dateTime14 = localDate8.toDateTimeAtMidnight();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime16 = dateTime14.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusMillis(100);
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean25 = cachedDateTimeZone17.equals((java.lang.Object) dateTimeZone18);
//        java.lang.String str27 = cachedDateTimeZone17.getNameKey(0L);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = cachedDateTimeZone17.getName(0L, locale29);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone17, 366L, 21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 21");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-15573946021999L) + "'", long12 == (-15573946021999L));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UTC" + "'", str27.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Coordinated Universal Time" + "'", str30.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        java.lang.String str5 = delegatedDateTimeField2.getName();
        long long7 = delegatedDateTimeField2.roundFloor((long) 'a');
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField2.getMaximumTextLength(locale8);
        java.lang.String str11 = delegatedDateTimeField2.getAsText(35L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "minuteOfHour" + "'", str5.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        org.joda.time.DateTime.Property property7 = dateTime2.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = buddhistChronology7.minutes();
        org.joda.time.Partial partial9 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime11 = partial9.toDateTime((org.joda.time.ReadableInstant) instant10);
        boolean boolean12 = instant4.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Instant instant14 = instant4.plus(readableDuration13);
        org.joda.time.Instant instant17 = instant14.withDurationAdded(0L, (int) 'a');
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Instant instant19 = instant14.plus(readableDuration18);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(instant19);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.DateTime dateTime8 = dateTime4.withChronology((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime8.toMutableDateTimeISO();
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withMinuteOfHour(194);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 194 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = instant1.toInstant();
        boolean boolean3 = instant2.isEqualNow();
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTime();
        int int7 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "UTC", (int) (short) 100);
        try {
            org.joda.time.DateTime dateTime9 = dateTimeFormatter0.parseDateTime("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-101) + "'", int7 == (-101));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendSecondOfMinute(0);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        long long16 = delegatedDateTimeField13.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField13.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType17, (int) ' ', 21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder5.appendFractionOfHour(31, 2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 600010L + "'", long16 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-15573946021999L), (java.lang.Number) 173, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        java.lang.String str5 = buddhistChronology1.toString();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str5.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone32);
        org.joda.time.LocalDate localDate35 = localDate33.minusWeeks((int) (byte) -1);
        int int36 = localDate35.getYearOfCentury();
        org.joda.time.LocalDate localDate38 = localDate35.plusMonths((int) (short) 100);
        org.joda.time.LocalDate localDate40 = localDate35.minusDays((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone42);
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone45);
        org.joda.time.DurationField durationField47 = buddhistChronology46.minutes();
        org.joda.time.Partial partial48 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology46);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.Partial partial50 = partial48.minus(readablePeriod49);
        int[] intArray53 = new int[] { (byte) -1, (short) 1 };
        buddhistChronology43.validate((org.joda.time.ReadablePartial) partial48, intArray53);
        java.util.Locale locale56 = null;
        try {
            int[] intArray57 = unsupportedDateTimeField31.set((org.joda.time.ReadablePartial) localDate35, (int) (short) -1, intArray53, "GJChronology[UTC]", locale56);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 19 + "'", int36 == 19);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(partial50);
        org.junit.Assert.assertNotNull(intArray53);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.era();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
//        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
//        int int27 = dateTime7.get(dateTimeFieldType23);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
//        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone32);
//        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury(15);
//        int int36 = localDate33.getYearOfEra();
//        int int37 = localDate33.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property38 = localDate33.yearOfEra();
//        try {
//            int int39 = unsupportedDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) localDate33);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
//        org.junit.Assert.assertNotNull(property38);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-9223372036854771616L));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 10L, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField9);
        long long12 = skipUndoDateTimeField10.roundHalfCeiling(60264L);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField10.getAsShortText((long) 900, locale14);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "365" + "'", str15.equals("365"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        try {
            long long33 = unsupportedDateTimeField31.remainder((long) 173);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) -1, 928, 518);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = instant0.toInstant();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.DateTime dateTime4 = instant1.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = buddhistChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology7.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.minus(readableDuration14);
        org.joda.time.DateTime.Property property16 = dateTime13.dayOfWeek();
        try {
            org.joda.time.LocalDate localDate17 = dateTime13.toLocalDate();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Adding time zone offset caused overflow");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = buddhistChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology7.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField13 = skipUndoDateTimeField11.getWrappedField();
        java.lang.String str14 = skipUndoDateTimeField11.getName();
        org.joda.time.DurationField durationField15 = skipUndoDateTimeField11.getRangeDurationField();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        long long20 = delegatedDateTimeField18.roundFloor((-210865896000000L));
        boolean boolean21 = delegatedDateTimeField18.isLenient();
        java.lang.String str22 = delegatedDateTimeField18.getName();
        long long24 = delegatedDateTimeField18.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField25 = delegatedDateTimeField18.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField18, 19);
        java.lang.String str28 = offsetDateTimeField27.toString();
        long long30 = offsetDateTimeField27.roundFloor((long) 937);
        java.lang.String str31 = offsetDateTimeField27.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField27.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField15, dateTimeFieldType32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 366 + "'", int12 == 366);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "dayOfYear" + "'", str14.equals("dayOfYear"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210865896000000L) + "'", long20 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "minuteOfHour" + "'", str22.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 60000L + "'", long24 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str28.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "minuteOfHour" + "'", str31.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = buddhistChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.dayOfYear();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology3.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField7, 19);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField9.getAsShortText((long) (-1), locale11);
        boolean boolean14 = skipUndoDateTimeField9.isLeap((long) 960);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "15" + "'", str12.equals("15"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DurationField durationField7 = buddhistChronology4.millis();
        try {
            org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(285, 15, 173, (org.joda.time.Chronology) buddhistChronology4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(292278993, 549, 173, (int) (short) 0, 0, 349, 173);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 349 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTime.Property property5 = dateTime4.hourOfDay();
        org.joda.time.DateTime dateTime6 = dateTime4.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        int int13 = offsetDateTimeField11.getOffset();
        try {
            long long16 = offsetDateTimeField11.set(1560637919518L, 264);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 264 for minuteOfHour must be in the range [19,78]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            boolean boolean7 = partial3.isEqual(readablePartial6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        int int13 = offsetDateTimeField11.getOffset();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField11.getAsShortText(549, locale15);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "549" + "'", str16.equals("549"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) "dayOfYear", (java.lang.Object) (-1L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        try {
            org.joda.time.LocalTime localTime5 = dateTimeFormatter2.parseLocalTime("2019-06-15T22:32:15.679");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-1), (int) (byte) 100, 549, 19, 0, 928);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 928 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitYear(10, true);
        boolean boolean7 = julianChronology1.equals((java.lang.Object) dateTimeFormatterBuilder3);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((-1L), (org.joda.time.Chronology) julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        long long34 = unsupportedDateTimeField31.getDifferenceAsLong(0L, 840L);
        try {
            java.lang.String str36 = unsupportedDateTimeField31.getAsText((long) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        long long14 = offsetDateTimeField11.roundFloor((long) 937);
        int int15 = offsetDateTimeField11.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTime.Property property5 = dateTime4.hourOfDay();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsShortText(locale6);
        java.util.Locale locale8 = null;
        java.lang.String str9 = property5.getAsShortText(locale8);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "15" + "'", str9.equals("15"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendFractionOfMinute(549, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder17.appendMinuteOfDay(31);
        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatterBuilder17.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser26 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder5.append(dateTimePrinter25, dateTimeParser26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimePrinter25);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DurationField durationField5 = buddhistChronology1.days();
        org.joda.time.DurationField durationField6 = buddhistChronology1.days();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(937);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendCenturyOfEra(549, 349);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder16.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder16.appendMinuteOfDay(31);
        org.joda.time.format.DateTimePrinter dateTimePrinter24 = dateTimeFormatterBuilder16.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser25 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter24, dateTimeParser25);
        org.joda.time.format.DateTimeParser dateTimeParser27 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder10.append(dateTimePrinter24, dateTimeParser27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimePrinter24);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str3 = dateTimeZone1.getName((long) (short) 10);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((-1L), dateTimeZone1);
//        long long8 = dateTimeZone1.convertLocalToUTC(0L, true, 2277453240000000L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28800000L + "'", long8 == 28800000L);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendMinuteOfDay(31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatterBuilder12.toFormatter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendMillisOfSecond((-53));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("960", 4, (int) ' ', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for 960 must be in the range [32,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.addWrapField((long) 10, (int) (short) 10);
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField2.getAsShortText((long) 6, locale7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField2.getAsText((long) (short) 10, locale10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 600010L + "'", long5 == 600010L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        long long14 = offsetDateTimeField11.remainder((long) 10);
        long long16 = offsetDateTimeField11.roundHalfCeiling((long) '4');
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        try {
            org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Adding time zone offset caused overflow");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str2 = gJChronology1.toString();
        java.lang.String str3 = gJChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = buddhistChronology5.minutes();
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime9 = partial7.toDateTime((org.joda.time.ReadableInstant) instant8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = gJChronology1.withZone(dateTimeZone10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.hourOfHalfday();
        org.joda.time.DurationField durationField16 = iSOChronology13.halfdays();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime19.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay22 = dateTime19.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime19.toDateTime(dateTimeZone23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        long long39 = delegatedDateTimeField36.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = delegatedDateTimeField36.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder33.appendDecimal(dateTimeFieldType40, 173, 2562);
        int int44 = dateTime24.get(dateTimeFieldType40);
        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) (byte) 100, "");
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, durationField16, dateTimeFieldType40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(yearMonthDay22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 600010L + "'", long39 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        long long6 = delegatedDateTimeField2.roundHalfFloor(0L);
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField2.getAsText(0, locale8);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        boolean boolean13 = offsetDateTimeField11.isLeap(1560637904158L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (byte) 100, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(78, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendSecondOfDay((int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        long long34 = unsupportedDateTimeField31.getDifferenceAsLong(0L, 840L);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone35);
        org.joda.time.DurationField durationField37 = buddhistChronology36.minutes();
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology36.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField39 = buddhistChronology36.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone40);
        org.joda.time.DurationField durationField42 = buddhistChronology41.minutes();
        org.joda.time.Partial partial43 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology41);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.Partial partial45 = partial43.minus(readablePeriod44);
        int[] intArray49 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology36.validate((org.joda.time.ReadablePartial) partial43, intArray49);
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.Partial partial52 = partial43.minus(readablePeriod51);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone53);
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology57 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone56);
        org.joda.time.DurationField durationField58 = buddhistChronology57.minutes();
        org.joda.time.Partial partial59 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology57);
        org.joda.time.ReadablePeriod readablePeriod60 = null;
        org.joda.time.Partial partial61 = partial59.minus(readablePeriod60);
        int[] intArray64 = new int[] { (byte) -1, (short) 1 };
        buddhistChronology54.validate((org.joda.time.ReadablePartial) partial59, intArray64);
        try {
            int int66 = unsupportedDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) partial43, intArray64);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(partial45);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(partial52);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(buddhistChronology57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(partial61);
        org.junit.Assert.assertNotNull(intArray64);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        java.lang.String str5 = delegatedDateTimeField2.getName();
        long long7 = delegatedDateTimeField2.roundFloor((long) 'a');
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField2.getMaximumTextLength(locale8);
        boolean boolean10 = delegatedDateTimeField2.isSupported();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "minuteOfHour" + "'", str5.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DurationField durationField2 = julianChronology0.years();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 518);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000059954d + "'", double1 == 2440587.5000059954d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858379200000L) + "'", long1 == (-210858379200000L));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        org.joda.time.Chronology chronology4 = dateTimeFormatter3.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        org.joda.time.Interval interval9 = property6.toInterval();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "960" + "'", str8.equals("960"));
        org.junit.Assert.assertNotNull(interval9);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial10 = partial8.minus(readablePeriod9);
        int[] intArray14 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology1.validate((org.joda.time.ReadablePartial) partial8, intArray14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.Partial partial17 = partial8.minus(readablePeriod16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial8.minus(readablePeriod18);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(partial17);
        org.junit.Assert.assertNotNull(partial19);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(937);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendCenturyOfEra(549, 349);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder9.toFormatter();
        try {
            org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("2019-06-15", dateTimeFormatter10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        java.util.Date date1 = instant0.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = instant0.isSupported(dateTimeFieldType2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant0, readableInstant4);
        boolean boolean6 = instant0.isAfterNow();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMillis(100);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime8 = dateTime3.plusDays(937);
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime3.toYearMonthDay();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime3.plus(readablePeriod10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        try {
            org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Adding time zone offset caused overflow");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        org.joda.time.DateTime dateTime8 = dateTime4.withYearOfEra(3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        long long15 = delegatedDateTimeField12.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = delegatedDateTimeField12.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder9.appendDecimal(dateTimeFieldType16, 173, 2562);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 600010L + "'", long15 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNull(dateTimePrinter3);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime8 = partial6.toDateTime((org.joda.time.ReadableInstant) instant7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
        org.joda.time.Chronology chronology11 = gJChronology0.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology0.hourOfDay();
        org.joda.time.DurationField durationField13 = gJChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime dateTime18 = dateTime16.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime16.toYearMonthDay();
        org.joda.time.DateTime dateTime21 = dateTime16.withMonthOfYear((int) (short) 1);
        int int22 = dateTime21.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay28 = dateTime25.toYearMonthDay();
        org.joda.time.DateTime dateTime30 = dateTime25.withMonthOfYear((int) (short) 1);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime30);
        try {
            org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) dateTime21, (org.joda.time.ReadableDateTime) dateTime30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(yearMonthDay28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(17, 173, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 173 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology9 = julianChronology8.withUTC();
        org.joda.time.Chronology chronology10 = julianChronology8.withUTC();
        org.joda.time.DateTime dateTime11 = dateTime5.withChronology((org.joda.time.Chronology) julianChronology8);
        try {
            int int12 = dateTime11.getMinuteOfHour();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Adding time zone offset caused overflow");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        java.util.Date date1 = instant0.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = instant0.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) instant0);
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.DateTime.Property property7 = dateTime6.era();
        org.joda.time.DateMidnight dateMidnight8 = dateTime6.toDateMidnight();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateMidnight8);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        int int34 = unsupportedDateTimeField31.getDifference(0L, (-1L));
        int int37 = unsupportedDateTimeField31.getDifference((long) 900, 600010L);
        boolean boolean38 = unsupportedDateTimeField31.isLenient();
        java.util.Locale locale41 = null;
        try {
            long long42 = unsupportedDateTimeField31.set((long) 2019, "yearOfEra", locale41);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-9) + "'", int37 == (-9));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.Partial partial8 = partial5.withFieldAdded(durationFieldType6, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(partial5);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField9);
        int int11 = skipUndoDateTimeField10.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField12 = skipUndoDateTimeField10.getWrappedField();
        java.lang.String str13 = skipUndoDateTimeField10.getName();
        org.joda.time.DurationField durationField14 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField10.getAsShortText((long) (byte) -1, locale16);
        java.lang.String str18 = skipUndoDateTimeField10.getName();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 366 + "'", int11 == 366);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "dayOfYear" + "'", str13.equals("dayOfYear"));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "365" + "'", str17.equals("365"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "dayOfYear" + "'", str18.equals("dayOfYear"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = null;
        int[] intArray6 = new int[] { 170, 285, 15, 518, 365 };
        try {
            org.joda.time.Partial partial7 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMillis(100);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime8 = dateTime3.plusDays(937);
        boolean boolean9 = dateTime8.isAfterNow();
        org.joda.time.DateTime dateTime11 = dateTime8.minusMillis(78);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str14 = gJChronology13.toString();
        java.lang.String str15 = gJChronology13.toString();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = buddhistChronology17.minutes();
        org.joda.time.Partial partial19 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime21 = partial19.toDateTime((org.joda.time.ReadableInstant) instant20);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime(dateTimeZone22);
        org.joda.time.Chronology chronology24 = gJChronology13.withZone(dateTimeZone22);
        org.joda.time.Chronology chronology25 = julianChronology12.withZone(dateTimeZone22);
        try {
            org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((java.lang.Object) 78, (org.joda.time.Chronology) julianChronology12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GJChronology[UTC]" + "'", str14.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GJChronology[UTC]" + "'", str15.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(chronology25);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 1560637919518L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.secondOfDay();
        java.lang.String str3 = buddhistChronology1.toString();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTime.Property property5 = dateTime4.hourOfDay();
        int int6 = dateTime4.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 900 + "'", int6 == 900);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime5.centuryOfEra();
        java.lang.String str9 = property8.getAsText();
        org.joda.time.DateTime dateTime10 = property8.roundFloorCopy();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2922750" + "'", str9.equals("2922750"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        int int34 = unsupportedDateTimeField31.getDifference(0L, (-1L));
        int int37 = unsupportedDateTimeField31.getDifference((long) 900, 600010L);
        try {
            long long39 = unsupportedDateTimeField31.roundHalfFloor(3119999L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-9) + "'", int37 == (-9));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendFractionOfMinute(549, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder5.appendFractionOfDay(900, 0);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime17.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateTime17.toDateTime(dateTimeZone21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology32.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        long long37 = delegatedDateTimeField34.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = delegatedDateTimeField34.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder31.appendDecimal(dateTimeFieldType38, 173, 2562);
        int int42 = dateTime22.get(dateTimeFieldType38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder14.appendDecimal(dateTimeFieldType38, 366, 668);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder14.appendDayOfWeek(365);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(yearMonthDay20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 600010L + "'", long37 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField11.getMaximumShortTextLength(locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField11.getLeapDurationField();
        long long17 = offsetDateTimeField11.addWrapField(0L, (int) (byte) 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField11.getDurationField();
        long long20 = offsetDateTimeField11.roundHalfCeiling(35L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 60000L + "'", long17 == 60000L);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime5.centuryOfEra();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readableDuration9);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.DateTime dateTime13 = dateTime5.withFieldAdded(durationFieldType11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 2562);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = buddhistChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.dayOfYear();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology3.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField7, 19);
        boolean boolean10 = skipUndoDateTimeField9.isLenient();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfWeek();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = gJChronology0.get(readablePeriod4, (-15573946021999L), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        java.util.Date date1 = instant0.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = instant0.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) instant0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime10 = partial8.toDateTime((org.joda.time.ReadableInstant) instant9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime(dateTimeZone11);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime4.toMutableDateTime(dateTimeZone11);
        boolean boolean15 = dateTime4.equals((java.lang.Object) "hi!");
        org.joda.time.DateTime dateTime17 = dateTime4.withMillisOfSecond((int) (short) 10);
        try {
            org.joda.time.DateTime dateTime19 = dateTime17.withHourOfDay(173);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 173 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.DurationField durationField5 = buddhistChronology1.minutes();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime2.minusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime2.withDayOfYear((int) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.withYearOfEra((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        long long4 = copticChronology0.add((long) (short) 0, 60264L, 668);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 40256352L + "'", long4 == 40256352L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        long long34 = unsupportedDateTimeField31.getDifferenceAsLong(0L, 840L);
        java.lang.String str35 = unsupportedDateTimeField31.getName();
        java.util.Locale locale36 = null;
        try {
            int int37 = unsupportedDateTimeField31.getMaximumTextLength(locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "minuteOfHour" + "'", str35.equals("minuteOfHour"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime8 = partial6.toDateTime((org.joda.time.ReadableInstant) instant7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
        org.joda.time.Chronology chronology11 = gJChronology0.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology0.hourOfDay();
        org.joda.time.DurationField durationField13 = gJChronology0.days();
        long long16 = durationField13.subtract((long) 173, (long) 194);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-16761599827L) + "'", long16 == (-16761599827L));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = unsupportedDateTimeField31.getAsText(8, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime2.minusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime2.plusWeeks((int) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.withSecondOfMinute(2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        long long14 = offsetDateTimeField11.roundFloor((long) 937);
        java.lang.String str16 = offsetDateTimeField11.getAsText((long) 19);
        boolean boolean17 = offsetDateTimeField11.isSupported();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime8 = partial6.toDateTime((org.joda.time.ReadableInstant) instant7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
        org.joda.time.Chronology chronology11 = gJChronology0.withZone(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        try {
            org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        int int34 = unsupportedDateTimeField31.getDifference(0L, (-1L));
        int int37 = unsupportedDateTimeField31.getDifference((long) 900, 600010L);
        boolean boolean38 = unsupportedDateTimeField31.isLenient();
        try {
            java.lang.String str40 = unsupportedDateTimeField31.getAsText(349L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-9) + "'", int37 == (-9));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsShortText(locale7);
        org.joda.time.DateTimeField dateTimeField9 = property6.getField();
        org.joda.time.DateTime dateTime11 = property6.addToCopy(2019);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "960" + "'", str8.equals("960"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField2, 840, 3, 389);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 840 for minuteOfHour must be in the range [3,389]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(928, 3, (int) (byte) 10, (org.joda.time.Chronology) julianChronology3);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray9 = new int[] { (-101), 15 };
        try {
            julianChronology3.validate(readablePartial6, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMillis(100);
        int int6 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime8 = dateTime3.plusDays(937);
        org.joda.time.DateTime.Property property9 = dateTime3.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = buddhistChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.dayOfYear();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = skipUndoDateTimeField8.getAsShortText(readablePartial9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = buddhistChronology9.minutes();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology9.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology9.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology4, dateTimeField12);
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology4.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        long long18 = buddhistChronology4.add(readablePeriod15, (long) (byte) -1, 2);
        try {
            org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(24, 0, 840, (org.joda.time.Chronology) buddhistChronology4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        java.util.Date date1 = instant0.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = instant0.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) instant0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime10 = partial8.toDateTime((org.joda.time.ReadableInstant) instant9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime(dateTimeZone11);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime4.toMutableDateTime(dateTimeZone11);
        boolean boolean15 = dateTime4.equals((java.lang.Object) "hi!");
        org.joda.time.DateTime dateTime17 = dateTime4.withMillisOfSecond((int) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime4.plusYears(10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendSecondOfDay(285);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendYear(389, 78);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = unsupportedDateTimeField31.getAsText(1560637919518L, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        try {
            org.joda.time.DateTime dateTime2 = dateTime0.minusHours(24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Adding time zone offset caused overflow");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        int int34 = unsupportedDateTimeField31.getDifference(0L, (-1L));
        int int37 = unsupportedDateTimeField31.getDifference((long) 900, 600010L);
        try {
            long long39 = unsupportedDateTimeField31.roundHalfCeiling((long) 365);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-9) + "'", int37 == (-9));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendDayOfYear(802);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MutableDateTime mutableDateTime2 = dateTime1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("dayOfYear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"dayOfYear\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField9);
        long long12 = skipUndoDateTimeField10.roundHalfCeiling(60264L);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = buddhistChronology14.minutes();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = buddhistChronology19.minutes();
        org.joda.time.Partial partial21 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology19);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.Partial partial23 = partial21.minus(readablePeriod22);
        int[] intArray27 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology14.validate((org.joda.time.ReadablePartial) partial21, intArray27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.Partial partial30 = partial21.minus(readablePeriod29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.Partial partial32 = partial21.plus(readablePeriod31);
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = skipUndoDateTimeField10.getAsText((org.joda.time.ReadablePartial) partial32, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfYear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(partial23);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(partial30);
        org.junit.Assert.assertNotNull(partial32);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime3.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.toDateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime3.minusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime12 = dateTime3.plusWeeks((int) (short) 10);
        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone15);
        org.joda.time.DateTime dateTime18 = dateTime16.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime16.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime16.toDateTime(dateTimeZone20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
        org.joda.time.DateTime.Property property24 = dateTime23.dayOfWeek();
        boolean boolean25 = dateMidnight13.isAfter((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder26.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology35.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
        long long40 = delegatedDateTimeField37.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField37.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder34.appendDecimal(dateTimeFieldType41, 173, 2562);
        boolean boolean45 = dateMidnight13.isSupported(dateTimeFieldType41);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField47 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType41, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 600010L + "'", long40 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("BuddhistChronology[America/Los_Angeles]", 6, 365, 17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 6 for BuddhistChronology[America/Los_Angeles] must be in the range [365,17]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        int int34 = unsupportedDateTimeField31.getDifference(0L, (-1L));
        int int37 = unsupportedDateTimeField31.getDifference((long) 900, 600010L);
        boolean boolean38 = unsupportedDateTimeField31.isLenient();
        org.joda.time.DurationField durationField39 = unsupportedDateTimeField31.getLeapDurationField();
        try {
            long long41 = unsupportedDateTimeField31.roundHalfCeiling(35L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-9) + "'", int37 == (-9));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(durationField39);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField11.getMaximumShortTextLength(locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField11.getLeapDurationField();
        long long17 = offsetDateTimeField11.addWrapField(0L, (int) (byte) 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField11.getDurationField();
        org.joda.time.DurationFieldType durationFieldType19 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField21 = new org.joda.time.field.ScaledDurationField(durationField18, durationFieldType19, 366);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 60000L + "'", long17 == 60000L);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 802);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000092825d + "'", double1 == 2440587.5000092825d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.year();
        try {
            long long13 = buddhistChronology1.getDateTimeMillis(24, 389, (int) ' ', (int) (byte) 0, (int) (short) 10, (int) (byte) 0, 937);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 389 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(78, (-53));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-4134) + "'", int2 == (-4134));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 10, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1000L + "'", long2 == 1000L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        long long14 = offsetDateTimeField11.roundFloor((long) 937);
        java.lang.String str15 = offsetDateTimeField11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField11.getType();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = offsetDateTimeField11.getMaximumValue(readablePartial17);
        int int19 = offsetDateTimeField11.getOffset();
        try {
            long long22 = offsetDateTimeField11.set(35L, "����-��-��");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"����-��-��\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "minuteOfHour" + "'", str15.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 78 + "'", int18 == 78);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime2.minusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime2.plusWeeks((int) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime2.minusMonths(0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        java.util.Date date1 = instant0.toDate();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.fromDateFields(date1);
        try {
            org.joda.time.LocalDate localDate4 = localDate2.withDayOfWeek((-9));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(localDate2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(194);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfSecond(4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, (-53));
        org.joda.time.DateTime dateTime14 = dateTime9.withEra((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("2019-06-15T22:32:05.045", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("549");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"549/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@53d9f80");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.Partial partial10 = partial8.minus(readablePeriod9);
        int[] intArray14 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology1.validate((org.joda.time.ReadablePartial) partial8, intArray14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology1.era();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(partial10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        java.util.Date date1 = instant0.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = instant0.isSupported(dateTimeFieldType2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant0, readableInstant4);
        org.joda.time.DateTime dateTime6 = instant0.toDateTime();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.DateTime.Property property6 = dateTime4.secondOfDay();
        int int7 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property8 = dateTime4.era();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        boolean boolean6 = dateTime2.isBefore((-210865896000000L));
        int int7 = dateTime2.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime2.minusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime2.plusWeeks((int) (short) 10);
        boolean boolean12 = dateTime2.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField9);
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology1.dayOfMonth();
        java.lang.String str12 = buddhistChronology1.toString();
        java.lang.String str13 = buddhistChronology1.toString();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str12.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str13.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
//        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.Instant instant5 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime6 = partial4.toDateTime((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(dateTimeZone7);
//        java.lang.String str10 = dateTimeZone7.getName(0L);
//        org.joda.time.Chronology chronology11 = julianChronology0.withZone(dateTimeZone7);
//        long long15 = dateTimeZone7.convertLocalToUTC((long) 173, false, (long) '#');
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 173L + "'", long15 == 173L);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = instant0.toInstant();
        boolean boolean2 = instant1.isEqualNow();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.String str4 = instant1.toString(dateTimeFormatter3);
        org.joda.time.Instant instant5 = instant1.toInstant();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withChronology(chronology7);
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        java.util.Date date10 = instant9.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = instant9.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) instant9);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = buddhistChronology15.minutes();
        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology15);
        org.joda.time.Instant instant18 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime19 = partial17.toDateTime((org.joda.time.ReadableInstant) instant18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime22 = dateTime13.toMutableDateTime(dateTimeZone20);
        int int25 = dateTimeFormatter6.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime22, "0", (int) '4');
        java.lang.String str26 = instant5.toString(dateTimeFormatter6);
        long long27 = instant5.getMillis();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-2922750550516T164708Z" + "'", str4.equals("-2922750550516T164708Z"));
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-53) + "'", int25 == (-53));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "-292275055-05-16T16:47:08.384" + "'", str26.equals("-292275055-05-16T16:47:08.384"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-9223372036854771616L) + "'", long27 == (-9223372036854771616L));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        int int8 = delegatedDateTimeField2.get((long) (-53));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 600010L + "'", long5 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = buddhistChronology7.minutes();
        org.joda.time.Partial partial9 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime11 = partial9.toDateTime((org.joda.time.ReadableInstant) instant10);
        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property13 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime15 = dateTime11.withMillisOfSecond(349);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime18.minusMillis(100);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = buddhistChronology22.minutes();
        org.joda.time.DateTime dateTime24 = dateTime20.withChronology((org.joda.time.Chronology) buddhistChronology22);
        org.joda.time.DateTime.Property property25 = dateTime24.weekOfWeekyear();
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.ReadableDateTime) dateTime15, (org.joda.time.ReadableDateTime) dateTime24);
        try {
            long long32 = limitChronology26.getDateTimeMillis((long) 2019, (-1), 365, 8, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is above the supported maximum of 2512-12-31T15:59:59.900-08:00 (BuddhistChronology[America/Los_Angeles])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9223372036854771616L) + "'", long12 == (-9223372036854771616L));
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(limitChronology26);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        int int34 = unsupportedDateTimeField31.getDifference(0L, (-1L));
        try {
            int int36 = unsupportedDateTimeField31.getMinimumValue(1560637905681L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime2.minusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime2.withDayOfYear((int) '4');
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.plusHours(8);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (byte) 100, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(0, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        int int34 = unsupportedDateTimeField31.getDifference(0L, (-1L));
        int int37 = unsupportedDateTimeField31.getDifference((long) 900, 600010L);
        boolean boolean38 = unsupportedDateTimeField31.isLenient();
        org.joda.time.Partial partial39 = new org.joda.time.Partial();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone40);
        org.joda.time.DurationField durationField42 = buddhistChronology41.minutes();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology41.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology41.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone45);
        org.joda.time.DurationField durationField47 = buddhistChronology46.minutes();
        org.joda.time.Partial partial48 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology46);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.Partial partial50 = partial48.minus(readablePeriod49);
        int[] intArray54 = new int[] { (byte) 10, '4', 0 };
        buddhistChronology41.validate((org.joda.time.ReadablePartial) partial48, intArray54);
        try {
            int int56 = unsupportedDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) partial39, intArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-9) + "'", int37 == (-9));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(partial50);
        org.junit.Assert.assertNotNull(intArray54);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        long long14 = offsetDateTimeField11.roundFloor((long) 937);
        java.lang.String str15 = offsetDateTimeField11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField11.getType();
        long long18 = offsetDateTimeField11.roundHalfEven((long) '4');
        org.joda.time.DurationField durationField19 = offsetDateTimeField11.getLeapDurationField();
        java.util.Locale locale22 = null;
        try {
            long long23 = offsetDateTimeField11.set((long) 928, "yearOfEra", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"yearOfEra\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "minuteOfHour" + "'", str15.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNull(durationField19);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology(chronology8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withDefaultYear(928);
        java.lang.String str12 = dateTime4.toString(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31T15:59:59.900" + "'", str12.equals("1969-12-31T15:59:59.900"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.minutes();
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology2.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = buddhistChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology7.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.minus(readableDuration14);
        org.joda.time.DateTime.Property property16 = dateTime13.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime18 = dateTime13.withWeekyear((-4134));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000-07:52:58 (BuddhistChronology[America/Los_Angeles])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        long long14 = offsetDateTimeField11.remainder((long) 10);
        long long16 = offsetDateTimeField11.roundHalfFloor((long) 366);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        int int34 = unsupportedDateTimeField31.getDifference(0L, (-1L));
        int int37 = unsupportedDateTimeField31.getDifference((long) 900, 600010L);
        boolean boolean38 = unsupportedDateTimeField31.isLenient();
        org.joda.time.DurationField durationField39 = unsupportedDateTimeField31.getLeapDurationField();
        try {
            long long41 = unsupportedDateTimeField31.roundHalfEven((long) (-101));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-9) + "'", int37 == (-9));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(durationField39);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitYear(10, true);
        boolean boolean6 = julianChronology0.equals((java.lang.Object) dateTimeFormatterBuilder2);
        org.joda.time.Chronology chronology7 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(840L, 60000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-59160L) + "'", long2 == (-59160L));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        int int7 = copticChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = buddhistChronology9.minutes();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology9.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology9.dayOfYear();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology9.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology6, dateTimeField13);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(17, 17, (int) ' ', 349, 960, (int) (short) 100, (org.joda.time.Chronology) copticChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 349 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        java.util.Locale locale32 = null;
        try {
            int int33 = unsupportedDateTimeField31.getMaximumShortTextLength(locale32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.DateTime dateTime8 = dateTime4.withChronology((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime8.toMutableDateTimeISO();
        int int11 = dateTime8.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57599 + "'", int11 == 57599);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.hours();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField4 = new org.joda.time.field.ScaledDurationField(durationField1, durationFieldType2, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology9 = julianChronology8.withUTC();
        org.joda.time.Chronology chronology10 = julianChronology8.withUTC();
        org.joda.time.DateTime dateTime11 = dateTime5.withChronology((org.joda.time.Chronology) julianChronology8);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
        try {
            org.joda.time.DateTime dateTime15 = dateTime13.withYearOfEra(17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Adding time zone offset caused overflow");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("UTC", (java.lang.Number) 1560637897829L, (java.lang.Number) (byte) 100, number3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        int int34 = unsupportedDateTimeField31.getDifference(0L, (-1L));
        int int37 = unsupportedDateTimeField31.getDifference((long) 900, 600010L);
        try {
            long long39 = unsupportedDateTimeField31.roundFloor(60000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-9) + "'", int37 == (-9));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = buddhistChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.dayOfYear();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology3.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField7, 19);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField9.getAsShortText((long) (-1), locale11);
        try {
            long long15 = skipUndoDateTimeField9.add(0L, 9223372036854775807L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 9223372036854775807 * 3600000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "15" + "'", str12.equals("15"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime2.minusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime2.withDayOfYear((int) '4');
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readableDuration12);
        int int14 = dateTime11.getDayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime11.getZone();
        boolean boolean17 = dateTime11.isBefore((long) 15);
        int int18 = dateTime11.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime21 = dateTime11.withDurationAdded(readableDuration19, 100);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 21 + "'", int14 == 21);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        long long14 = offsetDateTimeField11.roundFloor((long) 937);
        java.lang.String str15 = offsetDateTimeField11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField11.getType();
        org.joda.time.Partial partial18 = new org.joda.time.Partial(dateTimeFieldType16, 24);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        try {
            org.joda.time.Partial partial21 = partial18.withFieldAdded(durationFieldType19, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "minuteOfHour" + "'", str15.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField11.getMaximumShortTextLength(locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField11.getLeapDurationField();
        long long17 = offsetDateTimeField11.addWrapField(0L, (int) (byte) 1);
        org.joda.time.DurationField durationField18 = offsetDateTimeField11.getDurationField();
        int int21 = offsetDateTimeField11.getDifference(349L, (long) 2019);
        long long23 = offsetDateTimeField11.roundHalfFloor(1560637930749L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 60000L + "'", long17 == 60000L);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560637920000L + "'", long23 == 1560637920000L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.DateTime dateTime8 = dateTime4.withChronology((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        try {
            int[] intArray11 = buddhistChronology6.get(readablePeriod9, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField9);
        int int11 = skipUndoDateTimeField10.getMaximumValue();
        long long14 = skipUndoDateTimeField10.add((long) 15, 0L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField10.getAsShortText((int) (byte) 0, locale16);
        long long19 = skipUndoDateTimeField10.roundHalfFloor(100L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 366 + "'", int11 == 366);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 15L + "'", long14 == 15L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 349);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, dateTimeZone1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(389);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Adding time zone offset caused overflow");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        int int6 = dateTime2.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600000 + "'", int6 == 57600000);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        long long14 = offsetDateTimeField11.roundFloor((long) 937);
        java.lang.String str15 = offsetDateTimeField11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField11.getType();
        long long18 = offsetDateTimeField11.roundHalfEven((long) '4');
        org.joda.time.DurationField durationField19 = offsetDateTimeField11.getLeapDurationField();
        long long21 = offsetDateTimeField11.roundHalfEven((long) 6);
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField11.getMaximumShortTextLength(locale22);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "minuteOfHour" + "'", str15.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        long long5 = delegatedDateTimeField3.roundFloor((-210865896000000L));
        boolean boolean6 = delegatedDateTimeField3.isLenient();
        long long9 = delegatedDateTimeField3.set((long) (short) 100, (int) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) delegatedDateTimeField3, 4);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-210865896000000L) + "'", long5 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 600100L + "'", long9 == 600100L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        java.lang.String str2 = instant0.toString(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-292275055-05-16T16:47:08.384Z" + "'", str2.equals("-292275055-05-16T16:47:08.384Z"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str2 = gJChronology1.toString();
        java.lang.String str3 = gJChronology1.toString();
        org.joda.time.DurationField durationField4 = gJChronology1.years();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime7.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime7.toDateTime(dateTimeZone11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        long long27 = delegatedDateTimeField24.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField24.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder21.appendDecimal(dateTimeFieldType28, 173, 2562);
        int int32 = dateTime12.get(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone33);
        org.joda.time.DurationField durationField35 = buddhistChronology34.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField35);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField4, dateTimeFieldType28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 600010L + "'", long27 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.secondOfMinute();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        java.util.Date date9 = dateTime8.toDate();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036854771616L) + "'", long6 == (-9223372036854771616L));
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendMinuteOfDay(31);
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatterBuilder5.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder5.appendSecondOfMinute(264);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder5.appendWeekyear(2, 1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder5.appendMinuteOfHour((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = buddhistChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipUndoDateTimeField10.getAsShortText((long) 937, locale12);
        org.joda.time.DateTimeField dateTimeField14 = skipUndoDateTimeField10.getWrappedField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendTwoDigitWeekyear(937);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder18.appendCenturyOfEra(549, 349);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder29.appendFractionOfMinute(549, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder29.appendFractionOfDay(900, 0);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone40);
        org.joda.time.DateTime dateTime43 = dateTime41.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay44 = dateTime41.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTime dateTime46 = dateTime41.toDateTime(dateTimeZone45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder47.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder50.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder52.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField57 = gJChronology56.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField58 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField57);
        long long61 = delegatedDateTimeField58.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = delegatedDateTimeField58.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder55.appendDecimal(dateTimeFieldType62, 173, 2562);
        int int66 = dateTime46.get(dateTimeFieldType62);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder38.appendDecimal(dateTimeFieldType62, 366, 668);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder18.appendFixedSignedDecimal(dateTimeFieldType62, 668);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType62, 0, 0, (-101));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "365" + "'", str13.equals("365"));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(yearMonthDay44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(gJChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 600010L + "'", long61 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial3.minus(readablePeriod4);
        int int6 = partial5.size();
        try {
            int int8 = partial5.getValue(57599);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57599");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.clockhourOfDay();
        org.joda.time.DurationField durationField5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendSecondOfMinute(0);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder11.appendSignedDecimal(dateTimeFieldType23, (int) ' ', 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, durationField5, dateTimeFieldType23, 292278993);
        java.lang.String str29 = remainderDateTimeField28.getName();
        try {
            long long32 = remainderDateTimeField28.addWrapField((long) (-101), (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 47 for clockhourOfDay must be in the range [1,24]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "minuteOfHour" + "'", str29.equals("minuteOfHour"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        int int34 = unsupportedDateTimeField31.getDifference(0L, (-1L));
        int int37 = unsupportedDateTimeField31.getDifference((long) 900, 600010L);
        boolean boolean38 = unsupportedDateTimeField31.isLenient();
        java.util.Locale locale40 = null;
        try {
            java.lang.String str41 = unsupportedDateTimeField31.getAsText((long) 0, locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-9) + "'", int37 == (-9));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime11.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.toDateTime(dateTimeZone15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        long long31 = delegatedDateTimeField28.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = delegatedDateTimeField28.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder25.appendDecimal(dateTimeFieldType32, 173, 2562);
        int int36 = dateTime16.get(dateTimeFieldType32);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) (byte) 100, "");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType32, 173, (int) (short) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder42.appendFractionOfSecond((int) (byte) -1, 802);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 600010L + "'", long31 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime2.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime2.withMillis((long) 2019);
        int int10 = dateTime9.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        boolean boolean5 = delegatedDateTimeField2.isLenient();
        java.lang.String str6 = delegatedDateTimeField2.getName();
        long long8 = delegatedDateTimeField2.roundCeiling((long) 10);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, 19);
        java.lang.String str12 = offsetDateTimeField11.toString();
        int int13 = offsetDateTimeField11.getOffset();
        long long15 = offsetDateTimeField11.roundCeiling(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "minuteOfHour" + "'", str6.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str12.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("CopticChronology[America/Los_Angeles]", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime5 = partial3.toDateTime((org.joda.time.ReadableInstant) instant4);
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.secondOfMinute();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.plus(readablePeriod8);
        boolean boolean11 = dateTime5.isBefore((long) (byte) 100);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9223372036854771616L) + "'", long6 == (-9223372036854771616L));
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("2019-06-15T22:32:15.679", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15T22:32:15.679\" is malformed at \"19-06-15T22:32:15.679\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 0, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(100);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(10, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear(900);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfEra((int) ' ', (int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        long long22 = delegatedDateTimeField19.addWrapField((long) 10, (int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType23, 173, 2562);
        int int27 = dateTime7.get(dateTimeFieldType23);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = buddhistChronology29.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        int int34 = unsupportedDateTimeField31.getDifference(0L, (-1L));
        try {
            java.lang.String str36 = unsupportedDateTimeField31.getAsText(2277453240000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfHour field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 600010L + "'", long22 == 600010L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(937);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMinuteOfDay(19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundFloor((-210865896000000L));
        java.lang.String str5 = delegatedDateTimeField2.getName();
        long long7 = delegatedDateTimeField2.roundFloor((long) 'a');
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField2.getMaximumTextLength(locale8);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField2.getRangeDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-210865896000000L) + "'", long4 == (-210865896000000L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "minuteOfHour" + "'", str5.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(durationField10);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName(1560637904054L, locale2);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, 600010L, 900);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 900");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str2 = gJChronology1.toString();
        java.lang.String str3 = gJChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = buddhistChronology5.minutes();
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime9 = partial7.toDateTime((org.joda.time.ReadableInstant) instant8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology12 = gJChronology1.withZone(dateTimeZone10);
        org.joda.time.Chronology chronology13 = julianChronology0.withZone(dateTimeZone10);
        try {
            org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (byte) 100, "[]");
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(1, '#', 31, (-1), (int) '4', false, (int) (short) -1);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Coordinated Universal Time", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.joda.time.DurationField durationField3 = julianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.era();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@53d9f80");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.millisOfSecond();
        org.joda.time.DurationField durationField4 = buddhistChronology1.hours();
        org.joda.time.Chronology chronology5 = buddhistChronology1.withUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.plusMillis(549);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000-07:52:58 (BuddhistChronology[America/Los_Angeles])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        java.lang.String str2 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = buddhistChronology4.minutes();
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime8 = partial6.toDateTime((org.joda.time.ReadableInstant) instant7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
        org.joda.time.Chronology chronology11 = gJChronology0.withZone(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = buddhistChronology14.minutes();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.millisOfSecond();
        org.joda.time.DurationField durationField17 = buddhistChronology14.hours();
        boolean boolean18 = iSOChronology12.equals((java.lang.Object) durationField17);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.minutes();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 960);
        boolean boolean7 = offsetDateTimeField6.isSupported();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }
}

