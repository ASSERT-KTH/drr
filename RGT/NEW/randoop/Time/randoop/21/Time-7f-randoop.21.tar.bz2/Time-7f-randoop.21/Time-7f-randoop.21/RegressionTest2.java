import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        int int11 = dateTime7.getSecondOfDay();
        long long12 = dateTime7.getMillis();
        try {
            org.joda.time.DateTime dateTime14 = dateTime7.withDayOfMonth(33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 33 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57599 + "'", int11 == 57599);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime15.weekyear();
        mutableDateTime15.setMinuteOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-35125664235L));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.weeks();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (long) (-1), 1);
        org.joda.time.Instant instant9 = gJChronology8.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
        long long14 = dateTimeZone11.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter2.withZone(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone11);
        org.joda.time.Chronology chronology19 = zonedChronology18.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology21 = dateTimeFormatter20.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (long) (-1), 1);
        org.joda.time.Instant instant27 = gJChronology26.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter22.withChronology((org.joda.time.Chronology) gJChronology26);
        org.joda.time.DateTimeZone dateTimeZone29 = gJChronology26.getZone();
        long long32 = dateTimeZone29.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter20.withZone(dateTimeZone29);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.Chronology chronology36 = zonedChronology18.withZone(dateTimeZone29);
        org.joda.time.DurationField durationField37 = zonedChronology18.millis();
        org.joda.time.DateTimeField dateTimeField38 = zonedChronology18.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(instant27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test06");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
//        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone8.getName(1L, locale13);
//        org.joda.time.Chronology chronology15 = julianChronology0.withZone(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField16 = julianChronology0.halfdayOfDay();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pacific Standard Time" + "'", str14.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology6.getZone();
        long long12 = dateTimeZone9.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone9);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.year();
        org.joda.time.MutableDateTime mutableDateTime15 = property14.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.secondOfDay();
        mutableDateTime15.setDayOfYear((int) 'a');
        org.joda.time.ReadableDuration readableDuration19 = null;
        mutableDateTime15.add(readableDuration19, (int) '4');
        int int24 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime15, "16:00:00-08:00", 2);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime15.secondOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (long) (-1), 1);
        org.joda.time.Instant instant32 = gJChronology31.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) gJChronology31);
        org.joda.time.DateTimeZone dateTimeZone34 = gJChronology31.getZone();
        long long37 = dateTimeZone34.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone34);
        int int39 = mutableDateTime38.getDayOfMonth();
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField41 = buddhistChronology40.months();
        java.lang.String str42 = buddhistChronology40.toString();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology40.secondOfDay();
        mutableDateTime38.setRounding(dateTimeField43);
        mutableDateTime15.setTime((org.joda.time.ReadableInstant) mutableDateTime38);
        mutableDateTime38.setDayOfYear(33);
        mutableDateTime38.setYear(97);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-3) + "'", int24 == (-3));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(instant32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 31 + "'", int39 == 31);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "BuddhistChronology[UTC]" + "'", str42.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField43);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(59, (int) (byte) 1, (int) (short) 10, 0, (int) '#', (int) '4', (org.joda.time.Chronology) julianChronology6);
        java.lang.String str8 = julianChronology6.toString();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.dayOfYear();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology6.year();
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JulianChronology[UTC]" + "'", str8.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
        mutableDateTime20.addYears(0);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime20);
        mutableDateTime20.setMillis((long) (byte) 100);
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime20.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime28 = property26.addWrapField(4);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(mutableDateTime28);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.halfdays();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        long long16 = delegatedDateTimeField13.add(207356400010L, (int) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField13);
        org.joda.time.DateTimeField dateTimeField18 = skipDateTimeField17.getWrappedField();
        int int19 = skipDateTimeField17.getMinimumValue();
        try {
            org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((java.lang.Object) int19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3363116400010L + "'", long16 == 3363116400010L);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

//    @Test
//    public void test11() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test11");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
//        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
//        mutableDateTime12.setDayOfMonth((int) (byte) 1);
//        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        mutableDateTime15.add(readablePeriod16);
//        mutableDateTime15.addDays((-1));
//        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
//        mutableDateTime20.addYears(0);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        java.lang.String str25 = mutableDateTime20.toString(dateTimeFormatter24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (long) (-1), 1);
//        org.joda.time.Instant instant31 = gJChronology30.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) gJChronology30);
//        org.joda.time.DateTimeZone dateTimeZone33 = gJChronology30.getZone();
//        long long36 = dateTimeZone33.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime(dateTimeZone33);
//        long long40 = dateTimeZone33.convertLocalToUTC(0L, false);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField45 = gJChronology44.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField46 = gJChronology44.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone47, (long) (-1), 1);
//        org.joda.time.Instant instant51 = gJChronology50.getGregorianCutover();
//        org.joda.time.Chronology chronology52 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology50);
//        org.joda.time.DurationField durationField53 = gJChronology50.hours();
//        org.joda.time.DateTimeField dateTimeField54 = gJChronology50.clockhourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology44, dateTimeField54, 33);
//        long long59 = skipUndoDateTimeField56.add(207356400010L, (long) 0);
//        int int61 = skipUndoDateTimeField56.getMinimumValue(0L);
//        boolean boolean63 = skipUndoDateTimeField56.isLeap((long) (-1));
//        int int64 = skipUndoDateTimeField56.getMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter65 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone66 = null;
//        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone66, (long) (-1), 1);
//        org.joda.time.Instant instant70 = gJChronology69.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter71 = dateTimeFormatter65.withChronology((org.joda.time.Chronology) gJChronology69);
//        org.joda.time.DateTimeField dateTimeField72 = gJChronology69.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, (int) (byte) 10);
//        long long76 = offsetDateTimeField74.roundFloor((long) (-1));
//        int int77 = offsetDateTimeField74.getMaximumValue();
//        java.util.Locale locale78 = null;
//        int int79 = offsetDateTimeField74.getMaximumShortTextLength(locale78);
//        long long82 = offsetDateTimeField74.add((long) (short) 10, 57599);
//        org.joda.time.DurationField durationField83 = offsetDateTimeField74.getRangeDurationField();
//        long long86 = offsetDateTimeField74.add(0L, (long) 59);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField74.getAsShortText((-1595441066456L), locale88);
//        org.joda.time.DateTime dateTime90 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime91 = dateTime90.toLocalDateTime();
//        java.util.Locale locale92 = null;
//        java.lang.String str93 = offsetDateTimeField74.getAsText((org.joda.time.ReadablePartial) localDateTime91, locale92);
//        int int94 = skipUndoDateTimeField56.getMinimumValue((org.joda.time.ReadablePartial) localDateTime91);
//        boolean boolean95 = dateTimeZone33.isLocalDateTimeGap(localDateTime91);
//        org.joda.time.MutableDateTime mutableDateTime96 = mutableDateTime20.toMutableDateTime(dateTimeZone33);
//        int int97 = mutableDateTime20.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969-11-30T16:00:00-08:00" + "'", str25.equals("1969-11-30T16:00:00-08:00"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(instant31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28800000L + "'", long40 == 28800000L);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(instant51);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 207356400010L + "'", long59 == 207356400010L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2 + "'", int64 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter65);
//        org.junit.Assert.assertNotNull(gJChronology69);
//        org.junit.Assert.assertNotNull(instant70);
//        org.junit.Assert.assertNotNull(dateTimeFormatter71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-3600000L) + "'", long76 == (-3600000L));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 33 + "'", int77 == 33);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2 + "'", int79 == 2);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 207356400010L + "'", long82 == 207356400010L);
//        org.junit.Assert.assertNotNull(durationField83);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 212400000L + "'", long86 == 212400000L);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "32" + "'", str89.equals("32"));
//        org.junit.Assert.assertNotNull(dateTime90);
//        org.junit.Assert.assertNotNull(localDateTime91);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "16" + "'", str93.equals("16"));
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime96);
//        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 16 + "'", int97 == 16);
//    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (long) (-1), 1);
        org.joda.time.Instant instant22 = gJChronology21.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter17.withChronology((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeZone dateTimeZone24 = gJChronology21.getZone();
        long long27 = dateTimeZone24.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone24);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((-3600000L), dateTimeZone24);
        mutableDateTime12.setZone(dateTimeZone24);
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime12.yearOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35, (long) (-1), 1);
        org.joda.time.Instant instant39 = gJChronology38.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter34.withChronology((org.joda.time.Chronology) gJChronology38);
        org.joda.time.DateTimeZone dateTimeZone41 = gJChronology38.getZone();
        long long44 = dateTimeZone41.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone41);
        org.joda.time.MutableDateTime.Property property46 = mutableDateTime45.year();
        org.joda.time.MutableDateTime mutableDateTime47 = property46.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime47.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime49 = property48.roundHalfEven();
        mutableDateTime12.setTime((org.joda.time.ReadableInstant) mutableDateTime49);
        java.lang.String str51 = mutableDateTime12.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(instant39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(mutableDateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1969-12-01T16:00:00.000-08:00" + "'", str51.equals("1969-12-01T16:00:00.000-08:00"));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfDay(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendWeekyear((int) (short) 0, 30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology9 = gregorianChronology8.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        long long21 = delegatedDateTimeField18.add(207356400010L, (int) (short) 1);
        boolean boolean22 = delegatedDateTimeField18.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType23, (int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField27 = buddhistChronology26.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        int int31 = unsupportedDateTimeField28.getDifference((long) 4, (-35125695492L));
        long long34 = unsupportedDateTimeField28.add((-35125686156L), (long) 39114);
        try {
            int int35 = unsupportedDateTimeField28.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3363116400010L + "'", long21 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 13 + "'", int31 == 13);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 102824679113844L + "'", long34 == 102824679113844L);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long18 = skipUndoDateTimeField15.add(207356400010L, (long) 0);
        int int20 = skipUndoDateTimeField15.getMinimumValue(0L);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.secondOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType27);
        long long31 = delegatedDateTimeField28.add(207356400010L, (int) (short) 1);
        boolean boolean32 = delegatedDateTimeField28.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType33, (int) ' ');
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 2922730, "5:55:32 AM UTC");
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone39);
        boolean boolean41 = dateTime40.isAfterNow();
        org.joda.time.DateTime.Property property42 = dateTime40.centuryOfEra();
        org.joda.time.DateTime.Property property43 = dateTime40.dayOfWeek();
        org.joda.time.DurationField durationField44 = property43.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField45 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField44);
        long long48 = unsupportedDateTimeField45.add((-35125688000L), (int) (byte) 100);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 207356400010L + "'", long18 == 207356400010L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3363116400010L + "'", long31 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-26485688000L) + "'", long48 == (-26485688000L));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long18 = skipUndoDateTimeField15.add(207356400010L, (long) 0);
        int int20 = skipUndoDateTimeField15.getMinimumValue(0L);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.secondOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType27);
        long long31 = delegatedDateTimeField28.add(207356400010L, (int) (short) 1);
        boolean boolean32 = delegatedDateTimeField28.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType33, (int) ' ');
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 2922730, "5:55:32 AM UTC");
        java.lang.String str39 = illegalFieldValueException38.getIllegalStringValue();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 207356400010L + "'", long18 == 207356400010L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3363116400010L + "'", long31 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNull(str39);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime2 = property1.withMinimumValue();
        try {
            org.joda.time.DateTime dateTime4 = property1.setCopy(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("1969", "GregorianChronology[UTC]", 30, (-292275054));
        int int12 = fixedDateTimeZone10.getStandardOffset((-1892275200000L));
        long long14 = fixedDateTimeZone10.previousTransition((-19L));
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(1, 2922730, 0, 100, 2, (int) (short) 1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292275054) + "'", int12 == (-292275054));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-19L) + "'", long14 == (-19L));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(1, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTwoDigitYear(12, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField13 = iSOChronology12.eras();
        java.lang.String str14 = iSOChronology12.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str14.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1595441074502L));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.weekOfWeekyear();
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeField8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.minuteOfDay();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '#', (org.joda.time.Chronology) gJChronology4, locale6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        java.util.TimeZone timeZone14 = dateTimeZone13.toTimeZone();
        dateTimeParserBucket7.setZone(dateTimeZone13);
        dateTimeParserBucket7.setOffset((java.lang.Integer) 57600000);
        int int18 = dateTimeParserBucket7.getOffset();
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 57600000 + "'", int18 == 57600000);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology6.getZone();
        long long12 = dateTimeZone9.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone9);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.year();
        org.joda.time.MutableDateTime mutableDateTime15 = property14.getMutableDateTime();
        mutableDateTime15.setMonthOfYear((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (long) (-1), 1);
        org.joda.time.Instant instant22 = gJChronology21.getGregorianCutover();
        org.joda.time.DurationField durationField23 = gJChronology21.halfdays();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.secondOfDay();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology27.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29, dateTimeFieldType30);
        long long34 = delegatedDateTimeField31.add(207356400010L, (int) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology21, (org.joda.time.DateTimeField) delegatedDateTimeField31);
        org.joda.time.DateTimeField dateTimeField36 = skipDateTimeField35.getWrappedField();
        mutableDateTime15.setRounding((org.joda.time.DateTimeField) skipDateTimeField35, 0);
        int int39 = skipDateTimeField35.getMinimumValue();
        int int41 = skipDateTimeField35.get((long) 57600000);
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipDateTimeField35);
        java.lang.String str43 = skipDateTimeField42.getName();
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3363116400010L + "'", long34 == 3363116400010L);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 20 + "'", int41 == 20);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "centuryOfEra" + "'", str43.equals("centuryOfEra"));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        int int17 = mutableDateTime12.getDayOfWeek();
        mutableDateTime12.setMinuteOfDay((int) (short) 0);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime12.millisOfDay();
        org.joda.time.Interval interval21 = property20.toInterval();
        org.joda.time.ReadableInterval readableInterval22 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval21);
        org.joda.time.ReadableInterval readableInterval23 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval22);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(interval21);
        org.junit.Assert.assertNotNull(readableInterval22);
        org.junit.Assert.assertNotNull(readableInterval23);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long18 = skipUndoDateTimeField15.add(207356400010L, (long) 0);
        int int20 = skipUndoDateTimeField15.getMinimumValue(0L);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.secondOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType27);
        long long31 = delegatedDateTimeField28.add(207356400010L, (int) (short) 1);
        boolean boolean32 = delegatedDateTimeField28.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType33, (int) ' ');
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 19, "1968-W47-3T10:51:19");
        java.lang.String str39 = illegalFieldValueException38.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 207356400010L + "'", long18 == 207356400010L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3363116400010L + "'", long31 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "19" + "'", str39.equals("19"));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test31() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test31");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks(100);
//        boolean boolean5 = dateTime0.isBefore((long) 33);
//        int int6 = dateTime0.getDayOfWeek();
//        int int7 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property8 = dateTime0.yearOfCentury();
//        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//    }

//    @Test
//    public void test32() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test32");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        long long13 = property12.remainder();
//        boolean boolean15 = property12.equals((java.lang.Object) (-1.0d));
//        org.joda.time.DateTime dateTime16 = property12.roundCeilingCopy();
//        org.joda.time.TimeOfDay timeOfDay17 = dateTime16.toTimeOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1630566647492L) + "'", long13 == (-1630566647492L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(timeOfDay17);
//    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology9 = gregorianChronology8.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        long long21 = delegatedDateTimeField18.add(207356400010L, (int) (short) 1);
        boolean boolean22 = delegatedDateTimeField18.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType23, (int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField27 = buddhistChronology26.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3363116400010L + "'", long21 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNull(durationField29);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = dateTimeZone7.getID();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (long) (-1), 1);
        org.joda.time.Instant instant15 = gJChronology14.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology14.clockhourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology14);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime19, 5);
        boolean boolean23 = mutableDateTime19.isAfter((long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.secondOfDay();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology27.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (long) (-1), 1);
        org.joda.time.Instant instant34 = gJChronology33.getGregorianCutover();
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology33);
        org.joda.time.DurationField durationField36 = gJChronology33.hours();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology33.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37, 33);
        long long42 = skipUndoDateTimeField39.add(207356400010L, (long) 0);
        int int44 = skipUndoDateTimeField39.getMinimumValue(0L);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.secondOfDay();
        org.joda.time.DateTimeField dateTimeField50 = gJChronology48.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField50, dateTimeFieldType51);
        long long55 = delegatedDateTimeField52.add(207356400010L, (int) (short) 1);
        boolean boolean56 = delegatedDateTimeField52.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = delegatedDateTimeField52.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField39, dateTimeFieldType57, (int) ' ');
        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 19, "1968-W47-3T10:51:19");
        int int63 = mutableDateTime19.get(dateTimeFieldType57);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 207356400010L + "'", long42 == 207356400010L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 3363116400010L + "'", long55 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 21 + "'", int63 == 21);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DurationField durationField7 = gJChronology4.hours();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.clockhourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj0, (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology4.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (long) (-1), 1);
        org.joda.time.Instant instant17 = gJChronology16.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter12.withChronology((org.joda.time.Chronology) gJChronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology16.getZone();
        long long22 = dateTimeZone19.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone19);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.year();
        mutableDateTime23.setSecondOfMinute((int) (byte) 0);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime28 = dateTime27.toLocalDateTime();
        org.joda.time.DateTime dateTime30 = dateTime27.plusWeeks(100);
        boolean boolean32 = dateTime27.isBefore((long) 33);
        boolean boolean33 = mutableDateTime23.isAfter((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime34 = mutableDateTime23.toDateTimeISO();
        org.joda.time.LocalDateTime localDateTime35 = dateTime34.toLocalDateTime();
        int[] intArray37 = gJChronology4.get((org.joda.time.ReadablePartial) localDateTime35, (long) (-3));
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDateTime35);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (long) (-1), 1);
        org.joda.time.Instant instant9 = gJChronology8.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
        long long14 = dateTimeZone11.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter2.withZone(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone11);
        org.joda.time.Chronology chronology19 = zonedChronology18.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology21 = dateTimeFormatter20.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (long) (-1), 1);
        org.joda.time.Instant instant27 = gJChronology26.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter22.withChronology((org.joda.time.Chronology) gJChronology26);
        org.joda.time.DateTimeZone dateTimeZone29 = gJChronology26.getZone();
        long long32 = dateTimeZone29.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter20.withZone(dateTimeZone29);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.Chronology chronology36 = zonedChronology18.withZone(dateTimeZone29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (long) (-1), 1);
        org.joda.time.Instant instant42 = gJChronology41.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) gJChronology41);
        org.joda.time.DateTimeZone dateTimeZone44 = gJChronology41.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (long) (-1), 1);
        org.joda.time.Instant instant50 = gJChronology49.getGregorianCutover();
        boolean boolean51 = gregorianChronology45.equals((java.lang.Object) gJChronology49);
        boolean boolean52 = zonedChronology18.equals((java.lang.Object) gregorianChronology45);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(instant27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(instant42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(gJChronology49);
        org.junit.Assert.assertNotNull(instant50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

//    @Test
//    public void test37() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test37");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        long long13 = property12.remainder();
//        org.joda.time.DateTime dateTime14 = property12.getDateTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property12.getFieldType();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, (long) (-1), 1);
//        org.joda.time.Instant instant21 = gJChronology20.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) gJChronology20);
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology20.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (byte) 10);
//        long long27 = offsetDateTimeField25.roundFloor((long) (-1));
//        int int28 = offsetDateTimeField25.getMaximumValue();
//        boolean boolean29 = offsetDateTimeField25.isLenient();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, (long) (-1), 1);
//        org.joda.time.Instant instant37 = gJChronology36.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter32.withChronology((org.joda.time.Chronology) gJChronology36);
//        org.joda.time.DateTimeZone dateTimeZone39 = gJChronology36.getZone();
//        long long42 = dateTimeZone39.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone39);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.year();
//        org.joda.time.MutableDateTime mutableDateTime45 = property44.getMutableDateTime();
//        org.joda.time.MutableDateTime.Property property46 = mutableDateTime45.secondOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.Chronology chronology49 = dateTimeFormatter48.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone51, (long) (-1), 1);
//        org.joda.time.Instant instant55 = gJChronology54.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = dateTimeFormatter50.withChronology((org.joda.time.Chronology) gJChronology54);
//        org.joda.time.DateTimeZone dateTimeZone57 = gJChronology54.getZone();
//        long long60 = dateTimeZone57.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime61 = org.joda.time.DateTime.now(dateTimeZone57);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = dateTimeFormatter48.withZone(dateTimeZone57);
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone57);
//        org.joda.time.DateTimeZone dateTimeZone66 = null;
//        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone66, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField70 = gJChronology69.secondOfDay();
//        java.util.Locale locale71 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket74 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology69, locale71, (java.lang.Integer) 0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone75 = null;
//        org.joda.time.chrono.GJChronology gJChronology78 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone75, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField79 = gJChronology78.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField80 = gJChronology78.yearOfCentury();
//        dateTimeParserBucket74.saveField(dateTimeField80, (int) (short) 10);
//        java.util.Locale locale83 = dateTimeParserBucket74.getLocale();
//        java.lang.String str84 = dateTimeZone57.getShortName((long) (short) 10, locale83);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter85 = dateTimeFormatter47.withLocale(locale83);
//        int int86 = property46.getMaximumTextLength(locale83);
//        java.lang.String str87 = offsetDateTimeField25.getAsShortText(2000L, locale83);
//        java.lang.String str88 = property12.getAsShortText(locale83);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1630566646582L) + "'", long13 == (-1630566646582L));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(instant21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-3600000L) + "'", long27 == (-3600000L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 33 + "'", int28 == 33);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(instant37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertNull(chronology49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter50);
//        org.junit.Assert.assertNotNull(gJChronology54);
//        org.junit.Assert.assertNotNull(instant55);
//        org.junit.Assert.assertNotNull(dateTimeFormatter56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 10L + "'", long60 == 10L);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTimeFormatter62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(gJChronology69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(gJChronology78);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertNotNull(dateTimeField80);
//        org.junit.Assert.assertNotNull(locale83);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "PST" + "'", str84.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 5 + "'", int86 == 5);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "26" + "'", str87.equals("26"));
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "20" + "'", str88.equals("20"));
//    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (long) (-1), 1);
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) gJChronology17);
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology17.getZone();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology17.clockhourOfHalfday();
        long long26 = gJChronology17.getDateTimeMillis(57599, 1, 4, (int) (byte) 100);
        boolean boolean27 = iSOChronology12.equals((java.lang.Object) gJChronology17);
        org.joda.time.DurationField durationField28 = iSOChronology12.seconds();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1755481968000100L + "'", long26 == 1755481968000100L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfDay();
        org.joda.time.DurationField durationField6 = gJChronology4.halfdays();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) gJChronology4);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withMonthOfYear(21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(1, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.append(dateTimeParser10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder8.appendWeekyear((int) (short) 10, 33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

//    @Test
//    public void test42() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test42");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.minuteOfDay();
//        java.util.Locale locale6 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '#', (org.joda.time.Chronology) gJChronology4, locale6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
//        java.util.TimeZone timeZone14 = dateTimeZone13.toTimeZone();
//        dateTimeParserBucket7.setZone(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology19.centuryOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
//        long long26 = delegatedDateTimeField23.add(207356400010L, (int) (short) 1);
//        int int29 = delegatedDateTimeField23.getDifference((long) (byte) 100, (long) 5);
//        boolean boolean30 = delegatedDateTimeField23.isLenient();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, (long) (-1), 1);
//        org.joda.time.Instant instant37 = gJChronology36.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter32.withChronology((org.joda.time.Chronology) gJChronology36);
//        org.joda.time.DateTimeZone dateTimeZone39 = gJChronology36.getZone();
//        long long42 = dateTimeZone39.adjustOffset((long) (byte) 10, false);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = dateTimeZone39.getName(1L, locale44);
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone39);
//        long long49 = dateTimeZone39.convertLocalToUTC((-57600000L), false);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone52, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField56 = gJChronology55.minuteOfDay();
//        java.util.Locale locale57 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket58 = new org.joda.time.format.DateTimeParserBucket((long) '#', (org.joda.time.Chronology) gJChronology55, locale57);
//        java.util.Locale locale59 = dateTimeParserBucket58.getLocale();
//        java.lang.String str60 = dateTimeZone39.getName(41L, locale59);
//        java.lang.String str61 = delegatedDateTimeField23.getAsText(960, locale59);
//        long long64 = delegatedDateTimeField23.getDifferenceAsLong((-61786108747997L), (long) 2000);
//        dateTimeParserBucket7.saveField((org.joda.time.DateTimeField) delegatedDateTimeField23, 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone68 = null;
//        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone68, (long) (-1), 1);
//        org.joda.time.Instant instant72 = gJChronology71.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = dateTimeFormatter67.withChronology((org.joda.time.Chronology) gJChronology71);
//        org.joda.time.DateTimeZone dateTimeZone74 = gJChronology71.getZone();
//        long long77 = dateTimeZone74.adjustOffset((long) (byte) 10, false);
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = dateTimeZone74.getName(1L, locale79);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone81 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone74);
//        org.joda.time.DateTimeZone dateTimeZone82 = cachedDateTimeZone81.getUncachedZone();
//        java.lang.String str84 = cachedDateTimeZone81.getNameKey(0L);
//        dateTimeParserBucket7.setZone((org.joda.time.DateTimeZone) cachedDateTimeZone81);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3363116400010L + "'", long26 == 3363116400010L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(instant37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Pacific Standard Time" + "'", str45.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-28800000L) + "'", long49 == (-28800000L));
//        org.junit.Assert.assertNotNull(gJChronology55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(locale59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Pacific Standard Time" + "'", str60.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "960" + "'", str61.equals("960"));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-19L) + "'", long64 == (-19L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter67);
//        org.junit.Assert.assertNotNull(gJChronology71);
//        org.junit.Assert.assertNotNull(instant72);
//        org.junit.Assert.assertNotNull(dateTimeFormatter73);
//        org.junit.Assert.assertNotNull(dateTimeZone74);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 10L + "'", long77 == 10L);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "Pacific Standard Time" + "'", str80.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone81);
//        org.junit.Assert.assertNotNull(dateTimeZone82);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "PST" + "'", str84.equals("PST"));
//    }

//    @Test
//    public void test43() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test43");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMinuteOfDay();
//        org.joda.time.Chronology chronology2 = dateTime0.getChronology();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMonths(0);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusSeconds((-1));
//        org.joda.time.DateTime dateTime8 = dateTime0.withDayOfMonth((int) (byte) 1);
//        org.joda.time.DateTime.Property property9 = dateTime0.dayOfMonth();
//        org.joda.time.Interval interval10 = property9.toInterval();
//        org.joda.time.DateTime dateTime11 = property9.roundHalfFloorCopy();
//        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1009 + "'", int1 == 1009);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(interval10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test45() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test45");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
//        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
//        mutableDateTime12.setDayOfMonth((int) (byte) 1);
//        mutableDateTime12.addMinutes(1);
//        int int17 = mutableDateTime12.getDayOfWeek();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, (long) (-1), 1);
//        org.joda.time.Instant instant29 = gJChronology28.getGregorianCutover();
//        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology28);
//        org.joda.time.DurationField durationField31 = gJChronology28.hours();
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology28.clockhourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField32, 33);
//        long long37 = skipUndoDateTimeField34.add(207356400010L, (long) 0);
//        int int39 = skipUndoDateTimeField34.getMinimumValue(0L);
//        boolean boolean41 = skipUndoDateTimeField34.isLeap((long) (-1));
//        int int42 = skipUndoDateTimeField34.getMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, (long) (-1), 1);
//        org.joda.time.Instant instant48 = gJChronology47.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter43.withChronology((org.joda.time.Chronology) gJChronology47);
//        org.joda.time.DateTimeField dateTimeField50 = gJChronology47.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, (int) (byte) 10);
//        long long54 = offsetDateTimeField52.roundFloor((long) (-1));
//        int int55 = offsetDateTimeField52.getMaximumValue();
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField52.getMaximumShortTextLength(locale56);
//        long long60 = offsetDateTimeField52.add((long) (short) 10, 57599);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField52.getRangeDurationField();
//        long long64 = offsetDateTimeField52.add(0L, (long) 59);
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = offsetDateTimeField52.getAsShortText((-1595441066456L), locale66);
//        org.joda.time.DateTime dateTime68 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime69 = dateTime68.toLocalDateTime();
//        java.util.Locale locale70 = null;
//        java.lang.String str71 = offsetDateTimeField52.getAsText((org.joda.time.ReadablePartial) localDateTime69, locale70);
//        int int72 = skipUndoDateTimeField34.getMinimumValue((org.joda.time.ReadablePartial) localDateTime69);
//        int int73 = mutableDateTime12.get((org.joda.time.DateTimeField) skipUndoDateTimeField34);
//        java.lang.String str74 = skipUndoDateTimeField34.toString();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(instant29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 207356400010L + "'", long37 == 207356400010L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(instant48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-3600000L) + "'", long54 == (-3600000L));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 207356400010L + "'", long60 == 207356400010L);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 212400000L + "'", long64 == 212400000L);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "32" + "'", str67.equals("32"));
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertNotNull(localDateTime69);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "16" + "'", str71.equals("16"));
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 5 + "'", int73 == 5);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "DateTimeField[clockhourOfHalfday]" + "'", str74.equals("DateTimeField[clockhourOfHalfday]"));
//    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField9.getWrappedField();
        long long14 = offsetDateTimeField9.roundCeiling(2L);
        org.joda.time.DurationField durationField15 = offsetDateTimeField9.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3600000L + "'", long14 == 3600000L);
        org.junit.Assert.assertNotNull(durationField15);
    }

//    @Test
//    public void test47() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test47");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMinuteOfDay();
//        org.joda.time.Chronology chronology2 = dateTime0.getChronology();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMonths(0);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusSeconds((-1));
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) (short) 100, (-1));
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime6.toMutableDateTimeISO();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1009 + "'", int1 == 1009);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology9 = gregorianChronology8.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        long long21 = delegatedDateTimeField18.add(207356400010L, (int) (short) 1);
        boolean boolean22 = delegatedDateTimeField18.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType23, (int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField27 = buddhistChronology26.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        int int31 = unsupportedDateTimeField28.getDifference((long) 4, (-35125695492L));
        long long34 = unsupportedDateTimeField28.add((-35125686156L), (long) 39114);
        org.joda.time.DurationField durationField35 = unsupportedDateTimeField28.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3363116400010L + "'", long21 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 13 + "'", int31 == 13);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 102824679113844L + "'", long34 == 102824679113844L);
        org.junit.Assert.assertNull(durationField35);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
        mutableDateTime15.setWeekOfWeekyear((int) '4');
        try {
            mutableDateTime15.setDate(51, 17162808, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 17162808 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime20);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(57600000, 33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) (short) 10, (int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (long) (-1), 1);
        org.joda.time.Instant instant14 = gJChronology13.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology13);
        org.joda.time.DateTimeField dateTimeField16 = gJChronology13.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (byte) 10);
        long long20 = offsetDateTimeField18.roundFloor((long) (-1));
        int int21 = offsetDateTimeField18.getMaximumValue();
        java.lang.String str23 = offsetDateTimeField18.getAsText((long) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean25 = dateTimeFormatterBuilder24.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder24.appendCenturyOfEra(1, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendSecondOfMinute((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean32 = dateTimeFormatterBuilder31.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendMillisOfSecond(20);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.secondOfDay();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology40.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField44 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField42, dateTimeFieldType43);
        long long47 = delegatedDateTimeField44.add(207356400010L, (int) (short) 1);
        boolean boolean48 = delegatedDateTimeField44.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = delegatedDateTimeField44.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder36.appendFixedSignedDecimal(dateTimeFieldType49, 59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder28.appendFixedSignedDecimal(dateTimeFieldType49, 355);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType49, (int) (byte) -1, 0, 959);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder58.appendTwoDigitYear((int) (byte) 1, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-3600000L) + "'", long20 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 33 + "'", int21 == 33);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "26" + "'", str23.equals("26"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3363116400010L + "'", long47 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (long) (-1), 1);
        org.joda.time.Instant instant9 = gJChronology8.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
        long long14 = dateTimeZone11.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone11);
        mutableDateTime15.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime15.copy();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        mutableDateTime18.add(readablePeriod19);
        mutableDateTime18.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime23 = mutableDateTime18.toMutableDateTime();
        java.lang.String str24 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime23);
        java.util.Locale locale25 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter0.withLocale(locale25);
        java.lang.Appendable appendable27 = null;
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime29 = dateTime28.toLocalDateTime();
        org.joda.time.DateTime dateTime31 = dateTime28.plusWeeks(100);
        org.joda.time.DateTime dateTime33 = dateTime28.withMillis(0L);
        try {
            dateTimeFormatter0.printTo(appendable27, (org.joda.time.ReadableInstant) dateTime33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969W487" + "'", str24.equals("1969W487"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.minuteOfHour();
        int int19 = mutableDateTime15.getMonthOfYear();
        java.lang.String str20 = mutableDateTime15.toString();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime15.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-01T16:00:00.000-08:00" + "'", str20.equals("1969-12-01T16:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsShortText(locale13);
        org.joda.time.DateTime dateTime16 = property12.setCopy("26");
        org.joda.time.DateTime dateTime17 = property12.getDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "20" + "'", str14.equals("20"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        int int9 = dateTime7.getEra();
        org.joda.time.DateTime dateTime11 = dateTime7.withDayOfYear((int) (short) 10);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsShortText(locale13);
        org.joda.time.DateTime dateTime16 = property12.setCopy("26");
        org.joda.time.DateTime dateTime18 = dateTime16.withWeekOfWeekyear(11);
        org.joda.time.DateTime.Property property19 = dateTime16.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "20" + "'", str14.equals("20"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime12.dayOfMonth();
        int int15 = property14.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(chronology5);
        int int7 = mutableDateTime6.getRoundingMode();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test59() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test59");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
//        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
//        org.joda.time.DurationField durationField12 = gJChronology9.hours();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
//        long long18 = skipUndoDateTimeField15.add(207356400010L, (long) 0);
//        int int20 = skipUndoDateTimeField15.getMinimumValue(0L);
//        boolean boolean22 = skipUndoDateTimeField15.isLeap((long) (-1));
//        int int23 = skipUndoDateTimeField15.getMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        int int25 = dateTimeFormatter24.getDefaultYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (long) (-1), 1);
//        org.joda.time.Instant instant31 = gJChronology30.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) gJChronology30);
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology30.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) (byte) 10);
//        org.joda.time.DurationField durationField36 = offsetDateTimeField35.getDurationField();
//        long long39 = offsetDateTimeField35.add((long) 1, (long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField44 = gJChronology43.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField45 = gJChronology43.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (long) (-1), 1);
//        org.joda.time.Instant instant50 = gJChronology49.getGregorianCutover();
//        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology49);
//        org.joda.time.DurationField durationField52 = gJChronology49.hours();
//        org.joda.time.DateTimeField dateTimeField53 = gJChronology49.clockhourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField55 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology43, dateTimeField53, 33);
//        long long57 = skipUndoDateTimeField55.roundHalfEven((long) 100);
//        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime59 = dateTime58.toLocalDateTime();
//        int[] intArray65 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
//        int int66 = skipUndoDateTimeField55.getMaximumValue((org.joda.time.ReadablePartial) localDateTime59, intArray65);
//        int int67 = offsetDateTimeField35.getMinimumValue((org.joda.time.ReadablePartial) localDateTime59);
//        java.lang.String str68 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDateTime59);
//        int int69 = skipUndoDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) localDateTime59);
//        long long72 = skipUndoDateTimeField15.addWrapField((-19L), 1970);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(instant10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 207356400010L + "'", long18 == 207356400010L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2000 + "'", int25 == 2000);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(instant31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(gJChronology49);
//        org.junit.Assert.assertNotNull(instant50);
//        org.junit.Assert.assertNotNull(chronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(localDateTime59);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 12 + "'", int66 == 12);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 10 + "'", int67 == 10);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "2018-W18-2T16:49:14" + "'", str68.equals("2018-W18-2T16:49:14"));
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 12 + "'", int69 == 12);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 7199981L + "'", long72 == 7199981L);
//    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.Instant instant6 = instant4.minus((-1595441063535L));
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant4.plus(readableDuration7);
        org.joda.time.Instant instant10 = instant4.plus((-50492160422019L));
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology9 = gregorianChronology8.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        long long21 = delegatedDateTimeField18.add(207356400010L, (int) (short) 1);
        boolean boolean22 = delegatedDateTimeField18.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType23, (int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField27 = buddhistChronology26.months();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField27);
        org.joda.time.DurationField durationField29 = unsupportedDateTimeField28.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3363116400010L + "'", long21 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
    }

//    @Test
//    public void test62() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test62");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        long long13 = property12.remainder();
//        org.joda.time.DateTime dateTime14 = property12.getDateTime();
//        org.joda.time.DateTime dateTime16 = property12.setCopy(2922730);
//        org.joda.time.DateTime dateTime18 = property12.addToCopy(0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1630566644803L) + "'", long13 == (-1630566644803L));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }
//}

