import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        java.io.Writer writer7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (long) (-1), 1);
        org.joda.time.Instant instant12 = gJChronology11.getGregorianCutover();
        try {
            dateTimeFormatter6.printTo(writer7, (org.joda.time.ReadableInstant) instant12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(instant12);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((java.lang.Object) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(100, 0, 1, (int) (short) 100, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        try {
            long long14 = gJChronology4.getDateTimeMillis((int) (byte) -1, 100, (int) (byte) 10, (int) 'a', 0, (-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType5, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        java.lang.String str8 = dateTimeZone7.getID();
        org.joda.time.LocalDateTime localDateTime9 = null;
        try {
            boolean boolean10 = dateTimeZone7.isLocalDateTimeGap(localDateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, (int) (byte) -1, (int) (byte) 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 100, (int) (byte) -1, (int) '4', (int) ' ', (int) (short) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        try {
            mutableDateTime12.setDateTime((int) (short) -1, (int) (byte) 1, (int) (short) 0, 10, (int) (byte) -1, (int) (short) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTimeISO();
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = dateTime7.toString("America/Los_Angeles", locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            mutableDateTime12.add(durationFieldType17, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        try {
            long long9 = gJChronology3.getDateTimeMillis(0, (int) (byte) 100, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (long) (-1), 1);
        org.joda.time.Instant instant13 = gJChronology12.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) gJChronology12);
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology12.getZone();
        java.lang.String str16 = dateTimeZone15.getID();
        org.joda.time.DateTime dateTime17 = instant7.toDateTime(dateTimeZone15);
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime17.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadablePartial) yearMonthDay18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "America/Los_Angeles" + "'", str16.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(yearMonthDay18);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.util.Locale locale3 = null;
        try {
            org.joda.time.DateTime dateTime4 = property1.setCopy("", locale3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology9.getZone();
        java.lang.String str13 = dateTimeZone12.getID();
        org.joda.time.DateTime dateTime14 = instant4.toDateTime(dateTimeZone12);
        org.joda.time.YearMonthDay yearMonthDay15 = dateTime14.toYearMonthDay();
        long long16 = dateTime14.getMillis();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(yearMonthDay15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        try {
            org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, 10L, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.getMutableDateTime();
        java.util.Locale locale16 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime17 = property13.set("hi!", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        mutableDateTime12.setSecondOfMinute((int) '#');
        org.joda.time.DurationFieldType durationFieldType16 = null;
        try {
            mutableDateTime12.add(durationFieldType16, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime10 = dateTime7.minusMillis(0);
        try {
            org.joda.time.DateTime dateTime14 = dateTime7.withDate(57599, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test039");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        mutableDateTime12.setSecondOfMinute((int) (byte) 0);
        try {
            mutableDateTime12.setDayOfWeek(355);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 355 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (long) (-1), 1);
        try {
            org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((int) (byte) -1, (int) (byte) 1, (int) (short) -1, (int) '#', 10, (-1), (int) (short) 0, (org.joda.time.Chronology) gJChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime11 = dateTime10.toLocalDateTime();
        int[] intArray19 = new int[] { 0, 2, (byte) -1, (byte) 1, 100, 4 };
        try {
            int[] intArray21 = offsetDateTimeField9.addWrapField((org.joda.time.ReadablePartial) localDateTime11, (int) (byte) -1, intArray19, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType3, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        try {
            java.lang.String str2 = dateTime0.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) '4', (int) (byte) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.dayOfMonth();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) 'a', (int) '#', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        try {
            org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) -1, 355, 4, 0, 4, 0, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 355 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfDay();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology4, locale6, (java.lang.Integer) 0, (int) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            dateTimeParserBucket9.saveField(dateTimeFieldType10, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        int int12 = offsetDateTimeField9.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType13, (int) (byte) 1, (int) (byte) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            mutableDateTime0.add(durationFieldType1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(1, (int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType4, (-292275054), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime2 = dateTime1.toLocalDateTime();
        int[] intArray8 = new int[] { (byte) 100, 0, (byte) -1, 100, (short) 100 };
        try {
            iSOChronology0.validate((org.joda.time.ReadablePartial) localDateTime2, intArray8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.dayOfWeek();
        java.util.Locale locale18 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime19 = property16.set("hi!", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (long) (-1), 1);
        org.joda.time.Instant instant14 = gJChronology13.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (long) (-1), 1);
        org.joda.time.Instant instant20 = gJChronology19.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) gJChronology19);
        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology19.getZone();
        java.lang.String str23 = dateTimeZone22.getID();
        org.joda.time.DateTime dateTime24 = instant14.toDateTime(dateTimeZone22);
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime24.toYearMonthDay();
        int[] intArray27 = null;
        java.util.Locale locale29 = null;
        try {
            int[] intArray30 = offsetDateTimeField9.set((org.joda.time.ReadablePartial) yearMonthDay25, 0, intArray27, "19", locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "America/Los_Angeles" + "'", str23.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        try {
            long long10 = delegatedDateTimeField7.add((long) 100, (-1595441076314L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -159544107631400");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DurationField durationField7 = gJChronology4.hours();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField8 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10, 57599, (-1), 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatterBuilder0.toFormatter();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Both printing and parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfDay();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology4, locale6, (java.lang.Integer) 0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology13.yearOfCentury();
        dateTimeParserBucket9.saveField(dateTimeField15, (int) (short) 10);
        long long20 = dateTimeParserBucket9.computeMillis(true, "1969W487");
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1892275200000L) + "'", long20 == (-1892275200000L));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-1L), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        java.lang.String str8 = dateTimeZone7.getID();
        try {
            org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (-1595441076314L), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter2.getParser();
        org.junit.Assert.assertNull(dateTimeParser3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(10, (int) (byte) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (long) (-1), 1);
        org.joda.time.Instant instant16 = gJChronology15.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Instant instant18 = instant16.minus(readableDuration17);
        org.joda.time.DateTime dateTime19 = instant16.toDateTimeISO();
        org.joda.time.DateTime.Property property20 = dateTime19.dayOfYear();
        org.joda.time.DateTime dateTime21 = dateTime19.toDateTimeISO();
        try {
            org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime21, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.DateTime dateTime3 = dateTime0.withFieldAdded(durationFieldType1, 57599);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(1, (int) (short) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = null;
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray6 = new org.joda.time.format.DateTimeParser[] { dateTimeParser5 };
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.append(dateTimePrinter4, dateTimeParserArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParserArray6);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("1969W487");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969W487\" is malformed at \"69W487\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (long) (-1), 1);
        org.joda.time.Instant instant20 = gJChronology19.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.Instant instant22 = instant20.minus(readableDuration21);
        org.joda.time.DateTime dateTime23 = instant20.toDateTimeISO();
        org.joda.time.DateTime.Property property24 = dateTime23.dayOfYear();
        org.joda.time.DateTime.Property property25 = dateTime23.dayOfYear();
        org.joda.time.LocalDateTime localDateTime26 = dateTime23.toLocalDateTime();
        int[] intArray34 = new int[] { ' ', (byte) 100, (short) -1, 33, '#', (-292275054) };
        java.util.Locale locale36 = null;
        try {
            int[] intArray37 = skipUndoDateTimeField15.set((org.joda.time.ReadablePartial) localDateTime26, (-292275054), intArray34, "", locale36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for clockhourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            int int2 = mutableDateTime0.get(dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 1, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendCenturyOfEra(1, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfHour(100, 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMinuteOfDay((-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (long) (-1), 1);
        org.joda.time.Instant instant12 = gJChronology11.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology11.getZone();
        java.lang.String str15 = dateTimeZone14.getID();
        org.joda.time.DateTime dateTime16 = instant6.toDateTime(dateTimeZone14);
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime16.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) yearMonthDay17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        int int12 = offsetDateTimeField9.getMaximumValue();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField9.getMaximumShortTextLength(locale13);
        long long17 = offsetDateTimeField9.add((long) (short) 10, 57599);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int[] intArray22 = new int[] { 57600000, 59 };
        try {
            int[] intArray24 = offsetDateTimeField9.add(readablePartial18, 33, intArray22, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 33");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 207356400010L + "'", long17 == 207356400010L);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        int int9 = dateTime7.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (long) (-1), 1);
        org.joda.time.Instant instant14 = gJChronology13.getGregorianCutover();
        org.joda.time.DurationField durationField15 = gJChronology13.halfdays();
        org.joda.time.Instant instant16 = gJChronology13.getGregorianCutover();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) int9, (org.joda.time.Chronology) gJChronology13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(instant16);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        int int17 = skipUndoDateTimeField15.get((long) 960);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int[] intArray25 = new int[] { (short) -1, (-1), (byte) 10, 57600000, (short) 10 };
        try {
            int[] intArray27 = skipUndoDateTimeField15.addWrapField(readablePartial18, (int) '#', intArray25, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.halfdays();
        try {
            long long13 = gJChronology3.getDateTimeMillis((-292275054), 59, 33, (int) '#', (int) (short) 100, (int) (byte) 10, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant6.minus(readableDuration7);
        try {
            int int9 = property1.getDifference((org.joda.time.ReadableInstant) instant8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 100, "1969W487");
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray16 = new int[] { (byte) -1, 2, '4', (byte) 1 };
        try {
            int[] intArray18 = offsetDateTimeField9.set(readablePartial10, 0, intArray16, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.plusDays(1);
        try {
            org.joda.time.DateTime dateTime16 = dateTime11.withTime((int) (byte) 10, 57600000, 33, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) (-1892275200000L), (java.lang.Number) (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology9.getZone();
        java.lang.String str13 = dateTimeZone12.getID();
        org.joda.time.DateTime dateTime14 = instant4.toDateTime(dateTimeZone12);
        org.joda.time.YearMonthDay yearMonthDay15 = dateTime14.toYearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Chronology chronology17 = dateTimeFormatter16.getChronology();
        boolean boolean18 = dateTimeFormatter16.isPrinter();
        java.lang.String str19 = dateTime14.toString(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(yearMonthDay15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970W013" + "'", str19.equals("1970W013"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        int int17 = mutableDateTime12.getDayOfWeek();
        org.joda.time.DurationFieldType durationFieldType18 = null;
        try {
            mutableDateTime12.add(durationFieldType18, 355);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(355, (int) (byte) -1, 960, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime15.monthOfYear();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime15.secondOfMinute();
        try {
            mutableDateTime15.setHourOfDay(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "1969W487");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.minuteOfDay();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '#', (org.joda.time.Chronology) gJChronology4, locale6);
        boolean boolean9 = gJChronology4.equals((java.lang.Object) 1970);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.halfdays();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        long long16 = delegatedDateTimeField13.add(207356400010L, (int) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField13);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField13.getAsText(readablePartial18, (int) (short) 100, locale20);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (long) (-1), 1);
        org.joda.time.Instant instant26 = gJChronology25.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (long) (-1), 1);
        org.joda.time.Instant instant32 = gJChronology31.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) gJChronology31);
        org.joda.time.DateTimeZone dateTimeZone34 = gJChronology31.getZone();
        java.lang.String str35 = dateTimeZone34.getID();
        org.joda.time.DateTime dateTime36 = instant26.toDateTime(dateTimeZone34);
        org.joda.time.YearMonthDay yearMonthDay37 = dateTime36.toYearMonthDay();
        java.util.Locale locale38 = null;
        try {
            java.lang.String str39 = delegatedDateTimeField13.getAsText((org.joda.time.ReadablePartial) yearMonthDay37, locale38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'centuryOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3363116400010L + "'", long16 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "100" + "'", str21.equals("100"));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(instant26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(instant32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "America/Los_Angeles" + "'", str35.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(yearMonthDay37);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.months();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField5 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant6.minus(readableDuration7);
        org.joda.time.DateTime dateTime9 = instant6.toDateTimeISO();
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
        org.joda.time.DateTime.Property property11 = dateTime9.weekyear();
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra(1);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        try {
            long long12 = offsetDateTimeField9.set((long) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for hourOfDay must be in the range [10,33]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.clockhourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology4);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.centuryOfEra();
        try {
            mutableDateTime9.setDateTime((int) (byte) -1, 960, 57599, 57600000, (int) (byte) 0, (int) (byte) 100, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology6.getZone();
        long long12 = dateTimeZone9.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withZone(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime15.monthOfYear();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime15.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.MutableDateTime.Property property23 = mutableDateTime15.property(dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime12 = dateTime7.withTime(10, (int) (byte) 100, 2, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 69, (java.lang.Number) (-1595441068446L), (java.lang.Number) (-1595441069325L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        try {
            org.joda.time.DateTime dateTime11 = property9.setCopy(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime10 = dateTime7.minusMillis(0);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withYearOfEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZoneUTC();
//        java.lang.String str9 = dateTimeFormatter7.print((-1595441067197L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "5:55:32 AM UTC" + "'", str9.equals("5:55:32 AM UTC"));
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.months();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = buddhistChronology0.millis();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property9 = dateTime7.weekyear();
        int int10 = dateTime7.getYearOfEra();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        long long13 = property12.remainder();
//        org.joda.time.DateTime dateTime14 = property12.getDateTime();
//        try {
//            org.joda.time.DateTime dateTime16 = property12.setCopy("America/Los_Angeles");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for centuryOfEra is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1595441065370L) + "'", long13 == (-1595441065370L));
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(207356400010L, (int) (short) 1);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = delegatedDateTimeField7.getAsText(readablePartial11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3363116400010L + "'", long10 == 3363116400010L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long17 = skipUndoDateTimeField15.roundHalfEven((long) 100);
        org.joda.time.DurationField durationField18 = skipUndoDateTimeField15.getLeapDurationField();
        try {
            long long21 = skipUndoDateTimeField15.set((long) 1969, 355);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 355 for clockhourOfHalfday must be in the range [2,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        int int12 = offsetDateTimeField9.getMaximumValue();
        boolean boolean13 = offsetDateTimeField9.isLenient();
        org.joda.time.DurationField durationField14 = offsetDateTimeField9.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.weekOfWeekyear();
        org.joda.time.Chronology chronology9 = gJChronology4.withUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.monthOfYear();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        try {
            java.lang.String str11 = dateTime7.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        java.lang.Object obj6 = null;
        boolean boolean7 = gJChronology3.equals(obj6);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (long) (-1), 1);
        org.joda.time.Instant instant22 = gJChronology21.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter17.withChronology((org.joda.time.Chronology) gJChronology21);
        mutableDateTime12.setChronology((org.joda.time.Chronology) gJChronology21);
        int int25 = mutableDateTime12.getRoundingMode();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime12.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(property26);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.Instant instant9 = instant6.withDurationAdded(0L, (int) (short) 0);
        org.joda.time.Instant instant10 = instant9.toInstant();
        org.joda.time.Instant instant11 = instant10.toInstant();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        int int17 = mutableDateTime12.getDayOfWeek();
        mutableDateTime12.setWeekyear((-292275054));
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 0, 1, 0, (int) (byte) -1, 57599, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.months();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendTimeZoneOffset("100", "3", false, 2, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("Pacific Standard Time", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 100, 1970, 355, 97, 355, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.halfdays();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        long long16 = delegatedDateTimeField13.add(207356400010L, (int) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField13);
        org.joda.time.DateTimeField dateTimeField18 = skipDateTimeField17.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, (long) (-1), 1);
        org.joda.time.Instant instant23 = gJChronology22.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.Instant instant25 = instant23.minus(readableDuration24);
        org.joda.time.DateTime dateTime26 = instant23.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.dayOfYear();
        org.joda.time.DateTime.Property property28 = dateTime26.dayOfYear();
        org.joda.time.LocalDateTime localDateTime29 = dateTime26.toLocalDateTime();
        int[] intArray37 = new int[] { 97, 960, 97, '4', 100, 960 };
        try {
            int[] intArray39 = skipDateTimeField17.set((org.joda.time.ReadablePartial) localDateTime29, 2922730, intArray37, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [1,2922730]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3363116400010L + "'", long16 == 3363116400010L);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(instant23);
        org.junit.Assert.assertNotNull(instant25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (long) (-1), 1);
        org.joda.time.Instant instant12 = gJChronology11.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology11.getZone();
        long long17 = dateTimeZone14.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter5.withZone(dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(69, (int) (byte) 1, 10, 57599, 0, dateTimeZone21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral("3");
        dateTimeFormatterBuilder3.clear();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) 59, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (-1595441065265L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.secondOfDay();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology6, locale8, (java.lang.Integer) 0, (int) (short) 1);
        mutableDateTime1.setChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (long) (-1), 1);
        org.joda.time.Instant instant17 = gJChronology16.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Instant instant19 = instant17.minus(readableDuration18);
        org.joda.time.DateTime dateTime20 = instant17.toDateTimeISO();
        org.joda.time.DateTime.Property property21 = dateTime20.dayOfYear();
        org.joda.time.DateTime.Property property22 = dateTime20.dayOfYear();
        org.joda.time.LocalDateTime localDateTime23 = dateTime20.toLocalDateTime();
        try {
            long long25 = gJChronology6.set((org.joda.time.ReadablePartial) localDateTime23, (long) 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(localDateTime23);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
        int int21 = mutableDateTime15.getMillisOfDay();
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime15.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 57600000 + "'", int21 == 57600000);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 20);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            int int3 = mutableDateTime0.get(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.halfdays();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = buddhistChronology0.add(readablePeriod2, (-1595441068891L), 6);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1595441068891L) + "'", long5 == (-1595441068891L));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        int int12 = offsetDateTimeField9.getMaximumValue();
        java.lang.String str14 = offsetDateTimeField9.getAsText((long) (byte) 0);
        boolean boolean15 = offsetDateTimeField9.isLenient();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField9, (-1), 100, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [100,4]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "26" + "'", str14.equals("26"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral("3");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendTimeZoneOffset("", "Pacific Standard Time", true, 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.hourOfDay();
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = property2.set("32");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("32");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) (short) 100, 57600000);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfHour((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(57600000, 33);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfCentury(0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long17 = skipUndoDateTimeField15.roundHalfEven((long) 100);
        org.joda.time.DurationField durationField18 = skipUndoDateTimeField15.getLeapDurationField();
        boolean boolean19 = skipUndoDateTimeField15.isLenient();
        java.lang.String str20 = skipUndoDateTimeField15.toString();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[clockhourOfHalfday]" + "'", str20.equals("DateTimeField[clockhourOfHalfday]"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (long) (-1), 1);
        org.joda.time.Instant instant11 = gJChronology10.getGregorianCutover();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DurationField durationField13 = gJChronology10.days();
        org.joda.time.Chronology chronology14 = gJChronology10.withUTC();
        try {
            org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime(10, (int) ' ', (int) '#', (int) 'a', (int) 'a', (int) '4', (-1), (org.joda.time.Chronology) gJChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 960");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime15.monthOfYear();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime15.secondOfMinute();
        mutableDateTime15.setWeekyear((int) (byte) 1);
        try {
            mutableDateTime15.setSecondOfMinute((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 1, "America/Los_Angeles");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        java.lang.Throwable[] throwableArray5 = illegalInstantException2.getSuppressed();
        java.lang.String str6 = illegalInstantException2.toString();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (America/Los_Angeles)" + "'", str6.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (America/Los_Angeles)"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral("3");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfDay((-3), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsShortText(locale13);
        org.joda.time.DateTime dateTime16 = property12.setCopy("26");
        java.util.Locale locale18 = null;
        try {
            org.joda.time.DateTime dateTime19 = property12.setCopy("America/Los_Angeles", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "19" + "'", str14.equals("19"));
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 10, 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60 + "'", int2 == 60);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
        org.joda.time.DurationFieldType durationFieldType21 = null;
        try {
            mutableDateTime15.add(durationFieldType21, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime20);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(57600000, 33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) (short) 10, (int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.append(dateTimePrinter9, dateTimeParser11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("355");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType4, 960, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology6.getZone();
        long long12 = dateTimeZone9.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withZone(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        try {
            long long20 = gregorianChronology15.getDateTimeMillis(59, (int) (short) -1, 4, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        int int12 = offsetDateTimeField9.getMaximumValue();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField9.getMaximumShortTextLength(locale13);
        long long17 = offsetDateTimeField9.add((long) (short) 10, 57599);
        org.joda.time.DurationField durationField18 = offsetDateTimeField9.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, (long) (-1), 1);
        org.joda.time.Instant instant23 = gJChronology22.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.Instant instant25 = instant23.minus(readableDuration24);
        org.joda.time.DateTime dateTime26 = instant23.toDateTimeISO();
        org.joda.time.DateTime.Property property27 = dateTime26.dayOfYear();
        org.joda.time.DateTime.Property property28 = dateTime26.dayOfYear();
        org.joda.time.LocalDateTime localDateTime29 = dateTime26.toLocalDateTime();
        int[] intArray37 = new int[] { 20, 33, 57600000, 69, 100, 'a' };
        try {
            int[] intArray39 = offsetDateTimeField9.addWrapPartial((org.joda.time.ReadablePartial) localDateTime29, (-292275054), intArray37, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -292275054");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 207356400010L + "'", long17 == 207356400010L);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(instant23);
        org.junit.Assert.assertNotNull(instant25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime10 = dateTime7.withYearOfCentury((int) (short) 0);
        int int11 = dateTime7.getWeekyear();
        try {
            org.joda.time.DateTime dateTime13 = dateTime7.withSecondOfMinute((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral("3");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMinuteOfHour(97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendMinuteOfHour(1970);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 960);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210783816000000L) + "'", long1 == (-210783816000000L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime dateTime3 = dateTime0.plusWeeks(100);
        boolean boolean5 = dateTime0.isBefore((long) 33);
        try {
            org.joda.time.DateTime dateTime7 = dateTime0.withMinuteOfHour((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
        boolean boolean13 = property12.isLeap();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (long) (-1), 1);
        org.joda.time.Instant instant9 = gJChronology8.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
        long long14 = dateTimeZone11.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone11);
        mutableDateTime15.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime15.copy();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        mutableDateTime18.add(readablePeriod19);
        mutableDateTime18.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime23 = mutableDateTime18.toMutableDateTime();
        java.lang.String str24 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter0.withDefaultYear((int) ' ');
        try {
            long long28 = dateTimeFormatter0.parseMillis("3");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"3\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969W487" + "'", str24.equals("1969W487"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getMinuteOfDay();
        org.joda.time.Chronology chronology2 = dateTime0.getChronology();
        org.joda.time.DateTime dateTime4 = dateTime0.minusMonths(0);
        org.joda.time.DateTime dateTime6 = dateTime0.minusSeconds((-1));
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) (short) 100, (-1));
        org.joda.time.DateTime dateTime11 = dateTime9.minus((long) '#');
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 960 + "'", int1 == 960);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfDay();
        org.joda.time.DurationField durationField6 = gJChronology4.halfdays();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) gJChronology4);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withDayOfYear((-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.clockhourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology4);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        mutableDateTime9.add(readablePeriod11);
        int int13 = mutableDateTime9.getMillisOfSecond();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime9.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        try {
            mutableDateTime15.setDate((-292275054), (int) (short) 0, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long17 = skipUndoDateTimeField15.roundHalfEven((long) 100);
        org.joda.time.DurationField durationField18 = skipUndoDateTimeField15.getLeapDurationField();
        boolean boolean19 = skipUndoDateTimeField15.isLenient();
        try {
            long long22 = skipUndoDateTimeField15.set((-3600000L), 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for clockhourOfHalfday must be in the range [2,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        try {
            org.joda.time.LocalDate localDate8 = dateTimeFormatter6.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = buddhistChronology7.months();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.yearOfCentury();
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(100, (int) ' ', (int) (byte) 100, 1969, 1970, (int) '4', 31, (org.joda.time.Chronology) buddhistChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        long long14 = offsetDateTimeField9.set(0L, (int) (short) 10);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField9.getAsText(355, locale16);
        org.joda.time.DurationField durationField18 = offsetDateTimeField9.getDurationField();
        long long20 = offsetDateTimeField9.roundHalfCeiling((long) 57600000);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-57600000L) + "'", long14 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "355" + "'", str17.equals("355"));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 57600000L + "'", long20 == 57600000L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '4');
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long17 = skipUndoDateTimeField15.roundHalfEven((long) 100);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
        int[] intArray25 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
        int int26 = skipUndoDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) localDateTime19, intArray25);
        org.joda.time.DurationField durationField27 = skipUndoDateTimeField15.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertNull(durationField27);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.secondOfDay();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime14.weekOfWeekyear();
        org.joda.time.DurationField durationField17 = property16.getRangeDurationField();
        try {
            long long20 = durationField17.subtract((-1595441073681L), (-1892275200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1892275200000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.secondOfDay();
        mutableDateTime14.setDayOfYear((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime14.toMutableDateTime();
        try {
            mutableDateTime14.setMonthOfYear(97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(mutableDateTime18);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = instant4.isSupported(dateTimeFieldType5);
        org.joda.time.MutableDateTime mutableDateTime7 = instant4.toMutableDateTimeISO();
        org.joda.time.Instant instant10 = instant4.withDurationAdded((long) (byte) 1, 0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(2922730, (int) (short) 10, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendClockhourOfHalfday((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField11 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType9, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.hourOfDay();
        try {
            mutableDateTime1.setMillisOfSecond(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone7.getName(1L, locale12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.minus(readablePeriod15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        int int17 = mutableDateTime12.getDayOfWeek();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime12.dayOfWeek();
        try {
            org.joda.time.Instant instant19 = new org.joda.time.Instant((java.lang.Object) property18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MutableDateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long17 = skipUndoDateTimeField15.roundHalfEven((long) 100);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
        int[] intArray25 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
        int int26 = skipUndoDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) localDateTime19, intArray25);
        try {
            long long29 = skipUndoDateTimeField15.set((long) (-3), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for clockhourOfHalfday must be in the range [2,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (long) (-1), 1);
        org.joda.time.Instant instant11 = gJChronology10.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Instant instant13 = instant11.minus(readableDuration12);
        org.joda.time.DateTime dateTime14 = instant11.toDateTimeISO();
        org.joda.time.DateTime.Property property15 = dateTime14.dayOfYear();
        org.joda.time.DateTime dateTime17 = dateTime14.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime dateTime19 = dateTime14.withYearOfCentury((int) (short) 10);
        org.joda.time.DateTime dateTime21 = dateTime14.plus((long) ' ');
        org.joda.time.YearMonthDay yearMonthDay22 = dateTime14.toYearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (long) (-1), 1);
        org.joda.time.Instant instant28 = gJChronology27.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) gJChronology27);
        org.joda.time.DateTimeField dateTimeField30 = gJChronology27.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (byte) 10);
        long long34 = offsetDateTimeField32.roundFloor((long) (-1));
        long long37 = offsetDateTimeField32.set(0L, (int) (short) 10);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField32.getAsText(355, locale39);
        org.joda.time.DurationField durationField41 = offsetDateTimeField32.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone42, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField46 = gJChronology45.secondOfDay();
        org.joda.time.DateTimeField dateTimeField47 = gJChronology45.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone48, (long) (-1), 1);
        org.joda.time.Instant instant52 = gJChronology51.getGregorianCutover();
        org.joda.time.Chronology chronology53 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology51);
        org.joda.time.DurationField durationField54 = gJChronology51.hours();
        org.joda.time.DateTimeField dateTimeField55 = gJChronology51.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField57 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology45, dateTimeField55, 33);
        long long59 = skipUndoDateTimeField57.roundHalfEven((long) 100);
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime61 = dateTime60.toLocalDateTime();
        int[] intArray67 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
        int int68 = skipUndoDateTimeField57.getMaximumValue((org.joda.time.ReadablePartial) localDateTime61, intArray67);
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.chrono.GJChronology gJChronology73 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone70, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField74 = gJChronology73.secondOfDay();
        org.joda.time.DateTimeField dateTimeField75 = gJChronology73.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.chrono.GJChronology gJChronology79 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone76, (long) (-1), 1);
        org.joda.time.Instant instant80 = gJChronology79.getGregorianCutover();
        org.joda.time.Chronology chronology81 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology79);
        org.joda.time.DurationField durationField82 = gJChronology79.hours();
        org.joda.time.DateTimeField dateTimeField83 = gJChronology79.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField85 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology73, dateTimeField83, 33);
        long long87 = skipUndoDateTimeField85.roundHalfEven((long) 100);
        org.joda.time.DateTime dateTime88 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime89 = dateTime88.toLocalDateTime();
        int[] intArray95 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
        int int96 = skipUndoDateTimeField85.getMaximumValue((org.joda.time.ReadablePartial) localDateTime89, intArray95);
        int[] intArray98 = offsetDateTimeField32.addWrapField((org.joda.time.ReadablePartial) localDateTime61, 3, intArray95, (-3));
        try {
            gJChronology4.validate((org.joda.time.ReadablePartial) yearMonthDay22, intArray95);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(yearMonthDay22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-3600000L) + "'", long34 == (-3600000L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-57600000L) + "'", long37 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "355" + "'", str40.equals("355"));
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(instant52);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(localDateTime61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 12 + "'", int68 == 12);
        org.junit.Assert.assertNotNull(gJChronology73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(gJChronology79);
        org.junit.Assert.assertNotNull(instant80);
        org.junit.Assert.assertNotNull(chronology81);
        org.junit.Assert.assertNotNull(durationField82);
        org.junit.Assert.assertNotNull(dateTimeField83);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 0L + "'", long87 == 0L);
        org.junit.Assert.assertNotNull(dateTime88);
        org.junit.Assert.assertNotNull(localDateTime89);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 12 + "'", int96 == 12);
        org.junit.Assert.assertNotNull(intArray98);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(59, (int) (byte) 1, (int) (short) 10, 0, (int) '#', (int) '4', (org.joda.time.Chronology) julianChronology6);
        org.joda.time.DurationField durationField8 = julianChronology6.weeks();
        try {
            long long13 = julianChronology6.getDateTimeMillis((int) (byte) 1, (int) '4', 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.minuteOfHour();
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime15.era();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        mutableDateTime15.setZone(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.DurationField durationField6 = gJChronology4.millis();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (long) (-1), 1);
        org.joda.time.Instant instant11 = gJChronology10.getGregorianCutover();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DurationField durationField13 = gJChronology10.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField14 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField6, durationField13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.clockhourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology4);
        int int10 = mutableDateTime9.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(207356400010L, (int) (short) 1);
        boolean boolean11 = delegatedDateTimeField7.isSupported();
        int int13 = delegatedDateTimeField7.getMaximumValue((long) (short) 0);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField7.getAsShortText(0L, locale15);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3363116400010L + "'", long10 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2922730 + "'", int13 == 2922730);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "20" + "'", str16.equals("20"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant6.minus(readableDuration7);
        org.joda.time.DateTime dateTime9 = instant6.toDateTimeISO();
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
        org.joda.time.DateTime.Property property11 = dateTime9.dayOfYear();
        org.joda.time.LocalDateTime localDateTime12 = dateTime9.toLocalDateTime();
        org.joda.time.DateTime dateTime14 = dateTime9.plus((long) 5);
        org.joda.time.DateTime dateTime16 = dateTime9.plusWeeks(59);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.plusDays(1);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withMonthOfYear(33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 33 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1L, (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long17 = skipUndoDateTimeField15.roundHalfEven((long) 100);
        org.joda.time.DurationField durationField18 = skipUndoDateTimeField15.getLeapDurationField();
        java.lang.String str20 = skipUndoDateTimeField15.getAsShortText((-1L));
        java.lang.String str21 = skipUndoDateTimeField15.getName();
        org.joda.time.ReadablePartial readablePartial22 = null;
        java.util.Locale locale23 = null;
        try {
            java.lang.String str24 = skipUndoDateTimeField15.getAsShortText(readablePartial22, locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "3" + "'", str20.equals("3"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "clockhourOfHalfday" + "'", str21.equals("clockhourOfHalfday"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        int int17 = mutableDateTime12.getDayOfWeek();
        mutableDateTime12.setMinuteOfDay((int) (short) 0);
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime12.copy();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime20);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getMinuteOfDay();
        org.joda.time.Chronology chronology2 = dateTime0.getChronology();
        org.joda.time.DateTime dateTime4 = dateTime0.minusMonths(0);
        org.joda.time.DateTime dateTime6 = dateTime0.minusSeconds((-1));
        try {
            org.joda.time.DateTime dateTime8 = dateTime0.withDayOfMonth(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 960 + "'", int1 == 960);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        int int18 = mutableDateTime15.getMonthOfYear();
        try {
            mutableDateTime15.setWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime12.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (long) (-1), 1);
        org.joda.time.Instant instant22 = gJChronology21.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Instant instant24 = instant22.minus(readableDuration23);
        org.joda.time.Instant instant27 = instant24.withDurationAdded(0L, (int) (short) 0);
        org.joda.time.Instant instant28 = instant27.toInstant();
        mutableDateTime12.setDate((org.joda.time.ReadableInstant) instant28);
        int int30 = mutableDateTime12.getRoundingMode();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(instant24);
        org.junit.Assert.assertNotNull(instant27);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime15 = property13.roundHalfFloor();
        try {
            mutableDateTime15.setSecondOfMinute((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime15.monthOfYear();
        try {
            mutableDateTime15.setDateTime(0, 12, 2, (int) ' ', (int) (byte) 1, 33, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.clockhourOfHalfday();
        long long13 = gJChronology4.getDateTimeMillis(57599, 1, 4, (int) (byte) 100);
        org.joda.time.DurationField durationField14 = gJChronology4.millis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1755481968000100L + "'", long13 == 1755481968000100L);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(59, (int) (byte) 1, (int) (short) 10, 0, (int) '#', (int) '4', (org.joda.time.Chronology) julianChronology6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray10 = julianChronology6.get(readablePeriod8, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (long) (-1), 1);
        org.joda.time.Instant instant8 = gJChronology7.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology7);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology7.getZone();
        long long13 = dateTimeZone10.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone10);
        mutableDateTime14.setDayOfMonth((int) (byte) 1);
        mutableDateTime14.addMinutes(1);
        int int19 = mutableDateTime14.getDayOfWeek();
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime14.dayOfWeek();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("clockhourOfHalfday");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"clockhourOfHalfday\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"100\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        int int12 = offsetDateTimeField9.getMaximumValue();
        java.lang.String str14 = offsetDateTimeField9.getAsText((long) (byte) 0);
        boolean boolean15 = offsetDateTimeField9.isLenient();
        java.util.Locale locale18 = null;
        try {
            long long19 = offsetDateTimeField9.set((long) 960, "", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "26" + "'", str14.equals("26"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.String str2 = dateTimeFormatter0.print(0L);
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("19");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "16:00:00-08:00" + "'", str2.equals("16:00:00-08:00"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMonthOfYear(355);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long18 = skipUndoDateTimeField15.add(207356400010L, (long) 0);
        int int20 = skipUndoDateTimeField15.getMinimumValue(0L);
        try {
            long long23 = skipUndoDateTimeField15.set((long) ' ', 57600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for clockhourOfHalfday must be in the range [2,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 207356400010L + "'", long18 == 207356400010L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Pacific Standard Time", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Pacific Standard Time/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = instant4.isSupported(dateTimeFieldType5);
        org.joda.time.MutableDateTime mutableDateTime7 = instant4.toMutableDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime8 = instant4.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DurationField durationField7 = gJChronology4.hours();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.clockhourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj0, (org.joda.time.Chronology) gJChronology4);
        try {
            mutableDateTime9.setDayOfWeek(2922730);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922730 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (long) (-1), 1);
        org.joda.time.Instant instant13 = gJChronology12.getGregorianCutover();
        boolean boolean14 = gregorianChronology8.equals((java.lang.Object) gJChronology12);
        try {
            long long19 = gregorianChronology8.getDateTimeMillis((-1), (int) (short) -1, 20, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        org.joda.time.DurationField durationField10 = offsetDateTimeField9.getDurationField();
        long long13 = offsetDateTimeField9.add((long) 1, (long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.secondOfDay();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (long) (-1), 1);
        org.joda.time.Instant instant24 = gJChronology23.getGregorianCutover();
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology23);
        org.joda.time.DurationField durationField26 = gJChronology23.hours();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology23.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField27, 33);
        long long31 = skipUndoDateTimeField29.roundHalfEven((long) 100);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime33 = dateTime32.toLocalDateTime();
        int[] intArray39 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
        int int40 = skipUndoDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDateTime33, intArray39);
        int int41 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localDateTime33);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, (long) (-1), 1);
        org.joda.time.Instant instant48 = gJChronology47.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter43.withChronology((org.joda.time.Chronology) gJChronology47);
        org.joda.time.DateTimeZone dateTimeZone50 = gJChronology47.getZone();
        long long53 = dateTimeZone50.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime54 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone50);
        org.joda.time.MutableDateTime.Property property55 = mutableDateTime54.year();
        mutableDateTime54.setSecondOfMinute((int) (byte) 0);
        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime59 = dateTime58.toLocalDateTime();
        org.joda.time.DateTime dateTime61 = dateTime58.plusWeeks(100);
        boolean boolean63 = dateTime58.isBefore((long) 33);
        boolean boolean64 = mutableDateTime54.isAfter((org.joda.time.ReadableInstant) dateTime58);
        org.joda.time.DateTime dateTime65 = mutableDateTime54.toDateTimeISO();
        org.joda.time.LocalDateTime localDateTime66 = dateTime65.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone68, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField72 = gJChronology71.secondOfDay();
        org.joda.time.DateTimeField dateTimeField73 = gJChronology71.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.chrono.GJChronology gJChronology77 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone74, (long) (-1), 1);
        org.joda.time.Instant instant78 = gJChronology77.getGregorianCutover();
        org.joda.time.Chronology chronology79 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology77);
        org.joda.time.DurationField durationField80 = gJChronology77.hours();
        org.joda.time.DateTimeField dateTimeField81 = gJChronology77.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField83 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology71, dateTimeField81, 33);
        long long85 = skipUndoDateTimeField83.roundHalfEven((long) 100);
        org.joda.time.DateTime dateTime86 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime87 = dateTime86.toLocalDateTime();
        int[] intArray93 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
        int int94 = skipUndoDateTimeField83.getMaximumValue((org.joda.time.ReadablePartial) localDateTime87, intArray93);
        try {
            int[] intArray96 = offsetDateTimeField9.addWrapField((org.joda.time.ReadablePartial) localDateTime66, 60, intArray93, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 60");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(instant24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 12 + "'", int40 == 12);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(instant48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10L + "'", long53 == 10L);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(localDateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(localDateTime66);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(gJChronology77);
        org.junit.Assert.assertNotNull(instant78);
        org.junit.Assert.assertNotNull(chronology79);
        org.junit.Assert.assertNotNull(durationField80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 0L + "'", long85 == 0L);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(localDateTime87);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 12 + "'", int94 == 12);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsShortText(locale13);
        org.joda.time.DateTime dateTime16 = property12.setCopy("26");
        int int17 = property12.getMinimumValueOverall();
        org.joda.time.DateTime dateTime18 = property12.getDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "19" + "'", str14.equals("19"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        java.lang.String str8 = dateTimeZone7.getID();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (short) 100);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfYear(0);
        boolean boolean7 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.millisOfDay();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withDefaultYear(12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.monthOfYear();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readablePeriod7);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(207356400010L, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (long) (-1), 1);
        org.joda.time.Instant instant15 = gJChronology14.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Instant instant17 = instant15.minus(readableDuration16);
        org.joda.time.DateTime dateTime18 = instant15.toDateTimeISO();
        org.joda.time.DateTime.Property property19 = dateTime18.dayOfYear();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray22 = null;
        try {
            int int23 = delegatedDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) localDateTime21, intArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3363116400010L + "'", long10 == 3363116400010L);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDateTime21);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((-3600000L), dateTimeZone8);
        long long17 = dateTimeZone8.adjustOffset((long) 2000, false);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2000L + "'", long17 == 2000L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 60);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
        org.joda.time.DateTime dateTime14 = property12.setCopy(2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1969, 0, (int) (short) 10, 2000, (int) (short) 0, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 59);
        org.joda.time.Instant instant3 = instant1.withMillis((long) (short) 0);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.roundHalfCeiling();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.minuteOfHour();
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime15.era();
        int int20 = property19.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (byte) -1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        boolean boolean2 = buddhistChronology0.equals((java.lang.Object) (-1595441076314L));
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int10 = offsetDateTimeField9.getOffset();
        boolean boolean12 = offsetDateTimeField9.isLeap((long) 1970);
        int int13 = offsetDateTimeField9.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(4, 1969, 0, (int) (short) -1, (int) (byte) 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("100");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        mutableDateTime12.setSecondOfMinute((int) '#');
        int int16 = mutableDateTime12.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(59, (int) (byte) 1, (int) (short) 10, 0, (int) '#', (int) '4', (org.joda.time.Chronology) julianChronology6);
//        org.joda.time.DurationField durationField8 = julianChronology6.weeks();
//        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology6.getZone();
//        java.lang.String str11 = dateTimeZone9.getShortName((long) 'a');
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 2922730);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
        mutableDateTime20.addYears(0);
        try {
            mutableDateTime20.setHourOfDay(355);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 355 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime20);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(1, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendWeekOfWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        java.util.TimeZone timeZone6 = dateTimeZone5.toTimeZone();
        org.joda.time.LocalDateTime localDateTime7 = null;
        try {
            boolean boolean8 = dateTimeZone5.isLocalDateTimeGap(localDateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("26");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"26\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("5:55:32 AM UTC", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"5:55:32 AM UTC\" is malformed at \" AM UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        int int17 = mutableDateTime12.getDayOfWeek();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime12.dayOfWeek();
        org.joda.time.Interval interval19 = property18.toInterval();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval19);
        org.joda.time.ReadableInterval readableInterval21 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval19);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(interval19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(readableInterval21);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology6.getZone();
        long long12 = dateTimeZone9.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone9);
        org.joda.time.Chronology chronology14 = iSOChronology0.withZone(dateTimeZone9);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getChronology(chronology14);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime2 = dateTime1.toLocalDateTime();
        org.joda.time.DateTime dateTime4 = dateTime1.plusWeeks(100);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime4);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.minuteOfDay();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '#', (org.joda.time.Chronology) gJChronology4, locale6);
        dateTimeParserBucket7.setPivotYear((java.lang.Integer) 2000);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.halfdays();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        long long16 = delegatedDateTimeField13.add(207356400010L, (int) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField13);
        int int18 = delegatedDateTimeField13.getMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3363116400010L + "'", long16 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2922790 + "'", int18 == 2922790);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
        boolean boolean22 = mutableDateTime15.isEqual((long) 57599);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("355");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '355' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.secondOfDay();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology6, locale8, (java.lang.Integer) 0, (int) (short) 1);
        mutableDateTime1.setChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology6.getZone();
        long long16 = dateTimeZone13.adjustOffset(1755481968000100L, true);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1755481968000100L + "'", long16 == 1755481968000100L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        java.lang.String str11 = offsetDateTimeField9.getAsShortText((long) (byte) -1);
        org.joda.time.DurationField durationField12 = offsetDateTimeField9.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "25" + "'", str11.equals("25"));
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = buddhistChronology1.withUTC();
        try {
            org.joda.time.Instant instant3 = new org.joda.time.Instant((java.lang.Object) buddhistChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.BuddhistChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("DateTimeField[clockhourOfHalfday]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[clockhourOfHalfday]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-210866760000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-1595441073681L));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969W487", (java.lang.Number) (short) 1, (java.lang.Number) 0.0f, (java.lang.Number) 57600000);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 57600000 + "'", number5.equals(57600000));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969W487" + "'", str6.equals("1969W487"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 978336000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(2922730);
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        java.util.Locale locale4 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNull(locale4);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (-292275054L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 1, "America/Los_Angeles");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        java.lang.String str6 = illegalInstantException2.toString();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (America/Los_Angeles)" + "'", str6.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (America/Los_Angeles)"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime10 = dateTime7.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withYearOfCentury((int) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime7.plus((long) ' ');
        org.joda.time.YearMonthDay yearMonthDay15 = dateTime7.toYearMonthDay();
        org.joda.time.DateTime.Property property16 = dateTime7.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(yearMonthDay15);
        org.junit.Assert.assertNotNull(property16);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 51 + "'", int1 == 51);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendSecondOfDay(355);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("hi!");
        dateTimeFormatterBuilder6.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((-3600000L), dateTimeZone8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField16 = buddhistChronology15.centuries();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.secondOfDay();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime14.weekOfWeekyear();
        org.joda.time.DurationField durationField17 = property16.getRangeDurationField();
        int int18 = property16.getMinimumValueOverall();
        org.joda.time.MutableDateTime mutableDateTime19 = property16.roundHalfFloor();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.secondOfDay();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
        long long30 = delegatedDateTimeField27.add(207356400010L, (int) (short) 1);
        int int33 = delegatedDateTimeField27.getDifference((long) (byte) 100, (long) 5);
        boolean boolean34 = delegatedDateTimeField27.isLenient();
        try {
            mutableDateTime19.setRounding((org.joda.time.DateTimeField) delegatedDateTimeField27, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3363116400010L + "'", long30 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendTwoDigitYear(12, false);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (long) (-1), 1);
        org.joda.time.Instant instant17 = gJChronology16.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter12.withChronology((org.joda.time.Chronology) gJChronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology16.getZone();
        long long22 = dateTimeZone19.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone19);
        mutableDateTime23.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime26 = mutableDateTime23.copy();
        int int27 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) mutableDateTime26);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        long long31 = dateTimeZone7.adjustOffset((-61786108747997L), true);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-28800000) + "'", int27 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61786108747997L) + "'", long31 == (-61786108747997L));
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.clockhourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        mutableDateTime9.add(readablePeriod11);
//        int int13 = mutableDateTime9.getMillisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.secondOfDay();
//        org.joda.time.DurationField durationField20 = gJChronology18.halfdays();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) gJChronology18);
//        mutableDateTime9.setTime((org.joda.time.ReadableInstant) dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 808 + "'", int13 == 808);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = instant4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime8 = instant4.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "1969W487");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (long) (-1), 1);
        org.joda.time.Instant instant17 = gJChronology16.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter12.withChronology((org.joda.time.Chronology) gJChronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology16.getZone();
        long long22 = dateTimeZone19.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone19);
        mutableDateTime23.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime26 = mutableDateTime23.copy();
        int int27 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) mutableDateTime26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.secondOfDay();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34, (long) (-1), 1);
        org.joda.time.Instant instant38 = gJChronology37.getGregorianCutover();
        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology37);
        org.joda.time.DurationField durationField40 = gJChronology37.hours();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology37.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology31, dateTimeField41, 33);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45, (long) (-1), 1);
        org.joda.time.Instant instant49 = gJChronology48.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = dateTimeFormatter44.withChronology((org.joda.time.Chronology) gJChronology48);
        org.joda.time.DateTimeField dateTimeField51 = gJChronology48.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) (byte) 10);
        org.joda.time.DurationField durationField54 = offsetDateTimeField53.getDurationField();
        long long57 = offsetDateTimeField53.add((long) 1, (long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone58, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField62 = gJChronology61.secondOfDay();
        org.joda.time.DateTimeField dateTimeField63 = gJChronology61.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.chrono.GJChronology gJChronology67 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone64, (long) (-1), 1);
        org.joda.time.Instant instant68 = gJChronology67.getGregorianCutover();
        org.joda.time.Chronology chronology69 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology67);
        org.joda.time.DurationField durationField70 = gJChronology67.hours();
        org.joda.time.DateTimeField dateTimeField71 = gJChronology67.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField73 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology61, dateTimeField71, 33);
        long long75 = skipUndoDateTimeField73.roundHalfEven((long) 100);
        org.joda.time.DateTime dateTime76 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime77 = dateTime76.toLocalDateTime();
        int[] intArray83 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
        int int84 = skipUndoDateTimeField73.getMaximumValue((org.joda.time.ReadablePartial) localDateTime77, intArray83);
        int int85 = offsetDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) localDateTime77);
        int[] intArray88 = new int[] { 2922730, 57599 };
        int int89 = skipUndoDateTimeField43.getMinimumValue((org.joda.time.ReadablePartial) localDateTime77, intArray88);
        boolean boolean90 = dateTimeZone7.isLocalDateTimeGap(localDateTime77);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-28800000) + "'", int27 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(instant38);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(instant49);
        org.junit.Assert.assertNotNull(dateTimeFormatter50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1L + "'", long57 == 1L);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(gJChronology67);
        org.junit.Assert.assertNotNull(instant68);
        org.junit.Assert.assertNotNull(chronology69);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(localDateTime77);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 12 + "'", int84 == 12);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 10 + "'", int85 == 10);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply((-11359555622000L), 3600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -11359555622000 * 3600000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.halfdays();
        org.joda.time.Instant instant6 = gJChronology3.getGregorianCutover();
        try {
            long long14 = gJChronology3.getDateTimeMillis((int) (short) 0, 1970, (int) (byte) 0, 0, (int) (short) 100, (int) ' ', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(3, 808, 808, 1, (-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(33, (int) (byte) 0, 57599999, (int) ' ', 5, 69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime18 = property16.add(12);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(mutableDateTime18);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        long long13 = property12.remainder();
//        boolean boolean15 = property12.equals((java.lang.Object) (-1.0d));
//        org.joda.time.DateTime dateTime16 = property12.withMinimumValue();
//        java.util.Locale locale18 = null;
//        org.joda.time.DateTime dateTime19 = property12.setCopy("19", locale18);
//        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
//        org.joda.time.DateTime dateTime23 = dateTime21.minus(207356400010L);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime26 = dateTime21.withPeriodAdded(readablePeriod24, (int) (short) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-35125721489L) + "'", long13 == (-35125721489L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
//        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology6.getZone();
//        long long12 = dateTimeZone9.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone9);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.year();
//        org.joda.time.MutableDateTime mutableDateTime15 = property14.getMutableDateTime();
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.secondOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.Chronology chronology19 = dateTimeFormatter18.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (long) (-1), 1);
//        org.joda.time.Instant instant25 = gJChronology24.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter20.withChronology((org.joda.time.Chronology) gJChronology24);
//        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology24.getZone();
//        long long30 = dateTimeZone27.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone27);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter18.withZone(dateTimeZone27);
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone36, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.secondOfDay();
//        java.util.Locale locale41 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket44 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology39, locale41, (java.lang.Integer) 0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = gJChronology48.yearOfCentury();
//        dateTimeParserBucket44.saveField(dateTimeField50, (int) (short) 10);
//        java.util.Locale locale53 = dateTimeParserBucket44.getLocale();
//        java.lang.String str54 = dateTimeZone27.getShortName((long) (short) 10, locale53);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = dateTimeFormatter17.withLocale(locale53);
//        int int56 = property16.getMaximumTextLength(locale53);
//        try {
//            java.lang.String str57 = org.joda.time.format.DateTimeFormat.patternForStyle("32", locale53);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 3");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(instant25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(locale53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "PST" + "'", str54.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 5 + "'", int56 == 5);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 960, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96000 + "'", int2 == 96000);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(57600000, 33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) (short) 10, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.months();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gJChronology3.add(readablePeriod7, 212400000L, (int) '#');
        org.joda.time.DateTimeField dateTimeField11 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 212400000L + "'", long10 == 212400000L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        java.lang.String str11 = offsetDateTimeField9.getAsShortText((long) (byte) -1);
        long long14 = offsetDateTimeField9.add((long) 57600000, (long) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "25" + "'", str11.equals("25"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 54000000L + "'", long14 == 54000000L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        long long13 = property12.remainder();
//        boolean boolean15 = property12.equals((java.lang.Object) (-1.0d));
//        org.joda.time.DateTime dateTime16 = property12.withMinimumValue();
//        java.util.Locale locale18 = null;
//        org.joda.time.DateTime dateTime19 = property12.setCopy("19", locale18);
//        org.joda.time.DateTime dateTime20 = property12.roundHalfFloorCopy();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-35125720481L) + "'", long13 == (-35125720481L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.MutableDateTime mutableDateTime16 = mutableDateTime12.copy();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime10 = dateTime7.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withYearOfCentury((int) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime7.plus((long) ' ');
        org.joda.time.DateTime.Property property15 = dateTime7.millisOfDay();
        try {
            org.joda.time.DateTime dateTime17 = property15.setCopy("clockhourOfHalfday");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"clockhourOfHalfday\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            long long3 = dateTimeFormatter0.parseMillis("BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        long long10 = delegatedDateTimeField7.add(207356400010L, (int) (short) 1);
        int int13 = delegatedDateTimeField7.getDifference(0L, (-1595441073681L));
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3363116400010L + "'", long10 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology6.getZone();
        long long12 = dateTimeZone9.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withZone(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.ReadableInstant readableInstant17 = null;
        int int18 = dateTimeZone9.getOffset(readableInstant17);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.dayOfWeek();
        org.joda.time.ReadableDuration readableDuration17 = null;
        mutableDateTime15.add(readableDuration17);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        int int13 = offsetDateTimeField9.getLeapAmount((long) 5);
        try {
            org.joda.time.Instant instant14 = new org.joda.time.Instant((java.lang.Object) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (long) (-1), 1);
        org.joda.time.Instant instant9 = gJChronology8.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
        long long14 = dateTimeZone11.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone11);
        mutableDateTime15.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime15.copy();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        mutableDateTime18.add(readablePeriod19);
        mutableDateTime18.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime23 = mutableDateTime18.toMutableDateTime();
        java.lang.String str24 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter0.withPivotYear(59);
        java.lang.StringBuffer stringBuffer27 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (long) (-1), 1);
        org.joda.time.Instant instant34 = gJChronology33.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter29.withChronology((org.joda.time.Chronology) gJChronology33);
        org.joda.time.DateTimeZone dateTimeZone36 = gJChronology33.getZone();
        long long39 = dateTimeZone36.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone36);
        mutableDateTime40.setDayOfMonth((int) (byte) 1);
        mutableDateTime40.addMinutes(1);
        int int45 = mutableDateTime40.getDayOfWeek();
        mutableDateTime40.setMinuteOfDay((int) (short) 0);
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime40.millisOfDay();
        try {
            dateTimeFormatter26.printTo(stringBuffer27, (org.joda.time.ReadableInstant) mutableDateTime40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969W487" + "'", str24.equals("1969W487"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(property48);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        java.lang.String str7 = gJChronology3.toString();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GJChronology[America/Los_Angeles,cutover=1969-12-31T23:59:59.999Z,mdfw=1]" + "'", str7.equals("GJChronology[America/Los_Angeles,cutover=1969-12-31T23:59:59.999Z,mdfw=1]"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        long long9 = julianChronology0.getDateTimeMillis(12, 1, 31, 0, 0, (int) '4', 3);
        int int10 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61786108747997L) + "'", long9 == (-61786108747997L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1970W013");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1970W013' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        long long13 = property12.remainder();
//        boolean boolean15 = property12.equals((java.lang.Object) (-1.0d));
//        org.joda.time.DateTime dateTime16 = property12.withMinimumValue();
//        java.util.Locale locale18 = null;
//        org.joda.time.DateTime dateTime19 = property12.setCopy("19", locale18);
//        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime19.minus(readableDuration22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-35125719227L) + "'", long13 == (-35125719227L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 2922790);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2922790 + "'", int1 == 2922790);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        java.util.TimeZone timeZone6 = dateTimeZone5.toTimeZone();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        mutableDateTime12.setSecondOfMinute((int) (byte) 0);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime17 = dateTime16.toLocalDateTime();
        org.joda.time.DateTime dateTime19 = dateTime16.plusWeeks(100);
        boolean boolean21 = dateTime16.isBefore((long) 33);
        boolean boolean22 = mutableDateTime12.isAfter((org.joda.time.ReadableInstant) dateTime16);
        try {
            org.joda.time.DateTime dateTime24 = dateTime16.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime16 = property15.roundHalfEven();
        mutableDateTime16.setMillisOfSecond(1);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField9.getWrappedField();
        int int13 = offsetDateTimeField9.getMinimumValue();
        java.lang.String str14 = offsetDateTimeField9.getName();
        long long17 = offsetDateTimeField9.getDifferenceAsLong((long) 959, (long) 960);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hourOfDay" + "'", str14.equals("hourOfDay"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(59, (int) (byte) 1, (int) (short) 10, 0, (int) '#', (int) '4', (org.joda.time.Chronology) julianChronology12);
        org.joda.time.DurationField durationField14 = julianChronology12.weeks();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology12.getZone();
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((-292275054), 2, 651, (int) (byte) 10, (-3), 3, dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 100, 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
//        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
//        mutableDateTime12.setDayOfMonth((int) (byte) 1);
//        mutableDateTime12.addMinutes(1);
//        int int17 = mutableDateTime12.getDayOfWeek();
//        mutableDateTime12.addWeekyears((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (long) (-1), 1);
//        org.joda.time.Instant instant25 = gJChronology24.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter20.withChronology((org.joda.time.Chronology) gJChronology24);
//        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology24.getZone();
//        long long30 = dateTimeZone27.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone27);
//        org.joda.time.DateTime.Property property32 = dateTime31.centuryOfEra();
//        long long33 = property32.remainder();
//        boolean boolean35 = property32.equals((java.lang.Object) (-1.0d));
//        org.joda.time.DateTime dateTime36 = property32.withMinimumValue();
//        org.joda.time.DateTime dateTime38 = dateTime36.withYear(4);
//        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime38);
//        mutableDateTime12.setMillis((org.joda.time.ReadableInstant) dateTime38);
//        int int41 = dateTime38.getYear();
//        long long42 = dateTime38.getMillis();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(instant25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-35125718561L) + "'", long33 == (-35125718561L));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62012927740561L) + "'", long42 == (-62012927740561L));
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        java.io.Writer writer1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
//        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) 10);
//        long long13 = offsetDateTimeField11.roundFloor((long) (-1));
//        int int14 = offsetDateTimeField11.getMaximumValue();
//        java.util.Locale locale15 = null;
//        int int16 = offsetDateTimeField11.getMaximumShortTextLength(locale15);
//        long long19 = offsetDateTimeField11.add((long) (short) 10, 57599);
//        org.joda.time.DurationField durationField20 = offsetDateTimeField11.getRangeDurationField();
//        long long23 = offsetDateTimeField11.add(0L, (long) 59);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField11.getAsShortText((-1595441066456L), locale25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime28 = dateTime27.toLocalDateTime();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = offsetDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDateTime28, locale29);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDateTime28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-3600000L) + "'", long13 == (-3600000L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 33 + "'", int14 == 33);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 207356400010L + "'", long19 == 207356400010L);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 212400000L + "'", long23 == 212400000L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "32" + "'", str26.equals("32"));
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localDateTime28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10" + "'", str30.equals("10"));
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 1);
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter0.parseLocalDate("1969W487");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969W487\" is malformed at \"W487\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime15.weekyear();
        try {
            mutableDateTime15.setDayOfMonth(57599);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        org.joda.time.DateTime dateTime12 = dateTime9.plusWeeks(100);
        boolean boolean13 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean9 = dateTimeFormatterBuilder8.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendCenturyOfEra(1, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendSecondOfMinute((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean16 = dateTimeFormatterBuilder15.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond(20);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.secondOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType27);
        long long31 = delegatedDateTimeField28.add(207356400010L, (int) (short) 1);
        boolean boolean32 = delegatedDateTimeField28.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField28.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder20.appendFixedSignedDecimal(dateTimeFieldType33, 59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder12.appendFixedSignedDecimal(dateTimeFieldType33, 355);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType33, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3363116400010L + "'", long31 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = gregorianChronology0.get(readablePeriod3, (long) (-3));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (long) (-1), 1);
        org.joda.time.Instant instant9 = gJChronology8.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
        java.lang.String str12 = dateTimeZone11.getID();
        org.joda.time.Chronology chronology13 = julianChronology2.withZone(dateTimeZone11);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) (short) 100, (org.joda.time.Chronology) julianChronology2, locale14, (java.lang.Integer) 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (long) (-1), 1);
        org.joda.time.Instant instant22 = gJChronology21.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter17.withChronology((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) (byte) 10);
        long long28 = offsetDateTimeField26.roundFloor((long) (-1));
        int int29 = offsetDateTimeField26.getMaximumValue();
        long long31 = offsetDateTimeField26.roundHalfEven((-1595441068446L));
        boolean boolean32 = dateTimeParserBucket16.restoreState((java.lang.Object) long31);
        org.joda.time.DateTimeZone dateTimeZone33 = dateTimeParserBucket16.getZone();
        java.lang.String str34 = dateTimeZone33.toString();
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((long) 57600000, dateTimeZone33);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-3600000L) + "'", long28 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 33 + "'", int29 == 33);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1595440800000L) + "'", long31 == (-1595440800000L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "UTC" + "'", str34.equals("UTC"));
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone7.getName(1L, locale12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone7);
//        try {
//            org.joda.time.DateTime dateTime16 = dateTime14.withSecondOfMinute((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(1, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0, false);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder3.appendTimeZoneOffset("BuddhistChronology[UTC]", "", false, (int) (byte) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969W487", (java.lang.Number) (short) 1, (java.lang.Number) 0.0f, (java.lang.Number) 57600000);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        illegalFieldValueException4.prependMessage("3");
        java.lang.String str8 = illegalFieldValueException4.toString();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969W487" + "'", str5.equals("1969W487"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: 3: Value 1 for 1969W487 must be in the range [0.0,57600000]" + "'", str8.equals("org.joda.time.IllegalFieldValueException: 3: Value 1 for 1969W487 must be in the range [0.0,57600000]"));
        org.junit.Assert.assertNull(durationFieldType9);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.halfdays();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        long long16 = delegatedDateTimeField13.add(207356400010L, (int) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField13);
        org.joda.time.DateTimeField dateTimeField18 = skipDateTimeField17.getWrappedField();
        int int19 = skipDateTimeField17.getMinimumValue();
        long long22 = skipDateTimeField17.set((long) 1969, 2);
        long long24 = skipDateTimeField17.roundHalfCeiling(0L);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider26 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.secondOfDay();
        java.util.Locale locale33 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket36 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology31, locale33, (java.lang.Integer) 0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.secondOfDay();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology40.yearOfCentury();
        dateTimeParserBucket36.saveField(dateTimeField42, (int) (short) 10);
        java.util.Locale locale45 = dateTimeParserBucket36.getLocale();
        java.lang.String str48 = defaultNameProvider26.getName(locale45, "America/Los_Angeles", "100");
        java.lang.String str49 = skipDateTimeField17.getAsShortText(0L, locale45);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3363116400010L + "'", long16 == 3363116400010L);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-56803680420031L) + "'", long22 == (-56803680420031L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 978336000000L + "'", long24 == 978336000000L);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(locale45);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "20" + "'", str49.equals("20"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
        mutableDateTime20.addYears(0);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime20);
        org.joda.time.DurationFieldType durationFieldType24 = null;
        try {
            mutableDateTime20.add(durationFieldType24, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        int int17 = mutableDateTime12.getDayOfWeek();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime12.dayOfWeek();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2922730);
        org.joda.time.TimeOfDay timeOfDay21 = dateTime20.toTimeOfDay();
        try {
            int int22 = property18.compareTo((org.joda.time.ReadablePartial) timeOfDay21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(timeOfDay21);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfDay();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology4, locale6, (java.lang.Integer) 0, (int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (long) (-1), 1);
        org.joda.time.Instant instant15 = gJChronology14.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (byte) 10);
        long long21 = offsetDateTimeField19.roundFloor((long) (-1));
        long long24 = offsetDateTimeField19.add(57600000L, 2L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, (org.joda.time.DateTimeField) offsetDateTimeField19);
        try {
            long long28 = offsetDateTimeField19.set((-292275054L), 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [10,33]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-3600000L) + "'", long21 == (-3600000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 64800000L + "'", long24 == 64800000L);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        long long13 = property12.remainder();
//        boolean boolean15 = property12.equals((java.lang.Object) (-1.0d));
//        org.joda.time.DateTime dateTime16 = property12.withMinimumValue();
//        java.util.Locale locale18 = null;
//        org.joda.time.DateTime dateTime19 = property12.setCopy("19", locale18);
//        long long20 = property12.remainder();
//        org.joda.time.DateTime dateTime21 = property12.withMinimumValue();
//        org.joda.time.DateTime dateTime22 = property12.roundHalfFloorCopy();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-35125716991L) + "'", long13 == (-35125716991L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-35125716991L) + "'", long20 == (-35125716991L));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (long) (-1), 1);
        org.joda.time.Instant instant17 = gJChronology16.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter12.withChronology((org.joda.time.Chronology) gJChronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology16.getZone();
        long long22 = dateTimeZone19.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone19);
        mutableDateTime23.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime26 = mutableDateTime23.copy();
        int int27 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) mutableDateTime26);
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime26.year();
        java.lang.String str29 = property28.getName();
        org.joda.time.MutableDateTime mutableDateTime30 = property28.roundHalfCeiling();
        org.joda.time.ReadableDuration readableDuration31 = null;
        mutableDateTime30.add(readableDuration31);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-28800000) + "'", int27 == (-28800000));
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "year" + "'", str29.equals("year"));
        org.junit.Assert.assertNotNull(mutableDateTime30);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long17 = skipUndoDateTimeField15.roundHalfEven((long) 100);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
        int[] intArray25 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
        int int26 = skipUndoDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) localDateTime19, intArray25);
        long long29 = skipUndoDateTimeField15.add(0L, (int) (byte) -1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3600000L) + "'", long29 == (-3600000L));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, 57600000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        long long14 = offsetDateTimeField9.set(0L, (int) (short) 10);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField9.getAsText(355, locale16);
        org.joda.time.DurationField durationField18 = offsetDateTimeField9.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.secondOfDay();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, (long) (-1), 1);
        org.joda.time.Instant instant29 = gJChronology28.getGregorianCutover();
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology28);
        org.joda.time.DurationField durationField31 = gJChronology28.hours();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology28.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField32, 33);
        long long36 = skipUndoDateTimeField34.roundHalfEven((long) 100);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
        int[] intArray44 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
        int int45 = skipUndoDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDateTime38, intArray44);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone47, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.secondOfDay();
        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53, (long) (-1), 1);
        org.joda.time.Instant instant57 = gJChronology56.getGregorianCutover();
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology56);
        org.joda.time.DurationField durationField59 = gJChronology56.hours();
        org.joda.time.DateTimeField dateTimeField60 = gJChronology56.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology50, dateTimeField60, 33);
        long long64 = skipUndoDateTimeField62.roundHalfEven((long) 100);
        org.joda.time.DateTime dateTime65 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime66 = dateTime65.toLocalDateTime();
        int[] intArray72 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
        int int73 = skipUndoDateTimeField62.getMaximumValue((org.joda.time.ReadablePartial) localDateTime66, intArray72);
        int[] intArray75 = offsetDateTimeField9.addWrapField((org.joda.time.ReadablePartial) localDateTime38, 3, intArray72, (-3));
        java.util.Locale locale76 = null;
        int int77 = offsetDateTimeField9.getMaximumTextLength(locale76);
        org.joda.time.DurationField durationField78 = offsetDateTimeField9.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-57600000L) + "'", long14 == (-57600000L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "355" + "'", str17.equals("355"));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(instant29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDateTime38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(gJChronology56);
        org.junit.Assert.assertNotNull(instant57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(localDateTime66);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 12 + "'", int73 == 12);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2 + "'", int77 == 2);
        org.junit.Assert.assertNull(durationField78);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
        mutableDateTime20.addYears(0);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime20);
        mutableDateTime20.setMillis((long) (byte) 100);
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime20.dayOfWeek();
        mutableDateTime20.addWeekyears(5);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(property26);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        int int17 = mutableDateTime12.getDayOfWeek();
        mutableDateTime12.addWeekyears((int) (byte) 0);
        mutableDateTime12.addYears(57599);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYear(1, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendDayOfYear(2);
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatterBuilder10.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter6, dateTimeParser13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(69, (int) (byte) 10, 20, (-3), 0, 10, 355);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.DurationField durationField7 = gJChronology5.halfdays();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, dateTimeFieldType14);
        long long18 = delegatedDateTimeField15.add(207356400010L, (int) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, (org.joda.time.DateTimeField) delegatedDateTimeField15);
        org.joda.time.DateTimeField dateTimeField20 = skipDateTimeField19.getWrappedField();
        int int21 = skipDateTimeField19.getMinimumValue();
        long long24 = skipDateTimeField19.set((long) 1969, 2);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.secondOfDay();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology28.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30, dateTimeFieldType31);
        long long35 = delegatedDateTimeField32.add(207356400010L, (int) (short) 1);
        boolean boolean36 = delegatedDateTimeField32.isSupported();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.secondOfDay();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology40.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43, (long) (-1), 1);
        org.joda.time.Instant instant47 = gJChronology46.getGregorianCutover();
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology46);
        org.joda.time.DurationField durationField49 = gJChronology46.hours();
        org.joda.time.DateTimeField dateTimeField50 = gJChronology46.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField50, 33);
        long long54 = skipUndoDateTimeField52.roundHalfEven((long) 100);
        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        int[] intArray62 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
        int int63 = skipUndoDateTimeField52.getMaximumValue((org.joda.time.ReadablePartial) localDateTime56, intArray62);
        java.util.Locale locale65 = null;
        java.lang.String str66 = delegatedDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) localDateTime56, 10, locale65);
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone68, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField72 = gJChronology71.secondOfDay();
        java.util.Locale locale73 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket76 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology71, locale73, (java.lang.Integer) 0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone77 = null;
        org.joda.time.chrono.GJChronology gJChronology80 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone77, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField81 = gJChronology80.secondOfDay();
        org.joda.time.DateTimeField dateTimeField82 = gJChronology80.yearOfCentury();
        dateTimeParserBucket76.saveField(dateTimeField82, (int) (short) 10);
        java.util.Locale locale85 = dateTimeParserBucket76.getLocale();
        java.lang.String str86 = skipDateTimeField19.getAsShortText((org.joda.time.ReadablePartial) localDateTime56, locale85);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter87 = dateTimeFormatter0.withLocale(locale85);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3363116400010L + "'", long18 == 3363116400010L);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-56803680420031L) + "'", long24 == (-56803680420031L));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3363116400010L + "'", long35 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(instant47);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 12 + "'", int63 == 12);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "10" + "'", str66.equals("10"));
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(gJChronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(dateTimeField82);
        org.junit.Assert.assertNotNull(locale85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "19" + "'", str86.equals("19"));
        org.junit.Assert.assertNotNull(dateTimeFormatter87);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("GJChronology[America/Los_Angeles,cutover=1969-12-31T23:59:59.999Z,mdfw=1]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[America/Los_Angeles...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long18 = skipUndoDateTimeField15.add(207356400010L, (long) 0);
        int int20 = skipUndoDateTimeField15.getMinimumValue(0L);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.secondOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType27);
        long long31 = delegatedDateTimeField28.add(207356400010L, (int) (short) 1);
        boolean boolean32 = delegatedDateTimeField28.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType33, (int) ' ');
        try {
            long long38 = skipUndoDateTimeField15.set((-35125715199L), 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for clockhourOfHalfday must be in the range [2,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 207356400010L + "'", long18 == 207356400010L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3363116400010L + "'", long31 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 35, 2922730, 0, (int) (byte) 0, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.secondOfDay();
        mutableDateTime14.setDate(2440588L);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("1968-W47-3T10:51:19");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1968-W47-3T10:51:19\" is malformed at \"-W47-3T10:51:19\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
//        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.monthOfYear();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        int int8 = dateTime6.getHourOfDay();
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        int int12 = offsetDateTimeField9.getMaximumValue();
        long long14 = offsetDateTimeField9.roundHalfEven((-1595441068446L));
        org.joda.time.tz.DefaultNameProvider defaultNameProvider16 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.secondOfDay();
        java.util.Locale locale23 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology21, locale23, (java.lang.Integer) 0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField31 = gJChronology30.secondOfDay();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology30.yearOfCentury();
        dateTimeParserBucket26.saveField(dateTimeField32, (int) (short) 10);
        java.util.Locale locale35 = dateTimeParserBucket26.getLocale();
        java.lang.String str38 = defaultNameProvider16.getName(locale35, "America/Los_Angeles", "100");
        java.lang.String str39 = offsetDateTimeField9.getAsShortText((long) 355, locale35);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1595440800000L) + "'", long14 == (-1595440800000L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(locale35);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "26" + "'", str39.equals("26"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.year();
        java.lang.String str2 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        long long17 = skipUndoDateTimeField15.roundHalfEven((long) 100);
        org.joda.time.DurationField durationField18 = skipUndoDateTimeField15.getLeapDurationField();
        java.lang.String str20 = skipUndoDateTimeField15.getAsShortText((-1L));
        java.lang.String str21 = skipUndoDateTimeField15.getName();
        int int23 = skipUndoDateTimeField15.get(0L);
        java.lang.String str25 = skipUndoDateTimeField15.getAsText(43200005L);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "3" + "'", str20.equals("3"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "clockhourOfHalfday" + "'", str21.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "4" + "'", str25.equals("4"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime0, chronology2);
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra(33);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(59, (int) (byte) 1, (int) (short) 10, 0, (int) '#', (int) '4', (org.joda.time.Chronology) julianChronology6);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withDayOfWeek(59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1892275200000L));
        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime1.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMinuteOfDay();
//        org.joda.time.Chronology chronology2 = dateTime0.getChronology();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMonths(0);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusSeconds((-1));
//        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = null;
//        java.lang.String str9 = dateTime6.toString(dateTimeFormatter8);
//        try {
//            java.lang.String str11 = dateTime6.toString("GregorianChronology[UTC]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 651 + "'", int1 == 651);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1968-11-20T10:51:27.265-08:00" + "'", str9.equals("1968-11-20T10:51:27.265-08:00"));
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfDay();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology4, locale6, (java.lang.Integer) 0, (int) (short) 1);
        org.joda.time.DurationField durationField10 = gJChronology4.years();
        long long13 = durationField10.subtract((long) 2, 35);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1104537599998L) + "'", long13 == (-1104537599998L));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        long long13 = property12.remainder();
//        boolean boolean15 = property12.equals((java.lang.Object) (-1.0d));
//        org.joda.time.DateTime dateTime16 = property12.withMinimumValue();
//        org.joda.time.DateTime dateTime18 = dateTime16.withYear(4);
//        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.Instant instant20 = dateTime18.toInstant();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.Instant instant22 = instant20.minus(readableDuration21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-35125713680L) + "'", long13 == (-35125713680L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(instant20);
//        org.junit.Assert.assertNotNull(instant22);
//    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
//        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
//        org.joda.time.MutableDateTime mutableDateTime14 = property13.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime15 = property13.roundHalfFloor();
//        org.joda.time.MutableDateTime mutableDateTime17 = property13.set((int) (short) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (long) (-1), 1);
//        org.joda.time.Instant instant24 = gJChronology23.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter19.withChronology((org.joda.time.Chronology) gJChronology23);
//        org.joda.time.DateTimeZone dateTimeZone26 = gJChronology23.getZone();
//        long long29 = dateTimeZone26.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone26);
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.year();
//        org.joda.time.MutableDateTime mutableDateTime32 = property31.getMutableDateTime();
//        org.joda.time.MutableDateTime.Property property33 = mutableDateTime32.secondOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.Chronology chronology36 = dateTimeFormatter35.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (long) (-1), 1);
//        org.joda.time.Instant instant42 = gJChronology41.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) gJChronology41);
//        org.joda.time.DateTimeZone dateTimeZone44 = gJChronology41.getZone();
//        long long47 = dateTimeZone44.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now(dateTimeZone44);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter35.withZone(dateTimeZone44);
//        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField57 = gJChronology56.secondOfDay();
//        java.util.Locale locale58 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket61 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology56, locale58, (java.lang.Integer) 0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone62, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField66 = gJChronology65.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField67 = gJChronology65.yearOfCentury();
//        dateTimeParserBucket61.saveField(dateTimeField67, (int) (short) 10);
//        java.util.Locale locale70 = dateTimeParserBucket61.getLocale();
//        java.lang.String str71 = dateTimeZone44.getShortName((long) (short) 10, locale70);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = dateTimeFormatter34.withLocale(locale70);
//        int int73 = property33.getMaximumTextLength(locale70);
//        java.lang.String str74 = property13.getAsText(locale70);
//        org.joda.time.DateTimeField dateTimeField75 = property13.getField();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(instant24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNull(chronology36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(instant42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(gregorianChronology50);
//        org.junit.Assert.assertNotNull(gJChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(gJChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertNotNull(locale70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "PST" + "'", str71.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 5 + "'", int73 == 5);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "0" + "'", str74.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeField75);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        java.lang.String str11 = offsetDateTimeField9.getAsShortText((long) (byte) -1);
        java.lang.String str13 = offsetDateTimeField9.getAsText((-1595441076314L));
        int int15 = offsetDateTimeField9.getMaximumValue(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "25" + "'", str11.equals("25"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "32" + "'", str13.equals("32"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 33 + "'", int15 == 33);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone2.getName((long) (byte) -1, locale5);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1969W487");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1969W487' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.halfdays();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        long long16 = delegatedDateTimeField13.add(207356400010L, (int) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField13);
        org.joda.time.DateTimeField dateTimeField18 = skipDateTimeField17.getWrappedField();
        int int19 = skipDateTimeField17.getMinimumValue();
        try {
            long long22 = skipDateTimeField17.set(0L, (-3));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for centuryOfEra must be in the range [1,2922790]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3363116400010L + "'", long16 == 3363116400010L);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        int int17 = mutableDateTime12.getDayOfWeek();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime12.dayOfWeek();
        org.joda.time.Interval interval19 = property18.toInterval();
        org.joda.time.MutableDateTime mutableDateTime20 = property18.roundHalfFloor();
        mutableDateTime20.addYears(10);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(interval19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime15.weekyear();
        mutableDateTime15.addMonths(2);
        mutableDateTime15.addMinutes(100);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology9 = dateTimeFormatter8.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (long) (-1), 1);
        org.joda.time.Instant instant15 = gJChronology14.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology14.getZone();
        long long20 = dateTimeZone17.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter8.withZone(dateTimeZone17);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone17);
        try {
            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(2, 51, 4, (int) (short) 1, 4, 59, (org.joda.time.Chronology) zonedChronology24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 51 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(zonedChronology24);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (long) (-1), 1);
        org.joda.time.Instant instant15 = gJChronology14.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology14.getZone();
        long long20 = dateTimeZone17.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone17);
        mutableDateTime21.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime24 = mutableDateTime21.copy();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        mutableDateTime24.add(readablePeriod25);
        mutableDateTime24.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime24.toMutableDateTime();
        try {
            org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime24, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 12");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(mutableDateTime29);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime12.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.monthOfYear();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withEra(69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        mutableDateTime12.setWeekOfWeekyear((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
//        int int12 = offsetDateTimeField9.getMaximumValue();
//        java.lang.String str14 = offsetDateTimeField9.getAsText((long) (byte) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField9.getType();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, (long) (-1), 1);
//        org.joda.time.Instant instant21 = gJChronology20.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) gJChronology20);
//        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology20.getZone();
//        long long26 = dateTimeZone23.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone23);
//        org.joda.time.DateTime.Property property28 = dateTime27.centuryOfEra();
//        long long29 = property28.remainder();
//        org.joda.time.DateTime dateTime30 = property28.getDateTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType31, 69, 59, 57599);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType31, 11, (int) (short) 10, 6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 11 for centuryOfEra must be in the range [10,6]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "26" + "'", str14.equals("26"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(instant21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-35125711626L) + "'", long29 == (-35125711626L));
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone7.getName(1L, locale12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 651, 1, (-809));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(57600000, 33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) (short) 10, (int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.append(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.halfdays();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        long long16 = delegatedDateTimeField13.add(207356400010L, (int) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField13);
        org.joda.time.Chronology chronology18 = gJChronology3.withUTC();
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getChronology(chronology18);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3363116400010L + "'", long16 == 3363116400010L);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(1, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendFractionOfMinute(0, 57600000);
        boolean boolean14 = dateTimeFormatterBuilder10.canBuildFormatter();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder10.appendDecimal(dateTimeFieldType15, (int) (byte) 1, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1, 35, 0, 651, 0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 651 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (long) (-1), 1);
        org.joda.time.Instant instant12 = gJChronology11.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology11.getZone();
        java.lang.String str15 = dateTimeZone14.getID();
        try {
            org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(68, (int) (short) -1, 0, 3, (int) 'a', 20, 2, dateTimeZone14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (long) (-1), 1);
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) gJChronology17);
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology17.getZone();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology17.clockhourOfHalfday();
        long long26 = gJChronology17.getDateTimeMillis(57599, 1, 4, (int) (byte) 100);
        boolean boolean27 = iSOChronology12.equals((java.lang.Object) gJChronology17);
        org.joda.time.DateTimeField dateTimeField28 = gJChronology17.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1755481968000100L + "'", long26 == 1755481968000100L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1892275200000L));
//        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (long) (-1), 1);
//        org.joda.time.Instant instant9 = gJChronology8.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology8);
//        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
//        long long14 = dateTimeZone11.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        long long17 = property16.remainder();
//        boolean boolean19 = property16.equals((java.lang.Object) (-1.0d));
//        org.joda.time.DateTime dateTime20 = property16.withMinimumValue();
//        java.util.Locale locale22 = null;
//        org.joda.time.DateTime dateTime23 = property16.setCopy("19", locale22);
//        org.joda.time.DateTime dateTime25 = dateTime23.withMillis(100L);
//        int int26 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime25);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-35125710511L) + "'", long17 == (-35125710511L));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        int int1 = dateTimeFormatter0.getDefaultYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
//        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) 10);
//        org.joda.time.DurationField durationField12 = offsetDateTimeField11.getDurationField();
//        long long15 = offsetDateTimeField11.add((long) 1, (long) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology19.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (long) (-1), 1);
//        org.joda.time.Instant instant26 = gJChronology25.getGregorianCutover();
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.DurationField durationField28 = gJChronology25.hours();
//        org.joda.time.DateTimeField dateTimeField29 = gJChronology25.clockhourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField29, 33);
//        long long33 = skipUndoDateTimeField31.roundHalfEven((long) 100);
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime35 = dateTime34.toLocalDateTime();
//        int[] intArray41 = new int[] { (byte) 1, 'a', 59, 1, 'a' };
//        int int42 = skipUndoDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) localDateTime35, intArray41);
//        int int43 = offsetDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) localDateTime35);
//        java.lang.String str44 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime35);
//        try {
//            long long46 = dateTimeFormatter0.parseMillis("GJChronology[America/Los_Angeles,cutover=1969-12-31T23:59:59.999Z,mdfw=1]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[America/Los_Angeles...\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(instant26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localDateTime35);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1968-W47-3T10:51:29" + "'", str44.equals("1968-W47-3T10:51:29"));
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.months();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (long) (-1), 1);
        org.joda.time.Instant instant8 = gJChronology7.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology7);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology7.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) 10);
        long long14 = offsetDateTimeField12.roundFloor((long) (-1));
        long long17 = offsetDateTimeField12.set(0L, (int) (short) 10);
        long long19 = offsetDateTimeField12.roundHalfCeiling((-35125713680L));
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField12, 69);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-3600000L) + "'", long14 == (-3600000L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-57600000L) + "'", long17 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-35125200000L) + "'", long19 == (-35125200000L));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (long) (-1), 1);
        org.joda.time.Instant instant16 = gJChronology15.getGregorianCutover();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology15);
        org.joda.time.DurationField durationField18 = gJChronology15.hours();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology15.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField19, 33);
        long long23 = skipUndoDateTimeField21.roundHalfEven((long) 100);
        long long26 = skipUndoDateTimeField21.getDifferenceAsLong(212400000L, 64800000L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) skipUndoDateTimeField21, 2922730);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 41L + "'", long26 == 41L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime.Property property11 = dateTime7.hourOfDay();
        org.joda.time.DateTime dateTime12 = dateTime7.withTimeAtStartOfDay();
        int int13 = dateTime7.getWeekyear();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekyear(57600000, 33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) (short) 10, (int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology3.halfdays();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        long long16 = delegatedDateTimeField13.add(207356400010L, (int) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField13);
        int int18 = skipDateTimeField17.getMinimumValue();
        org.joda.time.DurationField durationField19 = skipDateTimeField17.getRangeDurationField();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3363116400010L + "'", long16 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(durationField19);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.clockhourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.monthOfYear();
//        int int11 = mutableDateTime9.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (long) (-1), 1);
        org.joda.time.Instant instant20 = gJChronology19.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (long) (-1), 1);
        org.joda.time.Instant instant26 = gJChronology25.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter21.withChronology((org.joda.time.Chronology) gJChronology25);
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology25.getZone();
        java.lang.String str29 = dateTimeZone28.getID();
        org.joda.time.DateTime dateTime30 = instant20.toDateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay31 = dateTime30.toYearMonthDay();
        int int32 = property15.compareTo((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime.Property property33 = dateTime30.secondOfMinute();
        org.joda.time.DateTime.Property property34 = dateTime30.weekOfWeekyear();
        org.joda.time.DateTime dateTime36 = dateTime30.minusWeeks((int) (short) 100);
        java.lang.String str37 = dateTime30.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(instant26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "America/Los_Angeles" + "'", str29.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(yearMonthDay31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1969-12-31T15:59:59.999-08:00" + "'", str37.equals("1969-12-31T15:59:59.999-08:00"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
//        int int12 = offsetDateTimeField9.getMaximumValue();
//        java.lang.String str14 = offsetDateTimeField9.getAsText((long) (byte) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField9.getType();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, (long) (-1), 1);
//        org.joda.time.Instant instant21 = gJChronology20.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) gJChronology20);
//        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology20.getZone();
//        long long26 = dateTimeZone23.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone23);
//        org.joda.time.DateTime.Property property28 = dateTime27.centuryOfEra();
//        long long29 = property28.remainder();
//        org.joda.time.DateTime dateTime30 = property28.getDateTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType31, 69, 59, 57599);
//        long long37 = offsetDateTimeField9.roundHalfCeiling((long) 97);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "26" + "'", str14.equals("26"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(instant21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-35125708925L) + "'", long29 == (-35125708925L));
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone7.getName(1L, locale12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (long) (-1), 1);
//        org.joda.time.Instant instant20 = gJChronology19.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) gJChronology19);
//        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology19.getZone();
//        java.util.TimeZone timeZone23 = dateTimeZone22.toTimeZone();
//        boolean boolean24 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime14, (java.lang.Object) timeZone23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(instant20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        long long13 = property12.remainder();
//        boolean boolean15 = property12.equals((java.lang.Object) (-1.0d));
//        org.joda.time.DateTime dateTime16 = property12.withMinimumValue();
//        java.util.Locale locale18 = null;
//        org.joda.time.DateTime dateTime19 = property12.setCopy("19", locale18);
//        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.Chronology chronology23 = dateTimeFormatter22.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, (long) (-1), 1);
//        org.joda.time.Instant instant29 = gJChronology28.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter24.withChronology((org.joda.time.Chronology) gJChronology28);
//        org.joda.time.DateTimeZone dateTimeZone31 = gJChronology28.getZone();
//        long long34 = dateTimeZone31.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone31);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter22.withZone(dateTimeZone31);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTime dateTime39 = dateTime19.withZone(dateTimeZone31);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime();
//        try {
//            org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, (org.joda.time.ReadableInstant) dateTime40, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-35125708454L) + "'", long13 == (-35125708454L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(instant29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTime39);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        int int10 = offsetDateTimeField9.getOffset();
        long long12 = offsetDateTimeField9.remainder((long) 355);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 355L + "'", long12 == 355L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.minuteOfDay();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = instant4.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTime();
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours(2000);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        boolean boolean9 = delegatedDateTimeField7.isLeap((long) 59);
        int int11 = delegatedDateTimeField7.getLeapAmount((long) (short) -1);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField7.getRangeDurationField();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMillisOfSecond(20);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
        long long25 = delegatedDateTimeField22.add(207356400010L, (int) (short) 1);
        boolean boolean26 = delegatedDateTimeField22.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = delegatedDateTimeField22.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder14.appendFixedSignedDecimal(dateTimeFieldType27, 59);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, (long) (-1), 1);
        org.joda.time.Instant instant35 = gJChronology34.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter30.withChronology((org.joda.time.Chronology) gJChronology34);
        org.joda.time.DateTimeField dateTimeField37 = gJChronology34.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 10);
        long long41 = offsetDateTimeField39.roundFloor((long) (-1));
        int int42 = offsetDateTimeField39.getMaximumValue();
        java.lang.String str44 = offsetDateTimeField39.getAsText((long) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField39.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder29.appendText(dateTimeFieldType45);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder8.appendDecimal(dateTimeFieldType45, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3363116400010L + "'", long25 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-3600000L) + "'", long41 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 33 + "'", int42 == 33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "26" + "'", str44.equals("26"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendCenturyOfEra(1, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendSecondOfMinute((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond(20);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.secondOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        long long23 = delegatedDateTimeField20.add(207356400010L, (int) (short) 1);
        boolean boolean24 = delegatedDateTimeField20.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField20.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder12.appendFixedSignedDecimal(dateTimeFieldType25, 59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType25, 355);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendMinuteOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder29.appendTwoDigitWeekyear((-28800000), true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3363116400010L + "'", long23 == 3363116400010L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(68, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6800 + "'", int2 == 6800);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.secondOfDay();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology4, locale6, (java.lang.Integer) 0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology13.yearOfCentury();
        dateTimeParserBucket9.saveField(dateTimeField15, (int) (short) 10);
        long long19 = dateTimeParserBucket9.computeMillis(false);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1861891199968L) + "'", long19 == (-1861891199968L));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.getMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime15 = property13.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime17 = property13.set(35);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long12 = offsetDateTimeField9.add((long) 57599, (long) (-3));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-10742401L) + "'", long12 == (-10742401L));
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
//        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
//        mutableDateTime12.setDayOfMonth((int) (byte) 1);
//        mutableDateTime12.addMinutes(1);
//        int int17 = mutableDateTime12.getDayOfWeek();
//        mutableDateTime12.addWeekyears((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (long) (-1), 1);
//        org.joda.time.Instant instant25 = gJChronology24.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter20.withChronology((org.joda.time.Chronology) gJChronology24);
//        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology24.getZone();
//        long long30 = dateTimeZone27.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone27);
//        org.joda.time.DateTime.Property property32 = dateTime31.centuryOfEra();
//        long long33 = property32.remainder();
//        boolean boolean35 = property32.equals((java.lang.Object) (-1.0d));
//        org.joda.time.DateTime dateTime36 = property32.withMinimumValue();
//        org.joda.time.DateTime dateTime38 = dateTime36.withYear(4);
//        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime38);
//        mutableDateTime12.setMillis((org.joda.time.ReadableInstant) dateTime38);
//        mutableDateTime12.setDayOfMonth(2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(instant25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-35125706442L) + "'", long33 == (-35125706442L));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(chronology39);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-10742401L), (-3600000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 38672643600000L + "'", long2 == 38672643600000L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime15.monthOfYear();
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int22 = julianChronology21.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (long) (-1), 1);
        org.joda.time.Instant instant28 = gJChronology27.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) gJChronology27);
        org.joda.time.DateTimeZone dateTimeZone30 = gJChronology27.getZone();
        java.lang.String str31 = dateTimeZone30.getID();
        org.joda.time.Chronology chronology32 = julianChronology21.withZone(dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime33 = org.joda.time.MutableDateTime.now(chronology32);
        mutableDateTime33.addYears(0);
        mutableDateTime15.setTime((org.joda.time.ReadableInstant) mutableDateTime33);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "America/Los_Angeles" + "'", str31.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.Chronology chronology8 = dateTimeFormatter7.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (long) (-1), 1);
//        org.joda.time.Instant instant14 = gJChronology13.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology13);
//        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology13.getZone();
//        long long19 = dateTimeZone16.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter7.withZone(dateTimeZone16);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.secondOfDay();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology28, locale30, (java.lang.Integer) 0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology37.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField39 = gJChronology37.yearOfCentury();
//        dateTimeParserBucket33.saveField(dateTimeField39, (int) (short) 10);
//        java.util.Locale locale42 = dateTimeParserBucket33.getLocale();
//        java.lang.String str43 = dateTimeZone16.getShortName((long) (short) 10, locale42);
//        try {
//            org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((int) (byte) 100, 3, 57599999, 6800, 69, 33, 6800, dateTimeZone16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 6800 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(locale42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "PST" + "'", str43.equals("PST"));
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMinuteOfDay();
//        org.joda.time.Chronology chronology2 = dateTime0.getChronology();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMonths(0);
//        java.util.Locale locale5 = null;
//        java.util.Calendar calendar6 = dateTime4.toCalendar(locale5);
//        org.joda.time.DateTime.Property property7 = dateTime4.millisOfDay();
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime4.withDayOfMonth((-3));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 651 + "'", int1 == 651);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(calendar6);
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        int int12 = offsetDateTimeField9.getMaximumValue();
        java.lang.String str14 = offsetDateTimeField9.getAsText((long) (byte) 0);
        boolean boolean15 = offsetDateTimeField9.isLenient();
        boolean boolean16 = offsetDateTimeField9.isLenient();
        boolean boolean17 = offsetDateTimeField9.isSupported();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "26" + "'", str14.equals("26"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
//        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
//        int int12 = offsetDateTimeField9.getMaximumValue();
//        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getDurationField();
//        int int15 = offsetDateTimeField9.getLeapAmount((-11359555622000L));
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.Chronology chronology20 = dateTimeFormatter19.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (long) (-1), 1);
//        org.joda.time.Instant instant26 = gJChronology25.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter21.withChronology((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology25.getZone();
//        long long31 = dateTimeZone28.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(dateTimeZone28);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter19.withZone(dateTimeZone28);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.secondOfDay();
//        java.util.Locale locale42 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket45 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology40, locale42, (java.lang.Integer) 0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField50 = gJChronology49.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology49.yearOfCentury();
//        dateTimeParserBucket45.saveField(dateTimeField51, (int) (short) 10);
//        java.util.Locale locale54 = dateTimeParserBucket45.getLocale();
//        java.lang.String str55 = dateTimeZone28.getShortName((long) (short) 10, locale54);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = dateTimeFormatter18.withLocale(locale54);
//        java.lang.String str57 = offsetDateTimeField9.getAsShortText(readablePartial16, 20, locale54);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(instant26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(gJChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(locale54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "PST" + "'", str55.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter56);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "20" + "'", str57.equals("20"));
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        mutableDateTime12.setSecondOfMinute((int) '#');
        try {
            mutableDateTime12.setDayOfWeek(12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getMinuteOfDay();
//        org.joda.time.Chronology chronology2 = dateTime0.getChronology();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMonths(0);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusDays(69);
//        int int7 = dateTime6.getYear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 651 + "'", int1 == 651);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1968 + "'", int7 == 1968);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) (-1), 1);
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology6.getZone();
        long long12 = dateTimeZone9.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone9);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.year();
        org.joda.time.MutableDateTime mutableDateTime15 = property14.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.secondOfDay();
        mutableDateTime15.setDayOfYear((int) 'a');
        org.joda.time.ReadableDuration readableDuration19 = null;
        mutableDateTime15.add(readableDuration19, (int) '4');
        int int24 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime15, "16:00:00-08:00", 2);
        java.util.GregorianCalendar gregorianCalendar25 = mutableDateTime15.toGregorianCalendar();
        int int26 = mutableDateTime15.getEra();
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime15.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime28 = property27.roundFloor();
        mutableDateTime28.setMillisOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-3) + "'", int24 == (-3));
        org.junit.Assert.assertNotNull(gregorianCalendar25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (long) (-1), 1);
        org.joda.time.Instant instant8 = gJChronology7.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology7);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology7.getZone();
        java.lang.String str11 = dateTimeZone10.getID();
        org.joda.time.Chronology chronology12 = julianChronology1.withZone(dateTimeZone10);
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket((long) (short) 100, (org.joda.time.Chronology) julianChronology1, locale13, (java.lang.Integer) 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, (long) (-1), 1);
        org.joda.time.Instant instant21 = gJChronology20.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) gJChronology20);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology20.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (byte) 10);
        long long27 = offsetDateTimeField25.roundFloor((long) (-1));
        int int28 = offsetDateTimeField25.getMaximumValue();
        long long30 = offsetDateTimeField25.roundHalfEven((-1595441068446L));
        boolean boolean31 = dateTimeParserBucket15.restoreState((java.lang.Object) long30);
        org.joda.time.Chronology chronology32 = dateTimeParserBucket15.getChronology();
        long long33 = dateTimeParserBucket15.computeMillis();
        java.lang.Object obj34 = dateTimeParserBucket15.saveState();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(instant21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-3600000L) + "'", long27 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 33 + "'", int28 == 33);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1595440800000L) + "'", long30 == (-1595440800000L));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (long) (-1), 1);
        org.joda.time.Instant instant20 = gJChronology19.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (long) (-1), 1);
        org.joda.time.Instant instant26 = gJChronology25.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter21.withChronology((org.joda.time.Chronology) gJChronology25);
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology25.getZone();
        java.lang.String str29 = dateTimeZone28.getID();
        org.joda.time.DateTime dateTime30 = instant20.toDateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay31 = dateTime30.toYearMonthDay();
        int int32 = property15.compareTo((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime.Property property33 = dateTime30.secondOfMinute();
        org.joda.time.DateTime.Property property34 = dateTime30.weekOfWeekyear();
        org.joda.time.DateTime dateTime36 = dateTime30.minusWeeks((int) (short) 100);
        org.joda.time.DateTime.Property property37 = dateTime30.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(instant26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "America/Los_Angeles" + "'", str29.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(yearMonthDay31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime.Property property11 = dateTime7.hourOfDay();
        int int12 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime14 = dateTime7.minusHours(57599);
        org.joda.time.DateTime dateTime15 = dateTime7.toDateTimeISO();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57599999 + "'", int12 == 57599999);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(4, (-3));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (long) (-1), 1);
        org.joda.time.Instant instant8 = gJChronology7.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology7);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology7.getZone();
        java.lang.String str11 = dateTimeZone10.getID();
        org.joda.time.Chronology chronology12 = julianChronology1.withZone(dateTimeZone10);
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket((long) (short) 100, (org.joda.time.Chronology) julianChronology1, locale13, (java.lang.Integer) 1970);
        org.joda.time.DateTimeField dateTimeField16 = julianChronology1.weekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 960);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (long) (-1), 1);
        org.joda.time.Instant instant9 = gJChronology8.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
        long long14 = dateTimeZone11.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter2.withZone(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone11);
        try {
            long long24 = zonedChronology18.getDateTimeMillis((long) (short) -1, (int) (short) 100, 355, 2, (-3));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(zonedChronology18);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((-3600000L), dateTimeZone8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        int int13 = julianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology14 = julianChronology12.withUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.copy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        mutableDateTime15.add(readablePeriod16);
        mutableDateTime15.addDays((-1));
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime15.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime15.weekyear();
        mutableDateTime15.addMonths(2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (long) (-1), 1);
        org.joda.time.Instant instant31 = gJChronology30.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) gJChronology30);
        org.joda.time.DateTimeZone dateTimeZone33 = gJChronology30.getZone();
        long long36 = dateTimeZone33.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone33);
        org.joda.time.MutableDateTime.Property property38 = mutableDateTime37.year();
        org.joda.time.MutableDateTime mutableDateTime39 = property38.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.secondOfDay();
        mutableDateTime39.setDayOfYear((int) 'a');
        org.joda.time.ReadableDuration readableDuration43 = null;
        mutableDateTime39.add(readableDuration43, (int) '4');
        int int48 = dateTimeFormatter24.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime39, "16:00:00-08:00", 2);
        java.util.GregorianCalendar gregorianCalendar49 = mutableDateTime39.toGregorianCalendar();
        int int50 = mutableDateTime39.getEra();
        org.joda.time.MutableDateTime.Property property51 = mutableDateTime39.millisOfDay();
        mutableDateTime15.setMillis((org.joda.time.ReadableInstant) mutableDateTime39);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(instant31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-3) + "'", int48 == (-3));
        org.junit.Assert.assertNotNull(gregorianCalendar49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(property51);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969W487", (java.lang.Number) (short) 1, (java.lang.Number) 0.0f, (java.lang.Number) 57600000);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969W487" + "'", str5.equals("1969W487"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 57600000 + "'", number6.equals(57600000));
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
//        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 10);
//        long long12 = offsetDateTimeField10.roundFloor((long) (-1));
//        int int13 = offsetDateTimeField10.getMaximumValue();
//        java.lang.String str15 = offsetDateTimeField10.getAsText((long) (byte) 0);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) offsetDateTimeField10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (long) (-1), 1);
//        org.joda.time.Instant instant24 = gJChronology23.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter19.withChronology((org.joda.time.Chronology) gJChronology23);
//        org.joda.time.DateTimeZone dateTimeZone26 = gJChronology23.getZone();
//        long long29 = dateTimeZone26.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone26);
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.year();
//        org.joda.time.MutableDateTime mutableDateTime32 = property31.getMutableDateTime();
//        org.joda.time.MutableDateTime.Property property33 = mutableDateTime32.secondOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.Chronology chronology36 = dateTimeFormatter35.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (long) (-1), 1);
//        org.joda.time.Instant instant42 = gJChronology41.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) gJChronology41);
//        org.joda.time.DateTimeZone dateTimeZone44 = gJChronology41.getZone();
//        long long47 = dateTimeZone44.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now(dateTimeZone44);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter35.withZone(dateTimeZone44);
//        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField57 = gJChronology56.secondOfDay();
//        java.util.Locale locale58 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket61 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology56, locale58, (java.lang.Integer) 0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone62, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField66 = gJChronology65.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField67 = gJChronology65.yearOfCentury();
//        dateTimeParserBucket61.saveField(dateTimeField67, (int) (short) 10);
//        java.util.Locale locale70 = dateTimeParserBucket61.getLocale();
//        java.lang.String str71 = dateTimeZone44.getShortName((long) (short) 10, locale70);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = dateTimeFormatter34.withLocale(locale70);
//        int int73 = property33.getMaximumTextLength(locale70);
//        java.lang.String str74 = offsetDateTimeField10.getAsShortText(1969, locale70);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-3600000L) + "'", long12 == (-3600000L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 33 + "'", int13 == 33);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "26" + "'", str15.equals("26"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(instant24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNull(chronology36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(instant42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(gregorianChronology50);
//        org.junit.Assert.assertNotNull(gJChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(gJChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertNotNull(locale70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "PST" + "'", str71.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 5 + "'", int73 == 5);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1969" + "'", str74.equals("1969"));
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int6 = julianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (long) (-1), 1);
        org.joda.time.Instant instant12 = gJChronology11.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology11.getZone();
        java.lang.String str15 = dateTimeZone14.getID();
        org.joda.time.Chronology chronology16 = julianChronology5.withZone(dateTimeZone14);
        java.lang.String str17 = dateTimeZone14.toString();
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((-3), 0, 959, 355, (int) ' ', dateTimeZone14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 355 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "America/Los_Angeles" + "'", str17.equals("America/Los_Angeles"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime10 = dateTime7.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime dateTime12 = dateTime7.withYearOfCentury((int) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime7.plus((long) ' ');
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        java.util.Date date16 = dateTime7.toDate();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.DurationField durationField6 = gJChronology4.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        java.lang.String str8 = gJChronology4.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GJChronology[America/Los_Angeles,cutover=1969-12-31T23:59:59.999Z,mdfw=1]" + "'", str8.equals("GJChronology[America/Los_Angeles,cutover=1969-12-31T23:59:59.999Z,mdfw=1]"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 10);
        long long11 = offsetDateTimeField9.roundFloor((long) (-1));
        int int12 = offsetDateTimeField9.getMaximumValue();
        java.lang.String str14 = offsetDateTimeField9.getAsText((long) (byte) 0);
        boolean boolean15 = offsetDateTimeField9.isLenient();
        long long18 = offsetDateTimeField9.add((long) (-3), 97);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-3600000L) + "'", long11 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "26" + "'", str14.equals("26"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 349199997L + "'", long18 == 349199997L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (long) (-1), 1);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DurationField durationField12 = gJChronology9.hours();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13, 33);
        org.joda.time.DurationField durationField16 = skipUndoDateTimeField15.getDurationField();
        int int18 = skipUndoDateTimeField15.get(978336000000L);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant4.toDateTimeISO();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime.Property property11 = dateTime7.hourOfDay();
        org.joda.time.DateTime dateTime12 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property13 = dateTime7.secondOfMinute();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime.Property property2 = dateTime0.era();
        org.joda.time.DateTime.Property property3 = dateTime0.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.secondOfDay();
        mutableDateTime14.setDayOfYear((int) 'a');
        org.joda.time.ReadableDuration readableDuration18 = null;
        mutableDateTime14.add(readableDuration18, (int) '4');
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime14.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime22 = property21.roundHalfFloor();
        boolean boolean24 = mutableDateTime22.isAfter((long) 69);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, (long) (-1), 1);
//        org.joda.time.Instant instant21 = gJChronology20.getGregorianCutover();
//        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology20);
//        org.joda.time.DurationField durationField23 = gJChronology20.hours();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology20.clockhourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField24, 33);
//        long long28 = skipUndoDateTimeField26.roundHalfEven((long) 100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.Chronology chronology32 = dateTimeFormatter31.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34, (long) (-1), 1);
//        org.joda.time.Instant instant38 = gJChronology37.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) gJChronology37);
//        org.joda.time.DateTimeZone dateTimeZone40 = gJChronology37.getZone();
//        long long43 = dateTimeZone40.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = dateTimeFormatter31.withZone(dateTimeZone40);
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40);
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField53 = gJChronology52.secondOfDay();
//        java.util.Locale locale54 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology52, locale54, (java.lang.Integer) 0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone58, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField62 = gJChronology61.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField63 = gJChronology61.yearOfCentury();
//        dateTimeParserBucket57.saveField(dateTimeField63, (int) (short) 10);
//        java.util.Locale locale66 = dateTimeParserBucket57.getLocale();
//        java.lang.String str67 = dateTimeZone40.getShortName((long) (short) 10, locale66);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter68 = dateTimeFormatter30.withLocale(locale66);
//        java.lang.String str69 = skipUndoDateTimeField26.getAsShortText((-35125721489L), locale66);
//        try {
//            org.joda.time.DateTime dateTime70 = property9.setCopy("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (America/Los_Angeles)", locale66);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (America/Los_Angeles)\" for weekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(instant21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNull(chronology32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(instant38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(gJChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(gJChronology61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(locale66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "PST" + "'", str67.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter68);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "2" + "'", str69.equals("2"));
//    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
//        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
//        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(dateTimeZone7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (long) (-1), 1);
//        org.joda.time.Instant instant19 = gJChronology18.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) gJChronology18);
//        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology18.getZone();
//        long long24 = dateTimeZone21.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone21);
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.year();
//        org.joda.time.MutableDateTime mutableDateTime27 = property26.getMutableDateTime();
//        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.secondOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.Chronology chronology31 = dateTimeFormatter30.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, (long) (-1), 1);
//        org.joda.time.Instant instant37 = gJChronology36.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter32.withChronology((org.joda.time.Chronology) gJChronology36);
//        org.joda.time.DateTimeZone dateTimeZone39 = gJChronology36.getZone();
//        long long42 = dateTimeZone39.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone39);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter30.withZone(dateTimeZone39);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39);
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone48, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.secondOfDay();
//        java.util.Locale locale53 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology51, locale53, (java.lang.Integer) 0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField61 = gJChronology60.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField62 = gJChronology60.yearOfCentury();
//        dateTimeParserBucket56.saveField(dateTimeField62, (int) (short) 10);
//        java.util.Locale locale65 = dateTimeParserBucket56.getLocale();
//        java.lang.String str66 = dateTimeZone39.getShortName((long) (short) 10, locale65);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = dateTimeFormatter29.withLocale(locale65);
//        int int68 = property28.getMaximumTextLength(locale65);
//        java.lang.String str69 = dateTimeZone7.getShortName((long) 7, locale65);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(instant37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(gJChronology60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(locale65);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "PST" + "'", str66.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 5 + "'", int68 == 5);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "PST" + "'", str69.equals("PST"));
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), 1);
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (long) (-1), 1);
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) gJChronology17);
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology17.getZone();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology17.clockhourOfHalfday();
        long long26 = gJChronology17.getDateTimeMillis(57599, 1, 4, (int) (byte) 100);
        boolean boolean27 = iSOChronology12.equals((java.lang.Object) gJChronology17);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology12.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1755481968000100L + "'", long26 == 1755481968000100L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.centuryOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
//        long long10 = delegatedDateTimeField7.add(207356400010L, (int) (short) 1);
//        boolean boolean11 = delegatedDateTimeField7.isSupported();
//        int int13 = delegatedDateTimeField7.getMaximumValue((long) (short) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (long) (-1), 1);
//        org.joda.time.Instant instant19 = gJChronology18.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) gJChronology18);
//        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology18.getZone();
//        long long24 = dateTimeZone21.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone21);
//        org.joda.time.DateTime.Property property26 = dateTime25.centuryOfEra();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = property26.getAsShortText(locale27);
//        org.joda.time.DateTime dateTime29 = property26.roundCeilingCopy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (long) (-1), 1);
//        org.joda.time.Instant instant36 = gJChronology35.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter31.withChronology((org.joda.time.Chronology) gJChronology35);
//        org.joda.time.DateTimeZone dateTimeZone38 = gJChronology35.getZone();
//        long long41 = dateTimeZone38.adjustOffset((long) (byte) 10, false);
//        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone38);
//        org.joda.time.MutableDateTime.Property property43 = mutableDateTime42.year();
//        org.joda.time.MutableDateTime mutableDateTime44 = property43.getMutableDateTime();
//        org.joda.time.MutableDateTime.Property property45 = mutableDateTime44.secondOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.Chronology chronology48 = dateTimeFormatter47.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, (long) (-1), 1);
//        org.joda.time.Instant instant54 = gJChronology53.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = dateTimeFormatter49.withChronology((org.joda.time.Chronology) gJChronology53);
//        org.joda.time.DateTimeZone dateTimeZone56 = gJChronology53.getZone();
//        long long59 = dateTimeZone56.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now(dateTimeZone56);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = dateTimeFormatter47.withZone(dateTimeZone56);
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone56);
//        org.joda.time.DateTimeZone dateTimeZone65 = null;
//        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone65, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField69 = gJChronology68.secondOfDay();
//        java.util.Locale locale70 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket73 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology68, locale70, (java.lang.Integer) 0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone74 = null;
//        org.joda.time.chrono.GJChronology gJChronology77 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone74, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField78 = gJChronology77.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField79 = gJChronology77.yearOfCentury();
//        dateTimeParserBucket73.saveField(dateTimeField79, (int) (short) 10);
//        java.util.Locale locale82 = dateTimeParserBucket73.getLocale();
//        java.lang.String str83 = dateTimeZone56.getShortName((long) (short) 10, locale82);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter84 = dateTimeFormatter46.withLocale(locale82);
//        int int85 = property45.getMaximumTextLength(locale82);
//        int int86 = property26.getMaximumShortTextLength(locale82);
//        int int87 = delegatedDateTimeField7.getMaximumShortTextLength(locale82);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3363116400010L + "'", long10 == 3363116400010L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2922730 + "'", int13 == 2922730);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "19" + "'", str28.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(instant36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(mutableDateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNull(chronology48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(gJChronology53);
//        org.junit.Assert.assertNotNull(instant54);
//        org.junit.Assert.assertNotNull(dateTimeFormatter55);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTimeFormatter61);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(gJChronology68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(gJChronology77);
//        org.junit.Assert.assertNotNull(dateTimeField78);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertNotNull(locale82);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "PST" + "'", str83.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter84);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 5 + "'", int85 == 5);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 7 + "'", int86 == 7);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 7 + "'", int87 == 7);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (long) (-1), 1);
        org.joda.time.Instant instant9 = gJChronology8.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) 10);
        int int14 = offsetDateTimeField13.getOffset();
        boolean boolean16 = offsetDateTimeField13.isLeap((long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField13.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType17, 2922730);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendSecondOfDay(31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-1), 1);
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology5.getZone();
        long long11 = dateTimeZone8.adjustOffset((long) (byte) 10, false);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) 0, dateTimeZone8);
        mutableDateTime12.setDayOfMonth((int) (byte) 1);
        mutableDateTime12.addMinutes(1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (long) (-1), 1);
        org.joda.time.Instant instant22 = gJChronology21.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter17.withChronology((org.joda.time.Chronology) gJChronology21);
        mutableDateTime12.setChronology((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField25 = gJChronology21.dayOfMonth();
        org.joda.time.DurationField durationField26 = gJChronology21.weeks();
        org.joda.time.DurationFieldType durationFieldType27 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField29 = new org.joda.time.field.ScaledDurationField(durationField26, durationFieldType27, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(959);
//        java.lang.Appendable appendable3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (long) (-1), 1);
//        org.joda.time.Instant instant9 = gJChronology8.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology8);
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) 10);
//        long long15 = offsetDateTimeField13.roundFloor((long) (-1));
//        int int16 = offsetDateTimeField13.getMaximumValue();
//        java.util.Locale locale17 = null;
//        int int18 = offsetDateTimeField13.getMaximumShortTextLength(locale17);
//        long long21 = offsetDateTimeField13.add((long) (short) 10, 57599);
//        org.joda.time.DurationField durationField22 = offsetDateTimeField13.getRangeDurationField();
//        long long25 = offsetDateTimeField13.add(0L, (long) 59);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField13.getAsShortText((-1595441066456L), locale27);
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime30 = dateTime29.toLocalDateTime();
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField13.getAsText((org.joda.time.ReadablePartial) localDateTime30, locale31);
//        try {
//            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadablePartial) localDateTime30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-3600000L) + "'", long15 == (-3600000L));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 33 + "'", int16 == 33);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 207356400010L + "'", long21 == 207356400010L);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 212400000L + "'", long25 == 212400000L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "32" + "'", str28.equals("32"));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDateTime30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10" + "'", str32.equals("10"));
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-1), 1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
        int int9 = delegatedDateTimeField7.getMaximumValue(0L);
        java.lang.String str10 = delegatedDateTimeField7.getName();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7);
        long long13 = delegatedDateTimeField11.roundFloor((-56803680420031L));
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922730 + "'", int9 == 2922730);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "centuryOfEra" + "'", str10.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-58979981222000L) + "'", long13 == (-58979981222000L));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (long) (-1), 1);
        org.joda.time.Instant instant9 = gJChronology8.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology8.getZone();
        long long14 = dateTimeZone11.adjustOffset((long) (byte) 10, false);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter2.withZone(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone11);
        try {
            long long24 = zonedChronology18.getDateTimeMillis((long) (-292275054), 57599, 69, 7, 47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(zonedChronology18);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (long) (-1), 1);
//        org.joda.time.Instant instant8 = gJChronology7.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology7);
//        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology7.getZone();
//        long long13 = dateTimeZone10.adjustOffset((long) (byte) 10, false);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter1.withZone(dateTimeZone10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.secondOfDay();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gJChronology22, locale24, (java.lang.Integer) 0, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (long) (-1), 1);
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.yearOfCentury();
//        dateTimeParserBucket27.saveField(dateTimeField33, (int) (short) 10);
//        java.util.Locale locale36 = dateTimeParserBucket27.getLocale();
//        java.lang.String str37 = dateTimeZone10.getShortName((long) (short) 10, locale36);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter0.withLocale(locale36);
//        java.lang.StringBuffer stringBuffer39 = null;
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40, (long) (-1), 1);
//        org.joda.time.Instant instant44 = gJChronology43.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (long) (-1), 1);
//        org.joda.time.Instant instant50 = gJChronology49.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter45.withChronology((org.joda.time.Chronology) gJChronology49);
//        org.joda.time.DateTimeZone dateTimeZone52 = gJChronology49.getZone();
//        java.lang.String str53 = dateTimeZone52.getID();
//        org.joda.time.DateTime dateTime54 = instant44.toDateTime(dateTimeZone52);
//        org.joda.time.YearMonthDay yearMonthDay55 = dateTime54.toYearMonthDay();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer39, (org.joda.time.ReadablePartial) yearMonthDay55);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(instant8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(locale36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PST" + "'", str37.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(instant44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertNotNull(gJChronology49);
//        org.junit.Assert.assertNotNull(instant50);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "America/Los_Angeles" + "'", str53.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(yearMonthDay55);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(59, (int) (byte) 1, (int) (short) 10, 0, (int) '#', (int) '4', (org.joda.time.Chronology) julianChronology13);
        org.joda.time.DurationField durationField15 = julianChronology13.weeks();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology13.getZone();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(0, 100, (int) (byte) -1, (int) (byte) 0, 1, 69, (int) (byte) 0, dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }
}

