import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DateTime.Property property13 = dateTime2.yearOfCentury();
//        int int14 = dateTime2.getMinuteOfHour();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology16);
//        int int18 = dateTime17.getDayOfWeek();
//        org.joda.time.DateTime.Property property19 = dateTime17.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        org.joda.time.MutableDateTime mutableDateTime22 = dateTime17.toMutableDateTime(dateTimeZone21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = dateTime17.withZone(dateTimeZone23);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime17.toMutableDateTime((org.joda.time.Chronology) iSOChronology26);
//        org.joda.time.DateTime.Property property28 = dateTime17.minuteOfDay();
//        org.joda.time.DateTime dateTime30 = dateTime17.plusMillis((int) (byte) 0);
//        boolean boolean31 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime.Property property32 = dateTime30.minuteOfHour();
//        int int33 = property32.getLeapAmount();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
//        java.lang.String str2 = dateTimeFormatter0.print(52L);
//        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970" + "'", str2.equals("1970"));
//        org.junit.Assert.assertNull(chronology3);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Thursday");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(permissionCollection3);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology6);
//        int int8 = dateTime7.getDayOfWeek();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime7.toMutableDateTime(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = dateTime7.withZone(dateTimeZone13);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime7.toMutableDateTime((org.joda.time.Chronology) iSOChronology16);
//        org.joda.time.DateTime.Property property18 = dateTime7.weekOfWeekyear();
//        int int19 = property4.getDifference((org.joda.time.ReadableInstant) dateTime7);
//        int int20 = property4.getMaximumValueOverall();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292278993 + "'", int20 == 292278993);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        long long20 = offsetDateTimeField16.roundHalfEven(0L);
//        org.joda.time.DurationField durationField21 = offsetDateTimeField16.getDurationField();
//        long long23 = offsetDateTimeField16.roundHalfEven(1560636217384L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-100L) + "'", long20 == (-100L));
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1559347199900L + "'", long23 == 1559347199900L);
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology20);
//        int int22 = dateTime21.getDayOfWeek();
//        org.joda.time.DateTime.Property property23 = dateTime21.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime21.toMutableDateTime(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = dateTime21.withZone(dateTimeZone27);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime31 = dateTime21.toMutableDateTime((org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DurationField durationField32 = iSOChronology30.millis();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 57600);
//        int int37 = offsetDateTimeField35.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField35.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, (int) (byte) 100);
//        int int41 = dividedDateTimeField40.getMaximumValue();
//        long long44 = dividedDateTimeField40.add((long) ' ', (long) 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField40);
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology47);
//        int int49 = dateTime48.getDayOfWeek();
//        org.joda.time.DateTime.Property property50 = dateTime48.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeUtils.getZone(dateTimeZone51);
//        org.joda.time.MutableDateTime mutableDateTime53 = dateTime48.toMutableDateTime(dateTimeZone52);
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
//        org.joda.time.DateTime dateTime56 = dateTime48.withZone(dateTimeZone54);
//        org.joda.time.chrono.ISOChronology iSOChronology57 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime58 = dateTime48.toMutableDateTime((org.joda.time.Chronology) iSOChronology57);
//        org.joda.time.Chronology chronology60 = null;
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology60);
//        int int62 = dateTime61.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.DateTime dateTime64 = dateTime61.withZone(dateTimeZone63);
//        org.joda.time.DateTime dateTime69 = dateTime61.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate70 = dateTime61.toLocalDate();
//        long long72 = iSOChronology57.set((org.joda.time.ReadablePartial) localDate70, (long) (byte) 100);
//        java.util.Locale locale74 = null;
//        java.lang.String str75 = remainderDateTimeField45.getAsShortText((org.joda.time.ReadablePartial) localDate70, 1, locale74);
//        int int76 = remainderDateTimeField45.getMinimumValue();
//        org.joda.time.DurationField durationField77 = remainderDateTimeField45.getRangeDurationField();
//        long long80 = durationField77.subtract((long) 2000, (long) 'a');
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 576 + "'", int41 == 576);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 788918400032L + "'", long44 == 788918400032L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(mutableDateTime53);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(iSOChronology57);
//        org.junit.Assert.assertNotNull(mutableDateTime58);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 100L + "'", long72 == 100L);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "1" + "'", str75.equals("1"));
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
//        org.junit.Assert.assertNotNull(durationField77);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-25508563198000L) + "'", long80 == (-25508563198000L));
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.days();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.Chronology chronology18 = iSOChronology11.withZone(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getChronology(chronology18);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology20);
//        int int22 = dateTime21.getDayOfWeek();
//        org.joda.time.DateTime.Property property23 = dateTime21.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime21.toMutableDateTime(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = dateTime21.withZone(dateTimeZone27);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime31 = dateTime21.toMutableDateTime((org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DurationField durationField32 = iSOChronology30.millis();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 57600);
//        int int37 = offsetDateTimeField35.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField35.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, (int) (byte) 100);
//        int int41 = dividedDateTimeField40.getMaximumValue();
//        long long44 = dividedDateTimeField40.add((long) ' ', (long) 3);
//        int int47 = dividedDateTimeField40.getDifference((long) 69, (long) '4');
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology49);
//        org.joda.time.DateTime.Property property51 = dateTime50.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType52, 57601, 3, 5820010);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField40, dateTimeFieldType52, 100, (int) (byte) 100, 100);
//        int int62 = dividedDateTimeField40.get(100L);
//        try {
//            long long64 = dividedDateTimeField40.roundFloor(0L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for monthOfYear must be in the range [57601,57612]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 576 + "'", int41 == 576);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 788918400032L + "'", long44 == 788918400032L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 576 + "'", int62 == 576);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        boolean boolean17 = offsetDateTimeField16.isLenient();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText((int) (byte) 100, locale19);
//        long long23 = offsetDateTimeField16.add((-96L), (-1));
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology25);
//        int int27 = dateTime26.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.withZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime34 = dateTime26.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate35 = dateTime26.toLocalDate();
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = offsetDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDate35, locale36);
//        int int39 = offsetDateTimeField16.getMinimumValue((-96L));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2678400096L) + "'", long23 == (-2678400096L));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1" + "'", str37.equals("1"));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 57601 + "'", int39 == 57601);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime2.minusHours((int) (byte) 0);
//        org.joda.time.DateTime dateTime10 = dateTime9.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime.Property property24 = dateTime22.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime22.toMutableDateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime22.toMutableDateTime((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DurationField durationField33 = iSOChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.millisOfDay();
//        org.joda.time.DurationField durationField35 = iSOChronology31.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField35);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField36.getRangeDurationField();
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField36.getLeapDurationField();
//        java.lang.String str39 = unsupportedDateTimeField36.getName();
//        int int42 = unsupportedDateTimeField36.getDifference((long) (byte) 1, (-101L));
//        try {
//            int int44 = unsupportedDateTimeField36.getLeapAmount((long) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertNull(durationField38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "monthOfYear" + "'", str39.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
//        int int21 = offsetDateTimeField16.getLeapAmount((-48L));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfHour((int) 'a', (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfHalfday(69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendSecondOfDay(57600);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder5.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        boolean boolean17 = offsetDateTimeField16.isLenient();
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        int[] intArray23 = new int[] { 'a', 110, 292278993, 57600 };
//        int int24 = offsetDateTimeField16.getMaximumValue(readablePartial18, intArray23);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(intArray23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 57612 + "'", int24 == 57612);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusHours((int) (short) 0);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.lang.String str8 = property7.getAsText();
//        try {
//            org.joda.time.DateTime dateTime10 = property7.setCopy("0365-01-01T00:00:00.000+00:00:00.100");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"0365-01-01T00:00:00.000+00:00:00.100\" for dayOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Wednesday", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Wednesday/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) (short) 10, true);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfDay(10, 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatterBuilder9.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime.Property property24 = dateTime22.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime22.toMutableDateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime22.toMutableDateTime((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DurationField durationField33 = iSOChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.millisOfDay();
//        org.joda.time.DurationField durationField35 = iSOChronology31.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField35);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField36.getRangeDurationField();
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField36.getLeapDurationField();
//        java.util.Locale locale39 = null;
//        try {
//            int int40 = unsupportedDateTimeField36.getMaximumTextLength(locale39);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertNull(durationField38);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTime dateTime5 = property4.withMinimumValue();
//        int int6 = dateTime5.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        int int21 = offsetDateTimeField16.getDifference((long) 69, (long) 1);
//        boolean boolean23 = offsetDateTimeField16.isLeap(0L);
//        long long26 = offsetDateTimeField16.add(1559347199900L, 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561939199900L + "'", long26 == 1561939199900L);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.days();
//        java.lang.String str14 = iSOChronology11.toString();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "", (int) (byte) 100, (int) (short) 0);
//        java.lang.String str20 = fixedDateTimeZone19.toString();
//        int int22 = fixedDateTimeZone19.getOffsetFromLocal((-28800000L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology11, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        org.joda.time.Chronology chronology26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology26);
//        int int28 = dateTime27.getDayOfWeek();
//        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone30);
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime27.toMutableDateTime(dateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = dateTime27.withZone(dateTimeZone33);
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime37 = dateTime27.toMutableDateTime((org.joda.time.Chronology) iSOChronology36);
//        org.joda.time.DurationField durationField38 = iSOChronology36.millis();
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 57600);
//        int int43 = offsetDateTimeField41.getLeapAmount((long) 'a');
//        org.joda.time.Chronology chronology45 = null;
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology45);
//        int int47 = dateTime46.getDayOfWeek();
//        org.joda.time.DateTime.Property property48 = dateTime46.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.MutableDateTime mutableDateTime51 = dateTime46.toMutableDateTime(dateTimeZone50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeUtils.getZone(dateTimeZone52);
//        org.joda.time.DateTime dateTime54 = dateTime46.withZone(dateTimeZone52);
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime56 = dateTime46.toMutableDateTime((org.joda.time.Chronology) iSOChronology55);
//        org.joda.time.DurationField durationField57 = iSOChronology55.millis();
//        org.joda.time.DateTimeField dateTimeField58 = iSOChronology55.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, 57600);
//        int int62 = offsetDateTimeField60.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType63 = offsetDateTimeField60.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField65 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField41, dateTimeFieldType63, (int) (byte) 100);
//        int int66 = dividedDateTimeField65.getMaximumValue();
//        long long69 = dividedDateTimeField65.add((long) ' ', (long) 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField65);
//        boolean boolean71 = zonedChronology24.equals((java.lang.Object) dividedDateTimeField65);
//        try {
//            long long73 = dividedDateTimeField65.roundCeiling(10L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for monthOfYear must be in the range [57601,57612]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[1969-12-31]" + "'", str14.equals("ISOChronology[1969-12-31]"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31" + "'", str20.equals("1969-12-31"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(zonedChronology24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(mutableDateTime51);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType63);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 576 + "'", int66 == 576);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 788918400032L + "'", long69 == 788918400032L);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology9);
//        int int11 = dateTime10.getDayOfWeek();
//        org.joda.time.DateTime.Property property12 = dateTime10.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime10.toMutableDateTime(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime10.withZone(dateTimeZone16);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime20 = dateTime10.toMutableDateTime((org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.DurationField durationField21 = iSOChronology19.millis();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime23 = mutableDateTime7.toMutableDateTime((org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.hourOfHalfday();
//        org.joda.time.DurationField durationField25 = iSOChronology19.millis();
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology27);
//        int int29 = dateTime28.getDayOfWeek();
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology31);
//        int int33 = dateTime32.getDayOfWeek();
//        org.joda.time.DateTime.Property property34 = dateTime32.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
//        org.joda.time.MutableDateTime mutableDateTime37 = dateTime32.toMutableDateTime(dateTimeZone36);
//        org.joda.time.MutableDateTime mutableDateTime38 = dateTime28.toMutableDateTime(dateTimeZone36);
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
//        org.joda.time.Chronology chronology41 = null;
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology41);
//        int int43 = dateTime42.getDayOfWeek();
//        org.joda.time.Chronology chronology45 = null;
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology45);
//        int int47 = dateTime46.getDayOfWeek();
//        org.joda.time.DateTime.Property property48 = dateTime46.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.MutableDateTime mutableDateTime51 = dateTime46.toMutableDateTime(dateTimeZone50);
//        org.joda.time.MutableDateTime mutableDateTime52 = dateTime42.toMutableDateTime(dateTimeZone50);
//        org.joda.time.Chronology chronology53 = gregorianChronology39.withZone(dateTimeZone50);
//        int int55 = dateTimeZone50.getOffsetFromLocal((long) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology56 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology19, dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(mutableDateTime51);
//        org.junit.Assert.assertNotNull(mutableDateTime52);
//        org.junit.Assert.assertNotNull(chronology53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 100 + "'", int55 == 100);
//        org.junit.Assert.assertNotNull(zonedChronology56);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-5L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) (short) 10, true);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneName(strMap8);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTimeZoneName(strMap10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.days();
//        java.lang.String str14 = iSOChronology11.toString();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "", (int) (byte) 100, (int) (short) 0);
//        java.lang.String str20 = fixedDateTimeZone19.toString();
//        int int22 = fixedDateTimeZone19.getOffsetFromLocal((-28800000L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology11, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone25 = zonedChronology24.getZone();
//        org.joda.time.DateTimeZone dateTimeZone26 = zonedChronology24.getZone();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[1969-12-31]" + "'", str14.equals("ISOChronology[1969-12-31]"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31" + "'", str20.equals("1969-12-31"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(zonedChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str3 = dateTimeFormatter1.print(10L);
//        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter1.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser4);
//        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeFormatter5.getZone();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01" + "'", str3.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeParser4);
//        org.junit.Assert.assertNull(dateTimeZone6);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology15);
//        int int17 = dateTime16.getDayOfWeek();
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology19);
//        int int21 = dateTime20.getDayOfWeek();
//        org.joda.time.DateTime.Property property22 = dateTime20.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime20.toMutableDateTime(dateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime16.toMutableDateTime(dateTimeZone24);
//        org.joda.time.Chronology chronology27 = gregorianChronology13.withZone(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology13.getZone();
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology13.getZone();
//        java.lang.String str31 = dateTimeZone29.getName((-25508563198000L));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.100" + "'", str31.equals("+00:00:00.100"));
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        int int21 = offsetDateTimeField16.getDifference((long) 69, (long) 1);
//        boolean boolean23 = offsetDateTimeField16.isLeap(0L);
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology25);
//        int int27 = dateTime26.getDayOfWeek();
//        org.joda.time.DateTime.Property property28 = dateTime26.yearOfEra();
//        org.joda.time.DateTime dateTime30 = dateTime26.plusHours((int) (short) 0);
//        org.joda.time.DateTime.Property property31 = dateTime30.year();
//        org.joda.time.DateTime dateTime32 = dateTime30.withTimeAtStartOfDay();
//        org.joda.time.LocalTime localTime33 = dateTime30.toLocalTime();
//        org.joda.time.LocalTime localTime34 = dateTime30.toLocalTime();
//        java.util.Locale locale35 = null;
//        try {
//            java.lang.String str36 = offsetDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localTime34, locale35);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'monthOfYear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(localTime33);
//        org.junit.Assert.assertNotNull(localTime34);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 240);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.days();
//        java.lang.String str14 = iSOChronology11.toString();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "", (int) (byte) 100, (int) (short) 0);
//        java.lang.String str20 = fixedDateTimeZone19.toString();
//        int int22 = fixedDateTimeZone19.getOffsetFromLocal((-28800000L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology11, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        java.lang.String str25 = zonedChronology24.toString();
//        org.joda.time.DurationField durationField26 = zonedChronology24.years();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[1969-12-31]" + "'", str14.equals("ISOChronology[1969-12-31]"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31" + "'", str20.equals("1969-12-31"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(zonedChronology24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ZonedChronology[ISOChronology[UTC], 1969-12-31]" + "'", str25.equals("ZonedChronology[ISOChronology[UTC], 1969-12-31]"));
//        org.junit.Assert.assertNotNull(durationField26);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.days();
//        java.lang.String str14 = iSOChronology11.toString();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "", (int) (byte) 100, (int) (short) 0);
//        java.lang.String str20 = fixedDateTimeZone19.toString();
//        int int22 = fixedDateTimeZone19.getOffsetFromLocal((-28800000L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology11, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone25 = zonedChronology24.getZone();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "", (int) (byte) 100, (int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone30);
//        long long33 = fixedDateTimeZone30.previousTransition((long) '#');
//        org.joda.time.Chronology chronology34 = zonedChronology24.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone30);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[1969-12-31]" + "'", str14.equals("ISOChronology[1969-12-31]"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31" + "'", str20.equals("1969-12-31"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(zonedChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 35L + "'", long33 == 35L);
//        org.junit.Assert.assertNotNull(chronology34);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology20);
//        int int22 = dateTime21.getDayOfWeek();
//        org.joda.time.DateTime.Property property23 = dateTime21.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime21.toMutableDateTime(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = dateTime21.withZone(dateTimeZone27);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime31 = dateTime21.toMutableDateTime((org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DurationField durationField32 = iSOChronology30.millis();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 57600);
//        int int37 = offsetDateTimeField35.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField35.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, (int) (byte) 100);
//        int int43 = dividedDateTimeField40.getDifference((long) 99, 0L);
//        try {
//            long long46 = dividedDateTimeField40.addWrapField(1561939199900L, 57612);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 0);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths((int) (byte) 0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTime dateTime5 = property4.withMinimumValue();
//        java.lang.String str6 = property4.toString();
//        org.joda.time.DateTime dateTime7 = property4.roundCeilingCopy();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[yearOfEra]" + "'", str6.equals("Property[yearOfEra]"));
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime14 = dateTime2.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime16 = dateTime2.plusDays(0);
//        org.joda.time.DateTime dateTime18 = dateTime2.minusHours((int) (byte) -1);
//        int int19 = dateTime2.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(11L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-24L) + "'", long2 == (-24L));
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology3);
//        int int5 = dateTime4.getDayOfWeek();
//        org.joda.time.DateTime.Property property6 = dateTime4.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime4.toMutableDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-1L), dateTimeZone8);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "PST", (int) (short) 10, (int) (byte) 100);
//        long long17 = dateTimeZone8.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, 10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        java.lang.String str20 = fixedDateTimeZone15.getNameKey(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        boolean boolean23 = fixedDateTimeZone15.isStandardOffset((long) 5820010);
//        java.lang.String str25 = fixedDateTimeZone15.getNameKey((long) (-18062));
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PST" + "'", str25.equals("PST"));
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DateTime.Property property13 = dateTime2.yearOfCentury();
//        org.joda.time.DateTime dateTime14 = property13.getDateTime();
//        org.joda.time.DateTime dateTime16 = dateTime14.plusHours(0);
//        long long17 = dateTime14.getMillis();
//        org.joda.time.DateTime.Property property18 = dateTime14.minuteOfHour();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(property18);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfMinute((int) (short) 10, 57601);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendWeekyear((int) (byte) 10, 3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfHour((int) 'a', (int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendDayOfYear(69);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendMonthOfYearText();
//        boolean boolean10 = dateTimeFormatterBuilder9.canBuildFormatter();
//        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatterBuilder9.toPrinter();
//        org.joda.time.format.DateTimePrinter dateTimePrinter12 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str15 = dateTimeFormatter13.print(10L);
//        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter13.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter12, dateTimeParser16);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder2.append(dateTimePrinter11, dateTimeParser16);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendFractionOfHour((int) 'a', (int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder21.appendDayOfYear(69);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder27.appendMonthOfYearText();
//        boolean boolean29 = dateTimeFormatterBuilder28.canBuildFormatter();
//        org.joda.time.format.DateTimePrinter dateTimePrinter30 = dateTimeFormatterBuilder28.toPrinter();
//        org.joda.time.format.DateTimePrinter dateTimePrinter31 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str34 = dateTimeFormatter32.print(10L);
//        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter32.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter31, dateTimeParser35);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder21.append(dateTimePrinter30, dateTimeParser35);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder38.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder40.appendFractionOfHour((int) 'a', (int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder40.appendDayOfYear(69);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder46.appendMonthOfYearText();
//        boolean boolean48 = dateTimeFormatterBuilder47.canBuildFormatter();
//        org.joda.time.format.DateTimePrinter dateTimePrinter49 = dateTimeFormatterBuilder47.toPrinter();
//        org.joda.time.format.DateTimePrinter dateTimePrinter50 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str53 = dateTimeFormatter51.print(10L);
//        org.joda.time.format.DateTimeParser dateTimeParser54 = dateTimeFormatter51.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter50, dateTimeParser54);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder40.append(dateTimePrinter49, dateTimeParser54);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder57.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimePrinter dateTimePrinter60 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str63 = dateTimeFormatter61.print(10L);
//        org.joda.time.format.DateTimeParser dateTimeParser64 = dateTimeFormatter61.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter65 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter60, dateTimeParser64);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder59.append(dateTimeParser64);
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray67 = new org.joda.time.format.DateTimeParser[] { dateTimeParser54, dateTimeParser64 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder18.append(dateTimePrinter30, dateTimeParserArray67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTimePrinter11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-01" + "'", str15.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeParser16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(dateTimePrinter30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-01-01" + "'", str34.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeParser35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertNotNull(dateTimePrinter49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1970-01-01" + "'", str53.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeParser54);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatter61);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1970-01-01" + "'", str63.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeParser64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertNotNull(dateTimeParserArray67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime2.toDateTimeISO();
//        org.joda.time.DateTime.Property property14 = dateTime13.millisOfSecond();
//        org.joda.time.DateTime.Property property15 = dateTime13.hourOfDay();
//        java.util.Locale locale16 = null;
//        int int17 = property15.getMaximumTextLength(locale16);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        java.lang.String str3 = dateTimeZone1.getName((long) 'a');
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(5);
//        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
//        java.lang.StringBuffer stringBuffer4 = null;
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology6);
//        int int8 = dateTime7.getDayOfWeek();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.joda.time.DateTime dateTime11 = dateTime7.plusHours((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.year();
//        org.joda.time.DateTime dateTime14 = dateTime11.plusHours((int) (short) 100);
//        org.joda.time.LocalDate localDate15 = dateTime11.toLocalDate();
//        try {
//            dateTimeFormatter2.printTo(stringBuffer4, (org.joda.time.ReadablePartial) localDate15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNull(locale3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localDate15);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology20);
//        int int22 = dateTime21.getDayOfWeek();
//        org.joda.time.DateTime.Property property23 = dateTime21.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime21.toMutableDateTime(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = dateTime21.withZone(dateTimeZone27);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime31 = dateTime21.toMutableDateTime((org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DurationField durationField32 = iSOChronology30.millis();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 57600);
//        int int37 = offsetDateTimeField35.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField35.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, (int) (byte) 100);
//        int int41 = dividedDateTimeField40.getMaximumValue();
//        long long44 = dividedDateTimeField40.add((long) ' ', (long) 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField40);
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology47);
//        int int49 = dateTime48.getDayOfWeek();
//        org.joda.time.DateTime.Property property50 = dateTime48.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeUtils.getZone(dateTimeZone51);
//        org.joda.time.MutableDateTime mutableDateTime53 = dateTime48.toMutableDateTime(dateTimeZone52);
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
//        org.joda.time.DateTime dateTime56 = dateTime48.withZone(dateTimeZone54);
//        org.joda.time.chrono.ISOChronology iSOChronology57 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime58 = dateTime48.toMutableDateTime((org.joda.time.Chronology) iSOChronology57);
//        org.joda.time.Chronology chronology60 = null;
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology60);
//        int int62 = dateTime61.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.DateTime dateTime64 = dateTime61.withZone(dateTimeZone63);
//        org.joda.time.DateTime dateTime69 = dateTime61.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate70 = dateTime61.toLocalDate();
//        long long72 = iSOChronology57.set((org.joda.time.ReadablePartial) localDate70, (long) (byte) 100);
//        java.util.Locale locale74 = null;
//        java.lang.String str75 = remainderDateTimeField45.getAsShortText((org.joda.time.ReadablePartial) localDate70, 1, locale74);
//        int int76 = remainderDateTimeField45.getMinimumValue();
//        int int77 = remainderDateTimeField45.getMinimumValue();
//        int int78 = remainderDateTimeField45.getMinimumValue();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 576 + "'", int41 == 576);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 788918400032L + "'", long44 == 788918400032L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(mutableDateTime53);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(iSOChronology57);
//        org.junit.Assert.assertNotNull(mutableDateTime58);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 100L + "'", long72 == 100L);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "1" + "'", str75.equals("1"));
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime.Property property24 = dateTime22.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime22.toMutableDateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime22.toMutableDateTime((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DurationField durationField33 = iSOChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.millisOfDay();
//        org.joda.time.DurationField durationField35 = iSOChronology31.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField35);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField36.getRangeDurationField();
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField36.getLeapDurationField();
//        long long41 = unsupportedDateTimeField36.add(35L, 57612);
//        long long44 = unsupportedDateTimeField36.add(0L, (-48L));
//        long long47 = unsupportedDateTimeField36.getDifferenceAsLong((long) (byte) -1, (long) 59);
//        try {
//            long long49 = unsupportedDateTimeField36.roundCeiling((long) 70);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 34843737600035L + "'", long41 == 34843737600035L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-29030400000L) + "'", long44 == (-29030400000L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Thursday");
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology3);
//        int int5 = dateTime4.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withZone(dateTimeZone6);
//        org.joda.time.DateTime dateTime12 = dateTime4.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate13 = dateTime4.toLocalDate();
//        int int14 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTime dateTime16 = dateTime4.withMillis((long) (byte) 0);
//        org.joda.time.DateTime dateTime18 = dateTime4.withDayOfWeek(7);
//        org.joda.time.DateTime.Property property19 = dateTime18.dayOfMonth();
//        boolean boolean20 = jodaTimePermission1.equals((java.lang.Object) dateTime18);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        long long20 = offsetDateTimeField16.roundHalfEven(0L);
//        org.joda.time.DurationField durationField21 = offsetDateTimeField16.getDurationField();
//        org.joda.time.DateTimeField dateTimeField22 = offsetDateTimeField16.getWrappedField();
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology24);
//        org.joda.time.DateTime.Property property26 = dateTime25.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField22, dateTimeFieldType27, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-100L) + "'", long20 == (-100L));
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.days();
//        java.lang.String str14 = iSOChronology11.toString();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "", (int) (byte) 100, (int) (short) 0);
//        java.lang.String str20 = fixedDateTimeZone19.toString();
//        int int22 = fixedDateTimeZone19.getOffsetFromLocal((-28800000L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology11, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone25 = zonedChronology24.getZone();
//        org.joda.time.DurationField durationField26 = zonedChronology24.hours();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[1969-12-31]" + "'", str14.equals("ISOChronology[1969-12-31]"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31" + "'", str20.equals("1969-12-31"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(zonedChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(durationField26);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int17 = offsetDateTimeField16.getMaximumValue();
//        long long20 = offsetDateTimeField16.add(100800770L, (int) (byte) 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 57612 + "'", int17 == 57612);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2779200770L + "'", long20 == 2779200770L);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DateTime.Property property13 = dateTime2.weekOfWeekyear();
//        java.lang.String str14 = property13.getAsString();
//        java.lang.String str15 = property13.getAsShortText();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 59);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime.Property property24 = dateTime22.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime22.toMutableDateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime22.toMutableDateTime((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DurationField durationField33 = iSOChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.millisOfDay();
//        org.joda.time.DurationField durationField35 = iSOChronology31.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField35);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField36.getRangeDurationField();
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField36.getLeapDurationField();
//        long long41 = unsupportedDateTimeField36.add(35L, 57612);
//        long long44 = unsupportedDateTimeField36.add(0L, (long) 1970);
//        java.lang.String str45 = unsupportedDateTimeField36.toString();
//        try {
//            int int46 = unsupportedDateTimeField36.getMinimumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 34843737600035L + "'", long41 == 34843737600035L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1191456000000L + "'", long44 == 1191456000000L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        int int5 = property4.getLeapAmount();
//        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology8);
//        int int10 = dateTime9.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withZone(dateTimeZone11);
//        org.joda.time.DateTime.Property property13 = dateTime12.dayOfWeek();
//        long long14 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime12);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
//        org.joda.time.DurationField durationField14 = gregorianChronology13.weekyears();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "", (int) (byte) 100, (int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = fixedDateTimeZone19.getName(10368000000L, locale23);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.100" + "'", str24.equals("+00:00:00.100"));
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int17 = offsetDateTimeField16.getMaximumValue();
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology19);
//        int int21 = dateTime20.getDayOfWeek();
//        org.joda.time.DateTime.Property property22 = dateTime20.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime20.toMutableDateTime(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
//        org.joda.time.DateTime dateTime28 = dateTime20.withZone(dateTimeZone26);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime30 = dateTime20.toMutableDateTime((org.joda.time.Chronology) iSOChronology29);
//        org.joda.time.DurationField durationField31 = iSOChronology29.millis();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, 57600);
//        int int36 = offsetDateTimeField34.getLeapAmount((long) 'a');
//        org.joda.time.Chronology chronology38 = null;
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology38);
//        int int40 = dateTime39.getDayOfWeek();
//        org.joda.time.DateTime.Property property41 = dateTime39.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeUtils.getZone(dateTimeZone42);
//        org.joda.time.MutableDateTime mutableDateTime44 = dateTime39.toMutableDateTime(dateTimeZone43);
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeUtils.getZone(dateTimeZone45);
//        org.joda.time.DateTime dateTime47 = dateTime39.withZone(dateTimeZone45);
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime49 = dateTime39.toMutableDateTime((org.joda.time.Chronology) iSOChronology48);
//        org.joda.time.DurationField durationField50 = iSOChronology48.millis();
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology48.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, 57600);
//        int int55 = offsetDateTimeField53.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = offsetDateTimeField53.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType56, (int) (byte) 100);
//        int int59 = dividedDateTimeField58.getMaximumValue();
//        long long62 = dividedDateTimeField58.add((long) ' ', (long) 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField58);
//        org.joda.time.Chronology chronology65 = null;
//        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology65);
//        int int67 = dateTime66.getDayOfWeek();
//        org.joda.time.DateTime.Property property68 = dateTime66.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeUtils.getZone(dateTimeZone69);
//        org.joda.time.MutableDateTime mutableDateTime71 = dateTime66.toMutableDateTime(dateTimeZone70);
//        org.joda.time.DateTimeZone dateTimeZone72 = null;
//        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeUtils.getZone(dateTimeZone72);
//        org.joda.time.DateTime dateTime74 = dateTime66.withZone(dateTimeZone72);
//        org.joda.time.chrono.ISOChronology iSOChronology75 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime76 = dateTime66.toMutableDateTime((org.joda.time.Chronology) iSOChronology75);
//        org.joda.time.Chronology chronology78 = null;
//        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology78);
//        int int80 = dateTime79.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone81 = null;
//        org.joda.time.DateTime dateTime82 = dateTime79.withZone(dateTimeZone81);
//        org.joda.time.DateTime dateTime87 = dateTime79.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate88 = dateTime79.toLocalDate();
//        long long90 = iSOChronology75.set((org.joda.time.ReadablePartial) localDate88, (long) (byte) 100);
//        java.util.Locale locale92 = null;
//        java.lang.String str93 = remainderDateTimeField63.getAsShortText((org.joda.time.ReadablePartial) localDate88, 1, locale92);
//        int[] intArray94 = null;
//        int int95 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate88, intArray94);
//        java.lang.String str96 = offsetDateTimeField16.toString();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 57612 + "'", int17 == 57612);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(mutableDateTime44);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(mutableDateTime49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 576 + "'", int59 == 576);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 788918400032L + "'", long62 == 788918400032L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 4 + "'", int67 == 4);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(dateTimeZone70);
//        org.junit.Assert.assertNotNull(mutableDateTime71);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(iSOChronology75);
//        org.junit.Assert.assertNotNull(mutableDateTime76);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 4 + "'", int80 == 4);
//        org.junit.Assert.assertNotNull(dateTime82);
//        org.junit.Assert.assertNotNull(dateTime87);
//        org.junit.Assert.assertNotNull(localDate88);
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 100L + "'", long90 == 100L);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "1" + "'", str93.equals("1"));
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 57601 + "'", int95 == 57601);
//        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "DateTimeField[monthOfYear]" + "'", str96.equals("DateTimeField[monthOfYear]"));
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime10 = dateTime2.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(7);
//        org.joda.time.DateTime.Property property13 = dateTime10.hourOfDay();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfFloorCopy();
//        org.joda.time.Interval interval15 = property13.toInterval();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(interval15);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.halfdayOfDay();
//        org.joda.time.DurationField durationField16 = iSOChronology11.hours();
//        org.joda.time.DurationField durationField17 = iSOChronology11.centuries();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(durationField17);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology20);
//        int int22 = dateTime21.getDayOfWeek();
//        org.joda.time.DateTime.Property property23 = dateTime21.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime21.toMutableDateTime(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = dateTime21.withZone(dateTimeZone27);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime31 = dateTime21.toMutableDateTime((org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DurationField durationField32 = iSOChronology30.millis();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 57600);
//        int int37 = offsetDateTimeField35.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField35.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, (int) (byte) 100);
//        int int43 = dividedDateTimeField40.getDifference((long) 99, 0L);
//        int int46 = dividedDateTimeField40.getDifference((long) (-18062), (long) 57600);
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dividedDateTimeField40.getAsShortText(10L, locale48);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "576" + "'", str49.equals("576"));
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("57601", "Wednesday", false, 4, (int) ' ');
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology8);
//        int int10 = dateTime9.getDayOfWeek();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology12);
//        int int14 = dateTime13.getDayOfWeek();
//        org.joda.time.DateTime.Property property15 = dateTime13.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime13.toMutableDateTime(dateTimeZone17);
//        org.joda.time.MutableDateTime mutableDateTime19 = dateTime9.toMutableDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime21 = dateTime9.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime23 = dateTime21.withYearOfEra(10);
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.DateTime dateTime30 = dateTime21.withField(dateTimeFieldType28, (int) '#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType28, (int) 'a', 0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter34 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str37 = dateTimeFormatter35.print(10L);
//        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter35.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter34, dateTimeParser38);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder0.append(dateTimeParser38);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatter41.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1970-01-01" + "'", str37.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeParser38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(dateTimeParser42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime14 = dateTime2.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime16 = dateTime14.withYearOfEra(10);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology18);
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.DateTime dateTime23 = dateTime14.withField(dateTimeFieldType21, (int) '#');
//        int int24 = dateTime23.getMillisOfSecond();
//        org.joda.time.DateTime dateTime26 = dateTime23.minus(1L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 110 + "'", int24 == 110);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime14 = dateTime2.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime16 = dateTime14.withYearOfEra(10);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology18);
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.DateTime dateTime23 = dateTime14.withField(dateTimeFieldType21, (int) '#');
//        org.joda.time.DateTime dateTime25 = dateTime14.withYearOfCentury(1);
//        org.joda.time.DateTime dateTime27 = dateTime25.minusHours((int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
//        java.lang.String str15 = dateTimeZone10.getShortName((long) 14400110);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.100" + "'", str15.equals("+00:00:00.100"));
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime.Property property24 = dateTime22.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime22.toMutableDateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime22.toMutableDateTime((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DurationField durationField33 = iSOChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.millisOfDay();
//        org.joda.time.DurationField durationField35 = iSOChronology31.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField35);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField36.getRangeDurationField();
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField36.getLeapDurationField();
//        long long41 = unsupportedDateTimeField36.add(35L, 57612);
//        long long44 = unsupportedDateTimeField36.add(0L, (long) 1970);
//        boolean boolean45 = unsupportedDateTimeField36.isLenient();
//        boolean boolean46 = unsupportedDateTimeField36.isSupported();
//        java.lang.String str47 = unsupportedDateTimeField36.getName();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 34843737600035L + "'", long41 == 34843737600035L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1191456000000L + "'", long44 == 1191456000000L);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "monthOfYear" + "'", str47.equals("monthOfYear"));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "", (int) (byte) 100, (int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField6 = iSOChronology5.days();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(28800000L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28799900L + "'", long2 == 28799900L);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology2);
//        int int4 = dateTime3.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime3.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime3.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((-1L), dateTimeZone7);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusSeconds((int) (short) 1);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusDays((int) (short) 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.hours();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.weekyearOfCentury();
//        org.joda.time.DurationField durationField16 = iSOChronology11.months();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Thursday");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Thursday" + "'", str3.equals("Thursday"));
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime14 = dateTime2.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime16 = dateTime14.withYearOfEra(10);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology22);
//        int int24 = dateTime23.getDayOfWeek();
//        org.joda.time.DateTime.Property property25 = dateTime23.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
//        org.joda.time.MutableDateTime mutableDateTime28 = dateTime23.toMutableDateTime(dateTimeZone27);
//        org.joda.time.MutableDateTime mutableDateTime29 = dateTime19.toMutableDateTime(dateTimeZone27);
//        org.joda.time.DateTime dateTime31 = dateTime19.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime33 = dateTime19.plusDays(0);
//        java.util.Date date34 = dateTime33.toDate();
//        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime14, (org.joda.time.ReadableInstant) dateTime33);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(chronology35);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology20);
//        int int22 = dateTime21.getDayOfWeek();
//        org.joda.time.DateTime.Property property23 = dateTime21.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime21.toMutableDateTime(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = dateTime21.withZone(dateTimeZone27);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime31 = dateTime21.toMutableDateTime((org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DurationField durationField32 = iSOChronology30.millis();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 57600);
//        int int37 = offsetDateTimeField35.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField35.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, (int) (byte) 100);
//        int int43 = dividedDateTimeField40.getDifference((long) 99, 0L);
//        int int46 = dividedDateTimeField40.getDifference((long) (-18062), (long) 57600);
//        try {
//            long long49 = dividedDateTimeField40.addWrapField((-29030400000L), 7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "PST", (int) (short) 10, (int) (byte) 100);
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal(14400110L);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology8);
//        int int10 = dateTime9.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime17 = dateTime9.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate18 = dateTime9.toLocalDate();
//        int int19 = dateTime9.getSecondOfDay();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime22.withZone(dateTimeZone24);
//        org.joda.time.DateTime dateTime30 = dateTime22.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate31 = dateTime22.toLocalDate();
//        int int32 = dateTime22.getSecondOfDay();
//        org.joda.time.DateTime dateTime34 = dateTime22.withMillis((long) (byte) 0);
//        org.joda.time.DateTime dateTime36 = dateTime34.plusMillis((int) (short) 0);
//        boolean boolean37 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime34);
//        boolean boolean38 = fixedDateTimeZone4.equals((java.lang.Object) dateTime34);
//        java.lang.String str39 = dateTime34.toString();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1970-01-01T00:00:00.100+00:00:00.100" + "'", str39.equals("1970-01-01T00:00:00.100+00:00:00.100"));
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime.Property property24 = dateTime22.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime22.toMutableDateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime22.toMutableDateTime((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DurationField durationField33 = iSOChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.millisOfDay();
//        org.joda.time.DurationField durationField35 = iSOChronology31.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField35);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField36.getRangeDurationField();
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField36.getLeapDurationField();
//        long long41 = unsupportedDateTimeField36.add(35L, 57612);
//        long long44 = unsupportedDateTimeField36.add(0L, (-48L));
//        long long47 = unsupportedDateTimeField36.add((long) 5, (-3283200096L));
//        try {
//            long long50 = unsupportedDateTimeField36.addWrapField(10368000000L, 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 34843737600035L + "'", long41 == 34843737600035L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-29030400000L) + "'", long44 == (-29030400000L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-1985679418060799995L) + "'", long47 == (-1985679418060799995L));
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology3);
//        int int5 = dateTime4.getDayOfWeek();
//        org.joda.time.DateTime.Property property6 = dateTime4.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime4.toMutableDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-1L), dateTimeZone8);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "PST", (int) (short) 10, (int) (byte) 100);
//        long long17 = dateTimeZone8.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, 10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        java.lang.String str20 = fixedDateTimeZone15.getNameKey(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        int int23 = cachedDateTimeZone21.getStandardOffset((long) (byte) -1);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone21);
//        org.joda.time.DateTime.Property property25 = dateTime24.dayOfWeek();
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology27);
//        int int29 = dateTime28.getDayOfWeek();
//        org.joda.time.DateTime.Property property30 = dateTime28.yearOfEra();
//        org.joda.time.DateTime dateTime32 = dateTime28.plusHours((int) (short) 0);
//        org.joda.time.DateTime.Property property33 = dateTime32.year();
//        org.joda.time.DateTime dateTime34 = dateTime32.withTimeAtStartOfDay();
//        org.joda.time.LocalTime localTime35 = dateTime32.toLocalTime();
//        org.joda.time.LocalTime localTime36 = dateTime32.toLocalTime();
//        try {
//            int int37 = property25.compareTo((org.joda.time.ReadablePartial) localTime36);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localTime35);
//        org.junit.Assert.assertNotNull(localTime36);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("57601", "Wednesday", false, 4, (int) ' ');
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology8);
//        int int10 = dateTime9.getDayOfWeek();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology12);
//        int int14 = dateTime13.getDayOfWeek();
//        org.joda.time.DateTime.Property property15 = dateTime13.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime13.toMutableDateTime(dateTimeZone17);
//        org.joda.time.MutableDateTime mutableDateTime19 = dateTime9.toMutableDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime21 = dateTime9.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime23 = dateTime21.withYearOfEra(10);
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.DateTime dateTime30 = dateTime21.withField(dateTimeFieldType28, (int) '#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType28, (int) 'a', 0);
//        boolean boolean34 = dateTimeFormatterBuilder33.canBuildPrinter();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap35 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendTimeZoneShortName(strMap35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime.Property property24 = dateTime22.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime22.toMutableDateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime22.toMutableDateTime((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DurationField durationField33 = iSOChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.millisOfDay();
//        org.joda.time.DurationField durationField35 = iSOChronology31.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField35);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField36.getRangeDurationField();
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField36.getLeapDurationField();
//        long long41 = unsupportedDateTimeField36.add((-2678400096L), (int) (byte) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField36.getType();
//        java.util.Locale locale45 = null;
//        try {
//            long long46 = unsupportedDateTimeField36.set(37868631494402000L, "1970", locale45);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-3283200096L) + "'", long41 == (-3283200096L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildFormatter();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatterBuilder1.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendYearOfEra(0, 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str6 = dateTimeFormatter4.print(10L);
//        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter4.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser7);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.append(dateTimeParser7);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendSecondOfMinute(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendHourOfDay((int) (byte) 10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970-01-01" + "'", str6.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeParser7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(292278993, 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime14 = dateTime2.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime16 = dateTime14.withYearOfEra(10);
//        long long17 = dateTime14.getMillis();
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime14.withDurationAdded(readableDuration18, (int) (byte) 10);
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology22);
//        int int24 = dateTime23.getDayOfWeek();
//        org.joda.time.DateTime.Property property25 = dateTime23.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
//        org.joda.time.MutableDateTime mutableDateTime28 = dateTime23.toMutableDateTime(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = dateTime23.withZone(dateTimeZone29);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime33 = dateTime23.toMutableDateTime((org.joda.time.Chronology) iSOChronology32);
//        org.joda.time.Chronology chronology35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology35);
//        int int37 = dateTime36.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime36.withZone(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = dateTime36.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate45 = dateTime36.toLocalDate();
//        long long47 = iSOChronology32.set((org.joda.time.ReadablePartial) localDate45, (long) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology32.minuteOfDay();
//        org.joda.time.Chronology chronology50 = null;
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology50);
//        int int52 = dateTime51.getDayOfWeek();
//        org.joda.time.DateTime.Property property53 = dateTime51.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
//        org.joda.time.MutableDateTime mutableDateTime56 = dateTime51.toMutableDateTime(dateTimeZone55);
//        org.joda.time.ReadablePeriod readablePeriod57 = null;
//        org.joda.time.DateTime dateTime59 = dateTime51.withPeriodAdded(readablePeriod57, (int) (byte) -1);
//        org.joda.time.DateTime dateTime61 = dateTime51.minusMillis(57601);
//        boolean boolean62 = iSOChronology32.equals((java.lang.Object) 57601);
//        org.joda.time.DateTime dateTime63 = dateTime20.withChronology((org.joda.time.Chronology) iSOChronology32);
//        org.joda.time.DateTimeField dateTimeField64 = iSOChronology32.weekOfWeekyear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5820010L + "'", long17 == 5820010L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(mutableDateTime33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology15);
//        int int17 = dateTime16.getDayOfWeek();
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology19);
//        int int21 = dateTime20.getDayOfWeek();
//        org.joda.time.DateTime.Property property22 = dateTime20.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime20.toMutableDateTime(dateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime16.toMutableDateTime(dateTimeZone24);
//        org.joda.time.Chronology chronology27 = gregorianChronology13.withZone(dateTimeZone24);
//        org.joda.time.DurationField durationField28 = gregorianChronology13.seconds();
//        org.joda.time.DurationField durationField29 = gregorianChronology13.halfdays();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(durationField29);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType4, 57601, 3, 5820010);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType4, (java.lang.Number) 1560636217384L, "+00:00:00.100");
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTime dateTime5 = property4.withMinimumValue();
//        java.lang.String str6 = property4.toString();
//        try {
//            org.joda.time.DateTime dateTime8 = property4.setCopy("ZonedChronology[ISOChronology[UTC], 1969-12-31]");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ZonedChronology[ISOChronology[UTC], 1969-12-31]\" for yearOfEra is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[yearOfEra]" + "'", str6.equals("Property[yearOfEra]"));
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime2.minuteOfHour();
//        int int9 = property8.getLeapAmount();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusHours((int) (short) 0);
//        org.joda.time.DateTime.Property property7 = dateTime6.year();
//        int int8 = property7.getMaximumValue();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292278993 + "'", int8 == 292278993);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("57601", "Wednesday", false, 4, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) (short) 10, true);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneName(strMap8);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str14 = dateTimeFormatter12.print(10L);
//        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter12.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.append(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-01-01" + "'", str14.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeParser15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        boolean boolean17 = offsetDateTimeField16.isLenient();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText((int) (byte) 100, locale19);
//        long long22 = offsetDateTimeField16.remainder((-1L));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 99L + "'", long22 == 99L);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology20);
//        int int22 = dateTime21.getDayOfWeek();
//        org.joda.time.DateTime.Property property23 = dateTime21.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime21.toMutableDateTime(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = dateTime21.withZone(dateTimeZone27);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime31 = dateTime21.toMutableDateTime((org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DurationField durationField32 = iSOChronology30.millis();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 57600);
//        int int37 = offsetDateTimeField35.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField35.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, (int) (byte) 100);
//        int int41 = dividedDateTimeField40.getMaximumValue();
//        long long44 = dividedDateTimeField40.add((long) ' ', (long) 3);
//        int int47 = dividedDateTimeField40.getDifference((long) 69, (long) '4');
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology49);
//        org.joda.time.DateTime.Property property51 = dateTime50.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType52, 57601, 3, 5820010);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField40, dateTimeFieldType52, 100, (int) (byte) 100, 100);
//        int int62 = dividedDateTimeField40.get(100L);
//        org.joda.time.DurationField durationField63 = dividedDateTimeField40.getDurationField();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 576 + "'", int41 == 576);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 788918400032L + "'", long44 == 788918400032L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 576 + "'", int62 == 576);
//        org.junit.Assert.assertNotNull(durationField63);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Thursday");
        jodaTimePermission1.checkGuard((java.lang.Object) 2678399900L);
        java.lang.String str4 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Thursday" + "'", str4.equals("Thursday"));
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        long long20 = offsetDateTimeField16.roundHalfEven(0L);
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial21);
//        long long24 = offsetDateTimeField16.roundCeiling((long) (byte) -1);
//        try {
//            long long27 = offsetDateTimeField16.set(1561939199900L, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [57601,57612]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-100L) + "'", long20 == (-100L));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 57601 + "'", int22 == 57601);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2678399900L + "'", long24 == 2678399900L);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime14 = dateTime2.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime16 = dateTime14.withYearOfEra(10);
//        org.joda.time.DateTime dateTime18 = dateTime16.minusMonths(59);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime14 = dateTime2.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime16 = dateTime14.withYearOfEra(10);
//        long long17 = dateTime14.getMillis();
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime14.withDurationAdded(readableDuration18, (int) (byte) 10);
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology22);
//        int int24 = dateTime23.getDayOfWeek();
//        org.joda.time.DateTime.Property property25 = dateTime23.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
//        org.joda.time.MutableDateTime mutableDateTime28 = dateTime23.toMutableDateTime(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = dateTime23.withZone(dateTimeZone29);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime33 = dateTime23.toMutableDateTime((org.joda.time.Chronology) iSOChronology32);
//        org.joda.time.Chronology chronology35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology35);
//        int int37 = dateTime36.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime36.withZone(dateTimeZone38);
//        org.joda.time.DateTime dateTime44 = dateTime36.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate45 = dateTime36.toLocalDate();
//        long long47 = iSOChronology32.set((org.joda.time.ReadablePartial) localDate45, (long) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology32.minuteOfDay();
//        org.joda.time.Chronology chronology50 = null;
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology50);
//        int int52 = dateTime51.getDayOfWeek();
//        org.joda.time.DateTime.Property property53 = dateTime51.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
//        org.joda.time.MutableDateTime mutableDateTime56 = dateTime51.toMutableDateTime(dateTimeZone55);
//        org.joda.time.ReadablePeriod readablePeriod57 = null;
//        org.joda.time.DateTime dateTime59 = dateTime51.withPeriodAdded(readablePeriod57, (int) (byte) -1);
//        org.joda.time.DateTime dateTime61 = dateTime51.minusMillis(57601);
//        boolean boolean62 = iSOChronology32.equals((java.lang.Object) 57601);
//        org.joda.time.DateTime dateTime63 = dateTime20.withChronology((org.joda.time.Chronology) iSOChronology32);
//        org.joda.time.DateTime dateTime65 = dateTime20.withYearOfCentury(69);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5820010L + "'", long17 == 5820010L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(mutableDateTime33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime65);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology20);
//        int int22 = dateTime21.getDayOfWeek();
//        org.joda.time.DateTime.Property property23 = dateTime21.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime21.toMutableDateTime(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = dateTime21.withZone(dateTimeZone27);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime31 = dateTime21.toMutableDateTime((org.joda.time.Chronology) iSOChronology30);
//        org.joda.time.DurationField durationField32 = iSOChronology30.millis();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 57600);
//        int int37 = offsetDateTimeField35.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField35.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, (int) (byte) 100);
//        try {
//            long long42 = dividedDateTimeField40.roundHalfCeiling((long) 57612);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for monthOfYear must be in the range [57601,57612]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.DateTime.Property property21 = dateTime19.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime19.toMutableDateTime(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = dateTime19.withZone(dateTimeZone25);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime29 = dateTime19.toMutableDateTime((org.joda.time.Chronology) iSOChronology28);
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology31);
//        int int33 = dateTime32.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime32.withZone(dateTimeZone34);
//        org.joda.time.DateTime dateTime40 = dateTime32.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate41 = dateTime32.toLocalDate();
//        long long43 = iSOChronology28.set((org.joda.time.ReadablePartial) localDate41, (long) (byte) 100);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = offsetDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate41, (int) (byte) 10, locale45);
//        org.joda.time.DurationField durationField47 = offsetDateTimeField16.getLeapDurationField();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10" + "'", str46.equals("10"));
//        org.junit.Assert.assertNotNull(durationField47);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.DateTime.Property property21 = dateTime19.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime19.toMutableDateTime(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = dateTime19.withZone(dateTimeZone25);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime29 = dateTime19.toMutableDateTime((org.joda.time.Chronology) iSOChronology28);
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology31);
//        int int33 = dateTime32.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime32.withZone(dateTimeZone34);
//        org.joda.time.DateTime dateTime40 = dateTime32.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate41 = dateTime32.toLocalDate();
//        long long43 = iSOChronology28.set((org.joda.time.ReadablePartial) localDate41, (long) (byte) 100);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = offsetDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate41, (int) (byte) 10, locale45);
//        org.joda.time.DurationField durationField47 = offsetDateTimeField16.getLeapDurationField();
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology49);
//        int int51 = dateTime50.getDayOfWeek();
//        org.joda.time.DateTime.Property property52 = dateTime50.yearOfEra();
//        org.joda.time.DateTime dateTime54 = dateTime50.plusHours((int) (short) 0);
//        org.joda.time.DateTime.Property property55 = dateTime54.year();
//        org.joda.time.DateTime dateTime57 = dateTime54.plusHours((int) (short) 100);
//        org.joda.time.LocalDate localDate58 = dateTime54.toLocalDate();
//        int[] intArray60 = new int[] {};
//        try {
//            int[] intArray62 = offsetDateTimeField16.set((org.joda.time.ReadablePartial) localDate58, (int) (byte) 1, intArray60, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for monthOfYear must be in the range [57601,57612]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10" + "'", str46.equals("10"));
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(localDate58);
//        org.junit.Assert.assertNotNull(intArray60);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.DateTime.Property property21 = dateTime19.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime19.toMutableDateTime(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = dateTime19.withZone(dateTimeZone25);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime29 = dateTime19.toMutableDateTime((org.joda.time.Chronology) iSOChronology28);
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology31);
//        int int33 = dateTime32.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime32.withZone(dateTimeZone34);
//        org.joda.time.DateTime dateTime40 = dateTime32.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate41 = dateTime32.toLocalDate();
//        long long43 = iSOChronology28.set((org.joda.time.ReadablePartial) localDate41, (long) (byte) 100);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = offsetDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate41, (int) (byte) 10, locale45);
//        int int48 = offsetDateTimeField16.getMaximumValue((long) 0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, (int) (byte) -1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10" + "'", str46.equals("10"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 57612 + "'", int48 == 57612);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime14 = dateTime2.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime16 = dateTime14.withYearOfEra(10);
//        long long17 = dateTime14.getMillis();
//        org.joda.time.DateTime.Property property18 = dateTime14.weekyear();
//        boolean boolean19 = property18.isLeap();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5820010L + "'", long17 == 5820010L);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        boolean boolean3 = dateTimeFormatter2.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property6.getAsText(locale7);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology10);
//        int int12 = dateTime11.getDayOfWeek();
//        org.joda.time.DateTime.Property property13 = dateTime11.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        org.joda.time.MutableDateTime mutableDateTime16 = dateTime11.toMutableDateTime(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime11.withZone(dateTimeZone17);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime21 = dateTime11.toMutableDateTime((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DurationField durationField22 = iSOChronology20.millis();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 57600);
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology27);
//        int int29 = dateTime28.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime28.withZone(dateTimeZone30);
//        org.joda.time.DateTime dateTime36 = dateTime28.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate37 = dateTime28.toLocalDate();
//        int[] intArray39 = new int[] { (short) 1 };
//        int int40 = offsetDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localDate37, intArray39);
//        int int41 = property6.compareTo((org.joda.time.ReadablePartial) localDate37);
//        org.joda.time.DurationField durationField42 = property6.getLeapDurationField();
//        org.joda.time.DurationField durationField43 = property6.getRangeDurationField();
//        org.joda.time.Chronology chronology45 = null;
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology45);
//        int int47 = dateTime46.getDayOfWeek();
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology49);
//        int int51 = dateTime50.getDayOfWeek();
//        org.joda.time.DateTime.Property property52 = dateTime50.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.MutableDateTime mutableDateTime55 = dateTime50.toMutableDateTime(dateTimeZone54);
//        org.joda.time.MutableDateTime mutableDateTime56 = dateTime46.toMutableDateTime(dateTimeZone54);
//        org.joda.time.DateTime dateTime58 = dateTime46.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime60 = dateTime58.plusMinutes((int) (byte) 1);
//        long long61 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime60);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Thursday" + "'", str8.equals("Thursday"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 57612 + "'", int40 == 57612);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(mutableDateTime55);
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, dateTimeZone1);
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology4);
//        int int6 = dateTime5.getDayOfWeek();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology8);
//        int int10 = dateTime9.getDayOfWeek();
//        org.joda.time.DateTime.Property property11 = dateTime9.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime9.toMutableDateTime(dateTimeZone13);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime5.toMutableDateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime17 = dateTime5.plusMillis((int) (short) 1);
//        int int18 = dateTime17.getYearOfCentury();
//        boolean boolean19 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime17);
//        long long20 = dateTime17.getMillis();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime17.minus(readablePeriod21);
//        org.joda.time.DateTime dateTime24 = dateTime22.plusMinutes((int) (short) -1);
//        org.joda.time.DurationFieldType durationFieldType25 = null;
//        try {
//            org.joda.time.DateTime dateTime27 = dateTime22.withFieldAdded(durationFieldType25, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 70 + "'", int18 == 70);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 11L + "'", long20 == 11L);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) 0);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) '#');
//        int int9 = dateTime8.getSecondOfDay();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology2);
//        int int4 = dateTime3.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime3.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime3.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = dateTime3.withZone(dateTimeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime3.toMutableDateTime((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField14 = iSOChronology12.millis();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.millisOfDay();
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((-100L), (org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DurationField durationField18 = iSOChronology12.millis();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(durationField18);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime14 = dateTime2.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime16 = dateTime14.withYearOfEra(10);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime16.withPeriodAdded(readablePeriod17, (-1));
//        int int20 = dateTime19.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology3);
//        int int5 = dateTime4.getDayOfWeek();
//        org.joda.time.DateTime.Property property6 = dateTime4.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime4.toMutableDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-1L), dateTimeZone8);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "PST", (int) (short) 10, (int) (byte) 100);
//        long long17 = dateTimeZone8.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, 10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        java.lang.String str19 = fixedDateTimeZone15.getID();
//        java.lang.String str21 = fixedDateTimeZone15.getNameKey((long) (short) 100);
//        int int23 = fixedDateTimeZone15.getOffsetFromLocal((long) (byte) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1969-12-31" + "'", str19.equals("1969-12-31"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime10 = dateTime2.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate11 = dateTime2.toLocalDate();
//        int int12 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime2.withMillis((long) (byte) 0);
//        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
//        try {
//            org.joda.time.DateTime dateTime17 = property15.setCopy((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Property[yearOfEra]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Property[yearOfEra]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime dateTime5 = dateTime2.plusDays((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.minus(readablePeriod6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime2.minus(readablePeriod8);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "", (int) (byte) 100, (int) (short) 0);
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) 99, locale7);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31" + "'", str5.equals("1969-12-31"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.100" + "'", str8.equals("+00:00:00.100"));
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime10 = dateTime2.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate11 = dateTime2.toLocalDate();
//        int int12 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime2.withMillis((long) (byte) 0);
//        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str6 = dateTimeFormatter4.print(10L);
//        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter4.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser7);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.append(dateTimeParser7);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendSecondOfMinute(0);
//        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatterBuilder9.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear(5, false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970-01-01" + "'", str6.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeParser7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeParser12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime10 = dateTime2.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate11 = dateTime2.toLocalDate();
//        int int12 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime2.withMillis((long) (byte) 0);
//        org.joda.time.Chronology chronology15 = dateTime2.getChronology();
//        int int16 = dateTime2.getSecondOfDay();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.DateTime.Property property21 = dateTime19.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime19.toMutableDateTime(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = dateTime19.withZone(dateTimeZone25);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime29 = dateTime19.toMutableDateTime((org.joda.time.Chronology) iSOChronology28);
//        org.joda.time.DurationField durationField30 = iSOChronology28.millis();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology28.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 57600);
//        org.joda.time.Chronology chronology35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology35);
//        int int37 = dateTime36.getDayOfWeek();
//        org.joda.time.DateTime.Property property38 = dateTime36.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeUtils.getZone(dateTimeZone39);
//        org.joda.time.MutableDateTime mutableDateTime41 = dateTime36.toMutableDateTime(dateTimeZone40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeUtils.getZone(dateTimeZone42);
//        org.joda.time.DateTime dateTime44 = dateTime36.withZone(dateTimeZone42);
//        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime46 = dateTime36.toMutableDateTime((org.joda.time.Chronology) iSOChronology45);
//        org.joda.time.DurationField durationField47 = iSOChronology45.millis();
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology45.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 57600);
//        int int52 = offsetDateTimeField50.getLeapAmount((long) 'a');
//        org.joda.time.Chronology chronology54 = null;
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology54);
//        int int56 = dateTime55.getDayOfWeek();
//        org.joda.time.DateTime.Property property57 = dateTime55.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeUtils.getZone(dateTimeZone58);
//        org.joda.time.MutableDateTime mutableDateTime60 = dateTime55.toMutableDateTime(dateTimeZone59);
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeUtils.getZone(dateTimeZone61);
//        org.joda.time.DateTime dateTime63 = dateTime55.withZone(dateTimeZone61);
//        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime65 = dateTime55.toMutableDateTime((org.joda.time.Chronology) iSOChronology64);
//        org.joda.time.DurationField durationField66 = iSOChronology64.millis();
//        org.joda.time.DateTimeField dateTimeField67 = iSOChronology64.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField69 = new org.joda.time.field.OffsetDateTimeField(dateTimeField67, 57600);
//        int int71 = offsetDateTimeField69.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = offsetDateTimeField69.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField74 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType72, (int) (byte) 100);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField33, dateTimeFieldType72, (int) (short) 100);
//        boolean boolean77 = dateTime2.isSupported(dateTimeFieldType72);
//        org.joda.time.DateTime dateTime79 = dateTime2.withDayOfYear(300);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(mutableDateTime41);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(iSOChronology45);
//        org.junit.Assert.assertNotNull(mutableDateTime46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertNotNull(mutableDateTime60);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(iSOChronology64);
//        org.junit.Assert.assertNotNull(mutableDateTime65);
//        org.junit.Assert.assertNotNull(durationField66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//        org.junit.Assert.assertNotNull(dateTime79);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime2.minusHours((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears(300);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime.Property property24 = dateTime22.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime22.toMutableDateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime22.toMutableDateTime((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DurationField durationField33 = iSOChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.millisOfDay();
//        org.joda.time.DurationField durationField35 = iSOChronology31.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField35);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField36.getRangeDurationField();
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField36.getLeapDurationField();
//        long long41 = unsupportedDateTimeField36.add(35L, 57612);
//        long long44 = unsupportedDateTimeField36.add(0L, (long) 1970);
//        boolean boolean45 = unsupportedDateTimeField36.isLenient();
//        long long48 = unsupportedDateTimeField36.getDifferenceAsLong(2995200L, 0L);
//        try {
//            int int50 = unsupportedDateTimeField36.getMaximumValue((-96L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 34843737600035L + "'", long41 == 34843737600035L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1191456000000L + "'", long44 == 1191456000000L);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime14 = dateTime2.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime16 = dateTime14.withYearOfEra(10);
//        org.joda.time.Instant instant17 = dateTime14.toInstant();
//        try {
//            org.joda.time.DateTime dateTime19 = dateTime14.withSecondOfMinute(57600);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(instant17);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusHours((int) (short) 0);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        int int9 = property7.getDifference(readableInstant8);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property7.getAsShortText(locale10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-18062) + "'", int9 == (-18062));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime.Property property24 = dateTime22.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime22.toMutableDateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime22.toMutableDateTime((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DurationField durationField33 = iSOChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.millisOfDay();
//        org.joda.time.DurationField durationField35 = iSOChronology31.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField35);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField36.getRangeDurationField();
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField36.getLeapDurationField();
//        long long41 = unsupportedDateTimeField36.add(35L, 57612);
//        long long44 = unsupportedDateTimeField36.add(0L, (long) 1970);
//        boolean boolean45 = unsupportedDateTimeField36.isLenient();
//        boolean boolean46 = unsupportedDateTimeField36.isSupported();
//        boolean boolean47 = unsupportedDateTimeField36.isLenient();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 34843737600035L + "'", long41 == 34843737600035L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1191456000000L + "'", long44 == 1191456000000L);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime.Property property24 = dateTime22.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime22.toMutableDateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime22.toMutableDateTime((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DurationField durationField33 = iSOChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.millisOfDay();
//        org.joda.time.DurationField durationField35 = iSOChronology31.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField35);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField36.getRangeDurationField();
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField36.getLeapDurationField();
//        java.lang.String str39 = unsupportedDateTimeField36.getName();
//        try {
//            int int41 = unsupportedDateTimeField36.getLeapAmount((-101L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertNull(durationField38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "monthOfYear" + "'", str39.equals("monthOfYear"));
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DateTime.Property property13 = dateTime2.yearOfCentury();
//        int int14 = dateTime2.getMinuteOfHour();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime2.minus(readablePeriod15);
//        org.joda.time.DateTime.Property property17 = dateTime2.dayOfYear();
//        org.joda.time.DurationField durationField18 = property17.getDurationField();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(durationField18);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology3);
//        int int5 = dateTime4.getDayOfWeek();
//        org.joda.time.DateTime.Property property6 = dateTime4.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime4.toMutableDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-1L), dateTimeZone8);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "PST", (int) (short) 10, (int) (byte) 100);
//        long long17 = dateTimeZone8.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, 10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        java.lang.String str20 = fixedDateTimeZone15.getNameKey(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        int int23 = cachedDateTimeZone21.getStandardOffset((long) (byte) -1);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone21);
//        org.joda.time.DateTime.Property property25 = dateTime24.dayOfWeek();
//        org.joda.time.DateTime dateTime26 = property25.roundHalfFloorCopy();
//        int int27 = property25.get();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        int int18 = offsetDateTimeField16.getLeapAmount((long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology21);
//        int int23 = dateTime22.getDayOfWeek();
//        org.joda.time.DateTime.Property property24 = dateTime22.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime22.toMutableDateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime22.withZone(dateTimeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime22.toMutableDateTime((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DurationField durationField33 = iSOChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology31.millisOfDay();
//        org.joda.time.DurationField durationField35 = iSOChronology31.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType19, durationField35);
//        org.joda.time.DurationField durationField37 = unsupportedDateTimeField36.getRangeDurationField();
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField36.getLeapDurationField();
//        try {
//            int int40 = unsupportedDateTimeField36.get((long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertNull(durationField38);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.withZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime27 = dateTime19.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate28 = dateTime19.toLocalDate();
//        int[] intArray30 = new int[] { (short) 1 };
//        int int31 = offsetDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDate28, intArray30);
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology33);
//        int int35 = dateTime34.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTime dateTime37 = dateTime34.withZone(dateTimeZone36);
//        org.joda.time.DateTime dateTime42 = dateTime34.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate43 = dateTime34.toLocalDate();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = offsetDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate43, (-1), locale45);
//        long long49 = offsetDateTimeField16.add(0L, (int) (short) -1);
//        long long51 = offsetDateTimeField16.roundHalfFloor((long) 1);
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology53);
//        int int55 = dateTime54.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.DateTime dateTime57 = dateTime54.withZone(dateTimeZone56);
//        org.joda.time.DateTime dateTime62 = dateTime54.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate63 = dateTime54.toLocalDate();
//        org.joda.time.Chronology chronology65 = null;
//        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology65);
//        int int67 = dateTime66.getDayOfWeek();
//        org.joda.time.DateTime.Property property68 = dateTime66.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeUtils.getZone(dateTimeZone69);
//        org.joda.time.MutableDateTime mutableDateTime71 = dateTime66.toMutableDateTime(dateTimeZone70);
//        org.joda.time.DateTimeZone dateTimeZone72 = null;
//        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeUtils.getZone(dateTimeZone72);
//        org.joda.time.DateTime dateTime74 = dateTime66.withZone(dateTimeZone72);
//        org.joda.time.chrono.ISOChronology iSOChronology75 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime76 = dateTime66.toMutableDateTime((org.joda.time.Chronology) iSOChronology75);
//        org.joda.time.DurationField durationField77 = iSOChronology75.millis();
//        org.joda.time.DateTimeField dateTimeField78 = iSOChronology75.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField(dateTimeField78, 57600);
//        org.joda.time.Chronology chronology82 = null;
//        org.joda.time.DateTime dateTime83 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology82);
//        int int84 = dateTime83.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone85 = null;
//        org.joda.time.DateTime dateTime86 = dateTime83.withZone(dateTimeZone85);
//        org.joda.time.DateTime dateTime91 = dateTime83.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate92 = dateTime83.toLocalDate();
//        int[] intArray94 = new int[] { (short) 1 };
//        int int95 = offsetDateTimeField80.getMaximumValue((org.joda.time.ReadablePartial) localDate92, intArray94);
//        int int96 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate63, intArray94);
//        long long98 = offsetDateTimeField16.roundHalfEven(10368000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 57612 + "'", int31 == 57612);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-1" + "'", str46.equals("-1"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2678400000L) + "'", long49 == (-2678400000L));
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-100L) + "'", long51 == (-100L));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 4 + "'", int67 == 4);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(dateTimeZone70);
//        org.junit.Assert.assertNotNull(mutableDateTime71);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(iSOChronology75);
//        org.junit.Assert.assertNotNull(mutableDateTime76);
//        org.junit.Assert.assertNotNull(durationField77);
//        org.junit.Assert.assertNotNull(dateTimeField78);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 4 + "'", int84 == 4);
//        org.junit.Assert.assertNotNull(dateTime86);
//        org.junit.Assert.assertNotNull(dateTime91);
//        org.junit.Assert.assertNotNull(localDate92);
//        org.junit.Assert.assertNotNull(intArray94);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 57612 + "'", int95 == 57612);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 57601 + "'", int96 == 57601);
//        org.junit.Assert.assertTrue("'" + long98 + "' != '" + 10367999900L + "'", long98 == 10367999900L);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendTimeZoneOffset("57601", "Wednesday", false, 4, (int) ' ');
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology11);
//        int int13 = dateTime12.getDayOfWeek();
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology15);
//        int int17 = dateTime16.getDayOfWeek();
//        org.joda.time.DateTime.Property property18 = dateTime16.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.MutableDateTime mutableDateTime21 = dateTime16.toMutableDateTime(dateTimeZone20);
//        org.joda.time.MutableDateTime mutableDateTime22 = dateTime12.toMutableDateTime(dateTimeZone20);
//        org.joda.time.DateTime dateTime24 = dateTime12.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime24.withYearOfEra(10);
//        org.joda.time.Chronology chronology28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology28);
//        org.joda.time.DateTime.Property property30 = dateTime29.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.DateTime dateTime33 = dateTime24.withField(dateTimeFieldType31, (int) '#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder3.appendFraction(dateTimeFieldType31, (int) 'a', 0);
//        boolean boolean37 = gregorianChronology1.equals((java.lang.Object) dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfHour((int) 'a', (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendFractionOfMinute(576, 576);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology4);
//        int int6 = dateTime5.getDayOfWeek();
//        org.joda.time.DateTime.Property property7 = dateTime5.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime5.toMutableDateTime(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((-1L), dateTimeZone9);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "PST", (int) (short) 10, (int) (byte) 100);
//        long long18 = dateTimeZone9.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone16, 10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
//        java.lang.String str21 = fixedDateTimeZone16.getNameKey(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
//        boolean boolean23 = cachedDateTimeZone22.isFixed();
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology25);
//        int int27 = dateTime26.getDayOfWeek();
//        org.joda.time.DateTime.Property property28 = dateTime26.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.MutableDateTime mutableDateTime31 = dateTime26.toMutableDateTime(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = dateTime26.withZone(dateTimeZone32);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime36 = dateTime26.toMutableDateTime((org.joda.time.Chronology) iSOChronology35);
//        org.joda.time.DurationField durationField37 = iSOChronology35.millis();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology35.monthOfYear();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField38, 0, 0, 1);
//        boolean boolean43 = cachedDateTimeZone22.equals((java.lang.Object) 1);
//        org.joda.time.DateTimeZone dateTimeZone44 = cachedDateTimeZone22.getUncachedZone();
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) 14400110, dateTimeZone44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(mutableDateTime36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DateTime.Property property13 = dateTime2.minuteOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime2.plusMillis((int) (byte) 0);
//        boolean boolean17 = dateTime15.isAfter(35L);
//        org.joda.time.DateTime.Property property18 = dateTime15.minuteOfHour();
//        java.lang.String str19 = property18.toString();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[minuteOfHour]" + "'", str19.equals("Property[minuteOfHour]"));
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DateTime.Property property13 = dateTime2.minuteOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime2.plusMillis((int) (byte) 0);
//        boolean boolean17 = dateTime15.isAfter(35L);
//        org.joda.time.DateTime.Property property18 = dateTime15.minuteOfHour();
//        java.lang.Object obj19 = null;
//        boolean boolean20 = property18.equals(obj19);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        boolean boolean17 = offsetDateTimeField16.isLenient();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText((int) (byte) 100, locale19);
//        long long23 = offsetDateTimeField16.add((-96L), (-1));
//        long long26 = offsetDateTimeField16.add(57612L, 10L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2678400096L) + "'", long23 == (-2678400096L));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 26265657612L + "'", long26 == 26265657612L);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology3);
//        int int5 = dateTime4.getDayOfWeek();
//        org.joda.time.DateTime.Property property6 = dateTime4.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime4.toMutableDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-1L), dateTimeZone8);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "PST", (int) (short) 10, (int) (byte) 100);
//        long long17 = dateTimeZone8.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, 10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        java.lang.String str20 = fixedDateTimeZone15.getNameKey(0L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        int int23 = cachedDateTimeZone21.getStandardOffset((long) (byte) -1);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone21);
//        org.joda.time.DateTime.Property property25 = dateTime24.dayOfWeek();
//        int int26 = dateTime24.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(100, '#', 0, (int) (byte) 100, (int) (byte) -1, false, 4);
        java.io.DataOutput dataOutput10 = null;
        try {
            dateTimeZoneBuilder8.writeTo("+00:00:00.010", dataOutput10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("57601", "Wednesday", false, 4, (int) ' ');
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology8);
//        int int10 = dateTime9.getDayOfWeek();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology12);
//        int int14 = dateTime13.getDayOfWeek();
//        org.joda.time.DateTime.Property property15 = dateTime13.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime13.toMutableDateTime(dateTimeZone17);
//        org.joda.time.MutableDateTime mutableDateTime19 = dateTime9.toMutableDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime21 = dateTime9.plusMinutes((int) 'a');
//        org.joda.time.DateTime dateTime23 = dateTime21.withYearOfEra(10);
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.DateTime dateTime30 = dateTime21.withField(dateTimeFieldType28, (int) '#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType28, (int) 'a', 0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter34 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str37 = dateTimeFormatter35.print(10L);
//        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter35.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter34, dateTimeParser38);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder0.append(dateTimeParser38);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder0.appendFractionOfDay((int) '4', (int) (byte) 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1970-01-01" + "'", str37.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeParser38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("monthOfYear");
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime2.withPeriodAdded(readablePeriod8, 0);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) gregorianChronology1);
        boolean boolean3 = dateTime2.isBeforeNow();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (-1), (-18062));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 57600);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.withZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime27 = dateTime19.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate28 = dateTime19.toLocalDate();
//        int[] intArray30 = new int[] { (short) 1 };
//        int int31 = offsetDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDate28, intArray30);
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology33);
//        int int35 = dateTime34.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTime dateTime37 = dateTime34.withZone(dateTimeZone36);
//        org.joda.time.DateTime dateTime42 = dateTime34.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate43 = dateTime34.toLocalDate();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = offsetDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate43, (-1), locale45);
//        long long49 = offsetDateTimeField16.add(0L, (int) (short) -1);
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology51);
//        int int53 = dateTime52.getDayOfWeek();
//        org.joda.time.DateTime.Property property54 = dateTime52.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeUtils.getZone(dateTimeZone55);
//        org.joda.time.MutableDateTime mutableDateTime57 = dateTime52.toMutableDateTime(dateTimeZone56);
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeUtils.getZone(dateTimeZone58);
//        org.joda.time.DateTime dateTime60 = dateTime52.withZone(dateTimeZone58);
//        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime62 = dateTime52.toMutableDateTime((org.joda.time.Chronology) iSOChronology61);
//        org.joda.time.DurationField durationField63 = iSOChronology61.millis();
//        org.joda.time.DateTimeField dateTimeField64 = iSOChronology61.monthOfYear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField64, 57600);
//        boolean boolean67 = offsetDateTimeField66.isLenient();
//        java.util.Locale locale69 = null;
//        java.lang.String str70 = offsetDateTimeField66.getAsShortText((int) (byte) 100, locale69);
//        long long73 = offsetDateTimeField66.add((-96L), (-1));
//        org.joda.time.Chronology chronology75 = null;
//        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology75);
//        int int77 = dateTime76.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone78 = null;
//        org.joda.time.DateTime dateTime79 = dateTime76.withZone(dateTimeZone78);
//        org.joda.time.DateTime dateTime84 = dateTime76.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate85 = dateTime76.toLocalDate();
//        java.util.Locale locale86 = null;
//        java.lang.String str87 = offsetDateTimeField66.getAsShortText((org.joda.time.ReadablePartial) localDate85, locale86);
//        java.util.Locale locale89 = null;
//        java.lang.String str90 = offsetDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate85, (int) (byte) 0, locale89);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 57612 + "'", int31 == 57612);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-1" + "'", str46.equals("-1"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2678400000L) + "'", long49 == (-2678400000L));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(mutableDateTime57);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(iSOChronology61);
//        org.junit.Assert.assertNotNull(mutableDateTime62);
//        org.junit.Assert.assertNotNull(durationField63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "100" + "'", str70.equals("100"));
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-2678400096L) + "'", long73 == (-2678400096L));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 4 + "'", int77 == 4);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertNotNull(localDate85);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "1" + "'", str87.equals("1"));
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "0" + "'", str90.equals("0"));
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime2.minuteOfHour();
//        java.lang.String str9 = property8.getAsString();
//        org.joda.time.DateTimeField dateTimeField10 = property8.getField();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeField10);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, dateTimeZone1);
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology4);
//        int int6 = dateTime5.getDayOfWeek();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology8);
//        int int10 = dateTime9.getDayOfWeek();
//        org.joda.time.DateTime.Property property11 = dateTime9.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime9.toMutableDateTime(dateTimeZone13);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime5.toMutableDateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime17 = dateTime5.plusMillis((int) (short) 1);
//        int int18 = dateTime17.getYearOfCentury();
//        boolean boolean19 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime22 = dateTime2.withDurationAdded(readableDuration20, (int) (byte) 10);
//        org.joda.time.DateTime dateTime24 = dateTime2.plus(1560636217384L);
//        org.joda.time.DateTime dateTime26 = dateTime2.minusMillis(300);
//        try {
//            org.joda.time.DateTime dateTime28 = dateTime26.withEra(100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 70 + "'", int18 == 70);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime2.withZone(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.joda.time.DurationField durationField13 = iSOChronology11.days();
//        java.lang.String str14 = iSOChronology11.toString();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "", (int) (byte) 100, (int) (short) 0);
//        java.lang.String str20 = fixedDateTimeZone19.toString();
//        int int22 = fixedDateTimeZone19.getOffsetFromLocal((-28800000L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology11, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
//        java.lang.String str25 = zonedChronology24.toString();
//        org.joda.time.DateTimeField dateTimeField26 = zonedChronology24.monthOfYear();
//        try {
//            long long32 = zonedChronology24.getDateTimeMillis((long) (short) 0, (int) (byte) -1, 292278993, (int) 'a', (-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[1969-12-31]" + "'", str14.equals("ISOChronology[1969-12-31]"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31" + "'", str20.equals("1969-12-31"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(zonedChronology24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ZonedChronology[ISOChronology[UTC], 1969-12-31]" + "'", str25.equals("ZonedChronology[ISOChronology[UTC], 1969-12-31]"));
//        org.junit.Assert.assertNotNull(dateTimeField26);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology1);
//        int int3 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime10 = dateTime2.withTime((int) (short) 1, (int) (short) 0, (int) (byte) 1, (int) (byte) 100);
//        org.joda.time.LocalDate localDate11 = dateTime2.toLocalDate();
//        int int12 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime2.withMillis((long) (byte) 0);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime2.toMutableDateTimeISO();
//        org.joda.time.DateTime.Property property16 = dateTime2.monthOfYear();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology18);
//        int int20 = dateTime19.getDayOfWeek();
//        org.joda.time.DateTime.Property property21 = dateTime19.yearOfEra();
//        org.joda.time.DateTime dateTime23 = dateTime19.plusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime25 = dateTime19.withMillisOfDay(10);
//        boolean boolean26 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.Chronology chronology27 = dateTime19.getChronology();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(chronology27);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 10L, chronology3);
//        int int5 = dateTime4.getDayOfWeek();
//        org.joda.time.DateTime.Property property6 = dateTime4.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime4.toMutableDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-1L), dateTimeZone8);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31", "PST", (int) (short) 10, (int) (byte) 100);
//        long long17 = dateTimeZone8.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, 10L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        java.lang.String str19 = fixedDateTimeZone15.getID();
//        java.lang.String str21 = fixedDateTimeZone15.getNameKey((long) (short) 100);
//        boolean boolean23 = fixedDateTimeZone15.isStandardOffset((long) 5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1969-12-31" + "'", str19.equals("1969-12-31"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) -1, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitYear((int) (short) 10, true);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneName(strMap8);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendYearOfCentury(10, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendFractionOfHour((int) 'a', (int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder15.appendDayOfYear(69);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendMonthOfYearText();
//        boolean boolean23 = dateTimeFormatterBuilder22.canBuildFormatter();
//        org.joda.time.format.DateTimePrinter dateTimePrinter24 = dateTimeFormatterBuilder22.toPrinter();
//        org.joda.time.format.DateTimePrinter dateTimePrinter25 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str28 = dateTimeFormatter26.print(10L);
//        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter25, dateTimeParser29);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder15.append(dateTimePrinter24, dateTimeParser29);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendMonthOfYearText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendFractionOfHour((int) 'a', (int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder34.appendDayOfYear(69);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder40.appendMonthOfYearText();
//        boolean boolean42 = dateTimeFormatterBuilder41.canBuildFormatter();
//        org.joda.time.format.DateTimePrinter dateTimePrinter43 = dateTimeFormatterBuilder41.toPrinter();
//        org.joda.time.format.DateTimePrinter dateTimePrinter44 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str47 = dateTimeFormatter45.print(10L);
//        org.joda.time.format.DateTimeParser dateTimeParser48 = dateTimeFormatter45.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter44, dateTimeParser48);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder34.append(dateTimePrinter43, dateTimeParser48);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder7.append(dateTimePrinter24, dateTimeParser48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(dateTimePrinter24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970-01-01" + "'", str28.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeParser29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(dateTimePrinter43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1970-01-01" + "'", str47.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(dateTimeParser48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//    }
//}

